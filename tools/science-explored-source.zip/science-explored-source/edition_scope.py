"""Select substantive teaching records for the general science catalogue."""
import re
def include_record(record):
 course=record.get('course','')
 title=record['title']
 if re.search(r'COVID-19 Transmission|Poker Theory|Win at Texas Hold|Battlecode Programming Competition',course,re.I):return False
 return not re.search(r'virulence|application of CRISPR|fundraising|meet the educator|using humor to enhance learning|making time for individual questions|transitioning from a lecturer',title,re.I)
