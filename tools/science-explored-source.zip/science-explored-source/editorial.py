"""Render editorial selections and ordered paths with the original evidence links."""
byid={r['id']:r for r in records}
def refid(i):return i.removeprefix('youtube:').replace(':','-')
def paragraphs(value):return ''.join('<p>'+e(x)+'</p>' for x in str(value or '').split('\n\n') if x)
def sources(items):return listing(a(x['url'],x['title'])+' — '+e(x.get('inspection',x.get('reason',''))) for x in items if x.get('url'))
guides=json.loads((root/'guides.json').read_text());paths=json.loads((root/'paths.json').read_text())
guide_links=[route(guide,q)];path_links=[route(path,'Reading an ocean ridge')]
for g in guides:
 first=byid[refid(g['startingResourceId'])];exercise=g['methodsOrExercise'];url='guides/'+g['slug']+'/'
 b=paragraphs(g['scope'])+'<h2>Start with '+res(first)+'</h2>'+paragraphs(g['startingReason'])+paragraphs(g['body'])+'<h2>'+e(exercise['title'])+'</h2>'+paragraphs(exercise['instructions'])+'<h2>Continue exploring</h2>'+listing(res(byid[refid(x['id'])])+' — '+e(x['reason']) for x in g['resources'])+'<h2>Teaching and evidence</h2>'+sources(g['sources'])+paragraphs(g['limits'])
 page(url,g['title'],b);guide_links.append(route(url,g['title']));indexrow('guide-'+g['slug'],g['title'],'guide',url,description=g['scope'],terms=[g['question']],topics=[slug(t) for t in first['topics']])
for p in paths:
 url='paths/'+p['slug']+'/';lines=[];items=[]
 for i,s in enumerate(p['steps'],1):
  r=byid[refid(s['resourceId'])]
  items.append('<li><label class="progress-check"><input type="checkbox" data-path="'+e(p['slug'])+'" data-step="'+str(i)+'">Step '+str(i)+'</label> · '+res(r)+paragraphs(s['reason'])+paragraphs(s['task'])+'</li>')
  lines.append(f"{i}. [{r['title']}]({r['source']}) — {s['task']}")
 page(url,p['title'],paragraphs(p['audience'])+paragraphs(p['description'])+'<ol>'+''.join(items)+'</ol><p data-progress-summary="'+e(p['slug'])+'"></p>'+route(url+'reading-list.md','Export reading list')+'<h2>Further reading</h2>'+sources(p['sources']))
 (out/url/'reading-list.md').write_text('# '+p['title']+'\n\n'+'\n'.join(lines));path_links.append(route(url,p['title']));indexrow('path-'+p['slug'],p['title'],'path',url,description=p['description'])
page('guides','Topic guides',listing(guide_links));page('paths','Learning paths',listing(path_links))
