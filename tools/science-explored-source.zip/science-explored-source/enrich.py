"""Attach documented lesson metadata, provider positions and inspection receipts."""
import re,json
from pathlib import Path
from collections import defaultdict
def load(p):return json.loads(Path(p).read_text())
rows=load('catalogue.json')
byid={r['id']:r for r in rows}
for f in Path('../mit').glob('*.json'):
 for src in load(f)['results']:
  for c in src['content_files'][:1]:
   r=byid.get(c['youtube_id'])
   if not r or not r['api'].startswith('https://api.learn.mit.edu/'):continue
   if c['content_language']:r['language']=c['content_language']
   r['credit']='MIT OpenCourseWare · '+c['run_title'];r['licence']='https://ocw.mit.edu/terms/'
   if not src['license_cc']:r['description']=''
   m=re.search(r'(?m)^Instructors?:\s*(.+)$',src.get('full_description') or '')
   if m:r['courseInstructors']=m[1].strip()[:240]
receipts={x['id']:x for x in load('inspections.json')}
notes=[x.split('\t') for x in Path('guide-notes.tsv').read_text().splitlines()]
for keys,note in zip(Path('selections.txt').read_text().splitlines(),notes):
 for i,ident in enumerate(keys.split()):
  r=byid[ident];d=receipts[ident];reason=note[1 if i==0 else 3]
  r['inspection']={'status':'checked','checkedAt':d['date'],'note':('Official transcript excerpt' if d.get('transcript') else 'Official lesson description')+' inspected on '+d['date']+'.'}
  r['selection']={'reason':reason,'basis':'editorial-selection'}
  if d.get('transcript'):r['transcript']={'url':d['transcript']}
  if ident in ['iwQ49oG-DO8','TcvY8Nt0ZGA']:r.update(speaker='Wolfgang Ketterle',level='advanced')
  if ident in ['4bwMeTKC0M4','-KUXPcs2Di4','SwW1K7Dibc8']:r['speaker']='Anna Frebel'
for r in rows:
 if r.get('inspection') and not r.get('selection'):r['selection']={'reason':'Selected for the linked teaching material.'}
Path('catalogue.json').write_text(json.dumps(rows,ensure_ascii=False))
