books_by_field={r[0]:r for r in json.loads((root/'books.json').read_text())}
aliases={'Computer Science':'Mathematics','Electrical Engineering':'Physics','Earth Science':'Physics','Climate Science':'Physics','Chemical Engineering':'Chemistry','Materials Science and Engineering':'Physics','Evolution and comparative minds':'Biology','Cells, circuits and brains':'Biology'}
def related(subjects):
 for t in subjects:
  b=books_by_field.get(aliases.get(t,t))
  if b:
   f,n,u,why=b
   return '<aside class="further-reading"><p class="eyebrow">Related reading · OpenStax</p><h2>'+a(u,n)+'</h2><p>'+e(why)+'</p>'+route('shop/#'+slug(f),'Explore this bookshelf')+'</aside>'
 return ''
