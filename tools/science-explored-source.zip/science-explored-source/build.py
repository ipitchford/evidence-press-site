"""Build the static edition from the frozen public catalogue. Python 3 + beautifulsoup4."""
import json,shutil,re,sys
from pathlib import Path
from html import escape
from collections import defaultdict
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'preview'/'science-explored'
out.mkdir(parents=True,exist_ok=True)
for asset in ['assets','fonts']:shutil.copytree(root/asset,out/asset,dirs_exist_ok=True)
base='/science-explored/'
def tpl(n):return (root/'templates'/(n+'.html')).read_text()
shell=tpl('shell')
def e(x):return escape(str(x),quote=True)
def a(url,title):return '<a href="'+e(url)+'">'+e(title)+'</a>'
def route(path,title):return a(base+path,title).replace('<a ', '<a download ',1) if path.endswith('.md') else a(base+path,title)
exec(compile((root/'layout.py').read_text(),'layout.py','exec'))
exec(compile((root/'reading_panels.py').read_text(),'reading_panels.py','exec'))
page_paths=set()
def page(path,title,body,intro=True):
 page_paths.add(path.strip('/'))
 folder=out/path;folder.mkdir(parents=True,exist_ok=True)
 if intro:
  body=wrap(path,title,body)
  kind=path.partition('/')[0]
  if kind=='resources':body+=related(r['topics'])
  if kind=='topics' and '/' in path:body+=related([title])
  if kind=='courses' and '/' in path:body+=related(items[0]['topics'])
 page_shell = shell
 if path.strip('/') == 'shop':
  page_shell = shell.replace('href="https://evidencepress.org/learn/" aria-current="true"', 'href="https://evidencepress.org/learn/"').replace('href="https://evidencepress.org/shop/"', 'href="https://evidencepress.org/shop/" aria-current="true"')
 (folder/'index.html').write_text(page_shell.replace('</head>','<link rel="canonical" href="https://evidencepress.org'+base+e(path.strip('/'))+('/' if path.strip('/') else '')+'"/></head>').replace('@@TITLE@@' ,e(title)+' | Science Explored').replace('@@BODY@@',body))
def listing(links):return '<ul>'+''.join('<li>'+x+'</li>' for x in links)+'</ul>'
def slug(x):return re.sub('[^a-z0-9]+','-',x.lower()).strip('-')
records=json.loads((root/'catalogue.json').read_text());fields=json.loads((root/'fields.json').read_text())
audit={row['id']:row for row in map(json.loads,(root/'access.jsonl').read_text().splitlines())}
courses=defaultdict(list);topics=defaultdict(list);index=[]
def res(r):return route('resources/'+r['id']+'/',r['title'])
def course(r):return route('courses/'+r['slug']+'/',r['course'])
def field(t):return route('topics/'+slug(t)+'/',t)
orders=defaultdict(list)
for ident,pid,pos,name,url in json.loads((root/'order.json').read_text()):orders[ident].append((pid,pos,name,url))
for r in records:
 if orders[r['id']]:
  playlist,pos,name,playlist_url=sorted(orders[r['id']])[0];r.update(playlist=playlist,position=pos,playlistName=name,playlistUrl=playlist_url)
 courses[r['slug']].append(r)
 for t in r['topics']:topics[t].append(r)
def order(r):
 if 'position' in r:return (r.get('playlist',0),r['position'],r['title'])
 m=re.search(r'(?:lecture|recitation|session|lesson|unit)\s*([0-9]+)(?:[.:]([0-9]+))?',r['title'],re.I)
 return (int(m[1]),int(m[2] or 0),r['title']) if m else (99999,0,r['title'])
def indexrow(id,title,kind,url,**kw):
 row=dict(id=id,title=title,kind=kind,url=base+url,description='',terms=[],topicTerms=[],topics=[],provider='',providerId='',courseId='',level=None,language=None,format=None,durationSeconds=None,selectionBasis='institutional-collection',independentPositiveMentions=0,availability='unknown',qualified=False,coreChecked=False,addedAt='2026-11-20',recordingDate=None,sourceUrl=None,canonicalUrl=None,speaker=None)
 row.update(kw);index.append(row)
english_transcripts={x['id'] for x in json.loads((root/'inspections.json').read_text()) if x.get('transcript')}
for cid,items in courses.items():
 items.sort(key=order);r=items[0]
 sequence=[];last=None
 for x in items:
  group=x.get('playlistName','')
  if group!=last:
   if last is not None:sequence.append('</ol>')
   if group:sequence.append('<h2>'+e(group)+'</h2>')
   sequence.append('<ol class="resource-list">');last=group
  sequence.append('<li class="resource-row"><div class="resource-main"><h3>'+res(x)+'</h3><p>'+e((x['description'] or '')[:260])+'</p></div></li>')
 sequence.append('</ol>')
 page('courses/'+cid,r['course'],'<p>'+e(r['provider']+' · '+r['term'])+'</p>'+a(r['courseUrl'],'Original course and syllabus ↗')+''.join(sequence))
 indexrow('course-'+cid,r['course'],'course','courses/'+cid+'/',sourceUrl=r['courseUrl'],topics=sorted(set(slug(t) for x in items for t in x['topics'])))
 for i,r in enumerate(items):
  rid=r['id'];ou=rid=='ou-stripes'
  duration=re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?',r['duration'] or '')
  seconds=sum(int(n or 0)*k for n,k in zip(duration.groups(),[3600,60,1])) if duration else None
  indexrow(rid,r['title'],'video','resources/'+rid+'/',description=r['description'],terms=[r['course'],r.get('courseInstructors',''),*r['topics']],topics=[slug(t) for t in r['topics']],provider=r['provider'],providerId=slug(r['provider']),courseId=cid,durationSeconds=seconds,sourceUrl=r['source'],canonicalUrl=r['source'],format='lecture' if 'lecture' in r['title'].lower() else 'unknown',coreChecked=ou)
  receipt=audit.get(rid,{})
  historic=r.get('historicAccess',{});media=receipt.get('media') if receipt.get('verified') else historic.get('alternativeUrl') if historic.get('status')=='accessible' else None
  checked=bool(media);inspected=r.get('inspection',{}).get('status')=='checked' or ou
  index[-1].update(qualified=checked,availability='accessible' if checked else 'unknown',coreChecked=inspected,selectionBasis=r.get('selection',{}).get('basis','institutional-collection'),language=r.get('language') or ('English transcript' if rid in english_transcripts else None),speaker=r.get('speaker'),level=r.get('level') or r.get('courseLevel'),durationSeconds=r.get('durationSeconds') or seconds)
  evidence='<p>'+e(r['selection']['reason'])+'</p>' if r.get('selection') and r['selection'].get('reason') else ''
  if inspected and not ou:evidence+= '<p>'+e(r['inspection'].get('note',''))+'</p>'
  if media:evidence+='<p>'+a(media,'Official media file')+' · MP4 prefix verified '+e((receipt.get('date') if receipt.get('verified') else historic.get('checkedAt',''))[:10])+'.</p>'
  if receipt and not receipt.get('verified'):evidence+='<p>Direct MP4 access was unconfirmed on '+e(receipt['date'][:10])+'. The original teaching page is available above.</p>'
  if r.get('courseLevel'):evidence+='<p>Provider-stated course level · '+e(r['courseLevel'])+'</p>'
  if r.get('credit'):evidence+='<p>'+e(r['credit'])+' · '+a(r['licence'],'Provider terms')+'</p>'
  if r.get('courseInstructors'):evidence+='<p>Course instructors · '+e(r['courseInstructors'])+'</p>'
  if r.get('playlistUrl'):evidence+='<p>'+a(r['playlistUrl'],r['playlistName'])+' · item '+str(r['position']+1)+'</p>'
  if r.get('speaker'):evidence+='<p>Speaker · '+e(r['speaker'])+'</p>'
  if r.get('transcript') and r['transcript'].get('url'):evidence+='<p>'+a(r['transcript']['url'],'Provider transcript or captions')+'</p>'
  if r.get('attribution'):evidence+='<p>'+e(r['attribution'])+'</p>'
  player='' if ou or len(rid)!=11 else '<div data-player class="player-shell"><button data-load-player class="primary">Load YouTube player</button></div><script type="application/json" id="player-data">'+json.dumps(dict(id=rid,title=r['title'],embedUrl='https://www.youtube-nocookie.com/embed/'+rid)).replace('<','\\u003c')+'</script>'
  if media:
   player='<div data-player class="player-shell"><div class="player-placeholder"><span class="play-symbol" aria-hidden="true">▷</span><p>Loads media from the original provider.</p><button data-load-alternative class="primary">Load institutional video</button></div></div><script id="player-data" type="application/json">'+json.dumps(dict(id=rid,title=r['title'],alternativeUrl=media)).replace('<','\\u003c')+'</script>'
  controls='<div class="resource-actions" data-resource="'+e(rid)+'"><button data-toggle="watchLater">Watch later</button><button data-toggle="liked">Favourite</button><button data-toggle="watched">Watched</button><button data-add-playlist>Add to playlist</button></div>'
  page('resources/'+rid,r['title'],'<p class="eyebrow">'+e(r['provider'])+'</p><p>'+e(r['description'])+'</p>'+player+evidence+'<p>'+a(r['source'],'Watch at source ↗')+'</p>'+controls+'<p>From '+course(r)+'</p><p>'+(' · '.join(field(t) for t in r['topics']))+'</p><p>'+('The university describes the clip and provides a download. Automated media access encountered a browser challenge.' if ou else 'A successful media check records access to the start of a file. Full playback was not tested.' if checked else 'Selected from the provider catalogue. Playback has not been verified.')+'</p>'+a(r['api'],'Inspect provider metadata')+'<nav>'+('Previous · '+res(items[i-1]) if i else '')+' '+('Next · '+res(items[i+1]) if i+1<len(items) else '')+'</nav>')
guide='guides/how-do-we-know-the-seafloor-spreads/'
path='paths/reading-an-ocean-ridge/'
q='How do we know the seafloor spreads?'
ou=next(r for r in records if r['id']=='ou-stripes')
prev=ou['courseUrl']+'&section=_unit1.10'
body='<p>Start with '+res(ou)+', a silent Open University animation. Follow one band of rock from the ridge to the edge of the screen. Its magnetic direction stays fixed as its distance from the ridge grows.</p><h2>Predict the other half</h2><p>Draw a ridge down the middle of a sheet. Give the magnetic field three successive intervals of unequal length. Add new crust to both sides at a constant rate. Cover one side and use the other to predict the order and widths of its bands. Which prediction would survive a change in the spreading rate on one side?</p><h2>From a pattern to a test</h2><p>The animation starts with spreading as an assumption. Work backwards from the observations in '+a(prev,'the preceding geology lesson')+'. Identify one measurement that could distinguish a reversal in magnetisation from a change in the kind of rock beneath the ship.</p><h2>A decision in 1963</h2><p>Vine and Matthews could reproduce the broad shape of magnetic anomalies over a ridge. One local fit was poor. Would another survey along the same track tell you as much as an independently dated rock sample? Ian Pitchford’s <em>A Connected History of Science and Technology</em> asks which test a geologist should fund next. In Historical judgement, find “Would you fund the next seafloor test?”</p>'+route(path,'Follow the ocean-ridge learning path')
body='<h2>Start with '+res(next(r for r in records if r['id']=='ucsb-sfs5'))+'</h2><p>In Tanya Atwater’s animation, use the reversal scale to identify the most recently formed crust. Pause after the next colour change. Trace both edges of the new band away from the ridge, then follow its offset across a transform fault.</p><h2>Compare a second model</h2>'+body.replace('Start with ','Open ')
body+='<p>'+a('https://sos.noaa.gov/catalog/datasets/plate-movement-200-million-years-ago-to-today/','See NOAA’s reconstruction of plate movement')+'. Compare the age pattern in the ocean basins with the crust forming at a single ridge.</p>'
page(guide,q,body)
indexrow('guide-seafloor',q,'guide',guide,topics=['earth-science'],terms=['sea floor spreading','seafloor spreads','magnetic reversal stripes'])
indexrow('path-ocean-ridge','Reading an ocean ridge','path',path,description='Read magnetic anomalies as a test of seafloor spreading.',topics=['earth-science'])
steps=[('Read the observations',prev,'Sketch the magnetic pattern before proposing a mechanism.'),('Watch the ridge grow',next(r for r in records if r['id']=='ucsb-sfs5')['historicAccess']['alternativeUrl'],'Track the position and magnetic direction of one band.'),('Choose a test',base+guide,'Explain which independent measurement could discriminate between two explanations.')]
page(path,'Reading an ocean ridge','<p>For learners meeting plate tectonics for the first time. Use a magnetic profile to make a prediction and design an independent check.</p><ol>'+''.join('<li><h3>'+a(u,n)+'</h3><p>'+t+'</p><label class="progress-check"><input type="checkbox" data-path="ocean-ridge" data-step="'+str(i)+'"> I have completed this step</label></li>' for i,(n,u,t) in enumerate(steps))+'</ol><p data-progress-summary="ocean-ridge"></p>'+route(path+'reading-list.md','Export the reading list'))
(out/path/'reading-list.md').write_text('# Reading an ocean ridge\n\n'+'\n'.join(f'{i}. [{n}]({u if u.startswith("https") else "https://evidencepress.org"+u}) — {t}' for i,(n,u,t) in enumerate(steps,1)))
directory='<div class="topic-map">'+''.join('<a href="'+base+'topics/'+slug(t)+'/"><span class="map-number">'+str(i).zfill(2)+'</span><span><strong>'+e(t)+'</strong><small>'+e(fields[t])+'</small></span><span aria-hidden="true">↗</span></a>' for i,t in enumerate(sorted(topics),1))+'</div>' 
for t,rows in topics.items():page('topics/'+slug(t),t,'<p>'+e(fields[t])+'</p>'+(route(guide,q) if t=='Earth Science' else '')+listing(course(r) for r in {r['slug']:r for r in rows}.values()))
page('courses','Courses and collections',listing(course(v[0]) for v in sorted(courses.values(),key=lambda v:v[0]['course'].casefold())))
page('topics','Explore fields',directory);page('guides','Topic guides',route(guide,q));page('paths','Learning paths',route(path,'Reading an ocean ridge'))
exec(compile((root/'editorial.py').read_text(),'editorial.py','exec'))
exec(compile((root/'science_editorial.py').read_text(),'science_editorial.py','exec'))
exec(compile((root/'field_pages.py').read_text(),'field_pages.py','exec'))
page('','Science Explored',tpl('hero')+'<section class="split-section"><div><p class="eyebrow">History of science and technology</p><h2>'+route('history/','Explore the historical atlas')+'</h2></div><p>Trace evidence from early tools and farming to planetary observations, medical comparisons and computing. Browse twelve periods, follow a question across centuries or weigh a decision with the evidence available at the time.</p></section><div class="collection-strip">'+f'<span><strong>{len(records):,}</strong> catalogue videos</span><span><strong>{len(guide_links)}</strong> topic guides</span><span><strong>{len(path_links)}</strong> learning paths</span>'+'</div><section class="wide-section"><h2>Explore a field</h2>'+directory+'</section><section class="split-section"><h2>Featured topic guide</h2>'+listing([guide_links[i] for i in (0,19,26,33,43)])+route('guides/','All topic guides')+'</section><section class="split-section tint"><h2>Learning paths</h2>'+listing([path_links[i] for i in (0,8,13)])+route('paths/','All learning paths')+'</section><aside class="further-reading"><h2>Related reading</h2>'+route('shop/','A Connected History of Science and Technology')+'</aside>',False)
exec(compile((root/'history.py').read_text(),'history.py','exec'))
s=BeautifulSoup(tpl('search'),'html.parser')
hist=s.new_tag('option',value='history');hist.string='Historical atlas';s.select_one('select[name=type]').append(hist)
for name,opts in [('topic',[(slug(t),t) for t in sorted(topics)]),('provider',[(slug(t),t) for t in sorted({r['provider'] for r in records})])]:
 sel=s.select_one(f'select[name={name}]')
 for opt in sel.select('option')[1:]:opt.decompose()
 for v,t in opts:opt=s.new_tag('option',value=v);opt.string=t;sel.append(opt)
for option in s.select('select[name=language] option')[1:]:option.decompose()
for level in sorted({r['courseLevel'] for r in records if r.get('courseLevel')}):
 opt=s.new_tag('option',value=level);opt.string=level+' course';s.select_one('select[name=level]').append(opt)
for lang in sorted({r.get('language') or 'unknown' for r in index if r['kind']=='video'}):
 opt=s.new_tag('option',value=lang);opt.string=lang;s.select_one('select[name=language]').append(opt)
page('search','Search',str(s),False)
for name in ['library','corrections']:page(name,name.capitalize(),tpl(name),False)
exec(compile((root/'bookshop.py').read_text(),'bookshop.py','exec'))
page('privacy','Privacy and provider terms','<p>Your library and theme are stored in this browser. Loading an external player shares connection information with its provider. You can use the original course link instead.</p>')
registry=json.loads((root/'source-links.json').read_text())
page('sources','Sources and attribution',listing(a(registry.get(k,{}).get('url',v['courseUrl']),k) for k,v in sorted({r['provider']:r for r in records}.items()))+listing([a('https://ocw.mit.edu/terms/','MIT OpenCourseWare terms'),a(ou['source'],'Open University geology course')])+'<p>Selected annotations and teaching sequences are adapted from the Evidence Press Minds Explored catalogue. Inspection dates and source links accompany the selections.</p><p>MIT descriptions and titles are supplied by MIT OpenCourseWare through MIT Learn. Teaching materials retain their original credits and licences.</p>')
page('about','About and coverage',route('data/access.json','Download dated access checks (JSON)')+f'<p>{len(records):,} video entries in {len(topics)} fields from {len(set(r["provider"] for r in records))} teaching providers. The catalogue includes {len(guide_links)} topic guides and {len(path_links)} learning paths.</p><p>{sum(r["qualified"] for r in index):,} entries have dated media-access evidence. {sum(r["coreChecked"] for r in index):,} carry individual source-inspection annotations. A media byte-range check establishes access to part of a video file. A source annotation records the teaching material inspected.</p>')
page('educators','For educators','<p>Export the reading list on a learning path or assemble a playlist in My library.</p>')
(out/'data').mkdir(exist_ok=True);(out/'data/index.json').write_text(json.dumps({'records':index},separators=(',',':')))
(out/'favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#422d40"/><text x="5" y="45" font-size="38" fill="#fff9eb">s·e</text></svg>')
print(len(records),len(courses),len(topics))

(out/'sitemap.xml').write_text('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>https://evidencepress.org'+base+e(u)+('/' if u else '')+'</loc></url>' for u in sorted(page_paths))+'</urlset>')

public_access=[]
for entry in records:
 receipt=audit.get(entry['id'])
 historic=entry.get('historicAccess',{})
 public_access.append(dict(id=entry['id'],source=entry['source'],checks=[x for x in [receipt,historic or None] if x]))
(out/'data/access.json').write_text(json.dumps(public_access,separators=(',',':')))
