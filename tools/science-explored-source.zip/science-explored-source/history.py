"""Historical teaching routes, grouped by the book's period and thematic structure."""
def tab(name):
 return [line.split('\t') for line in (root/name).read_text().splitlines() if line]
sources={k:(publisher,title,url) for k,publisher,title,url in tab('historical-sources.tsv')}
periods=tab('periods.tsv');trails=tab('history-trails.tsv');decisions=tab('decisions.tsv')
video={x['id']:x for x in records}
aliases=json.loads((root/'history-aliases.json').read_text())
extras=tab('more-cases.tsv')
def teaching(key):
 key=aliases.get(key,key)
 if key in video:return res(video[key])+' · '+e(video[key]['provider'])
 publisher,title,url=sources[key];return a(url,title)+' · '+e(publisher)
def part(i):return 'history/period-'+str(i)+'/'
def trail(i):return 'history/trail-'+str(i)+'/'
def related_periods(ids):return ' · '.join(route(part(int(i)),periods[int(i)-1][0]) for i in ids.split(','))
book_path='books/a-connected-history-of-science-and-technology/'
def history_page(url,title,lead,body,terms):
 nav='<p>'+route('history/','Historical atlas')+' · '+route(book_path,'About the book')+'</p>'
 page(url,title,'<div class="page-intro"><p class="eyebrow">Historical atlas</p><h1>'+e(title)+'</h1><p class="standfirst">'+e(lead)+'</p></div><div class="reading-layout"><article class="prose">'+body+'</article><aside class="side-note">'+nav+'</aside></div>',False)
 indexrow('history-'+slug(url),title,'history',url,description=lead,terms=terms)
for i,row in enumerate(periods,1):
 era,chapter,title,lead,*rest=row;body='<p>In the book’s Contents, open “'+e(era)+' · '+e(chapter)+'”.</p>';keywords=[era]
 for case in rest[:-1]+['|'.join(x[1:]) for x in extras if int(x[0])==i]:
  heading,detail,key=case.split('|');keywords.extend([heading,detail]);body+='<h2>'+e(heading)+'</h2><p>'+e(detail)+'</p><p>'+teaching(key)+'</p>'
 body+='<h2>Try the comparison</h2><p>'+e(rest[-1])+'</p><h2>Follow a connection</h2>'+listing(route(trail(j),t[0]) for j,t in enumerate(trails,1) if str(i) in t[4].split(','))
 body+='<h2>Decide with the evidence then available</h2>'+listing(route('history/decisions/#case-'+str(j),d[0]) for j,d in enumerate(decisions,1) if int(d[2])==i)
 if i<len(periods):body+='<p>'+route(part(i+1),'Next period · '+periods[i][0])+'</p>'
 history_page(part(i),title,lead,body,keywords)
for j,(name,question,exercise,key,ids,book_section) in enumerate(trails,1):
 body='<p>In the Kindle edition, open Thematic trails and find “'+e(book_section)+'”.</p><h2>Investigate the connection</h2><p>'+e(exercise)+'</p><h2>Teaching to work with</h2><p>'+teaching(key)+'</p><h2>Follow the periods</h2><p>'+related_periods(ids)+'</p>'
 history_page(trail(j),name,question,body,[name,exercise,book_section])
body=''
for j,(case,date,i,key,task,book_section) in enumerate(decisions,1):
 body+='<section id="case-'+str(j)+'"><p class="eyebrow">'+e(date)+'</p><h2>'+e(book_section)+'</h2><p>'+e(task)+'</p><p>'+teaching(key)+'</p><p>'+related_periods(i)+'</p></section>'
history_page('history/decisions/','Making a decision in its own time','Choose a case. Write the decision you would make with the evidence available at the stated date, then identify the observation most likely to change it. Modern teaching supplies methods for checking your reasoning. In the Kindle edition, open Historical judgement. The headings below match the book’s contents.',body,[term for d in decisions for term in (d[0],d[5])])
intro='Explore the history of science and technology from the earliest surviving tools to November 2026. Each period pairs historical questions with museum objects, university teaching or observational records.'
history_page('history/','A connected history of science and technology',intro,'<h2>Explore by period</h2><ol>'+''.join('<li>'+route(part(i),r[0]+' · '+r[2])+' <small>'+e(r[1])+'</small></li>' for i,r in enumerate(periods,1))+'</ol><h2>Follow a question across periods</h2>'+listing(route(trail(i),r[0]) for i,r in enumerate(trails,1))+'<h2>Weigh the evidence</h2>'+route('history/decisions/','Explore 27 historical decisions'),['history','archaeology','ancient','medieval','technology','historical judgement'])
