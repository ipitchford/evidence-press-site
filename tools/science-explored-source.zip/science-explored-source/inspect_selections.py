import concurrent.futures as cf,json,urllib.request,re,hashlib
from bs4 import BeautifulSoup
from pathlib import Path
records={r['id']:r for r in json.load(open('catalogue.json'))}
def check(id):
 r=records[id];url=r['source']
 with urllib.request.urlopen(url,timeout=25) as f:raw=f.read()
 s=BeautifulSoup(raw,'html.parser');main=s.select_one('#course-content-section') or s.select_one('main') or s
 text=' '.join(main.stripped_strings)
 pos=text.find('Description:');original=text[pos+12:] if pos>=0 else ''
 description=re.split('Instructor:|Instructors:|Transcript|Your browser|Download video',original,1)[0].strip()
 return dict(id=id,url=url,title=r['title'],date='2026-11-20',sha256=hashlib.sha256(raw).hexdigest(),summary=description[:1000] or r['description'],method='Official lesson page and MIT Learn catalogue description')
ids=list(dict.fromkeys(Path('selections.txt').read_text().split()))
with cf.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(check,ids))
Path('inspections.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(r['id'],r['summary'][:300])
