"""Reuse source-inspected science teaching and its original dated evidence."""
import json,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent
ref=Path(sys.argv[1])
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False))
base=load(root/'catalogue.json');lookup={r['id']:r for r in base};fields=load(root/'fields.json')
families={f['id']:f for f in load(ref/'data/taxonomy.json')['families']}
chosen={'methods','computation-ai','neuroscience','evolution-comparative','perception-action'}
guides=[g for p in (ref/'content/guides').glob('*.json') if (g:=load(p))['topics'][0] in chosen and g['status']=='reviewed']
paths=[g for p in (ref/'content/paths').glob('*.json') if (g:=load(p))['topics'][0] in chosen and g['status']=='reviewed']
required={r['id'] for g in guides for r in g['resources']}|{g['startingResourceId'] for g in guides}|{s['resourceId'] for p in paths for s in p['steps']}
sources={s['id']:s for s in load(ref/'data/sources.json')}
courses={c['id']:c for c in load(ref/'data/courses.json')}
def rid(i):return i.removeprefix('youtube:').replace(':','-')
for line in (ref/'data/catalogue.jsonl').open():
 r=json.loads(line);c=courses.get(r['courseId'],{});i=rid(r['id']);s=sources[r['providerId']]
 if r['withdrawn'] or r['qualification']['status']=='excluded' or not r['reuse']['exportAllowed'] or s['status']!='verified':continue
 if r['providerId'] not in {'3blue1brown','cambridge','complexity-explorer','statquest','boston-university','bristol','gresham-college','stanford-culture-emotion'} and r['id'] not in required and not (r['descriptionCheck']['status']=='checked'):continue
 if 'security' in (r['title']+' '+c.get('title','')).lower():continue
 topics=[families[t]['label'] for t in r['topics'] if t in families]
 for t in r['topics']:
  if t in families:fields[families[t]['label']]=families[t]['question']
 if not topics:topics=['Mathematics'] if r['id'] in required and 'statistic' in c.get('title','').lower() else ['Learning science'];fields.setdefault('Learning science','How can learning be measured?')
 if i not in lookup:
  row=dict(id=i,title=r['title'],course=c.get('title',s['name']+' · selected teaching'),slug=c.get('id','collection-'+s['id']),source=r['sourceUrl'],provider=s['name'],topics=topics,description=r['description'],term=c.get('term') or '',duration=None,api=r['sourceUrl'],courseUrl=c.get('sourceUrl',s['url']))
  base.append(row);lookup[i]=row
 row=lookup[i];row.update(speaker=r.get('speaker'),level=r.get('level'),language=r.get('language'),transcript=r.get('transcript'),durationSeconds=r.get('durationSeconds'),inspection=r['descriptionCheck'],selection=r['selection'],provenance=r['provenance'],historicAccess=r['availability'],attribution=r['reuse']['attribution'])
 if r['id'] in c.get('memberIds',[]):row['position']=c['memberIds'].index(r['id'])
save(root/'catalogue.json',base);save(root/'fields.json',fields)
save(root/'guides.json',[g for g in guides if all(rid(i) in lookup for i in [g['startingResourceId']]+[r['id'] for r in g['resources']])])
save(root/'paths.json',[p for p in paths if all(rid(s['resourceId']) in lookup for s in p['steps'])])
