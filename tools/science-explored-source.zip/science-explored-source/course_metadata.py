"""Collect only provider-stated course language, level and their source receipts."""
import json,urllib.request,re,concurrent.futures as cf,hashlib
from pathlib import Path
from bs4 import BeautifulSoup
rows=json.loads(Path('catalogue.json').read_text())
courses={r['slug']:r['courseUrl'] for r in rows if r['courseUrl'].startswith('https://ocw.mit.edu/courses/')}
def inspect(item):
 key,url=item;out={'course':key,'source':url,'date':'2026-11-20'}
 try:
  data=urllib.request.urlopen(url,timeout=15).read();s=BeautifulSoup(data,'html.parser');out['sha256']=hashlib.sha256(data).hexdigest()
  out['levels']=sorted({a.get_text(strip=True) for a in s.select('a[href]') if a.get_text(strip=True) in ['Undergraduate','Graduate'] and 'search' in a['href']})
  for script in s.select('script[type="application/ld+json"]'):
   try:j=json.loads(script.get_text())
   except ValueError:continue
   if isinstance(j,dict) and j.get('@type')=='Course':out['language']=j.get('inLanguage')
 except Exception as exc:out['error']=str(exc)
 return out
with cf.ThreadPoolExecutor(max_workers=4) as pool:meta=list(pool.map(inspect,courses.items()))
Path('course-evidence.json').write_text(json.dumps(meta))
lookup={r['course']:r for r in meta}
for r in rows:
 m=lookup.get(r['slug'],{})
 if m.get('language')=='en':r['courseLanguage']='English'
 if m.get('levels'):r['courseLevel']=' / '.join(m['levels'])
Path('catalogue.json').write_text(json.dumps(rows,ensure_ascii=False))
print(sum('courseLevel' in r for r in rows),sum('courseLanguage' in r for r in rows))
