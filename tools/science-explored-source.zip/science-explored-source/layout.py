"""Place edition content in the reference layout with a linked reading sidebar."""
def wrap(path,title,body):
 path=path.strip('/');kind=path.split('/')[0];labels={'resources':'Lecture or video','topics':'Explore a field','guides':'Topic guide','paths':'Learning path','courses':'Course or collection'}
 label=labels.get(kind,'Science Explored');side=route('shop/','Browse related books');summary=''
 if '/' in path:
  if kind=='resources':
   selected=r
   summary=selected['description'] or selected['course']
   if len(summary)>320:summary=summary[:317].rsplit(' ',1)[0]+'…'
   side='<h2>In this collection</h2>'+course(selected)+'<p>'+e(selected['provider'])+'</p>'+listing(field(t) for t in selected['topics'])
   side+='<h3>Viewing details</h3><p>'+e(' · '.join(str(z) for z in [selected.get('level'),selected.get('language'),(str(round(index[-1]['durationSeconds']/60))+' min') if index[-1].get('durationSeconds') else None] if z) or 'Duration, level and language unrecorded')+'</p>'
   body=body.replace('<p>'+e(selected['description'])+'</p>','',1)
   if 'data-player' not in body:
    provider_link='<a class="button" href="'+e(selected['source'])+'">Open the teaching page ↗</a>'
    body='<div class="player-shell"><div class="player-placeholder"><span aria-hidden="true" class="play-symbol">▷</span><p>Watch with the original provider</p>'+provider_link+'</div></div>'+body
  elif kind=='topics':
   summary=fields.get(title,'');title,summary=summary or title,title;side='<h2>Continue exploring</h2>'+route('guides/','Browse the question guides')+'<p>'+route('paths/','Follow a learning path')+'</p>'
  elif kind in ('guides','paths'):
   if kind=='paths' and body.startswith('<p>'):
    first,body=body.split('</p>',1);summary=first[3:]
   if path=='guides/how-do-we-know-the-seafloor-spreads':summary='Use the magnetic stripes on either side of an ocean ridge to predict where crust formed. Then decide what evidence a geologist could have asked for in 1963.'
   side='<h2>Use this '+('guide' if kind=='guides' else 'path')+'</h2>'+route('library/','Open My library')+'<p>'+route('guides/','Explore other questions')+'</p>'+route('shop/','Find related reading')
  elif kind=='courses':
   summary=items[0]['provider']+' · '+str(len(items))+' catalogue '+('entry' if len(items)==1 else 'entries')
 intro='<div class="page-intro"><p class="eyebrow">'+e(label)+'</p><h1>'+e(title)+'</h1>'+('<p class="standfirst">'+e(summary)+'</p>' if summary else '')+'</div>'
 if '<div class="reading-layout">' in body:return intro+body.replace('<article>','<article class="prose">').replace('<aside>','<aside class="side-note">')
 if '/' in path and kind in ['resources','topics','guides','paths']:
  return intro+'<div class="reading-layout"><article class="prose">'+body+'</article><aside class="side-note">'+side+'</aside></div>'
 return intro+'<section class="wide-section">'+body+'</section>'
