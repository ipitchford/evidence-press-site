import json,hashlib,urllib.request,datetime
from pathlib import Path
p=Path('catalogue.json');records=[r for r in json.loads(p.read_text()) if not r['id'].startswith('ucsb-sfs')]
course='https://animations.geol.ucsb.edu/2_infopgs/IP1GTect/fSFSpreadingSeries.html'
for i,(file,title,note) in enumerate([('SFS4_PolRevExplan','Magnetic polarity reversal explanation','Read the reversal timescale from youngest to oldest before applying it to the crust.'),('SFS5_MagStripes+RevScale','Seafloor spreading with magnetic stripes and reversal scale','Track one strip of crust against the polarity timescale. The model adds crust at three ridge segments linked by transform faults.'),('SFS6_MagStripes','Seafloor spreading with magnetic stripes','Compare the stripe sequence across the ridge. Then follow one stripe towards an offset in the ridge axis.')],4):
 url='https://animations.geol.ucsb.edu/3_downloads/M1GTect/fSFSMovies/'+file+'.mp4'
 with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=0-1023'}),timeout=45) as f:
  data=f.read(1024);assert data[4:8]==b'ftyp';status=f.status
 records.append(dict(id='ucsb-sfs'+str(i),title=title,course='Seafloor Spreading and Marine Magnetic Anomalies',slug='ucsb-seafloor-spreading',source=course,provider='University of California, Santa Barbara',topics=['Earth Science'],description=note,term='',duration=None,api=course,courseUrl=course,position=i-1,speaker=None,inspection={'status':'checked','note':'The university’s series notes identify the animation, its conventions and its place in the sequence.'},selection={'basis':'editorial-selection','reason':note},historicAccess={'status':'accessible','checkedAt':'2026-11-20','alternativeUrl':url,'method':'official-media-range','sha256':hashlib.sha256(data).hexdigest(),'statusCode':status},attribution='Animation by Tanya Atwater, University of California, Santa Barbara.'))
p.write_text(json.dumps(records,ensure_ascii=False))
