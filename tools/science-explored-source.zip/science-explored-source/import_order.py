import json,urllib.request
from pathlib import Path
url='https://api.learn.mit.edu/api/v1/learning_resources/?resource_type=video_playlist&limit=50'
rows=[]
while url:
 with urllib.request.urlopen(url,timeout=60) as f:data=json.load(f)
 for p in data['results']:
  for c in p['children']:
   if c.get('relation_type')=='PLAYLIST_VIDEOS':rows.append([c['readable_id'],p['id'],c['position'],p['title'],p['learn_url']])
 url=data['next']
Path('order.json').write_text(json.dumps(rows,ensure_ascii=False))
print(len(rows))
