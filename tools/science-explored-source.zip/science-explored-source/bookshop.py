books = json.loads((root / 'books.json').read_text())
bookname = 'A Connected History of Science and Technology'
bookroute = 'books/a-connected-history-of-science-and-technology/'
kindle_url = 'https://www.amazon.com/dp/B0HSP1VJQ8?tag=aphonicdrift-20'
kindle = '<a class="button primary" rel="sponsored noopener" href="' + kindle_url + '">Kindle edition on Amazon</a>'
disclosure = '<p class="meta">Ad · As an Amazon Associate, Evidence Press earns from qualifying purchases.</p>'
cover = '<img class="connected-history-cover" src="' + base + 'assets/connected-history-cover.jpg" alt="Front cover of A Connected History of Science and Technology" width="1825" height="2560" loading="lazy" decoding="async">'
subtitle = '<p class="standfirst">How Discoveries Became Possible and Changed the World</p>'
historical = [
    ('Would you fund the next seafloor test?', 'Vine and Matthews had a mechanism for magnetic stripes and an imperfect fit at one ridge. Decide which new measurement would be worth paying for.', guide),
    ('An interferometer constrains the ether wind', 'Michelson and Morley compared a predicted shift of 0.4 fringe with an observed bound below 0.02. Read the figure as a bound on a proposed effect.', 'guides/' + slug(notes[14][0]) + '/')
]
panel = ('<section class="shop-own connected-history-book">' + cover + '<div><p class="eyebrow">Edited by Ian Pitchford · Evidence Press</p><h2>' +
         bookname + '</h2>' + subtitle + kindle + disclosure + route(bookroute, 'About the book and selected readings') + '</div></section>')
page(bookroute, bookname, '<div class="connected-history-book">' + cover + '<div>' + subtitle + '<p>Edited by Ian Pitchford · Evidence Press</p>' +
     kindle + disclosure + '</div></div><p>How do investigators decide what to measure next? Explore twelve periods, then try a historical decision alongside an open lecture.</p>' +
     route('history/', 'Explore the historical atlas') + '<h2>Read alongside the atlas</h2><p>In the Kindle edition, find these section headings in Contents or search for the title.</p>' +
     ''.join('<h3>' + e(title) + '</h3><p>' + e(detail) + '</p>' + route(url, 'Explore the teaching') for title, detail, url in historical))
own = panel
shelves=''.join('<section class="shop-shelf" id="'+slug(f)+'"><h2>'+e(f)+'</h2><ul class="book-list"><li><span class="book-title">'+a(u,n)+'</span> <span class="meta">OpenStax</span><br>'+e(why)+'</li></ul></section>' for f,n,u,why in books)
page('shop','Science bookshop','<div class="page-intro"><p class="eyebrow">Related reading</p><h1>The science bookshop.</h1><p class="standfirst">Read alongside a lecture or follow a historical question back to its evidence.</p></div>'+own+shelves,False)
