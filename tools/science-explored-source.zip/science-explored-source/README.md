# Science Explored

Science Explored is the science and technology edition of the Evidence Press learning atlas. Its static pages use the Minds Explored masthead, stylesheet, fonts, search, theme controls and personal-library implementation. Science Explored keeps its own browser storage key.

## Build and preview

Use Python 3.11 or later. Run these commands from this directory. Choose an empty output directory for a release build.

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 build.py ../preview/science-explored
python3 verify.py ../preview/science-explored
python3 -m http.server 4187 --bind 127.0.0.1 --directory ../preview
```

Open http://127.0.0.1:4187/science-explored/. Copy the complete science-explored directory to the website's corresponding path when the publisher approves release. The files can be served by any static web server with directory-index support and a JavaScript MIME type for .mjs. The deployable ZIP contains the built directory. The build uses the frozen local evidence and requires no network access after dependencies are installed.

## Editorial and catalogue inputs

The frozen catalogue carries original course links, catalogue metadata and the evidence available for each individual selection. MIT Learn supplies institutional video identities and playlist positions. MIT OpenCourseWare supplies course levels, descriptions and media links. Multiple playlists in one course retain their own ordering. Where a provider sequence was unavailable, the catalogue uses explicit lesson numbers and then titles. A course or collection may contain a selection of its published teaching.

The collection also includes the Open University geology lesson, the UC Santa Barbara magnetic-stripe animations, and relevant teaching and individually documented selections from the Evidence Press Minds Explored source package. The latter package had SHA-256 c5d3af992de2a732317ec878d9c72739e377a369ce37485f4501232462fea508. Each reused inspection retains its original scope and date. Source-specific material stays under the provider’s terms. The code and original editorial content have separate licence files. The fonts include their own licences.

The 31 paired selections in selections.txt correspond in order to guide-notes.tsv and interpretation.txt. Science learning paths refer to those guide positions. editorial.py renders the retained specialist selections, and science_editorial.py renders the paired teaching guides. The seafloor guide and path are defined together in build.py. Reading notes identify entries by the section titles in the Kindle edition.

## Evidence maintenance

The complete frozen inputs are sufficient for a reproducible build. For a new catalogue snapshot, use a fresh workspace and preserve the previous receipts. The import scripts collect MIT video records and playlist positions. prepare.py selects the edition records, import_reference.py incorporates the reference source directory, and the inspection and enrichment scripts populate the evidence. Supply the complete Minds Explored source as the argument to import_reference.py. Use the lowercase filenames shown in this directory. Run the individual build checks after editorial changes.

Media audit rows record the source teaching page, media response, check method and date. The bounded MP4 check reads at most the first 1,024 bytes of each media response. Browser playback tests are reported separately. A course page alone is insufficient to qualify a video as access-checked. Where an Open University access challenge occurs, readers can use the UCSB animation and NOAA reconstruction linked from the guide.

The site sends no personal library data to a server. Loading a player contacts its provider. The deployment directory contains the public atlas and its evidence index. The book manuscript and source media are excluded.

## Historical atlas

The history directory contains twelve period studies, nineteen cross-period trails and twenty-seven historical decisions. Edit periods.tsv and more-cases.tsv for the case studies, history-trails.tsv for the connections and decisions.tsv for the exercises. Historical-sources.tsv contains teaching and object records, and history-aliases.json resolves added Yale lectures against the catalogue. The historical routes use chapter and section titles from the Kindle edition so readers can find the passages at any text size.
