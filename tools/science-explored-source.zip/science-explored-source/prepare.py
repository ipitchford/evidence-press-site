"""Read the locally cached MIT Learn pages and select course-linked science videos."""
from edition_scope import include_record
import json,re,sys
from pathlib import Path
from html import unescape
from collections import Counter
from urllib.parse import urlparse
fields={'Physics':'What changes when a system oscillates?', 'Earth Science':'How do we know the seafloor spreads?', 'Climate Science':'What sets the temperature of a planet?', 'Mathematics':'What can a change of basis simplify?', 'Computer Science':'How much work does an algorithm require?', 'Biology':'How does a cell use energy?', 'Chemistry':'What holds a molecule together?', 'Mechanical Engineering':'How does a structure carry a load?', 'Electrical Engineering':'What happens when a signal crosses a circuit?', 'Materials Science and Engineering':'How does crystal structure affect a material?', 'Chemical Engineering':'What sets the rate of a reaction?', 'Civil Engineering':'How do engineers measure structural deformation?', 'Aerospace Engineering':'How does a wing generate lift?', 'Astronomy':'How can light reveal a distant star?', 'Environmental Engineering':'How do contaminants travel through water?', 'Data Science':'How well does a model predict new observations?'}
def clean(s):return ' '.join(unescape(re.sub('<[^>]*>',' ',s or '')).split())
records={}
for f in sorted(Path(sys.argv[1]).glob('*.json')):
 for r in json.loads(f.read_text())['results']:
  for c in r['content_files'][:1]:
   course=c['run_title'] or '';title=r['title'];url=c['url'];vid=c['youtube_id']
   if not re.fullmatch(r'[\w-]{11}',vid or '') or urlparse(url or '').hostname!='ocw.mit.edu':continue
   if re.search(r'security|hacking|exploit|weapon|pathogen|virolog|virus|infectious|genetic engineering|synthetic biology|defen[sc]e|military|ballistic|shooting|explosive',course+' '+title,re.I):continue
   topics=[t['name'] for t in r['topics'] if t['name'] in fields]
   if re.search(r'astrophys|astronomy|stars and|cosmology',course,re.I):topics.insert(0,'Astronomy')
   if not topics:continue
   slug=c['run_slug'].strip('/').split('/')[-1]
   if not re.fullmatch(r'[a-zA-Z0-9._-]+',slug):continue
   records.setdefault(vid,dict(id=vid,title=title,course=course,slug=slug,source=url,provider='MIT OpenCourseWare',topics=topics,description=clean(r['description'])[:1200],term=' '.join(str(x) for x in [c['semester'],c['year']] if x),duration=r['video']['duration'],api='https://api.learn.mit.edu/api/v1/learning_resources/'+str(r['id'])+'/',courseUrl='https://ocw.mit.edu/courses/'+slug+'/'))
ou='https://www.open.edu/openlearn/mod/oucontent/view.php?id=101227'
records['ou-stripes']=dict(id='ou-stripes',title='Magnetic reversal stripes',course='An introduction to geology',slug='ou-introduction-to-geology',source=ou+'&section=_unit1.11',provider='The Open University',topics=['Earth Science'],description='A silent animation shows how new crust at a ridge records successive periods of normal and reversed magnetic polarity.',term='',duration=None,api=ou+'&section=_unit1.11',courseUrl=ou)
Path('catalogue.json').write_text(json.dumps([r for r in records.values() if include_record(r)],ensure_ascii=False))
Path('fields.json').write_text(json.dumps(fields))
