import json,urllib.request,urllib.error,concurrent.futures,hashlib
from pathlib import Path
from bs4 import BeautifulSoup
refs=[l.split('\t') for l in Path('historical-sources.tsv').read_text().splitlines()]
aliases=set(json.loads(Path('history-aliases.json').read_text()).values())
refs.extend((r['id'],r['provider'],r['title'],r['source']) for r in json.loads(Path('catalogue.json').read_text()) if r['id'] in aliases)
def check(ref):
 k,p,t,u=ref
 try:
  with urllib.request.urlopen(u,timeout=18) as f:raw=f.read(2200000);code=f.status;final=f.url
  s=BeautifulSoup(raw,'html.parser');title=s.title.get_text(' ',strip=True) if s.title else ''
  summary=s.select_one('meta[name=description]');desc=summary.get('content','') if summary else ''
  if p=='Open Yale Courses':
   box=s.select_one('.field-name-field-lecture-overview') or s.select_one('.field-name-body');desc=box.get_text(' ',strip=True) if box else desc
  return dict(key=k,url=u,final=final,status=code,title=title,excerpt=desc[:580])
 except Exception as exc:return dict(key=k,url=u,status=str(exc))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:rows=list(pool.map(check,refs))
Path('../historical-source-checks.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(r['key'],r['status'],r.get('title','')[:65],r.get('excerpt','')[:210] if r['key'] in aliases else '')
