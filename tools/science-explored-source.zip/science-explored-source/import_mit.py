import urllib.request,json,pathlib,time
root=pathlib.Path(__file__).resolve().parent.parent/'mit'
root.mkdir(exist_ok=True)
url='https://api.learn.mit.edu/api/v1/learning_resources/?resource_type=video&limit=100'
while url:
    offset=urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get('offset',['0'])[0]
    path=root/(offset+'.json')
    if not path.exists():
        for attempt in range(5):
            try:
                data=json.load(urllib.request.urlopen(url,timeout=90))
                path.write_text(json.dumps(data))
                break
            except OSError:
                if attempt==4: raise
                time.sleep(2**attempt)
    url=json.loads(path.read_text())['next']
print('Retrieved',sum(len(json.loads(p.read_text())['results']) for p in root.glob('*.json')))
