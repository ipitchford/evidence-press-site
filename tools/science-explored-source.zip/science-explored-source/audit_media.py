"""Check MP4 signatures using bounded reads of officially linked media, with durable receipts."""
import concurrent.futures as cf,json,re,hashlib,time,urllib.request,urllib.parse,datetime
from pathlib import Path
root=Path(__file__).resolve().parent
log=root/'access.jsonl'
done={r['id'] for r in map(json.loads,log.read_text().splitlines())} if log.exists() else set()
def check(r):
 row=dict(id=r['id'],page=r['source'],date=datetime.datetime.now(datetime.timezone.utc).isoformat(),verified=False)
 try:
  with urllib.request.urlopen(r['source'],timeout=12) as f:html=f.read(1200000).decode(errors='replace')
  match=re.search(r'data-downloadlink\s*=\s*"([^"]+\.mp4)"',html)
  if not match:return dict(row,result='No official direct MP4 located')
  url=urllib.parse.urljoin(r['source'],match[1])
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=0-1023'}),timeout=15) as f:
   data=f.read(1024);row.update(media=url,status=f.status,range=f.headers.get('Content-Range'),sha256=hashlib.sha256(data).hexdigest(),verified=f.status in (200,206) and data[4:8]==b'ftyp',method='official-mp4-prefix',bytes=len(data))
 except Exception as exc:row['result']=str(exc)
 return row
rows=[r for r in json.loads((root/'catalogue.json').read_text()) if r['id'] not in done and r['provider']=='MIT OpenCourseWare']
with cf.ThreadPoolExecutor(max_workers=6) as pool,log.open('a',buffering=1) as out:
 for row in pool.map(check,rows):out.write(json.dumps(row)+'\n')
