inspections={r['id']:r for r in json.loads((root/'inspections.json').read_text())}
pairs=[line.split() for line in (root/'selections.txt').read_text().splitlines()]
notes=[line.split('\t') for line in (root/'guide-notes.tsv').read_text().splitlines()]
def section(t,b):return '<section><h2>'+e(t)+'</h2>'+paragraphs(b)+'</section>'
interpretations=(root/'interpretation.txt').read_text().splitlines()
assert len(interpretations)==len(notes)
guide_data=[]
for (first,second),(question,watch,task,follow) in zip(pairs,notes,strict=True):
 one,two=byid[first],byid[second];url='guides/'+slug(question)+'/'
 material=[]
 for item in [one,two]:
  receipt=inspections[item['id']]
  material.append(a(receipt['url'],item['title'])+(' · '+a(receipt['transcript'],'English transcript') if receipt.get('transcript') else ' · official teaching description'))
 body='<div class="reading-layout"><article><h2>Start with '+res(one)+'</h2>'+paragraphs(watch)+section('Try it',task)+section('Check your reasoning',interpretations[len(guide_data)])+'<h2>Continue with '+res(two)+'</h2>'+paragraphs(follow)+'<h2>Teaching and evidence</h2>'+listing(material)+'</article><aside><h2>Original course</h2>'+course(one)+'</aside></div>'
 connections={
  'iwQ49oG-DO8':('The caesium atom replaces the turning Earth as the measure of the second','The caesium clock','In 1955 Essen and Parry used a beam of caesium atoms and two microwave fields to establish a frequency standard. Which part of the apparatus sets the reference and which part detects departure from it?'),
  'TdOuHUabbJs':('Separating a rising carbon-dioxide record from local air','Read a carbon-dioxide record','The Mauna Loa chart shows a rising baseline, a seasonal cycle and four missing months. Which of these features could you infer from an annual average, and which observations would it conceal?'),
  'X6cea7dAhBc':('Repairing a telescope by correcting its light','Correct a telescope in orbit','The 1993 Hubble servicing mission changed the optical path while leaving the primary mirror in place. Trace rays from different parts of the mirror and show where a corrective element could bring them to a common focus.'),
  '20GlFVyxqHY':('Tandem cells divide sunlight between two absorbers','Two absorbers in one solar cell','A perovskite layer absorbs shorter wavelengths while silicon receives longer ones. Why would a result from a single small cell leave the performance of a full module uncertain?'),
  's_2w1gY1K4M':('A recorded interference pattern reconstructs a wavefront','Recover a wavefront','Gabor used a reference wave to encode relative phase in an interference pattern. Which information would be lost in an ordinary intensity image?'),
  'q-9YlXesHtI':('A metal frame takes the load from the walls of tall buildings','Trace the load through a building','A metal skeleton let columns and beams carry floors while an exterior wall enclosed the building. Compare this load path with the one you drew for a honeycomb cell.')}
 if first in connections:
  book_section,heading,text=connections[first];body+='<aside class="further-reading"><h2>'+e(heading)+'</h2>'+paragraphs(text)+'<p><em>A Connected History of Science and Technology</em>. In the Kindle edition, find “'+e(book_section)+'”. '+route('books/a-connected-history-of-science-and-technology/','About the book')+'</p></aside>'
 if first in {'4-YaJUUTrNw','EsciE9ws4qw'}:body+='<aside class="further-reading"><h2>Measure a fringe shift</h2><p>In 1887 Michelson and Morley compared an expected displacement of 0.4 fringe with an observed bound below 0.02. Which claim can an upper bound support? See <em>A Connected History of Science and Technology</em>, “An interferometer constrains the ether wind”.</p>'+route('books/a-connected-history-of-science-and-technology/','About the book')+'</aside>'
 page(url,question,body);guide_links.append(route(url,question));guide_data.append((url,one,two,task,follow,question))
 indexrow('guide-'+slug(question),question,'guide',url,description=watch,terms=[one['title'],two['title'],one['course']],topics=[slug(t) for t in one['topics']])
for line in (root/'science_paths.tsv').read_text().splitlines():
 title,audience,steps=line.split('\t');key=slug(title);url='paths/'+key+'/';items=[];lines=[]
 for i,j in enumerate(steps.split(),1):
  gu,one,two,task,follow,question=guide_data[int(j)-1]
  items.append(f'<li><label class="progress-check"><input type="checkbox" data-path="{key}" data-step="{i}">Step {i}</label><h3>'+route(gu,question)+'</h3>'+paragraphs(task)+res(one)+' · '+res(two)+'</li>')
  lines.extend([f'{i}. {question}',f"   - [{one['title']}]({one['source']})",f"   - [{two['title']}]({two['source']})",'   '+task])
 page(url,title,paragraphs(audience)+'<ol>'+''.join(items)+'</ol><p data-progress-summary="'+key+'"></p>'+route(url+'reading-list.md','Export the reading list'))
 (out/url/'reading-list.md').write_text('# '+title+'\n\n'+audience+'\n\n'+'\n'.join(lines));path_links.append(route(url,title));indexrow('path-'+key,title,'path',url,description=audience)
page('guides','Topic guides',listing(guide_links));page('paths','Learning paths',listing(path_links))
