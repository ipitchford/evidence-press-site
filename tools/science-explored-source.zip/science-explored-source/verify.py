"""Check static pages, internal destinations, section counts and per-video receipts."""
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urljoin,urlparse,unquote
import sys,json
site=Path(sys.argv[1]);base='/science-explored/';data=json.loads((site/'data/index.json').read_text())['records']
errors=[];urls=set()
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ['src','href','action'] and v and v.startswith(base):urls.add(unquote(urlparse(v).path[len(base):]))
parser=Links()
for p in site.rglob('*.html'):parser.feed(p.read_text())
for name in urls:
 p=site/name
 if not (p.is_file() or (p/'index.html').is_file()):errors.append('Missing internal target '+name)
for r in data:
 if not (site/r['url'][len(base):]/'index.html').is_file():errors.append('Broken search entry '+r['id'])
counts=Counter(r['kind'] for r in data);videos=[r for r in data if r['kind']=='video']
if len({r['id'] for r in data})!=len(data):errors.append('Duplicate index identifier')
for kind,folder in [('course','courses'),('path','paths'),('guide','guides'),('video','resources')]:
 if counts[kind]!=len(list((site/folder).glob('*/index.html'))):errors.append('Route count mismatch '+folder)
if any(p.suffix.lower() in ['.epub','.pdf'] for p in site.rglob('*')):errors.append('Unexpected document in public build')
report={'counts':dict(counts),'accessEvidence':sum(r['qualified'] for r in videos),'coreAnnotations':sum(r['coreChecked'] for r in videos),'fields':len(list((site/'topics').glob('*/index.html'))),'providers':len({r['providerId'] for r in videos}),'internalTargets':len(urls),'htmlPages':len(list(site.rglob('*.html'))),'errors':errors}
print(json.dumps(report,indent=2));sys.exit(bool(errors))
