for topic,rows in topics.items():
 key=slug(topic);questions=[r for r in index if r['kind']=='guide' and key in r['topics']]
 selections=''.join('<article class="editorial-row"><div><p class="eyebrow">Topic guide</p><h3>'+a(r['url'],r['title'])+'</h3><p>'+e(r['description'])+'</p></div><span class="arrow" aria-hidden="true">↗</span></article>' for r in questions) if questions else ''
 ordered=sorted({r['slug']:r for r in rows}.values(),key=lambda r:r['course'].lower())
 page('topics/'+key,topic,selections+'<h2>Courses and collections</h2>'+listing(course(r) for r in ordered)+route('search/?topic='+key,'Search videos in this field'))
