# Project progress

Updated: 7 November 2026, final local release verification.

## Status

All numerical first-release targets are met. The local application, checked static build, actual browser checks, credential-free clean execution and release-package verification are complete. Production publication and DNS changes are not authorised for this atlas. Additional cash expenditure: £0.

## Completed and evidenced

- Matching validation/build: **4,645 canonical source records; 4,202 qualified accessible videos; 118 course/series records; 28 verified source-register entries; 21 verified video-provider groups; 14 subject families; 51 guides; 20 paths; 201 individually checked qualified core resources; 127 supporting resources.** Zero structural errors or warnings. See `evaluation/validation.json`, `final-release-check.log` and `build.json`.
- The overlap review holds 111 possible repeat uploads outside discovery and the distinct-qualified count. Zero confirmed equivalences are asserted. Source records/course positions remain; no selected route/core is affected. Actual import twice produced byte-identical outputs and preserved overrides, withdrawals and all 71 reviewed content files. See `evaluation/alternate-integration.json`.
- All 51 guides and 20 paths passed substantive source-based agent review and repair readbacks. Of 250 selected resources, 249 have recorded access evidence; one optional restricted historical video is disclosed with alternatives. Final hashes match. No full-video viewing, human peer review or blanket scientific validation is claimed.
- Frozen 100-record source inspection, separate critical-comment supplement and actual repairs are under `evaluation/source-sample/`. This purposive sample does not estimate scientific accuracy. Earlier cache integrity checked 2,371 source files; additive overlap/reading inputs received their own hash checks.
- Final fixed 24-task search review covers all five variants and first-five/route results: 18:52:07 UTC, 4,398 indexed records. Keyword 19 pass/5 partial/0 fail; optional enhanced 20/4/0. Lower-result defects and the small final ordering regression remain explicit in `SEARCH_REVIEW.md`.
- **56/56 tests pass.** Final build: 4,536 sitemap pages plus the 404 copy, 4,209 source-only export rows and 637,993 bytes gzip for initial assets plus discovery. Static audit: 4,573 files, 102,788 local references, 4,691 fragments, zero errors. The expected localhost-canonical warning requires a future approved-address rebuild. All 111 held pages/course links were inspected; none enters discovery or exports.
- The 10,000-record fixture stays in memory; no synthetic records are published. Actual browser checks passed control-driven search and filters, keyboard focus, dark-mode persistence, library/playlist/path persistence and export/reset/import. All fields of the library roundtrip match. Thumbnail and player choices, short institutional and approved YouTube playback, and controlled failure/expiry states were observed. Final desktop/390px homepages have no horizontal overflow. See `evaluation/browser/resumed-qa.json`.
- Browser checks prompted three repairs: contain Tab focus in dialogs, preserve Watch at source after loading a player, and align the tinted homepage section with its page gutter. Actual readbacks passed; the static guard verifies permanent source links on all 4,320 player pages.
- API retention is integrated and tested with 22 explicit evaluation targets. Original retrieval clocks control expiry; actual dry run has no due redactions/blocks. Audio-language metadata was corrected. Static API display data must be replaced before **2026-12-05T15:41:34.033Z**.
- Clean source execution passed offline install, build, all 56 tests and explicit validation without token/API cache: 1,608 qualified videos and 88 qualified core, with all 51 guides/20 paths retained. The final source payload is checked against the tested copy, allowing only closeout documentation differences. See `evaluation/clean-source-final.json`. The static ZIP was reopened and every member hash verified; see `evaluation/static-package-latest.json`.
- Source/schema/licence information, maintenance/correction workflow, deployment instructions and voluntary pilot materials are present. No recruitment, feedback, adoption or learning impact has been observed.

## Local release complete

No local delivery gate remains unfinished. The browser stall ended when the user closed the old tab. The final preview is retained at `http://127.0.0.1:4173/`, with QA-only library state cleared and the original system theme restored. The temporary failure server was stopped and its fixture removed.

The final source and static archives, checksums and distribution limits are listed in `releases/README.md`. The final source code, data, content and tests match the fresh clean-tested package; only closeout documentation differs. The main API-enriched build and credential-free source build deliberately have different accessibility totals.

## Next maintenance action

Refresh or remove API-derived display data and replace affected static artifacts before 5 December 2026, 15:41:34 UTC. Any future publication needs explicit authorisation, a confirmed free destination and a rebuild with that destination's canonical address. No new account, paid service, outreach or production deployment was performed.

Detailed results and coverage limits are in [EVALUATION.md](EVALUATION.md); operational gates are in [the release checklist](docs/RELEASE_CHECKLIST.md). Human feedback and learning impact remain separate, unobserved outcomes.
