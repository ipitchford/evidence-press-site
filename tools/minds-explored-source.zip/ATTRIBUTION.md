# Attribution and separate rights

Original application code is licensed under the root [MIT licence](LICENSE), copyright 2026 Evidence Press. Original public guides, paths and editorial annotations use CC BY 4.0 as described in [CONTENT-LICENCE.md](CONTENT-LICENCE.md). Third-party material keeps its own rights and exclusions. Listing, embedding or linking a video does not grant permission to download or rehost it.

Item-level `reuse` fields and `data/sources.json` provide the detailed register. Principal sources include:

| Source | Attribution and reuse boundary |
| --- | --- |
| [MIT OpenCourseWare](https://ocw.mit.edu/pages/privacy-and-terms-of-use/) | Credit MIT OCW and the identified instructor/source. Most course material uses CC BY-NC-SA 4.0; exceptions and third-party rights apply. |
| [Open Yale Courses](https://oyc.yale.edu/terms) | Credit the faculty member, Yale and course URL. Most material uses CC BY-NC-SA 3.0 with exceptions; the terms page links both US and Unported variants. |
| [Neuromatch](https://compneuro.neuromatch.io/tutorials/intro.html) | Course/repository material states CC BY 4.0, with software additionally BSD 3-Clause. Do not infer identical permission for every embedded video or third-party asset. |
| [NPTEL](https://nptel.ac.in/) | Preserve NPTEL, course and lecturer attribution. The source register records notices and exceptions; partner institutions are not extra provider counts by default. |
| [HackerTube](https://hackertube.org/download/DATA.md) | Discovery export under ODC-By 1.0, with Hacker News as discussion source. Retrieved 7 November 2026; local checksums are in `data/audits/hackertube/export-receipt.json`. Application code and individual source content have separate rights. |
| YouTube | Official API data is an expiring operational overlay, excluded from catalogue downloads and source distributions. Provider terms and privacy notices remain linked in the application. |

Other conditions, including Noba, BrainFacts, institute recordings and society talks, remain in the register. A supporting reading provider is not automatically a qualified-video provider. Identity, availability, reuse permission and scientific assessment are distinct decisions.

EB Garamond and Inter are self-hosted under the SIL Open Font License. Preserve `public/fonts/OFL-eb-garamond.txt` and `public/fonts/OFL-inter.txt` in the build. npm dependencies retain their package licences and locked versions.

The original annotations and guides were drafted and source-checked by agents, followed by the recorded editorial checks. This does not imply human peer review, full-video viewing, source-provider endorsement or scientific validation. Provider text is evidence for original editorial writing, not unrestricted prose to copy into exports. A checked non-creator recommendation does not establish financial independence or endorse scientific claims.
