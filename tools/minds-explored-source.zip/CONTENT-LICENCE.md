# Licence for original editorial prose

Copyright 2026 Evidence Press. Unless an item states otherwise, original atlas guide prose, learning-path explanations and original editorial catalogue annotations are licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).

When reusing that writing, credit Evidence Press, identify the work and its source/version, link the licence and indicate changes. Do not imply endorsement.

This licence does not cover linked or embedded videos, transcripts, source descriptions, figures, provider marks, API data, raw research caches or other third-party assets. Their source-specific terms continue to apply. Original application code and technical software documentation are covered by the root [MIT licence](LICENSE).
