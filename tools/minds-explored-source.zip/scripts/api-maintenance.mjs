import {purgeEvaluationAPIData} from './api-retention.mjs';
import {pruneYouTubeCache} from './youtube-refresh.mjs';
import {writeJSON} from './data.mjs';
export async function maintainAPIData(){
  // Redact copied fields before deleting original clocks from the ingestion cache.
  const evaluation=await purgeEvaluationAPIData({apply:true});
  await writeJSON('evaluation/api-retention.json',evaluation);
  if(evaluation.blocked.length)throw Error('API retention needs an original source date; inspect evaluation/api-retention.json before continuing.');
  const cache=await pruneYouTubeCache();
  const receipt={checkedAt:new Date().toISOString(),evaluation,cache:{currentRecords:Object.keys(cache.records).length,removedRecords:cache.removedRecords,removedBatches:cache.removedBatches},networkRequests:0};
  await writeJSON('evaluation/api-retention.json',receipt);
  return receipt;
}
