import Ajv from 'ajv';
import {maintainAPIData} from './api-maintenance.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {loadData,json,writeJSON,ROOT} from './data.mjs';
import {canonicalVideo,isQualified,safeURL} from '../src/model.mjs';

export async function validate(data, {release=false}={}) {
  const errors=[], warnings=[]; const check=new Ajv({allErrors:true,strict:false}).compile(await json('data/schema/video.schema.json'));
  const ids=new Set(),urls=new Set(),providers=new Map(data.sources.map(s=>[s.id,s])),families=new Set(data.taxonomy.families.map(f=>f.id));
  const courses=new Set(data.courses.map(c=>c.id));
  for(const r of data.records) {
    if(!check(r)) errors.push(`${r.id??'(missing id)'}: ${check.errors.map(x=>x.instancePath+' '+x.message).join('; ')}`);
    if(ids.has(r.id)) errors.push(`Duplicate canonical id: ${r.id}`);ids.add(r.id);
    if(urls.has(r.canonicalUrl)) errors.push(`Duplicate canonical URL: ${r.canonicalUrl}`);urls.add(r.canonicalUrl);
    if(!safeURL(r.canonicalUrl)||!safeURL(r.sourceUrl)) errors.push(`${r.id}: unsafe URL`);
    try { const canonical=canonicalVideo(r.canonicalUrl); if(canonical.id && canonical.id!==r.id) errors.push(`${r.id}: canonical identifier mismatch`); } catch(e){errors.push(`${r.id}: ${e.message}`)}
    if(!providers.has(r.providerId)) errors.push(`${r.id}: missing source provider ${r.providerId}`);
    if(r.courseId && !courses.has(r.courseId)) errors.push(`${r.id}: unknown parent course`);
    if(r.topics?.some(t=>!families.has(t))) errors.push(`${r.id}: unknown topic family`);
    const evidence=new Set(r.provenance?.map(p=>p.id));
    for(const id of [...(r.availability?.evidence??[]),...(r.durationEvidence??[]),...(r.descriptionCheck?.evidenceIds??[]),...(r.selection?.evidenceIds??[])]) if(!evidence.has(id)) errors.push(`${r.id}: missing evidence ${id}`);
    if(r.availability?.status==='accessible' && !isQualified({...r,qualification:{status:'qualified'},withdrawn:false,alternateOf:null})) errors.push(`${r.id}: accessibility has insufficient evidence`);
    if(r.availability?.playbackObserved && r.availability.method!=='browser-playback') errors.push(`${r.id}: playback observation does not match method`);
    if(r.durationSeconds!==null && !r.durationEvidence?.length) errors.push(`${r.id}: duration lacks evidence`);
    if(r.descriptionCheck?.status==='checked' && (!r.descriptionCheck.checkedAt||!r.descriptionCheck.checker||!r.descriptionCheck.evidenceIds?.length)) errors.push(`${r.id}: description check incomplete`);
    if(r.alternateOf===r.id) errors.push(`${r.id}: self-referencing alternate`);
    if(r.qualification?.status==='qualified' && !isQualified(r) && !r.withdrawn && !r.alternateOf) warnings.push(`${r.id}: not in qualified accessible release count`);
    for(const p of r.provenance??[]) if(!safeURL(p.url)) errors.push(`${r.id}: unsafe provenance URL`);
  }
  for(const r of data.records) if(r.alternateOf&&!ids.has(r.alternateOf)) errors.push(`${r.id}: missing canonical parent`);
  const recordMap=new Map(data.records.map(r=>[r.id,r]));
  const checkReceipt=async(doc)=>{const rel=doc.check?.receipt;if(!rel)return;const file=path.resolve(ROOT,rel);if(!file.startsWith(ROOT+path.sep)){errors.push(`${doc.slug}: unsafe editorial receipt path`);return;}try{const receipt=JSON.parse(await fs.readFile(file,'utf8'));if(!receipt||!Object.keys(receipt).length)throw Error('Empty receipt');}catch{errors.push(`${doc.slug}: missing or unreadable editorial receipt`);}};
  const reviewedGuide=[],reviewedPath=[];
  for(const g of data.guides) {
    for(const field of ['slug','title','question','audience','scope','startingResourceId','startingReason','body','prerequisites','keyTerms','neighbours','nextStep','sources','check']) if(g[field]===undefined) errors.push(`${g.slug}: missing guide ${field}`);
    const resourceIds=[g.startingResourceId,...(g.resources??[]).map(r=>r.id)];
    for(const id of resourceIds) if(!ids.has(id)) errors.push(`${g.slug}: missing video ${id}`);
    if(g.status==='reviewed')await checkReceipt(g);
    if(release&&g.status==='reviewed'&&!isQualified(recordMap.get(g.startingResourceId)??{}))errors.push(`${g.slug}: starting resource has no current accessibility evidence`);
    if((g.resources??[]).length<4) warnings.push(`${g.slug}: fewer than four further resources; editorial justification required`);
    if(g.status==='reviewed' && g.check?.date && g.check?.checker && g.check?.materialInspected && g.check?.receipt && g.sources?.length && g.courseId && g.supporting?.length && g.methodsOrExercise) reviewedGuide.push(g);
    else if(g.status==='reviewed') errors.push(`${g.slug}: guide declared reviewed without its complete editorial record`);
  }
  for(const p of data.paths) {
    for(const field of ['slug','title','audience','prerequisites','objectives','steps','shortRoute','continuation','check']) if(p[field]===undefined) errors.push(`${p.slug}: missing path ${field}`);
    for(const step of p.steps??[]) if(!ids.has(step.resourceId)||!step.reason||!step.task) errors.push(`${p.slug}: incomplete or unknown path step`);
    if(p.status==='reviewed')await checkReceipt(p);
    if(release&&p.status==='reviewed')for(const step of p.steps??[])if(!isQualified(recordMap.get(step.resourceId)??{}))errors.push(`${p.slug}: required step lacks current accessibility evidence: ${step.resourceId}`);
    if(p.status==='reviewed' && p.steps?.length>=5 && p.check?.date && p.check?.checker && p.check?.receipt && p.check?.materialInspected) reviewedPath.push(p);
    else if(p.status==='reviewed') errors.push(`${p.slug}: incomplete reviewed path`);
  }
  const qualified=data.records.filter(isQualified),core=qualified.filter(r=>r.descriptionCheck.status==='checked'&&['publisher-description','transcript','viewing'].includes(r.descriptionCheck.method)&&r.selection.checkedAt&&r.selection.checker&&r.selection.reason);
  const counts={canonicalVideos:data.records.filter(r=>!r.alternateOf&&!r.withdrawn).length,qualifiedAccessibleVideos:qualified.length,alternateUploads:data.records.filter(r=>r.alternateOf).length,courses:data.courses.length,sourceProviders:data.sources.filter(s=>s.status==='verified').length,videoProviders:new Set(qualified.filter(r=>providers.get(r.providerId)?.status==='verified').map(r=>providers.get(r.providerId)?.countingProviderId??r.providerId)).size,subjectFamilies:new Set(qualified.flatMap(r=>r.topics)).size,taxonomyFamilies:families.size,completedGuides:reviewedGuide.length,completedPaths:reviewedPath.length,checkedCore:core.length,supportingResources:data.supporting.length};
  const targets={qualifiedAccessibleVideos:3000,completedGuides:50,completedPaths:20,checkedCore:200,subjectFamilies:12,videoProviders:20};
  const gaps=Object.entries(targets).filter(([key,target])=>counts[key]<target).map(([key,target])=>({requirement:key,actual:counts[key],target,shortfall:target-counts[key]}));
  if(release) for(const gap of gaps) errors.push(`First-release target unmet: ${gap.requirement} ${gap.actual}/${gap.target}`);
  return {checkedAt:new Date().toISOString(),schemaValid:errors.length===0,releaseTargetMet:!gaps.length,counts,targets,gaps,errors,warnings,boundary:'Structural and provenance checks do not establish scientific correctness, human review or learning impact.'};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){await maintainAPIData();const result=await validate(await loadData(),{release:process.argv.includes('--release')});await writeJSON('evaluation/validation.json',result);console.log(JSON.stringify(result,null,2));if(result.errors.length)process.exitCode=1;}
