import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';
import Ajv from 'ajv';
import {canonicalVideo, isQualified, resolveAlternateId, safeURL} from '../src/model.mjs';

const DEFAULT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CHECKER = 'source-audit normaliser; not an individual editorial reviewer';
const SHA = /^[a-f0-9]{64}$/;
const TOPICS = new Set(['neuroscience','perception-action','learning-memory','language','reasoning-decisions','development','emotion-motivation-sleep','individual-differences','social-cultural','evolution-comparative','mental-health','consciousness-philosophy','computation-ai','methods']);
const ALIASES = {
  'perception-attention-action':'perception-action', 'learning-memory-education':'learning-memory',
  'learning-and-education':'learning-memory', 'language-communication':'language', 'language-and-communication':'language',
  'reasoning-decision-making':'reasoning-decisions', 'decision-making':'reasoning-decisions',
  'personality-intelligence-individual-differences':'individual-differences', 'social-cultural-behaviour':'social-cultural',
  'social-and-cultural-behaviour':'social-cultural', 'evolution-comparative-cognition':'evolution-comparative',
  'evolution-genetics-comparative-cognition':'evolution-comparative', 'evolution':'evolution-comparative',
  'consciousness-philosophy-of-mind':'consciousness-philosophy', 'computational-cognition':'computation-ai',
  'research-methods':'methods', 'methods-reproducibility':'methods', 'emotion-motivation':'emotion-motivation-sleep',
  'philosophy-and-research-foundations':'consciousness-philosophy',
};
const FORMATS = new Set(['lecture','seminar','tutorial','interview','panel','documentary','demonstration','unknown']);
const FORMAT_ALIASES = {talk:'seminar', course:'lecture', podcast:'interview', demo:'demonstration', explainer:'tutorial'};
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const clone = value => structuredClone(value);
const array = value => Array.isArray(value) ? value : value ? [value] : [];
const unique = values => [...new Set(values.filter(v=>v!==null&&v!==undefined))];
const sorted = values => unique(values).sort();
const validDate = value => typeof value==='string' && /^\d{4}-\d{2}-\d{2}/.test(value) && Number.isFinite(Date.parse(value));
const validRecordingDate = value => typeof value==='string' && /^\d{4}(?:-\d{2}(?:-\d{2})?)?$/.test(value);
const asRows = value => Array.isArray(value) ? value : array(value?.records);
const stable = value => JSON.stringify(value, null, 2)+'\n';
const timestamp = sources => sources.map(x=>x.retrievedAt??x.checkedAt).filter(validDate).sort().at(-1)??null;

export function publicURL(value) {
  const safe=safeURL(value); if(!safe)return null;
  const u=new URL(safe);
  if([...u.searchParams.keys()].some(k=>/^(?:key|api[_-]?key|access[_-]?token|refresh[_-]?token|token|authorization|auth|signature|sig|x-amz-.+|x-goog-.+)$/i.test(k)))return null;
  return safe;
}
export function canonicalIdentity(value) {
  if(!publicURL(value))throw new Error('Unsafe or credential-bearing destination URL');
  const c=canonicalVideo(value);
  return {id:c.id??`institution:${digest(c.url).slice(0,16)}`,url:c.url};
}
export function normaliseTopics(values, report, context='') {
  const mapped=[];
  for(const value of unique(array(values))) {
    const topic=ALIASES[value]??value;
    if(TOPICS.has(topic))mapped.push(topic);
    else report?.unmappedTopics.push({context,topic:value});
  }
  return sorted(mapped);
}
function safeCache(value) {
  return typeof value==='string' && /^data\/(?:raw|audits)\//.test(value) && !value.split('/').includes('..') ? value : null;
}
export function evidence(raw, context, defaults={}) {
  if(!raw||typeof raw!=='object')return null;
  const url=publicURL(raw.url??raw.sourceUrl??raw.requestedUrl??defaults.url);
  const sha256=raw.sha256??raw.sampleSha256??defaults.sha256;
  const retrievedAt=raw.retrievedAt??raw.checkedAt??defaults.retrievedAt;
  if(!url||!SHA.test(sha256??'')||!validDate(retrievedAt))return null;
  return {
    id:raw.id??`${context}-${digest(`${url}\n${sha256}\n${retrievedAt}`).slice(0,16)}`,
    url,retrievedAt,sha256,
    inspection:String(raw.inspection??raw.inspectedMaterial??raw.inspected??defaults.inspection??'Source retrieval recorded; no video viewing.'),
    cachePath:safeCache(raw.cachePath??raw.rawPath??raw.bodyCachePath??raw.privateSampleFile),
    checker:raw.checker??'agent source audit',
  };
}
function evidenceUnion(...groups) {
  const byId=new Map();
  for(const item of groups.flat().filter(Boolean)) {
    const old=byId.get(item.id);
    if(old && (old.url!==item.url||old.sha256!==item.sha256))throw new Error(`Conflicting provenance ID: ${item.id}`);
    byId.set(item.id,item);
  }
  return [...byId.values()].sort((a,b)=>a.id.localeCompare(b.id));
}
async function readSample(root, receipt) {
  const filename=safeCache(receipt.bodyCachePath??receipt.privateSampleFile);
  if(!filename)return false;
  try {
    const bytes=receipt.receivedBytes??receipt.bytes;
    if(!Number.isSafeInteger(bytes)||bytes<12||bytes>2048)return false;
    const target=path.join(root,filename);const stat=await fs.stat(target);
    if(!stat.isFile()||stat.size!==bytes)return false;
    const body=await fs.readFile(target);
    return body.length===bytes && bytes>=12 && bytes<=2048 && body.subarray(4,8).toString()==='ftyp'
      && new Set(['isom','iso2','iso4','iso5','iso6','avc1','mp41','mp42','M4V ','M4VH','M4VP','dash','MSNV']).has(body.subarray(8,12).toString())
      && digest(body)===(receipt.sampleSha256??receipt.sha256);
  } catch{return false;}
}

export async function accessEvidence(raw, {root=DEFAULT_ROOT,context='access',officialAlternatives=[]}={}) {
  const a=raw.availability??{};
  const historical=a.auditOnly===true || a.repeatablePermittedRoute===false || /watch.page|historical|player.metadata|player_metadata/i.test(`${a.method??''} ${a.status??''}`);
  const none={status:'unknown',method:'source-page-only',checkedAt:validDate(a.checkedAt)?a.checkedAt:null,evidence:[],playbackObserved:false,note:historical?'Historical watch-page observations are audit only; an authorised destination check is pending.':'Source page or outline retrieved; no qualifying destination check.',auditOnly:historical,permitted:!historical,alternativeUrl:null,refreshDueAt:null};
  const attempts=[...array(raw.mediaEndpointChecks),...(a.method?.includes('range')||a.method?.includes('Range')?[a]:[]),...array(raw.authorisedAlternative?.availabilityCheck)];
  const accepted=[];
  for(const r of attempts) {
    if(r.auditOnly||r.permitted===false||/HEAD/i.test(r.method??''))continue;
    const url=publicURL(r.requestUrl??r.url??r.requestedUrl);
    const bytes=r.receivedBytes??r.bytes;
    const http=Number(r.httpStatus??r.status);
    const exit=r.curlExit??r.exitCode??r.exit;
    const mp4Type=/^video\/mp4(?:;|$)/i.test(r.contentType??'') || (/^application\/octet-stream(?:;|$)/i.test(r.contentType??'')&&/\.mp4$/i.test(new URL(url??'https://invalid.example').pathname));
    if(!url||!officialAlternatives.includes(url)||http!==206||exit!==0||bytes<12||bytes>2048||!mp4Type)continue;
    if(!new RegExp(`^bytes 0-${bytes-1}/[1-9][0-9]*$`).test(r.contentRange??''))continue;
    if(r.finalUrl&&r.finalUrl!==url)continue;
    if(!await readSample(root,r))continue;
    const ev=evidence({...r,url},context,{inspection:r.inspection??`Officially linked MP4: HTTP 206 and ${bytes} bytes with a verified MP4 file header; no playback or complete-file inspection.`});
    if(!ev)continue;
    accepted.push({r,ev,url});
  }
  if(accepted.length) {
    accepted.sort((x,y)=>y.ev.retrievedAt.localeCompare(x.ev.retrievedAt)||x.url.localeCompare(y.url));
    const {r,ev,url}=accepted[0];
    return {availability:{status:'accessible',method:'official-media-range',checkedAt:ev.retrievedAt,evidence:[ev.id],playbackObserved:false,permitted:true,auditOnly:false,alternativeUrl:url,refreshDueAt:new Date(Date.parse(ev.retrievedAt)+7*86400000).toISOString(),note:`${r.receivedBytes??r.bytes}-byte range from the officially listed MP4, HTTP 206, matching content range and MP4 header. ${r.contentType==='application/octet-stream'?'Server labels the MP4 as generic binary data; the saved bytes identify its container. ':''}No full playback or decoding; YouTube availability is unknown.`},provenance:[ev]};
  }
  // YouTube API evidence belongs to the private, expiring runtime overlay. Never
  // persist API metadata or its derived accessibility into the reusable catalogue.
  return {availability:none,provenance:[]};
}

function originalDescription(raw, course) {
  const title=String(raw.title??'').trim();
  if(raw.originalSynopsis)return String(raw.originalSynopsis);
  const courseTitle=course?.title??raw.parentCourseTitle??raw.courseTitle;
  if(courseTitle)return `“${title}” is listed in ${courseTitle}. Its place in the course provides the learning context; an individual account of the lecture's content has not yet been checked.`;
  return raw.description??`The source lists “${title}”. An individual description has not yet been checked.`;
}
function transcript(raw, origin) {
  const linked=array(raw.transcriptUrls).map(publicURL).filter(Boolean)[0]??array(raw.transcriptLinks).map(x=>publicURL(x.url)).filter(Boolean)[0];
  if(linked)return {status:'available',url:linked,language:null,inspected:false,note:'Official source lists this transcript/caption link; text was not retrieved or inspected.'};
  // Historical watch-page captions are not carried into the reusable catalogue.
  return {status:'unknown',url:null,language:null,inspected:false};
}
function sourceSpeaker(raw, origin) {
  if(origin==='courses')return raw.speakerEvidence?.basis && !/course.level|inferred|not.*established/i.test(raw.speakerEvidence.basis)?raw.speaker??null:null;
  if(origin==='providers')return raw.speaker??null;
  if(origin==='nptel')return raw.speakerEvidence?.basis?raw.speaker??null:null;
  return null;
}
function material(raw) {
  return ['empirical','method','theoretical','historical','clinical','mixed'].includes(raw.materialType)?raw.materialType:'unknown';
}

export async function normaliseRecord(raw, origin, ctx) {
  const {root,report,courses,sources}=ctx;
  const canonical=canonicalIdentity(raw.canonicalUrl??raw.url);
  const sourceUrl=publicURL(raw.sourceUrl); if(!sourceUrl)throw new Error('Missing safe original source URL');
  const providerId=origin==='hackertube'?'hackertube-discovery':raw.providerId;
  if(!sources.has(providerId))throw new Error(`Missing registered provider: ${providerId}`);
  const courseId=courses.has(raw.parentCourse)?raw.parentCourse:null;
  const course=courses.get(courseId);
  const families=raw.subjectFamilies??raw.topics??course?.topics;
  const topics=normaliseTopics(families,report,canonical.id);
  if(!topics.length)throw new Error('No supported topic assignment; broad source category needs editorial mapping');
  let prov=[];
  const defaults={retrievedAt:raw.retrievedAt??raw.retrieval?.retrievedAt??course?.retrievedAt,url:sourceUrl};
  for(const item of [...array(raw.descriptionEvidence),raw.retrieval,raw.sourceEvidence].filter(Boolean)) {
    const p=evidence(item,`${origin}-source`,defaults); if(p)prov.push(p);
  }
  if(origin==='hackertube')prov.push(evidence({url:raw.sourceUrl,retrievedAt:raw.retrievedAt,sha256:ctx.hackertubeReceipt.sha256,inspection:'Attributed HackerTube export card and retained-comment context reviewed; model-generated annotation, no video or transcript inspection.'},'hackertube-export'));
  if(!prov.length)throw new Error('Missing real source retrieval hash/date');
  prov=evidenceUnion(prov);
  const sourceEvidenceIds=prov.map(x=>x.id);
  const sourceAlternatives=[...array(raw.authorisedMediaAlternatives),raw.authorisedAlternative?.url,raw.institutionalAlternative?.requestedUrl,...(origin==='providers'&&/\.mp4$/.test(raw.canonicalUrl)?[raw.canonicalUrl]:[])].filter(Boolean);
  const officialAlternatives=sourceAlternatives.map(publicURL).filter(Boolean);
  // Some MIT pages link legacy HTTP Archive.org addresses. Accept their HTTPS
  // equivalent only when that exact request is recorded in a successful audit.
  for(const r of array(raw.mediaEndpointChecks))if(r.requestUrl&&sourceAlternatives.includes(r.url)) {
    try {
      const source=new URL(r.url),request=new URL(r.requestUrl);
      if(source.protocol==='http:'&&['archive.org','www.archive.org'].includes(source.hostname)&&!source.username&&!source.password&&request.protocol==='https:'&&['archive.org','www.archive.org'].includes(request.hostname)&&source.pathname===request.pathname&&source.search===request.search&&publicURL(r.requestUrl))officialAlternatives.push(r.requestUrl);
    } catch{}
  }
  const access=await accessEvidence(raw,{root,context:`${origin}-media`,officialAlternatives});
  prov=evidenceUnion(prov,access.provenance);
  // Prove the link from the source inventory to an alternative, as well as its bytes.
  if(raw.authorisedAlternative?.listedBy) {
    const alt=raw.authorisedAlternative;
    const p=evidence({url:alt.listedBy,sha256:alt.sourceSha256,retrievedAt:alt.sourceRetrievedAt??raw.downloadSourceRetrievedAt??raw.retrievedAt,inspection:'Official download inventory maps this course and lesson to the MP4 alternative; source title agreement recorded.'},`${origin}-download-inventory`);
    if(p){prov=evidenceUnion(prov,[p]);if(access.availability.status==='accessible')access.availability.evidence.push(p.id);}
    else if(access.availability.status==='accessible') {
      access.availability={...access.availability,status:'unknown',method:'source-page-only',evidence:[],note:'Media bytes were observed but the official mapping provenance is incomplete.'};
    }
  }
  let durationSeconds=null,durationEvidence=[];
  if(Number.isFinite(raw.durationSeconds)&&raw.durationSeconds>0) {
    const e=evidence(raw.durationEvidence,`${origin}-duration`,defaults);
    if(e){prov=evidenceUnion(prov,[e]);durationSeconds=raw.durationSeconds;durationEvidence=[e.id];}
    else if(origin==='providers'&&raw.providerId==='oxford-podcasts') {durationSeconds=raw.durationSeconds;durationEvidence=[sourceEvidenceIds[0]];}
  }
  const ambiguous=raw.titleStatus==='page_context_only_multiple_videos';
  const substantive=!(typeof raw.substanceCheck==='string'&&/^Pending\b/i.test(raw.substanceCheck));
  const excluded=raw.qualificationStatus==='excluded';
  const qualification=excluded?{status:'excluded',reason:raw.exclusionReason??'Source audit excluded this record.'}
    :ambiguous?{status:'candidate',reason:'This page contains several videos and the individual title/destination association is unresolved.'}
    :!substantive?{status:'candidate',reason:'The source audit has not resolved whether this item is substantive instruction or an auxiliary recap/exercise fragment.'}
    :access.availability.status==='accessible'?{status:'qualified',reason:'In-scope source-listed resource with canonical identity, course/topic context, source provenance and a permitted official media byte-range check.'}
    :{status:'candidate',reason:'Source and topical context identified; qualifying permitted destination accessibility remains unverified.'};
  qualification.checkedAt=timestamp(prov);qualification.checker=CHECKER;
  qualification.sourceIdentityResolved=!ambiguous;
  qualification.substanceResolved=substantive;
  const imported=origin==='hackertube';
  const descriptionCheck={status:'unchecked',method:imported?'imported-annotation':'unknown',checkedAt:null,checker:null,evidenceIds:sourceEvidenceIds,note:imported?'Imported model annotation and sampled HN context only; no independent publisher/transcript check.':'Original navigation based on retrieved title and course/publisher context. Bulk normalisation is not an individual description or scientific check.'};
  const selection={basis:raw.selectionBasis==='editorial-selection'||imported||origin==='providers'?'editorial-selection':'institutional-collection',reason:raw.selectionReason??`Source-listed resource within ${course?.title??'the selected collection'}.`,evidenceIds:sourceEvidenceIds,checkedAt:null,checker:null,subjectAssignmentBasis:raw.subjectAssignmentBasis??raw.metadataScope?.subjectFamilies??(courseId?'Parent-course context; not an individual transcript-derived assignment.':'Source-audit topical assignment; scientific assessment is separate.'),note:raw.parentCourse&&!courseId?'Named series/collection context has not been registered as a verified course.':null};
  const provider=sources.get(providerId);
  const sourceLicence=raw.rights?.licence??raw.reuse?.licence??raw.licence?.databaseLicence??raw.sourceLicenceNotes??provider.licence??null;
  const title=String(raw.title??'').replace(/\s+/g,' ').trim();
  if(title.length<3||title.length>600)throw new Error('Title length outside schema bounds');
  const output={id:canonical.id,title,canonicalUrl:canonical.url,sourceUrl,providerId,courseId,topics,tags:[],description:originalDescription(raw,course),descriptionCheck,selection,qualification,availability:access.availability,provenance:prov,language:null,level:'unknown',levelBasis:course?.statedLevel?`Parent course states “${course.statedLevel}”; individual lecture difficulty not separately established.`:raw.levelBasis??null,format:FORMATS.has(raw.format)?raw.format:FORMAT_ALIASES[raw.format]??'unknown',speaker:sourceSpeaker(raw,origin),durationSeconds,durationEvidence,uploadDate:null,recordingDate:null,recordingDatePrecision:'unknown',courseTerm:course?.term??null,addedAt:prov.map(p=>p.retrievedAt).sort()[0],transcript:transcript(raw,origin),thumbnail:null,scientificAssessment:{status:'not-assessed',claimCheckIds:[]},materialType:material(raw),reuse:{exportAllowed:true,basis:imported?'Factual metadata and original audit annotations derived from an attributed ODC-By database; individual content rights remain separate.':'Links, factual metadata and original navigation annotations only. No source page, transcript, image, video or restricted platform metadata is included in the reusable export.',attribution:imported?raw.licence?.notice??'HackerTube and open-index/hacker-news; ODC-By 1.0.':`${provider.name}; original source ${sourceUrl}. ${provider.reuseConditions??''}`.trim(),sourceLicence,annotationLicence:'Original atlas navigation only; source rights preserved.'},community:null,alternateOf:null,withdrawn:false,withdrawalReason:null};
  if(origin==='providers'&&validRecordingDate(raw.recordingDate)&&raw.recordingDateNote&&!/upload|watch.page/i.test(raw.recordingDateNote)) {output.recordingDate=raw.recordingDate;output.recordingDatePrecision=raw.recordingDatePrecision??(raw.recordingDate.length===4?'year':raw.recordingDate.length===7?'month':'day');}
  if(imported&&raw.communitySignals) {const c=raw.communitySignals;output.community={positiveMentions:c.positiveMentionCount,independentPositiveMentions:null,retainedMentions:c.retainedMentions,sampleLimit:20,exportDate:raw.exportDate,note:'Positive labels are rec and strong_rec only, from at most twenty retained mentions. Independence is not verified; references, criticism and jokes are not endorsements.'};}
  const memberships=unique([courseId,...array(raw.courseMemberships).map(x=>x.parentCourse),...array(raw.additionalSourceContexts).map(x=>x.parentCourse)]).filter(id=>courses.has(id));
  const membershipDetails=memberships.map(id=>membershipOrder(raw,id));
  return {record:output,origin,memberships,membershipDetails,sourceInputId:raw.id??canonical.id};
}

function membershipOrder(raw,courseId) {
  const explicit=array(raw.courseMemberships).find(x=>x.parentCourse===courseId);
  if(explicit&&Number.isFinite(explicit.unitOrder)&&Number.isFinite(explicit.lessonOrder))return {courseId,unitOrder:explicit.unitOrder,lessonOrder:explicit.lessonOrder,sourceOrder:raw._sourceOrder??null,basis:'Official parent-course unit and lesson order',sourceUrl:publicURL(explicit.sourceUrl??raw.sourceUrl)};
  const number=/(?:^|\b)(?:lecture|lec)\s*(\d+)/i.exec(raw.title??'')?.[1]??/\/lecture-(\d+)(?:\/|$)/i.exec(raw.sourceUrl??'')?.[1];
  if(number)return {courseId,unitOrder:0,lessonOrder:Number(number),sourceOrder:raw._sourceOrder??null,basis:'Explicit institutional lecture number in title or source URL',sourceUrl:publicURL(raw.sourceUrl)};
  const numberedLesson=/\/lessons\/(\d+)-(\d+)-/.exec(raw.sourceUrl??'');
  if(numberedLesson)return {courseId,unitOrder:Number(numberedLesson[1]),lessonOrder:Number(numberedLesson[2]),sourceOrder:raw._sourceOrder??null,basis:'Publisher unit and lesson numbers in the official lesson URL',sourceUrl:publicURL(raw.sourceUrl)};
  const section=/\/W(\d+)D(\d+)_/i.exec(raw.sourceUrl??'');
  const tutorial=/Tutorial(\d+)/i.exec(raw.sourceUrl??'')?.[1];
  if(section&&tutorial)return {courseId,unitOrder:Number(section[1])*100+Number(section[2]),lessonOrder:Number(tutorial),sourceOrder:raw._sourceOrder??null,basis:'Official week/day and tutorial number; within-page video order remains unestablished',sourceUrl:publicURL(raw.sourceUrl)};
  return {courseId,unitOrder:null,lessonOrder:null,sourceOrder:raw._sourceOrder??null,basis:'Audit discovery order only; original teaching sequence not established',sourceUrl:publicURL(raw.sourceUrl)};
}

const preference=x=>(x.record.providerId==='hackertube-discovery'?0:20)+(x.record.descriptionCheck.status==='checked'?10:0)+(isQualified(x.record)?5:0)+(x.record.courseId?2:0);
export function mergeRecords(inputs, report={conflicts:[]}) {
  const groups=new Map();for(const row of inputs){if(!groups.has(row.record.id))groups.set(row.record.id,[]);groups.get(row.record.id).push(row);}
  const out=[];
  for(const [id,rows] of groups) {
    rows.sort((a,b)=>preference(b)-preference(a)||a.origin.localeCompare(b.origin)||a.record.sourceUrl.localeCompare(b.record.sourceUrl));
    const best=clone(rows[0]);
    best.memberships=sorted(rows.flatMap(x=>x.memberships??[]));
    const details=rows.flatMap(x=>x.membershipDetails??[]);
    best.membershipDetails=best.memberships.map(courseId=>details.filter(x=>x.courseId===courseId).sort((a,b)=>(a.unitOrder===null)-(b.unitOrder===null)||(a.unitOrder??0)-(b.unitOrder??0)||(a.lessonOrder??0)-(b.lessonOrder??0)||(a.sourceOrder??0)-(b.sourceOrder??0))[0]??{courseId,unitOrder:null,lessonOrder:null,sourceOrder:null,basis:'Membership retained; order unknown',sourceUrl:best.record.sourceUrl});
    best.origins=sorted(rows.flatMap(x=>x.origins??[x.origin]));
    best.sourceInputIds=sorted(rows.flatMap(x=>x.sourceInputIds??[x.sourceInputId]).filter(Boolean));
    best.record.provenance=evidenceUnion(...rows.map(x=>x.record.provenance));
    best.record.topics=sorted(rows.flatMap(x=>x.record.topics));
    best.record.tags=sorted(rows.flatMap(x=>x.record.tags??[]));
    best.record.addedAt=rows.map(x=>x.record.addedAt).sort()[0];
    if(!best.record.community)best.record.community=rows.find(x=>x.record.community)?.record.community??null;
    if(best.memberships.length)best.record.courseId=best.memberships[0];
    for(const field of ['title','providerId','speaker','durationSeconds','courseId']) {
      const values=unique(rows.map(x=>x.record[field]).filter(v=>v!==null));
      if(values.length>1)report.conflicts.push({id,field,values,chosen:best.record[field],policy:field==='courseId'?'Lexically first registered membership; all courses retain resource IDs.':'Evidence-specific deterministic preference; alternative source contexts retained in provenance.'});
    }
    out.push(best);
  }
  return out.sort((a,b)=>a.record.id.localeCompare(b.record.id));
}

function fragments(value) {return Array.isArray(value)?value:Object.entries(value??{}).map(([id,rest])=>({id,...rest}));}
// Different upload IDs remain separate records. Only a dated, source-backed
// equivalence decision may make one an alternate; overlap alone creates a hold.
export function applyAlternateReviews(rows, packs, report) {
  const byId=new Map(rows.map(x=>[x.record.id,x]));
  const normalize=id=>typeof id==='string'?id.replace(/^yt:/,'youtube:'):id;
  const review=report.alternateReviews??={confirmed:[],holds:[],unresolvedGroups:[]};
  const mappings=[],holds=[],edges=new Map(rows.filter(x=>x.record.alternateOf).map(x=>[x.record.id,x.record.alternateOf]));
  const checked=(d,file)=>{
    const rawProof=array(d.checkSources),proof=rawProof.map(p=>evidence(p,'alternate-review')).filter(Boolean);
    if(!validDate(d.checkedAt)||!d.checker||!d.reason||!rawProof.length||proof.length!==rawProof.length)throw new Error(`Alternate review lacks complete source receipts, dated reviewer or rationale: ${file}`);
    return proof;
  };
  for(const {file,value} of [...packs].sort((a,b)=>a.file.localeCompare(b.file))) {
    if(!Array.isArray(value?.mappings)||!Array.isArray(value?.unresolved))throw new Error(`Invalid alternate review pack: ${file}`);
    for(const d of value.mappings) {
      const id=normalize(d.id),parent=normalize(d.alternateOf),proof=checked(d,file);
      if(d.status!=='confirmed-equivalent'||!byId.has(id)||!byId.has(parent)||id===parent)throw new Error(`Invalid confirmed alternate mapping: ${file}: ${id}`);
      if(edges.has(id)&&edges.get(id)!==parent)throw new Error(`Conflicting alternate parents for ${id}`);
      edges.set(id,parent);mappings.push({file,d,id,parent,proof});
    }
    for(const d of value.unresolved) {
      const ids=unique(array(d.ids??d.id).map(normalize)),proof=checked(d,file);
      if(!d.status||d.status==='confirmed-equivalent'||!ids.length||ids.some(id=>!byId.has(id))||array(d.primaryIds).map(normalize).some(id=>!byId.has(id)))throw new Error(`Unresolved overlap must name existing, explicit held and primary IDs: ${file}`);
      holds.push({file,d,ids,proof});
    }
  }
  const graph=new Map(rows.map(x=>[x.record.id,{id:x.record.id,alternateOf:edges.get(x.record.id)??null}]));
  const parents=new Map(rows.map(x=>[x.record.id,resolveAlternateId(x.record.id,graph)]));
  for(const {file,d,id,parent,proof} of mappings) {
    const record=byId.get(id).record,canonical=byId.get(parents.get(id)).record;
    record.alternateOf=canonical.id;
    record.provenance=evidenceUnion(record.provenance,proof);
    canonical.provenance=evidenceUnion(canonical.provenance,proof);
    record.qualification={...record.qualification,status:record.qualification.status==='excluded'?'excluded':'candidate',reason:`Confirmed alternate upload of ${canonical.id}. ${d.reason}`,distinctnessResolved:true,distinctnessReview:{status:'confirmed-equivalent',reason:d.reason,checkedAt:d.checkedAt,checker:d.checker,evidenceIds:proof.map(p=>p.id),reviewedParentId:parent,canonicalId:canonical.id}};
    review.confirmed.push({file,id,alternateOf:canonical.id,reviewedParentId:parent,evidenceIds:proof.map(p=>p.id)});
  }
  // Flatten any previously retained chains too; never copy access or descriptive
  // assertions from one upload to another.
  for(const item of rows)if(parents.get(item.record.id)!==item.record.id)item.record.alternateOf=parents.get(item.record.id);
  for(const {file,d,ids,proof} of holds) {
    review.unresolvedGroups.push({file,status:d.status,ids,reason:d.reason,groupId:d.groupId??d.clusterId??null});
    for(const id of ids) {
      const record=byId.get(id).record;
      record.provenance=evidenceUnion(record.provenance,proof);
      record.qualification={...record.qualification,status:record.qualification.status==='excluded'?'excluded':'candidate',reason:`Possible overlapping upload or course edition; distinctness remains unresolved. ${d.reason}`,distinctnessResolved:false,distinctnessReview:{status:'unresolved-overlap',detailStatus:d.status,reason:d.reason,checkedAt:d.checkedAt,checker:d.checker,evidenceIds:proof.map(p=>p.id),relatedIds:unique([...array(d.relatedIds??d.ids??d.id),...array(d.primaryIds)].map(normalize)),primaryIds:array(d.primaryIds).map(normalize),groupId:d.groupId??d.clusterId??null,relationship:d.relationship??null,sourcePositions:d.sourcePositions??null,releaseCondition:d.releaseCondition??null}};
      review.holds.push({file,id,status:d.status,evidenceIds:proof.map(p=>p.id)});
    }
  }
  const groups=new Map();
  for(const {record} of rows)if(record.alternateOf){if(!groups.has(record.alternateOf))groups.set(record.alternateOf,[]);groups.get(record.alternateOf).push({id:record.id,sourceUrl:record.sourceUrl,canonicalUrl:record.canonicalUrl});}
  for(const [id,alternatives] of groups){const canonical=byId.get(id).record;canonical.selection={...canonical.selection,alternateUploads:alternatives.sort((a,b)=>a.id.localeCompare(b.id))};}
  return rows;
}
export function mergeCoreFragments(rows, packs, report) {
  const byId=new Map(rows.map(x=>[x.record.id,x]));
  const aliases=new Map(rows.flatMap(x=>array(x.sourceInputIds??x.sourceInputId).map(id=>[id,x.record.id])));
  for(const {file,value} of packs.sort((a,b)=>a.file.localeCompare(b.file)))for(const fragment of fragments(value)) {
    const normalId=fragment.id?.replace(/^yt:/,'youtube:');const id=aliases.get(fragment.id)??normalId;const item=byId.get(id);
    if(!item){report.orphanEditorialFragments.push({file,id});continue;}
    const proof=[...array(fragment.provenance),...array(fragment.checkSources)].map(p=>evidence(p,`core-${digest(file).slice(0,8)}`)).filter(Boolean);
    const all=evidenceUnion(item.record.provenance,proof);const ids=new Set(all.map(x=>x.id));
    const f=clone(fragment);delete f.id;delete f.checkSources;delete f.provenance;
    const allowed=['description','descriptionCheck','selection','topics','tags','materialType','speaker','level','levelBasis','language','recordingDate','recordingDatePrecision'];
    const proposed={...item.record};
    for(const key of allowed)if(f[key]!==undefined)proposed[key]=f[key];
    if(f.descriptionCheck&&!f.descriptionCheck.evidenceIds?.length)proposed.descriptionCheck={...f.descriptionCheck,evidenceIds:proof.map(x=>x.id)};
    if(f.selection&&!f.selection.evidenceIds?.length)proposed.selection={...f.selection,evidenceIds:proof.map(x=>x.id)};
    if(proposed.descriptionCheck?.status==='checked' && (!validDate(proposed.descriptionCheck.checkedAt)||!proposed.descriptionCheck.checker||!proposed.descriptionCheck.evidenceIds?.length)) {report.editorialFragmentFailures.push({file,id,reason:'Checked description lacks real source-check fields'});continue;}
    if([...(proposed.descriptionCheck?.evidenceIds??[]),...(proposed.selection?.evidenceIds??[])].some(x=>!ids.has(x))) {report.editorialFragmentFailures.push({file,id,reason:'Unresolved evidence IDs'});continue;}
    if(f.topics) {proposed.topics=normaliseTopics(f.topics,report,id);if(!proposed.topics.length){report.editorialFragmentFailures.push({file,id,reason:'No mapped topic'});continue;}}
    for(const field of ['description','descriptionCheck','selection'])if(item.record.descriptionCheck.status==='checked'&&f[field]&&JSON.stringify(item.record[field])!==JSON.stringify(f[field]))report.conflicts.push({id,field,chosenSource:file,policy:'Later lexical source-core pack replaces an earlier source-core fragment; local editorial overrides still win.'});
    if(proposed.descriptionCheck.status==='checked'&&['publisher-description','transcript','viewing'].includes(proposed.descriptionCheck.method)&&proposed.selection.checkedAt&&proposed.selection.checker) {
      proposed.qualification={...proposed.qualification,substanceResolved:true};
      if(proposed.qualification.sourceIdentityResolved!==false&&proposed.availability.status==='accessible'&&proposed.qualification.status!=='excluded')proposed.qualification={...proposed.qualification,status:'qualified',reason:'Individually checked source content and selection, with separately documented permitted accessibility.'};
      else if(proposed.qualification.sourceIdentityResolved!==false&&proposed.qualification.status!=='excluded')proposed.qualification={...proposed.qualification,status:'candidate',reason:'Individual source content and selection checked; qualifying permitted destination accessibility remains unverified in the reusable source catalogue.'};
    }
    proposed.provenance=all;item.record=proposed;report.appliedEditorialFragments.push({file,id});
  }
  return rows;
}

// Source-boundary and topic corrections are separate from description checks.
// A title-only correction must never inflate the checked-core denominator.
export function applyAuditDecisions(rows, packs, report) {
  const byId=new Map(rows.map(x=>[x.record.id,x]));
  for(const {file,value} of packs.sort((a,b)=>a.file.localeCompare(b.file)))for(const d of fragments(value.records??value)) {
    const id=d.id?.replace(/^yt:/,'youtube:');const item=byId.get(id);
    if(!item){report.orphanAuditDecisions.push({file,id});continue;}
    const proof=array(d.checkSources).map(p=>evidence(p,'scope-review')).filter(Boolean);
    if(!proof.length||!validDate(d.checkedAt)||!d.checker||!d.reason||!['retain','supporting','exclude','topic-correction'].includes(d.action)) {
      report.auditDecisionFailures.push({file,id,reason:'Decision lacks source receipts, dated reviewer, rationale or recognised action'});continue;
    }
    const record=item.record;
    record.provenance=evidenceUnion(record.provenance,proof);
    const review={action:d.action,reason:d.reason,checkedAt:d.checkedAt,checker:d.checker,evidenceIds:proof.map(x=>x.id),clusterId:d.clusterId??null};
    record.selection={...record.selection,scopeReview:review};
    if(d.topics) {
      const topics=normaliseTopics(d.topics,report,id);
      if(!topics.length){report.auditDecisionFailures.push({file,id,reason:'No supported correction topic'});continue;}
      record.topics=d.topicMode==='add'?sorted([...record.topics,...topics]):topics;
      record.selection.subjectAssignmentBasis=d.subjectAssignmentBasis??'Individual source title or inspected publisher overview; parent-course breadth is retained separately in the course register.';
    }
    if(['supporting','exclude'].includes(d.action)) {
      record.qualification={...record.qualification,status:'excluded',reason:d.reason,checkedAt:d.checkedAt,checker:d.checker};
      if(d.action==='supporting')item.supportingDecision=review;
    }
    report.appliedAuditDecisions.push({file,id,action:d.action,clusterId:d.clusterId??null});
  }
  return rows;
}

export function applyCommunityReviews(rows, reviews, report) {
  const byId=new Map(rows.map(x=>[x.record.id,x]));
  const grouped=new Map();const seen=new Set();
  for(const r of array(reviews)) {
    const item=byId.get(r.videoId);
    const key=`${r.videoId}:${r.commentId}`;
    const proof=array(r.checkSources).map(p=>evidence(p,'community-review')).filter(Boolean);
    if(!item?.record.community||!Number.isSafeInteger(r.commentId)||seen.has(key)||!validDate(r.checkedAt)||!r.checker||!proof.length) {
      report.communityReviewFailures.push({videoId:r.videoId,commentId:r.commentId,reason:'Missing catalogue community record, unique comment ID or dated source receipt'});continue;
    }
    seen.add(key);
    item.record.provenance=evidenceUnion(item.record.provenance,proof);
    const counted=r.positiveContextConfirmed===true&&['rec','strong_rec'].includes(r.stance)&&r.selfPromotion===false&&r.independenceChecked===true&&proof.length>=3&&!!r.independenceRationale;
    const review={commentId:r.commentId,url:publicURL(r.sourceUrl),stance:r.stance,positiveContextConfirmed:r.positiveContextConfirmed===true,selfPromotion:r.selfPromotion===false?false:r.selfPromotion===true?true:null,independenceChecked:counted,reason:r.independenceRationale??null,checkedAt:r.checkedAt,checker:r.checker,evidenceIds:proof.map(x=>x.id)};
    if(!grouped.has(r.videoId))grouped.set(r.videoId,[]);grouped.get(r.videoId).push(review);
  }
  for(const [id,reviewedMentions] of grouped) {
    const community=byId.get(id).record.community;
    const count=reviewedMentions.filter(x=>x.independenceChecked).length;
    if(count>community.positiveMentions)throw new Error(`Community review exceeds source-positive count: ${id}`);
    community.independentPositiveMentions=count||null;
    community.reviewedMentions=reviewedMentions.sort((a,b)=>a.commentId-b.commentId);
    community.note+=' A bounded public-identity/context review supplies only a checked lower bound of non-creator recommendations; undisclosed affiliations are not ruled out and unreviewed or unresolved mentions remain unknown.';
    report.communityReviews.push({id,reviewed:reviewedMentions.length,checkedNonCreatorRecommendations:count,notCounted:reviewedMentions.filter(x=>!x.independenceChecked).length});
  }
  return rows;
}

function sourceFromCourse(raw) {
  const p=evidence(raw.seedRetrieval,'provider-identity');const terms=evidence(raw.termsRetrieval,'provider-terms');
  return {id:raw.id,name:raw.name,url:publicURL(raw.url??raw.seedUrl),status:p?'verified':'candidate',kind:'institutional-provider',coverage:array(raw.coverage),verificationNote:raw.officialIdentityBasis??null,licence:raw.licence??null,licenceUrl:publicURL(raw.licenceUrl),reuseConditions:raw.reusePolicy??null,accessConditions:raw.accessConditions??null,limitations:array(raw.limitations),provenance:evidenceUnion(p?[p]:[],terms?[terms]:[])};
}
function sourceFromProvider(raw, report) {
  const proof=array(raw.inspectedSourceEvidence).map(x=>evidence(x,'provider-source')).filter(Boolean);
  return {id:raw.providerId,name:raw.name,url:publicURL(raw.initialUrls?.[0]??raw.sourceUrl)??proof[0]?.url??null,status:raw.officialPrimaryPageRetrieved&&proof.length?'verified':'blocked',kind:'provider-or-supporting-source',owner:raw.owner??null,countingProviderId:raw.providerId==='world-science-festival'?'world-science-u':raw.providerId,coverage:normaliseTopics(raw.subjectFamilies,report,`source:${raw.providerId}`),originalSubjectLabels:array(raw.subjectFamilies),verificationNote:raw.verificationNote??null,licence:raw.licenceStatus??null,reuseConditions:raw.reuseConditions??null,accessConditions:raw.status,limitations:[raw.sharedParentNote,...array(raw.failedAttempts).map(x=>typeof x==='string'?x:'A bounded source request failed; see private audit receipt.')].filter(Boolean),provenance:proof};
}
function courseFromRaw(raw, origin, report) {
  const source=evidence(raw.sourceCheck??raw.sourceEvidence??{url:raw.sourceUrl,retrievedAt:raw.sourceRetrievedAt,sha256:raw.sourceSha256,inspection:'Official course title, metadata and outline retrieved; no full lecture viewing.'},'course-source');
  const topics=normaliseTopics(raw.subjectFamilies??raw.families??raw.subjectFamily,report,raw.id);
  return {id:raw.id,title:raw.title,providerId:raw.providerId??raw.provider,sourceUrl:publicURL(raw.sourceUrl??raw.url),topics,topicAssignmentBasis:'Course-level syllabus/collection context; individual lecture topics may be refined separately.',courseInstructor:raw.courseInstructor??raw.speaker??null,statedLevel:raw.statedLevel??raw.level??null,courseLanguage:raw.language??null,term:raw.year?String(raw.year):null,recordingDate:null,uploadDate:null,provenance:source?[source]:[],retrievedAt:source?.retrievedAt??null,resourceIds:[],sequence:[],memberIds:array(raw.memberIds),parentCourseAliases:array(raw.parentCourseAliases),membershipComplete:raw.membershipComplete??null,orderBasis:'Pending reconciliation of source order',status:source?'source-verified':'candidate',kind:raw.kind??'course-or-seminar-collection',origin};
}
function normaliseSupporting(raw, providerMap, candidateById=new Map()) {
  const candidate=candidateById.get(raw.id);const sourceUrl=publicURL(raw.sourceUrl??raw.url??raw.source?.url);if(!sourceUrl)return null;
  const proofs=[...array(raw.evidence),...array(raw.source),...array(raw.sourceEvidence),...array(candidate?.descriptionEvidence)].map(x=>evidence(x,'supporting-source')).filter(Boolean);
  let providerId=providerMap.has(raw.providerId)?raw.providerId:null;
  if(!providerId) {
    const host=new URL(sourceUrl).hostname.replace(/^www\./,'');
    providerId=[...providerMap.values()].find(x=>x.url&&new URL(x.url).hostname.replace(/^www\./,'')===host)?.id??`supporting-source-${host.replace(/[^a-z0-9-]/g,'-')}`;
    if(!providerMap.has(providerId))providerMap.set(providerId,{id:providerId,name:raw.providerName??host,url:new URL(sourceUrl).origin+'/',status:'supporting-source',kind:'supporting-reading-source',coverage:[],licence:raw.licence??null,reuseConditions:'Factual links and original navigation only; no blanket reuse licence established.',verificationNote:'Source receipt exists for this supporting item; no separate verified video-provider identity is claimed.',provenance:evidenceUnion(proofs)});
  }
  return {id:raw.id??`supporting:${digest(sourceUrl).slice(0,16)}`,title:raw.title??raw.source?.title,kind:raw.type??raw.kind??'supporting-resource',providerId,url:sourceUrl,canonicalUrl:publicURL(candidate?.canonicalUrl)??sourceUrl,description:raw.reason??raw.description??raw.purpose??candidate?.originalSynopsis??'Supporting reading or source material; excluded from the substantive video count.',limits:raw.limits??null,provenance:evidenceUnion(proofs),durationSeconds:null,language:null,scientificAssessment:'not-assessed',countsAsCatalogueVideo:false,reuse:{exportAllowed:true,basis:'Factual link metadata and original navigation only; individual source rights remain separate.',sourceLicence:raw.licence??candidate?.sourceLicenceNotes??providerMap.get(providerId).licence??null,attribution:providerMap.get(providerId).name}};
}

export async function normalise({root=DEFAULT_ROOT,write=true}={}) {
  const report={schemaVersion:1,inputs:[],missingOptionalInputs:[],rejectedInputs:[],unmappedTopics:[],conflicts:[],orphanEditorialFragments:[],editorialFragmentFailures:[],appliedEditorialFragments:[],orphanAuditDecisions:[],auditDecisionFailures:[],appliedAuditDecisions:[],communityReviewFailures:[],communityReviews:[],preservedMissingRecords:[],orphanLocalOverrides:[],orphanLocalWithdrawals:[],boundaries:['Only verified official MP4 byte ranges qualify persisted accessibility; authorised API metadata belongs to a private expiring runtime overlay.','Course-level subjects, levels, language and instructors are not asserted as individual lecture metadata.','Bulk descriptions and topic/scope corrections are unchecked and contribute zero to the checked-core target.','Local editorial-overrides.json and withdrawals.json are read but never rewritten.']};
  async function read(file,fallback=null) {
    try {const text=await fs.readFile(path.join(root,file),'utf8');const value=JSON.parse(text);report.inputs.push({file,sha256:digest(text),bytes:Buffer.byteLength(text)});return value;}
    catch(e){if(e.code==='ENOENT'){report.missingOptionalInputs.push(file);return fallback;}throw new Error(`Cannot read a consistent JSON source snapshot: ${file}: ${e.name}`);}
  }
  const oldText=await fs.readFile(path.join(root,'data/catalogue.jsonl'),'utf8').catch(e=>{if(e.code==='ENOENT')return '';throw e;});
  const oldRows=oldText.split('\n').filter(Boolean).map(JSON.parse);
  const oldSources=await read('data/sources.json',[]),oldCourses=await read('data/courses.json',[]),oldSupporting=await read('data/supporting.json',[]);
  const overrides=await read('data/editorial-overrides.json',{}),withdrawals=await read('data/withdrawals.json',[]);
  const priorState=await read('data/normalisation-state.json',{records:{}});
  const courseRows=asRows(await read('data/audits/courses/candidates.json',[]));
  const courseRegister=asRows(await read('data/audits/courses/course-register.json',[]));
  const courseProviders=asRows(await read('data/audits/courses/provider-register.json',[]));
  const providerRows=[...asRows(await read('data/audits/providers/candidate-observations.json',[])),...asRows(await read('data/audits/providers/additional-candidate-observations.json',[]))];
  const providerRegister=[...asRows(await read('data/audits/providers/source-register.json',[])),...asRows(await read('data/audits/providers/additional-source-register.json',[]))];
  const providerCourses=asRows(await read('data/audits/providers/course-register.json',[]));
  const providerRanges=asRows(await read('data/audits/providers/institutional-media-range-checks.json',[]));
  const supportingRaw=asRows(await read('data/audits/providers/supporting-resources.json',[]));
  const hacker=asRows(await read('data/audits/hackertube/candidates.json',[]));
  const hackerReceipt=await read('data/audits/hackertube/export-receipt.json',null);
  const communityReview=await read('data/audits/hackertube/community-context-review.json',null);
  const nptelQualified=await read('data/audits/nptel/qualified-candidates.json',null);
  const nptelPending=await read('data/audits/nptel/pending-accessibility.json',null);
  const nptelReviewed=asRows(await read('data/audits/nptel/reviewed-candidates.json',[]));
  const nptelSplit=Array.isArray(nptelQualified)&&Array.isArray(nptelPending)?[...nptelQualified,...nptelPending]:[];
  const nptelSplitIds=new Set(nptelSplit.map(x=>x.id));
  const nptelComplete=Array.isArray(nptelQualified)&&Array.isArray(nptelPending)&&nptelSplitIds.size===nptelSplit.length&&nptelSplit.length===nptelReviewed.length&&nptelReviewed.every(x=>nptelSplitIds.has(x.id));
  const nptelCourses=nptelComplete?asRows(await read('data/audits/nptel/public-courses.json',[])):[];
  const nptelSource=nptelComplete?await read('data/audits/nptel/source-register.json',null):null;
  const nptelRetrievals=nptelComplete?asRows(await read('data/audits/nptel/source-retrievals.json',[])):[];
  const nptelManifest=nptelComplete?await read('data/audits/nptel/handoff-manifest.json',null):null;
  const nptelMappings=nptelComplete?asRows(await read('data/audits/nptel/media-mappings.json',[])):[];
  const mappingById=new Map(nptelMappings.map(x=>[x.id,x]));
  const sources=new Map(oldSources.map(x=>[x.id,x]));
  for(const raw of courseProviders){const item=sourceFromCourse(raw);sources.set(item.id,item);}
  for(const raw of providerRegister){const item=sourceFromProvider(raw,report);sources.set(item.id,item);}
  if(hacker.length&&hackerReceipt)sources.set('hackertube-discovery',{id:'hackertube-discovery',name:'HackerTube discovery — original provider unverified',url:'https://hackertube.org',status:'discovery-source',kind:'discovery-source',coverage:[],licence:'ODC-By-1.0',licenceUrl:'https://opendatacommons.org/licenses/by/1-0/',reuseConditions:'Credit HackerTube and open-index/hacker-news. Individual content rights are separate. Not an original video provider.',provenance:[evidence(hackerReceipt,'hackertube-export')]});
  if(nptelComplete) {
    const sourceRaw=Array.isArray(nptelSource)?nptelSource.find(x=>(x.id??x.providerId)==='nptel'):nptelSource;
    const proof=nptelRetrievals.filter(x=>[sourceRaw?.identitySource,...array(sourceRaw?.reuse?.evidenceUrls)].includes(x.url)&&x.status===200).map(x=>evidence(x,'nptel-provider',{inspection:x.url===sourceRaw.identitySource?'Official NPTEL identity page inspected.':'Official source licence/terms page inspected; individual content exceptions remain.'})).filter(Boolean);
    sources.set('nptel',{id:'nptel',name:sourceRaw?.name??'NPTEL',url:'https://nptel.ac.in/',status:proof.some(x=>x.url===sourceRaw?.identitySource)?'verified':'candidate',kind:'institutional-course-provider',owner:'NPTEL; partner institutions are course context, not additional counted providers',coverage:[],licence:'CC BY-NC-SA 4.0 site notice; individual-source exceptions apply',reuseConditions:sourceRaw?.reuse?.defaultPublicUse??'Link, factual metadata and original navigation only. No full course prose, transcript or media redistribution.',verificationNote:sourceRaw?.identityStatus??'Official source identity check pending.',limitations:sourceRaw?.limitations??[],provenance:evidenceUnion(proof)});
  }
  const courses=new Map(oldCourses.map(x=>[x.id,{...x,resourceIds:[],sequence:[]} ]));
  for(const raw of courseRegister)courses.set(raw.id,courseFromRaw(raw,'courses',report));
  for(const raw of providerCourses)courses.set(raw.id,{...courseFromRaw(raw,'providers',report),kind:raw.kind??'course-or-series'});
  for(const raw of nptelCourses)courses.set(raw.id,courseFromRaw(raw,'nptel',report));
  const candidates=[...courseRows.map((raw,i)=>({raw:{...raw,_sourceOrder:i},origin:'courses'})),...providerRows.filter(x=>x.editorialRole==='substantial').map(raw=>({raw,origin:'providers'})),...hacker.map(raw=>({raw,origin:'hackertube'})),...(nptelComplete?[...nptelQualified,...nptelPending].map(raw=>({raw,origin:'nptel'})):[])];
  const normal=[];
  for(const {raw:incoming,origin} of candidates) {
    const raw=clone(incoming);
    if(origin==='providers') {
      const id=canonicalIdentity(raw.canonicalUrl).id;
      const matches=[...courses.values()].filter(c=>c.providerId===raw.providerId&&(c.memberIds.includes(id)||c.title===raw.parentCourse||c.parentCourseAliases.includes(raw.parentCourse)));
      if(matches.length) {
        raw.parentCourse=matches.map(c=>c.id).sort()[0];
        raw.courseMemberships=matches.map(c=>({parentCourse:c.id,sourceUrl:c.sourceUrl}));
      }
    }
    if(origin==='nptel') {const m=mappingById.get(raw.id);if(m&&raw.authorisedAlternative)raw.authorisedAlternative.sourceRetrievedAt=m.downloadSourceRetrievedAt;}
    if(origin==='providers') {
      const matched=providerRanges.filter(x=>x.sourcePage===raw.sourceUrl&&[raw.canonicalUrl,raw.institutionalAlternative?.requestedUrl].includes(x.requestedUrl));
      raw.mediaEndpointChecks=[];
      for(const r of matched) {
        const filename=safeCache(r.headerPath);if(!filename)continue;
        const headers=await fs.readFile(path.join(root,filename)).catch(()=>null);
        if(!headers||digest(headers)!==r.headerSha256)continue;
        const ranges=[...headers.toString().matchAll(/^content-range:\s*(.+)$/gmi)];
        raw.mediaEndpointChecks.push({...r,url:r.requestedUrl,checkedAt:r.retrievedAt,bytes:r.bytesSaved,bodyCachePath:r.rangeBodyPath,contentRange:ranges.at(-1)?.[1]?.trim(),finalUrl:r.effectiveUrl});
      }
    }
    if(raw.qualificationStatus==='excluded'){report.rejectedInputs.push({origin,id:raw.id,reason:raw.exclusionReason??'Explicit source audit exclusion'});continue;}
    try {normal.push(await normaliseRecord(raw,origin,{root,report,courses,sources,hackertubeReceipt:hackerReceipt}));}
    catch(e){report.rejectedInputs.push({origin,id:String(raw.id??'missing').slice(0,100),reason:e.message});}
  }
  let merged=mergeRecords(normal,report);
  const generated=new Set(merged.map(x=>x.record.id));
  const activeOrigins=new Set(candidates.map(x=>x.origin));
  for(const record of oldRows)if(!generated.has(record.id)) {
    const owners=priorState.records?.[record.id]?.origins??[];
    const disappeared=owners.length&&owners.every(x=>activeOrigins.has(x));
    const keep=clone(record);
    if(disappeared&&!record.withdrawn){keep.qualification={status:'excluded',reason:'Previously imported record is absent from the current reviewed source snapshot; preserved for editorial history, excluded from release.',checkedAt:record.qualification?.checkedAt??null,checker:CHECKER};keep.withdrawn=true;keep.withdrawalReason='Missing from the current reviewed source snapshot; needs reconciliation.';}
    merged.push({record:keep,origin:'preserved-existing',origins:owners,memberships:priorState.records?.[record.id]?.memberships??(record.courseId?[record.courseId]:[]),membershipDetails:priorState.records?.[record.id]?.membershipDetails??[]});
    report.preservedMissingRecords.push({id:record.id,action:disappeared?'withdrawn-pending-reconciliation':'preserved-source-not-refreshed-or-local-record'});
  }
  const packs=[],decisionPacks=[],supportingPacks=[],alternatePacks=[];
  for(const dir of (await fs.readdir(path.join(root,'data/audits'),{withFileTypes:true})).filter(x=>x.isDirectory()).sort((a,b)=>a.name.localeCompare(b.name))) {
    const file=`data/audits/${dir.name}/core-overrides.json`;try{await fs.access(path.join(root,file));packs.push({file,value:await read(file)});}catch(e){if(e.code!=='ENOENT')throw e;}
    const decisionsFile=`data/audits/${dir.name}/record-decisions.json`;try{await fs.access(path.join(root,decisionsFile));decisionPacks.push({file:decisionsFile,value:await read(decisionsFile)});}catch(e){if(e.code!=='ENOENT')throw e;}
    for(const alternateFile of [`data/audits/${dir.name}/alternate-mappings.json`,`data/audits/${dir.name}/alternate-review/alternate-mappings.json`])try{await fs.access(path.join(root,alternateFile));alternatePacks.push({file:alternateFile,value:await read(alternateFile)});}catch(e){if(e.code!=='ENOENT')throw e;}
    const supportingFile=`data/audits/${dir.name}/supporting-resources.json`;
    if(dir.name!=='providers')try{await fs.access(path.join(root,supportingFile));supportingPacks.push(...asRows(await read(supportingFile)));}catch(e){if(e.code!=='ENOENT')throw e;}
  }
  supportingPacks.push(...asRows(await read('data/audits/providers/editorial-reading-evidence.json',[])));
  merged=mergeCoreFragments(merged,packs,report).sort((a,b)=>a.record.id.localeCompare(b.record.id));
  merged=applyAuditDecisions(merged,decisionPacks,report);
  merged=applyCommunityReviews(merged,communityReview?.reviews,report);
  merged=applyAlternateReviews(merged,alternatePacks,report);
  const recordById=new Map(merged.map(x=>[x.record.id,x.record]));
  for(const item of merged)for(const id of item.memberships)if(courses.has(id)) {
    const detail=item.membershipDetails?.find(x=>x.courseId===id)??{unitOrder:null,lessonOrder:null,sourceOrder:null,basis:'Membership retained; order unknown',sourceUrl:item.record.sourceUrl};
    const resourceId=resolveAlternateId(item.record.id,recordById);
    courses.get(id).sequence.push({resourceId,...(resourceId!==item.record.id?{sourceResourceId:item.record.id}:{}),...detail});
  }
  for(const c of courses.values()) {
    c.sequence.sort((a,b)=>(a.unitOrder===null)-(b.unitOrder===null)||(a.unitOrder??0)-(b.unitOrder??0)||(a.lessonOrder??0)-(b.lessonOrder??0)||(a.sourceOrder??0)-(b.sourceOrder??0)||a.resourceId.localeCompare(b.resourceId));
    c.resourceIds=unique(c.sequence.map(x=>x.resourceId));
    c.orderBasis=unique(c.sequence.map(x=>x.basis)).join('; ');
  }
  const supporting=new Map(oldSupporting.map(x=>[x.id,x]));
  const providerIndex=new Map(providerRows.map(x=>[x.id,x]));
  for(const raw of supportingRaw){const s=normaliseSupporting(raw,sources,providerIndex);if(s)supporting.set(s.id,s);}
  for(const raw of supportingPacks){const s=normaliseSupporting(raw,sources);if(s)supporting.set(s.id,s);}
  for(const item of merged.filter(x=>x.supportingDecision)) {
    const r=item.record;
    const s=normaliseSupporting({id:`context:${r.id}`,title:r.title,providerId:r.providerId,sourceUrl:r.sourceUrl,type:'contextual-video',reason:item.supportingDecision.reason,evidence:r.provenance,limits:'Retained as course background; outside the qualified mind, brain and behaviour video denominator.'},sources,new Map([[`context:${r.id}`,{canonicalUrl:r.canonicalUrl}]]));
    if(s)supporting.set(s.id,s);
  }
  const courseIndex=new Map(courseRows.map(x=>[x.id,x]));
  for(const raw of courseRows.filter(x=>x.qualificationStatus==='excluded'&&/recap/i.test(x.exclusionReason??''))) {
    const s=normaliseSupporting({...raw,type:'course-recap',reason:raw.exclusionReason,evidence:raw.retrieval},sources,courseIndex);if(s)supporting.set(s.id,s);
  }
  for(const c of nptelCourses.filter(x=>x.contentType==='Web'&&x.scopeStatus!=='excluded')) {
    const s=normaliseSupporting({id:`supporting:${c.id}`,title:c.title,providerId:'nptel',sourceUrl:c.sourceUrl,type:'web-course',reason:'Source-listed web course retained as supporting reading, separate from lecture/video totals.',evidence:{url:c.sourceUrl,retrievedAt:c.sourceRetrievedAt,sha256:c.sourceSha256,inspection:'Official web-course title and outline inspected; not a video resource.'}},sources);if(s)supporting.set(s.id,s);
  }
  const records=merged.map(x=>x.record);
  const withdrawn=new Map(withdrawals.map(x=>[x.id,x]));
  const effective=records.map(r=>({...r,...overrides[r.id],qualification:{...r.qualification,...overrides[r.id]?.qualification},...(withdrawn.has(r.id)?{withdrawn:true,withdrawalReason:withdrawn.get(r.id).reason}: {})}));
  const effectiveById=new Map(effective.map(r=>[r.id,r]));
  for(const r of effective)resolveAlternateId(r.id,effectiveById);
  const currentIds=new Set(records.map(x=>x.id));
  report.orphanLocalOverrides=Object.keys(overrides).filter(id=>!currentIds.has(id));
  report.orphanLocalWithdrawals=withdrawals.filter(x=>!currentIds.has(x.id)).map(x=>x.id);
  const schema=JSON.parse(await fs.readFile(path.join(DEFAULT_ROOT,'data/schema/video.schema.json'),'utf8'));
  const check=new Ajv({allErrors:true,strict:false}).compile(schema);
  const schemaErrors=[];
  for(const r of effective)if(!check(r))schemaErrors.push({id:r.id,errors:check.errors.map(x=>`${x.instancePath} ${x.message}`)});
  report.schemaErrors=schemaErrors;
  if(schemaErrors.length)throw new Error(`Normalised output failed schema validation for ${schemaErrors.length} record(s): ${schemaErrors.slice(0,3).map(x=>x.id+': '+x.errors.join('; ')).join(' | ')}`);
  const state={version:1,records:Object.fromEntries(merged.map(x=>[x.record.id,{origins:x.origins??[x.origin],memberships:x.memberships,membershipDetails:x.membershipDetails??[]}]))};
  const qualified=effective.filter(isQualified);
  report.counts={inputCandidates:candidates.length,normalisedCanonicalRecords:records.length,canonicalVideos:effective.filter(x=>!x.alternateOf&&!x.withdrawn).length,alternateUploads:effective.filter(x=>x.alternateOf).length,unresolvedDistinctness:effective.filter(x=>x.qualification.distinctnessResolved===false).length,qualifiedAccessibleVideos:qualified.length,unqualifiedRecords:effective.length-qualified.length,excludedOrWithdrawn:effective.filter(x=>x.qualification.status==='excluded'||x.withdrawn).length,coursesWithRecords:[...courses.values()].filter(x=>x.resourceIds.length).length,sourceRegisterEntries:sources.size,verifiedSourceIdentities:[...sources.values()].filter(x=>x.status==='verified').length,qualifiedVideoProviders:new Set(qualified.map(x=>x.providerId)).size,supportingResources:supporting.size,localOverrideEntries:Object.keys(overrides).length,localWithdrawals:withdrawals.length,appliedSourceCoreFragments:report.appliedEditorialFragments.length,checkedCore:qualified.filter(x=>x.descriptionCheck.status==='checked'&&['publisher-description','transcript','viewing'].includes(x.descriptionCheck.method)&&x.selection.checkedAt&&x.selection.checker).length};
  report.nptelSnapshotComplete=nptelComplete;
  report.inputs.sort((a,b)=>a.file.localeCompare(b.file));
  if(nptelManifest)for(const [name,sha] of Object.entries(nptelManifest.files??{})) {
    const item=report.inputs.find(x=>x.file===`data/audits/nptel/${name}`);
    if(item&&item.sha256!==sha)throw new Error(`NPTEL handoff checksum mismatch: ${name}`);
  }
  // Input changes during a read invalidate this run before output is replaced.
  for(const input of report.inputs){const current=await fs.readFile(path.join(root,input.file));if(digest(current)!==input.sha256)throw new Error(`Source changed during normalisation; rerun from the new snapshot: ${input.file}`);}
  if(write) {
    const outputs=new Map([
      ['data/catalogue.jsonl',records.map(x=>JSON.stringify(x)).join('\n')+'\n'],
      ['data/sources.json',stable([...sources.values()].sort((a,b)=>a.id.localeCompare(b.id)))],
      ['data/courses.json',stable([...courses.values()].filter(x=>x.resourceIds.length).sort((a,b)=>a.id.localeCompare(b.id)))],
      ['data/supporting.json',stable([...supporting.values()].sort((a,b)=>a.id.localeCompare(b.id)))],
      ['data/normalisation-state.json',stable(state)],
    ]);
    report.outputHashes=Object.fromEntries([...outputs].map(([file,text])=>[file,digest(text)]));
    for(const [file,text] of outputs)await atomicWrite(root,file,text);
    await atomicWrite(root,'evaluation/normalisation-reconciliation.json',stable(report));
  }
  return {records,effectiveRecords:effective,sources:[...sources.values()],courses:[...courses.values()].filter(x=>x.resourceIds.length),supporting:[...supporting.values()],report};
}
async function atomicWrite(root,file,text) {
  const target=path.join(root,file);await fs.mkdir(path.dirname(target),{recursive:true});
  const current=await fs.readFile(target,'utf8').catch(e=>{if(e.code==='ENOENT')return null;throw e;});
  if(current===text)return;
  const temp=`${target}.normalise-${process.pid}.tmp`;
  try{await fs.writeFile(temp,text,{mode:0o600});await fs.rename(temp,target);}finally{await fs.rm(temp,{force:true});}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href) {
  try {const result=await normalise();console.log(JSON.stringify({counts:result.report.counts,nptelSnapshotComplete:result.report.nptelSnapshotComplete,rejectedInputs:result.report.rejectedInputs.length,unmappedTopics:result.report.unmappedTopics.length,conflicts:result.report.conflicts.length,report:'evaluation/normalisation-reconciliation.json'},null,2));}
  catch(error){console.error(`Normalisation stopped without accepting a changed source snapshot: ${error.message}`);process.exitCode=1;}
}
