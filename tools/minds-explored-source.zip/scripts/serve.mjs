import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
import {ROOT} from './data.mjs';
const root=path.join(ROOT,'dist'),port=Number(process.env.PORT??4173);
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.woff2':'font/woff2','.xml':'application/xml','.txt':'text/plain; charset=utf-8','.md':'text/markdown; charset=utf-8'};
http.createServer(async(req,res)=>{
  try{const u=new URL(req.url,'http://localhost'),decoded=decodeURIComponent(u.pathname);if(decoded.includes('\0'))throw Error('Invalid path');let file=path.resolve(root,'.'+decoded);if(!file.startsWith(root+path.sep)&&file!==root){res.writeHead(403);res.end('Forbidden');return;}
    let status=200;try{if((await fs.stat(file)).isDirectory())file=path.join(file,'index.html');}catch{file=path.join(root,'404.html');status=404;}
    const body=await fs.readFile(file),compress=/gzip/.test(req.headers['accept-encoding']??'')&&['.html','.css','.mjs','.js','.json','.xml','.md','.txt'].includes(path.extname(file)),payload=compress?gzipSync(body):body;
    res.writeHead(status,{'Content-Type':types[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Vary':'Accept-Encoding','Content-Length':payload.length,...(compress?{'Content-Encoding':'gzip'}:{})});res.end(req.method==='HEAD'?undefined:payload);
  }catch{res.writeHead(500,{'Content-Type':'text/plain'});res.end('The local build is unavailable. Run npm run build.');}
}).listen(port,'127.0.0.1',()=>console.log(`Atlas local preview: http://127.0.0.1:${port}/`));
