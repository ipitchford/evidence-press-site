import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';

export const MAX_API_AGE_MS = 28 * 24 * 60 * 60 * 1000;
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const API_METHOD = 'authorised-api-metadata';
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const own = (object, key) => Object.hasOwn(object, key);
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);

// This is an allowlist, not a recursive deletion rule. Mixed files are redacted,
// never deleted: their independent notes, source material and receipts survive.
export const EVALUATION_API_MANIFEST = Object.freeze([
  {file: 'evaluation/source-sample/snapshot.json', type: 'records'},
  {file: 'evaluation/source-sample/access-inspection.json', type: 'access'},
  {file: 'evaluation/source-sample/records.jsonl', type: 'mixed-review'},
  {file: 'evaluation/source-sample/inspection-packet.json', type: 'source-projection'},
  {file: 'evaluation/source-sample/repair-readback.json', type: 'mixed-review'},
  {file: 'evaluation/editorial-review/current-resources.json', type: 'records'},
  {file: 'evaluation/editorial-review/access-checks.json', type: 'access'},
  {file: 'evaluation/editorial-review/reviews.jsonl', type: 'mixed-review'},
  {file: 'evaluation/search-results.json', type: 'search'},
  {file: 'evaluation/pre-tuning-search-results.json', type: 'search'},
  {file: 'evaluation/search-manual-review.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/pre-tuning-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/intermediate-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/coverage-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/noise-filter-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/pre-genetics-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/manual-review-pre-genetics.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/pre-overlap-search-results.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/manual-review-pre-overlap.json', type: 'search'},
  {file: 'evaluation/search-review-inputs/selected-records.json', type: 'records'},
  {directory: 'evaluation/search-review-inputs', filenamePattern: '^manual-review-[0-9]{6}\\.json$', type: 'search'},
]);

function timestamp(value) {
  // Reject locale-dependent dates and date-only copy labels.
  if (typeof value !== 'string' || !/^\d{4}-\d\d-\d\dT.+(?:Z|[+-]\d\d:\d\d)$/.test(value)) return null;
  const result = Date.parse(value);
  return Number.isFinite(result) ? result : null;
}

export function retentionClock(checkedAt, expiresAt) {
  const start = timestamp(checkedAt);
  if (start === null) return null;
  const declared = timestamp(expiresAt);
  // An absent/invalid later-expiry label never extends the 28-day hard limit.
  const end = Math.min(start + MAX_API_AGE_MS, declared ?? Infinity);
  return {checkedAt: new Date(start).toISOString(), expiresAt: new Date(end).toISOString(), start, end};
}

function apiProvenance(value) {
  return [...(Array.isArray(value.provenance) ? value.provenance : []), ...(Array.isArray(value.retrievalProvenance) ? value.retrievalProvenance : [])]
    .filter(p => isObject(p) && (String(p.id).startsWith('youtube-api-') || String(p.cachePath).startsWith('.cache/youtube/')));
}

function localClock(value) {
  if (!isObject(value)) return null;
  // Prefer the actual overlay block to an older receipt also present in a record.
  for (const candidate of [value.apiMetadata, value.api, value.apiInspection,
    value.availability?.method === API_METHOD ? value.availability : null,
    value.access?.method === API_METHOD ? value.access : null,
    value.method === API_METHOD ? value : null]) {
    if (candidate) {
      const clock = retentionClock(candidate.checkedAt, candidate.expiresAt);
      if (clock) return clock;
    }
  }
  const clocks = apiProvenance(value).map(p => retentionClock(p.retrievedAt)).filter(Boolean);
  if (clocks.length) return clocks.sort((a, b) => a.start - b.start)[0];
  return null;
}

async function safeFile(root, relative, optional = true) {
  if (path.isAbsolute(relative) || relative.split(/[\\/]/).includes('..')) throw Error('Unsafe retention path');
  let current = root;
  for (const part of relative.split('/')) {
    current = path.join(current, part);
    let stat;
    try { stat = await fs.lstat(current); }
    catch (error) { if (error.code === 'ENOENT' && optional) return null; throw error; }
    if (stat.isSymbolicLink()) throw Error(`Retention refuses symlink: ${relative}`);
    if (current !== path.join(root, relative) && !stat.isDirectory()) throw Error(`Retention ancestor is not a directory: ${relative}`);
  }
  const stat = await fs.stat(current);
  if (!stat.isFile()) throw Error(`Retention target is not a regular file: ${relative}`);
  return current;
}

async function manifestFiles(root) {
  const found = [];
  for (const entry of EVALUATION_API_MANIFEST) {
    if (entry.file) { found.push(entry); continue; }
    // Inspect the directory itself before enumeration; never follow a link.
    const marker = path.join(root, entry.directory);
    let stat;
    try { stat = await fs.lstat(marker); } catch (e) { if (e.code === 'ENOENT') continue; throw e; }
    if (stat.isSymbolicLink() || !stat.isDirectory()) throw Error(`Retention refuses directory: ${entry.directory}`);
    for (const name of (await fs.readdir(marker)).sort()) {
      if (new RegExp(entry.filenamePattern).test(name)) found.push({file: `${entry.directory}/${name}`, type: entry.type});
    }
  }
  return found;
}

function parseDocument(text, file) {
  return file.endsWith('.jsonl') ? text.split('\n').filter(line => line.trim()).map(line => JSON.parse(line)) : JSON.parse(text);
}

function walkObjects(value, visit) {
  if (Array.isArray(value)) { for (const item of value) walkObjects(item, visit); return; }
  if (!isObject(value)) return;
  visit(value);
  for (const [key, item] of Object.entries(value)) if (key !== 'apiRetention') walkObjects(item, visit);
}

function buildClockIndex(documents, cache) {
  const byId = new Map();
  function add(id, clock) {
    if (typeof id !== 'string' || !id.startsWith('youtube:') || !clock) return;
    const list = byId.get(id) ?? [];
    list.push(clock); byId.set(id, list);
  }
  for (const doc of documents) walkObjects(doc.value, value => {
    add(value.id, localClock(value));
    for (const event of value.apiRetention?.events ?? []) add(value.id, retentionClock(event.originalCheckedAt, event.effectiveExpiresAt));
  });
  for (const [id, value] of Object.entries(cache?.records ?? {})) add(`youtube:${id}`, retentionClock(value.checkedAt, value.expiresAt));
  // The oldest evidenced retrieval is conservative for a projection that lost
  // its API clock. A cache refresh must never make an older copy young again.
  for (const list of byId.values()) list.sort((a, b) => a.start - b.start);
  return byId;
}

function transformDocument(document, clockIndex, frozenRecords, now) {
  const value = structuredClone(document.value), changes = [], blocked = [];
  const removedAt = new Date(now).toISOString();
  function remove(object, key, clock, pointer) {
    if (!own(object, key)) return;
    const old = object[key]; delete object[key];
    const event = {field: key, originalCheckedAt: clock.checkedAt, effectiveExpiresAt: clock.expiresAt,
      removedAt, removedValueSha256: digest(JSON.stringify(old))};
    object.apiRetention ??= {policy: 'API-derived values removed; independent source material and review conclusions retained.', events: []};
    object.apiRetention.events.push(event);
    changes.push({pointer: `${pointer}/${key}`, originalCheckedAt: clock.checkedAt, effectiveExpiresAt: clock.expiresAt});
  }
  function needClock(clock, id, upper, pointer) {
    if (clock) return clock;
    // Copy/report time is only an upper bound on an original retrieval. It is
    // never itself the retention start, and a later refresh is ineligible.
    const candidate = upper !== null ? clockIndex.get(id)?.find(c => c.start <= upper) : null;
    if (candidate) return candidate;
    blocked.push({pointer, id: id ?? null, reason: 'Original API retrieval time cannot be established. No copy-time lifetime is granted.'});
    return null;
  }
  function visit(node, pointer = '', inherited = null, inheritedId = null, upper = null) {
    if (Array.isArray(node)) { node.forEach((item, i) => visit(item, `${pointer}/${i}`, inherited, inheritedId, upper)); return; }
    if (!isObject(node)) return;
    const id = typeof node.id === 'string' ? node.id : inheritedId;
    const reportTime = timestamp(node.reviewedAt) ?? timestamp(node.checkedAt) ?? timestamp(node.indexBuiltAt);
    const isReport = pointer === '' || own(node, 'reviewedAt') || ['records', 'tasks', 'runs'].some(key => own(node, key));
    if (isReport && reportTime !== null && node.method !== API_METHOD) upper = reportTime;
    const clock = localClock(node) ?? inherited;
    const expired = c => c && now >= c.end;
    for (const key of ['apiMetadata', 'api', 'apiInspection']) {
      if (!isObject(node[key])) continue;
      const c = retentionClock(node[key].checkedAt, node[key].expiresAt) ?? needClock(clock, id, upper, `${pointer}/${key}`);
      if (expired(c)) remove(node, key, c, pointer);
    }
    for (const [field, origin] of [['durationSeconds', 'durationOrigin'], ['language', 'languageOrigin'], ['uploadDate', 'uploadDateOrigin'], ['recordingDate', 'recordingDateOrigin']]) {
      if (node[origin] !== 'youtube-api') continue;
      const c = needClock(clock, id, upper, `${pointer}/${field}`);
      if (expired(c)) { remove(node, field, c, pointer); remove(node, origin, c, pointer); }
    }
    if (node.method === API_METHOD) {
      const fields = ['status', 'note', 'qualification'];
      if (fields.some(key => own(node, key))) {
        const c = needClock(clock, id, upper, pointer);
        if (expired(c)) for (const key of fields) remove(node, key, c, pointer);
      }
    }
    if (String(node.accessEvidence).startsWith('youtube-api-') && own(node, 'status') && node.status !== 'excluded') {
      const c = needClock(clock, id, upper, `${pointer}/status`);
      if (expired(c)) remove(node, 'status', c, pointer);
    }
    if (node.method === 'official-media-range' && typeof node.note === 'string' && node.note.includes('Separate YouTube API check')) {
      const c = needClock(clock, id, upper, `${pointer}/note`);
      if (expired(c)) {
        const note = node.note.split('Separate YouTube API check')[0].trim();
        remove(node, 'note', c, pointer);
        node.note = note; // Preserve the independent range-observation wording.
      }
    }
    if (document.type === 'source-projection' && typeof node.id === 'string') {
      const original = frozenRecords.get(node.id);
      for (const [field, origin] of [['durationSeconds', 'durationOrigin'], ['language', 'languageOrigin'], ['recordingDate', 'recordingDateOrigin']]) {
        const wasAPI = original?.[origin] === 'youtube-api' || original?.apiRetention?.events?.some(e => e.field === origin);
        if (wasAPI && own(node, field)) {
          const c = localClock(original) ?? needClock(clock, id, upper, `${pointer}/${field}`);
          if (expired(c)) remove(node, field, c, pointer);
        } else if (!original && node[field] != null) {
          blocked.push({pointer: `${pointer}/${field}`, id, reason: 'Projection lacks its frozen origin-labelled record; source-derived and API-derived values cannot safely be separated.'});
        }
      }
    }
    if (document.type === 'search' && String(node.id).startsWith('youtube:') && typeof node.qualified === 'boolean') {
      const c = needClock(clock, id, upper, `${pointer}/qualified`);
      if (expired(c)) remove(node, 'qualified', c, pointer);
    }
    // API provenance, source-text blocks, review prose and their hashes are not
    // expiry targets. Their dates are evidence references, not live API values.
    for (const [key, child] of Object.entries(node)) {
      if (['apiRetention', 'provenance', 'retrievalProvenance', 'sourceReceiptChecks', 'sourceText', 'sourceBlocks', 'sources'].includes(key)) continue;
      visit(child, `${pointer}/${key}`, clock, id, upper);
    }
  }
  visit(value);
  return {value, changes, blocked};
}

export async function purgeEvaluationAPIData({root = ROOT, now = Date.now(), apply = false} = {}) {
  if (!Number.isFinite(now)) throw Error('Invalid retention clock');
  root = await fs.realpath(root);
  const documents = [];
  for (const entry of await manifestFiles(root)) {
    const absolute = await safeFile(root, entry.file);
    if (!absolute) continue;
    const text = await fs.readFile(absolute, 'utf8');
    documents.push({...entry, absolute, text, sha256: digest(text), value: parseDocument(text, entry.file)});
  }
  const cachePath = await safeFile(root, '.cache/youtube/metadata.json');
  const cache = cachePath ? JSON.parse(await fs.readFile(cachePath, 'utf8')) : null;
  const clockIndex = buildClockIndex(documents, cache);
  const frozen = documents.find(d => d.file === 'evaluation/source-sample/snapshot.json')?.value ?? [];
  const frozenRecords = new Map(frozen.map(r => [r.id, r]));
  const plans = documents.map(document => ({document, ...transformDocument(document, clockIndex, frozenRecords, now)}));
  const blocked = plans.flatMap(p => p.blocked.map(b => ({file: p.document.file, ...b})));
  const changed = plans.filter(p => p.changes.length);
  // Validate all paths/input hashes before any write. A concurrent author or an
  // untraceable date blocks the run rather than permitting a partial cleanup.
  if (apply && !blocked.length) {
    for (const p of changed) {
      const file = await safeFile(root, p.document.file, false);
      if (digest(await fs.readFile(file)) !== p.document.sha256) throw Error(`Retention input changed: ${p.document.file}`);
    }
    for (const p of changed) {
      const output = p.document.file.endsWith('.jsonl') ? p.value.map(r => JSON.stringify(r)).join('\n') + '\n' : JSON.stringify(p.value, null, 2) + '\n';
      const temporary = `${p.document.absolute}.retention-${crypto.randomUUID()}.tmp`;
      try {
        await fs.writeFile(temporary, output, {flag: 'wx', mode: 0o600});
        await fs.rename(temporary, p.document.absolute);
      } finally { await fs.unlink(temporary).catch(e => { if (e.code !== 'ENOENT') throw e; }); }
    }
  }
  return {
    checkedAt: new Date(now).toISOString(), maxAgeDays: 28, mode: apply ? 'apply' : 'dry-run',
    applied: apply && !blocked.length, inspectedFiles: documents.length,
    changedFiles: changed.map(p => ({file: p.document.file, beforeSha256: p.document.sha256, redactions: p.changes.length,
      firstExpiry: p.changes.map(c => c.effectiveExpiresAt).sort()[0]})),
    redactions: changed.reduce((n, p) => n + p.changes.length, 0), blocked,
    preserved: 'Independent review prose, source records/text, provenance and hashes. No credentials read, network requests, or public redistribution.',
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const flags = process.argv.slice(2);
  if (flags.some(flag => !['--apply', '--dry-run', '--manifest'].includes(flag)) || (flags.includes('--apply') && flags.includes('--dry-run'))) {
    throw Error('Usage: node scripts/api-retention.mjs [--dry-run|--apply|--manifest]');
  }
  if (flags.includes('--manifest')) console.log(JSON.stringify(EVALUATION_API_MANIFEST, null, 2));
  else {
    const report = await purgeEvaluationAPIData({apply: flags.includes('--apply')});
    console.log(JSON.stringify(report, null, 2));
    if (report.blocked.length) process.exitCode = 1;
  }
}
