import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import MarkdownIt from 'markdown-it';
import {canonicalVideo,isDiscoverable} from '../src/model.mjs';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const utils=new MarkdownIt().utils;
const decode=value=>String(value??'').replace(/&(?:#[xX][0-9a-fA-F]+|#\d+|[A-Za-z][A-Za-z0-9]+);/g,x=>utils.unescapeAll(x));
const plain=value=>decode(String(value??'').replace(/<[^>]*>/g,' ')).replace(/\s+/g,' ').trim();
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
const TEXT=/\.(?:html?|svg|xml|css|m?js|jsonl?|md|txt|map|ya?ml|toml|ini|csv)$/i;
const EXPORT_FIELDS=new Set(['id','title','url','sourceUrl','providerId','topics','attribution','licence','annotationLicence','description']);
export const FREE_LIMITS={maxFiles:20000,maxAssetBytes:25*1024*1024,maxHeaderRules:100,maxHeaderCharacters:2000,source:'https://developers.cloudflare.com/pages/platform/limits/',verifiedAt:'2026-11-07',scope:'Cloudflare Pages Free static-file limits; no account, quota consumption or deployment is inspected.'};
const routeFor=file=>file==='index.html'?'/':file.endsWith('/index.html')?'/'+file.slice(0,-10):'/'+file;
const aliasCanonical=file=>file==='404.html'?'/404/':routeFor(file);
const meaningful=(s,min)=>s.length>=min&&!/^(?:untitled|undefined|null|nan|\[object Object\]|todo|tbd|placeholder|lorem ipsum|index\.html?)(?:\s*[|–—-].*)?$/i.test(s)&&/[\p{L}\p{N}]/u.test(s);
const VOID_TAGS=new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);

function attributes(text){
  const out={};for(const m of text.matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))out[m[1].toLowerCase()]=decode(m[2]??m[3]??m[4]??'');return out;
}
function cssReferences(text){
  const refs=[];
  for(const m of text.matchAll(/url\(\s*(?:"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|([^\s)]+))\s*\)/gi))refs.push(m[1]??m[2]??m[3]);
  for(const m of text.matchAll(/@import\s+["']([^"']+)["']/gi))refs.push(m[1]);
  return refs;
}

// Tokenise generated markup without executing scripts or loading a DOM/network.
// Quoted '>' characters and raw script/style bodies do not create false tags.
export function inspectMarkup(text){
  const doc={ids:new Set(),duplicateIds:[],refs:[],titles:[],h1:[],descriptions:[],canonicals:[],jsonScripts:[],baseHrefs:[],openTitles:0,openH1:0,playerContainers:0,anchors:[]};
  const captures=[],stack=[];let at=0;
  while(at<text.length){
    const start=text.indexOf('<',at);if(start<0)break;
    if(text.startsWith('<!--',start)){const end=text.indexOf('-->',start+4);at=end<0?text.length:end+3;continue;}
    const nameMatch=/^<(\/?)([A-Za-z][\w:-]*)\b/.exec(text.slice(start));
    if(!nameMatch){at=start+1;continue;}
    let end=start+nameMatch[0].length,quote=null;
    for(;end<text.length;end++){const c=text[end];if(quote){if(c===quote)quote=null;}else if(c==='"'||c==="'")quote=c;else if(c==='>')break;}
    if(end>=text.length)break;
    const tag=nameMatch[2].toLowerCase(),closing=!!nameMatch[1],a=closing?{}:attributes(text.slice(start+nameMatch[0].length,end));at=end+1;
    if(closing){
      const i=captures.findLastIndex(x=>x.tag===tag);if(i>=0){const c=captures.splice(i,1)[0];doc[tag==='title'?'titles':'h1'].push(plain(text.slice(c.start,start)));}
      const j=stack.findLastIndex(x=>x.tag===tag);if(j>=0){const node=stack[j];if(tag==='a'&&node.anchor)node.anchor.label=node.anchor.ariaLabel||plain(text.slice(node.start,start));stack.splice(j);}
      continue;
    }
    const parent=stack.at(-1),insidePlayer=Boolean(parent?.insidePlayer||a['data-player']!==undefined);
    const unavailable=Boolean(parent?.unavailable||a.hidden!==undefined||a.inert!==undefined||a['aria-hidden']==='true'||['template','noscript','head'].includes(tag)||/(?:^|;)\s*(?:display\s*:\s*none|visibility\s*:\s*hidden)\b/i.test(a.style??''));
    if(a['data-player']!==undefined)doc.playerContainers++;
    const anchor=tag==='a'?{href:a.href??'',label:null,ariaLabel:a['aria-label']??null,insidePlayer,unavailable}:null;
    if(anchor)doc.anchors.push(anchor);
    if(tag==='title'||tag==='h1'){captures.push({tag,start:at});doc[tag==='title'?'openTitles':'openH1']++;}
    if(a.id!==undefined){if(doc.ids.has(a.id))doc.duplicateIds.push(a.id);doc.ids.add(a.id);}
    if(tag==='a'&&a.name)doc.ids.add(a.name);
    if(tag==='meta'&&a.name?.toLowerCase()==='description')doc.descriptions.push(plain(a.content));
    if(tag==='link'&&a.rel?.toLowerCase().split(/\s+/).includes('canonical'))doc.canonicals.push(a.href??'');
    if(tag==='base')doc.baseHrefs.push(a.href??'');
    for(const key of ['href','src','poster','action'])if(a[key])doc.refs.push({value:a[key],kind:`${tag}.${key}`});
    if(a.srcset)for(const item of a.srcset.split(',')){const value=item.trim().split(/\s+/)[0];if(value)doc.refs.push({value,kind:`${tag}.srcset`});}
    if(a.style)doc.refs.push(...cssReferences(a.style).map(value=>({value,kind:'inline-style.url'})));
    if(tag==='script'||tag==='style'){
      const rest=text.slice(at),match=new RegExp(`</${tag}\\s*>`,'i').exec(rest),body=match?rest.slice(0,match.index):rest;
      if(tag==='style')doc.refs.push(...cssReferences(body).map(value=>({value,kind:'style.url'})));
      if(tag==='script'&&/^(?:application\/json|application\/ld\+json)$/i.test(a.type??''))doc.jsonScripts.push({id:a.id??null,text:body});
      at=match?at+match.index+match[0].length:text.length;
    }else if(!VOID_TAGS.has(tag)&&! /\/\s*$/.test(text.slice(start+nameMatch[0].length,end)))stack.push({tag,start:at,insidePlayer,unavailable,anchor});
  }
  return doc;
}

async function inventory(dir,prefix=''){
  const files=[];for(const ent of (await fs.readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const rel=prefix+ent.name,full=path.join(dir,ent.name);if(ent.isDirectory())files.push(...await inventory(full,rel+'/'));else{const st=await fs.lstat(full);files.push({file:rel,bytes:st.size,mtimeMs:st.mtimeMs,symlink:st.isSymbolicLink(),regular:st.isFile()});}}return files;
}
function privacyFindings(text){
  const checks=[
    ['private-path',/(?:file:\/\/|\/Users\/|\/Volumes\/|\/private\/(?:tmp|var)\/|(?:^|[\s"'`(/])(?:data\/(?:raw|audits|editorial-checks)\/|\.cache\/youtube\/|\.config\/))/m],
    ['synthetic-fixture',/(?:synthetic-performance:|\[fixture\d+\]|THIS MUST NEVER APPEAR IN EXPORT|fixture source page)/i],
    ['credential-key',/\b(?:AIza[A-Za-z0-9_-]{30,}|sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|ya29\.[A-Za-z0-9._-]{20,})\b/],
    ['credential-field',/["'](?:access_token|refresh_token|client_secret|private_key|OPENAI_API_KEY|YOUTUBE_API_KEY)["']\s*:/i],
    ['credential-assignment',/\b(?:OPENAI_API_KEY|YOUTUBE_API_KEY|CLIENT_SECRET|ACCESS_TOKEN|REFRESH_TOKEN)\s*=\s*["']?[A-Za-z0-9_./+-]{12,}/],
    ['credential-query',/[?&](?:api[_-]?key|access[_-]?token|refresh[_-]?token|signature|x-amz-credential)=/i],
    ['private-key',/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
    ['raw-youtube-payload',/(?:["']kind["']\s*:\s*["']youtube#(?:video|videoListResponse|channel|channelListResponse)|ytInitialPlayerResponse|["'](?:streamingData|playabilityStatus)["']\s*:)/],
  ];
  return checks.filter(([,pattern])=>pattern.test(text)).map(([code])=>code);
}
function structuredPrivacy(value){
  const found=new Set(),pending=[value];
  while(pending.length){const item=pending.pop();if(typeof item==='string'){for(const code of privacyFindings(item))found.add(code);continue;}if(!item||typeof item!=='object')continue;
    if((item.snippet&&(item.contentDetails||item.statistics||item.status||item.id))||item.contentDetails?.duration||item.status?.privacyStatus||item.status?.uploadStatus||item.streamingData||item.playabilityStatus)found.add('raw-youtube-payload');
    for(const [key,child] of Object.entries(item)){if(/^(?:access_token|refresh_token|client_secret|private_key|OPENAI_API_KEY|YOUTUBE_API_KEY)$/i.test(key))found.add('credential-field');pending.push(child);}
  }
  return found;
}
const diagnostic=value=>value===null?null:privacyFindings(String(value)).length?'[redacted forbidden marker]':String(value);
function publicURL(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u:null;}catch{return null;}}
function sourceExport(r){return {id:r.id,title:r.title,url:r.canonicalUrl,sourceUrl:r.sourceUrl,providerId:r.providerId,topics:r.topics,attribution:r.reuse?.attribution,licence:r.reuse?.sourceLicence,annotationLicence:r.reuse?.annotationLicence,description:r.reuse?.annotationLicence?r.description:undefined};}

export async function checkBuild({root=ROOT,dist=path.join(root,'dist'),write=true,limits=FREE_LIMITS,now=new Date()}={}){
  const startedAt=new Date().toISOString();
  const report={checkedAt:startedAt,passed:false,buildDirectory:path.relative(root,dist)||'.',errors:[],warnings:[],errorCount:0,warningCount:0,limits,counts:{files:0,htmlPages:0,internalReferences:0,externalReferencesSkipped:0,nonFetchReferencesSkipped:0,fragmentChecks:0,nonDocumentFragmentsSkipped:0,publicCatalogueRecords:0,discoveryRecords:0,resourcePlayerPages:0,permanentSourceFallbacks:0},boundary:'Static files, local targets, recognised HTML/SVG IDs, player-fallback ancestry and serialized metadata only. No external URLs, computed CSS visibility, GUI behaviour, playback, account quota, deployment or scientific correctness is tested.'};
  const add=(kind,code,file,message)=>{const key=kind==='error'?'errors':'warnings';report[kind+'Count']++;if(report[key].length<500)report[key].push({code,file:diagnostic(file),message:diagnostic(message)});};
  const error=(code,file,message)=>add('error',code,file,message),warn=(code,file,message)=>add('warning',code,file,message);
  const finish=async()=>{report.passed=report.errorCount===0;report.finishedAt=new Date().toISOString();if(write){const target=path.join(root,'evaluation/artifact-check.json');await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,JSON.stringify(report,null,2)+'\n');}return report;};
  let files;
  try{files=await inventory(dist);}catch(e){error('missing-build',null,e.code==='ENOENT'?'No build directory exists. Run the build before this audit.':`Cannot inventory build: ${e.code??e.name}`);return finish();}
  report.counts.files=files.length;report.totalBytes=files.reduce((n,x)=>n+x.bytes,0);report.largestAssets=[...files].sort((a,b)=>b.bytes-a.bytes||a.file.localeCompare(b.file)).slice(0,10).map(({file,bytes})=>({file:diagnostic(file),bytes}));
  if(!files.length)error('empty-build',null,'Build directory contains no files.');
  if(files.length>limits.maxFiles)error('free-file-limit',null,`${files.length} files exceeds the configured ${limits.maxFiles}-file static limit.`);
  const fileSet=new Set(files.filter(f=>f.regular).map(f=>f.file)),documents=new Map(),references=[],jsonFiles=new Map(),manifest=[];
  for(const f of files){
    for(const code of privacyFindings(f.file))error(code,f.file,'A forbidden publication marker occurs in a file name; its value is omitted.');
    if(f.symlink||!f.regular){error('nonregular-file',f.file,'Public artifacts must be regular files, not symbolic links or special files.');continue;}
    if(f.bytes>limits.maxAssetBytes){error('free-asset-limit',f.file,`${f.bytes} bytes exceeds the configured ${limits.maxAssetBytes}-byte per-asset limit.`);continue;}
    if(/(?:^|\/)(?:\.git|\.cache|\.config|node_modules|data\/(?:raw|audits))(?:\/|$)|^(?:functions|_worker\.js)(?:\/|$)|(?:^|\/)(?:\.env(?:\.[^/]*)?|\.DS_Store|[^/]*\.(?:pem|p12|pfx))$/i.test(f.file))error('private-or-server-file',f.file,'Private, credential, dependency or server-function material appears in the static artifact.');
    let body;try{body=await fs.readFile(path.join(dist,f.file));}catch(e){error('unreadable-file',f.file,`Cannot read artifact: ${e.code??e.name}`);continue;}
    manifest.push([f.file,body.length,hash(body)]);
    if(body.length!==f.bytes)error('build-changed',f.file,'File size changed during audit.');
    if(!TEXT.test(f.file)&&!['_headers','_redirects'].includes(f.file))continue;
    const text=body.toString('utf8');
    const privacyCodes=new Set();const privacy=values=>{for(const code of values)if(!privacyCodes.has(code)){privacyCodes.add(code);error(code,f.file,'A forbidden publication marker was detected; its value is deliberately omitted from this report.');}};
    privacy(privacyFindings(decode(text)));
    if(/\.(?:html?|svg)$/i.test(f.file)){
      const doc=inspectMarkup(text);documents.set(f.file,doc);references.push(...doc.refs.map(r=>({...r,file:f.file})));
      for(const id of doc.duplicateIds)error('duplicate-fragment-id',f.file,`Duplicate document ID (${String(id).slice(0,100)}).`);
      if(doc.baseHrefs.length)error('base-element',f.file,'Unexpected base element makes generated-root URL resolution ambiguous.');
      if(/\.html?$/i.test(f.file)){
        report.counts.htmlPages++;
        if(doc.openTitles!==1||doc.titles.length!==1||!meaningful(doc.titles[0],5))error('page-title',f.file,'Expected one meaningful, closed document title.');
        if(doc.openH1!==1||doc.h1.length!==1||!meaningful(doc.h1[0],3))error('page-h1',f.file,'Expected one meaningful, closed h1.');
        if(doc.descriptions.length!==1||!meaningful(doc.descriptions[0],20))error('page-description',f.file,'Expected one meaningful meta description of at least 20 characters.');
        if(doc.canonicals.length!==1)error('page-canonical',f.file,'Expected exactly one canonical URL.');
      }
      const playerConfigs=[];
      for(const item of doc.jsonScripts){try{const obj=JSON.parse(item.text);if(item.id==='player-data')playerConfigs.push(obj);privacy(structuredPrivacy(obj));if(obj?.apiExpiresAt&&(!Number.isFinite(Date.parse(obj.apiExpiresAt))||Date.parse(obj.apiExpiresAt)<=+now))error('expired-display-metadata',f.file,'The embedded display metadata has an invalid or expired API expiry.');}catch{error('invalid-embedded-json',f.file,'An application/json script is not valid JSON.');}}
      if(/^resources\/[^/]+\/index\.html$/.test(f.file)&&(doc.playerContainers||doc.jsonScripts.some(x=>x.id==='player-data'))){
        report.counts.resourcePlayerPages++;
        if(doc.playerContainers!==1||playerConfigs.length!==1)error('resource-player-shape',f.file,'Expected one replaceable player container and one valid player configuration.');
        const source=publicURL(playerConfigs[0]?.canonicalUrl);
        const fallback=source&&doc.anchors.some(a=>!a.insidePlayer&&!a.unavailable&&publicURL(a.href)?.href===source.href&&/\b(?:watch|open|view)\b.*\b(?:source|provider|original|video|recording)\b/i.test(a.label??''));
        if(fallback)report.counts.permanentSourceFallbacks++;
        else error('permanent-source-fallback',f.file,'The resource needs a named source/video link to its configured canonical destination outside the replaceable player container and statically hidden/inert content.');
      }
    } else if(/\.css$/i.test(f.file))references.push(...cssReferences(text).map(value=>({file:f.file,value,kind:'css.url'})));
    else if(/\.m?js$/i.test(f.file)){
      for(const m of text.matchAll(/\b(?:import\s+(?:[^;\n]*?\s+from\s+)?|export\s+[^;\n]*?\s+from\s+)["']([^"']+)["']|\bimport\(\s*["']([^"']+)["']\s*\)/g)){const value=m[1]??m[2];if(/^(?:[./]|https?:)/.test(value))references.push({file:f.file,value,kind:'module-import'});else error('bare-browser-import',f.file,'An unbundled bare module import is not resolved by this static build.');}
    }
    if(/\.json$/i.test(f.file)){try{const obj=JSON.parse(text);jsonFiles.set(f.file,obj);privacy(structuredPrivacy(obj));}catch{error('invalid-json',f.file,'Invalid JSON artifact.');}}
    if(f.file==='_headers'){
      const lines=text.split(/\r?\n/).filter(x=>x.trim()&&!/^\s*#/.test(x)),rules=lines.filter(x=>!/^\s/.test(x));
      report.headerRules=rules.length;if(rules.length>limits.maxHeaderRules)error('free-header-rule-limit',f.file,'Too many static header rules.');
      if(lines.some(x=>/^\s/.test(x)&&[...x].length>limits.maxHeaderCharacters))error('free-header-length-limit',f.file,'A header exceeds the configured character limit.');
    }
  }
  report.manifestSha256=hash(JSON.stringify(manifest));
  const home=documents.get('index.html');if(!home)error('missing-homepage','index.html','The root page is missing.');
  const origin=publicURL(home?.canonicals[0])?.origin??'https://invalid-build.example';report.canonicalOrigin=diagnostic(origin);
  if(/^(?:localhost|127\.0\.0\.1|\[::1\])$/.test(new URL(origin).hostname))warn('local-canonical',null,'Canonical URLs target a local preview. Rebuild with the approved production address before publication.');
  const canonicalPages=new Set();
  for(const [file,doc] of documents)if(/\.html?$/i.test(file)){
    const u=publicURL(doc.canonicals[0]),expected=new URL(aliasCanonical(file),origin).pathname;
    if(!u||u.origin!==origin||u.pathname!==expected||u.search||u.hash)error('canonical-target',file,'Canonical URL does not match this generated page and the common site origin.');
    else canonicalPages.add(u.href);
  }
  const resolveFile=pathname=>{let p;try{p=decodeURIComponent(pathname);}catch{return null;}if(p.includes('\0')||p.includes('\\'))return null;const rel=p.replace(/^\/+/,''),choices=p.endsWith('/')?[rel+'index.html']:[rel,rel+'.html',rel+'/index.html'];return choices.find(x=>fileSet.has(x))??null;};
  for(const [file,obj] of jsonFiles)if(file==='data/index.json'){
    if(!Array.isArray(obj.records))error('discovery-shape',file,'Discovery index has no records array.');
    else{const seen=new Set();report.counts.discoveryRecords=obj.records.length;for(const r of obj.records){if(typeof r.id!=='string'||seen.has(r.id))error('discovery-id',file,'Missing or duplicate discovery identifier.');seen.add(r.id);if(typeof r.url!=='string')error('discovery-url',file,'Discovery entry has no navigable URL.');else references.push({file:'index.html',value:r.url,kind:'discovery-url'});}}
  }
  for(const ref of references){
    let u;try{u=new URL(ref.value,new URL(routeFor(ref.file),origin));}catch{error('invalid-reference',ref.file,`Invalid ${ref.kind} URL.`);continue;}
    if(['javascript:','vbscript:','file:'].includes(u.protocol)){error('unsafe-reference',ref.file,`Unsafe ${ref.kind} scheme.`);continue;}
    if(!['http:','https:'].includes(u.protocol)){report.counts.nonFetchReferencesSkipped++;continue;}
    if(u.origin!==origin){report.counts.externalReferencesSkipped++;continue;}
    report.counts.internalReferences++;const target=resolveFile(u.pathname);
    if(!target){error('missing-local-target',ref.file,`${ref.kind} points to missing local pathname ${u.pathname.slice(0,200)}.`);continue;}
    if(u.hash&&u.hash!=='#'){
      let fragment;try{fragment=decodeURIComponent(u.hash.slice(1)).split(':~:')[0];}catch{error('invalid-fragment',ref.file,'Malformed percent escape in fragment.');continue;}
      if(!fragment||fragment.toLowerCase()==='top')continue;
      const doc=documents.get(target);if(!doc){report.counts.nonDocumentFragmentsSkipped++;continue;}
      report.counts.fragmentChecks++;if(!doc.ids.has(fragment))error('missing-fragment',ref.file,`${ref.kind} points to missing ID ${fragment.slice(0,120)} in ${target}.`);
    }
  }
  let sitemap='';try{sitemap=await fs.readFile(path.join(dist,'sitemap.xml'),'utf8');}catch{error('missing-sitemap','sitemap.xml','Sitemap is missing.');}
  if(sitemap){const locs=[...sitemap.matchAll(/<loc\b[^>]*>([\s\S]*?)<\/loc\s*>/gi)].map(x=>decode(x[1].trim()));const seen=new Set();if(!/<urlset\b/i.test(sitemap)||!locs.length)error('sitemap-shape','sitemap.xml','Expected a nonempty URL-set sitemap.');for(const loc of locs){const u=publicURL(loc);if(!u||u.origin!==origin||u.hash||u.search){error('sitemap-url','sitemap.xml','Sitemap contains an invalid or nonlocal page URL.');continue;}if(seen.has(u.href))error('sitemap-duplicate','sitemap.xml','Duplicate sitemap location.');seen.add(u.href);if(!canonicalPages.has(u.href))error('sitemap-extra','sitemap.xml',`Sitemap location has no matching canonical HTML page: ${u.pathname}.`);}for(const url of canonicalPages)if(!seen.has(url))error('sitemap-missing','sitemap.xml',`Canonical page omitted from sitemap: ${new URL(url).pathname}.`);report.sitemapPages=seen.size;report.canonicalPages=canonicalPages.size;}
  const exported=jsonFiles.get('exports/catalogue.json');
  if(!exported||!Array.isArray(exported.records)||!exported.records.length)error('catalogue-shape','exports/catalogue.json','Expected a nonempty public catalogue records array.');
  else{
    const seen=new Set();report.counts.publicCatalogueRecords=exported.records.length;
    for(const r of exported.records){
      if(!r||typeof r!=='object'){error('catalogue-record','exports/catalogue.json','A public record is not an object.');continue;}
      if(typeof r.id!=='string'||! /^(?:youtube:[A-Za-z0-9_-]{11}|vimeo:\d+|institution:[a-f0-9]{16})$/.test(r.id)||seen.has(r.id))error('catalogue-id','exports/catalogue.json','Invalid or duplicate canonical identifier.');seen.add(r.id);
      if(Object.keys(r).some(k=>!EXPORT_FIELDS.has(k)))error('catalogue-forbidden-field','exports/catalogue.json',`Record ${String(r.id).slice(0,80)} contains a field outside the source-only export allowlist.`);
      if(!publicURL(r.url)||!publicURL(r.sourceUrl))error('catalogue-url','exports/catalogue.json','A public catalogue URL is unsafe or malformed.');
      else{try{const c=canonicalVideo(r.url);if(c.id&&c.id!==r.id)error('catalogue-canonical-id','exports/catalogue.json','Record ID and canonical URL disagree.');}catch{error('catalogue-canonical-id','exports/catalogue.json','Invalid canonical video URL.');}}
    }
    try{
      const raw=await fs.readFile(path.join(root,'data/catalogue.jsonl'),'utf8');report.sourceCatalogueSha256=hash(raw);
      const source=raw.split('\n').filter(Boolean).map(JSON.parse);
      const optional=async(f,fallback)=>{try{return JSON.parse(await fs.readFile(path.join(root,f),'utf8'));}catch(e){if(e.code==='ENOENT')return fallback;throw e;}};
      const overrides=await optional('data/editorial-overrides.json',{}),withdrawn=new Set((await optional('data/withdrawals.json',[])).map(x=>x.id));
      const permitted=new Map(source.map(r=>({...r,...overrides[r.id],qualification:{...r.qualification,...overrides[r.id]?.qualification}})).filter(r=>!withdrawn.has(r.id)&&r.reuse?.exportAllowed&&isDiscoverable(r)).map(r=>[r.id,sourceExport(r)]));
      for(const r of exported.records){const expected=permitted.get(r.id);if(!expected)error('catalogue-not-source-permitted','exports/catalogue.json',`Record ${String(r.id).slice(0,80)} is not an eligible source-catalogue export.`);else for(const key of EXPORT_FIELDS)if(JSON.stringify(r[key])!==JSON.stringify(expected[key]))error('catalogue-source-mismatch','exports/catalogue.json',`Record ${r.id}, field ${key}, differs from the source-only catalogue/local overrides.`);}
      for(const id of permitted.keys())if(!seen.has(id))error('catalogue-missing-record','exports/catalogue.json',`Permitted source record ${id} is absent from the catalogue export.`);
      report.sourcePermittedRecords=permitted.size;
    }catch(e){error('source-catalogue-check','exports/catalogue.json',`Source-only comparison could not be completed (${e.code??e.name}).`);}
  }
  try{const after=await inventory(dist);if(JSON.stringify(after)!==JSON.stringify(files))error('build-changed',null,'Build inventory changed during the audit; rerun against a stable build.');}catch{error('build-changed',null,'Build disappeared or changed during the audit.');}
  report.elapsedMs=Date.now()-Date.parse(startedAt);return finish();
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  try{const args=process.argv.slice(2);let root=ROOT,dist;
    for(let i=0;i<args.length;i++){if(args[i]==='--root'&&args[i+1])root=path.resolve(args[++i]);else if(args[i]==='--dist'&&args[i+1])dist=path.resolve(args[++i]);else throw new Error('Usage: node scripts/check-build.mjs [--root PROJECT] [--dist BUILD]');}
    const result=await checkBuild({root,dist:dist??path.join(root,'dist')});console.log(JSON.stringify({passed:result.passed,counts:result.counts,errorCount:result.errorCount,warningCount:result.warningCount,errors:result.errors.slice(0,20),warnings:result.warnings,report:'evaluation/artifact-check.json'},null,2));if(!result.passed)process.exitCode=1;
  }catch(e){console.error(`Static artifact audit failed: ${e.message}`);process.exitCode=1;}
}
