import {isoDuration,API_RETENTION_DAYS} from './youtube-refresh.mjs';
export function applyAPI(records,cache,now=Date.now()){
  return records.map(record=>{
    const id=record.id.startsWith('youtube:')?record.id.slice(8):null,meta=cache.records?.[id];
    if(!meta||!Number.isFinite(Date.parse(meta.expiresAt))||Date.parse(meta.expiresAt)<=now||!(Date.parse(meta.checkedAt)+API_RETENTION_DAYS*86400000>now))return record;
    const r=structuredClone(record),item=meta.item;
    r.provenance=[...(r.provenance??[]),meta.provenance];
    r.apiMetadata={title:item?.snippet?.title??null,channel:item?.snippet?.channelTitle??null,thumbnail:item?.snippet?.thumbnails?.medium?.url??null,embeddable:item?.status?.embeddable??null,madeForKids:item?.status?.madeForKids??null,accessStatus:meta.availability.status,checkedAt:meta.checkedAt,expiresAt:meta.expiresAt,source:'YouTube Data API v3'};
    const officialAlternative=r.availability?.status==='accessible'&&r.availability?.method==='official-media-range';
    if(officialAlternative){r.availability.note=String(r.availability.note??'').replace(/YouTube availability is unknown\.?/gi,'').trim()+` Separate YouTube API check (${meta.checkedAt.slice(0,10)}): ${meta.availability.reason}`;}
    if(!officialAlternative){
      r.availability={status:meta.availability.status,method:meta.method,checkedAt:meta.checkedAt,evidence:[meta.provenance.id],playbackObserved:false,note:meta.availability.reason,expiresAt:meta.expiresAt,permitted:true};
      if(meta.availability.status==='accessible'&&r.qualification.status!=='excluded'&&r.qualification.sourceIdentityResolved!==false&&r.qualification.substanceResolved!==false&&r.qualification.distinctnessResolved!==false&&!r.alternateOf)r.qualification={...r.qualification,status:'qualified',reason:'Source-reviewed substantive resource with resolved identity and permitted official API accessibility evidence; no playback observation or scientific validation is implied.',accessEvidence:meta.provenance.id};
      else if(r.qualification.status==='qualified')r.qualification={...r.qualification,status:'candidate'};
    }
    // The institutional record remains intact on disk. API-only values are expiring overlays.
    if(r.durationSeconds==null&&item?.contentDetails?.duration){r.durationSeconds=isoDuration(item.contentDetails.duration);r.durationEvidence=[meta.provenance.id];r.durationOrigin='youtube-api';}
    if(!r.uploadDate&&item?.snippet?.publishedAt){r.uploadDate=item.snippet.publishedAt;r.uploadDateOrigin='youtube-api';}
    if(!r.recordingDate&&item?.recordingDetails?.recordingDate){r.recordingDate=item.recordingDetails.recordingDate;r.recordingDateOrigin='youtube-api';}
    if(!r.language&&item?.snippet?.defaultAudioLanguage){r.language=item.snippet.defaultAudioLanguage;r.languageOrigin='youtube-api';}
    return r;
  });
}
