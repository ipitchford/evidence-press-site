import {spawnSync} from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {ROOT,writeJSON} from './data.mjs';
import {refreshYouTube} from './youtube-refresh.mjs';
import {maintainAPIData} from './api-maintenance.mjs';
await maintainAPIData();
const hash=async file=>crypto.createHash('sha256').update(await fs.readFile(path.join(ROOT,file))).digest('hex');
const overridesBefore=await hash('data/editorial-overrides.json'),withdrawalsBefore=await hash('data/withdrawals.json');
const args=process.argv.slice(2),offline=args.includes('--offline');
const normalise=spawnSync(process.execPath,['scripts/normalise.mjs'],{cwd:ROOT,stdio:'inherit'});if(normalise.status)process.exit(normalise.status);
let apiStatus='offline-cache-only',apiFailed=false;if(!offline){try{const result=await refreshYouTube();apiStatus=`metadata cache contains ${Object.keys(result.records??{}).length} records`;}catch(error){console.error(error.message);apiStatus='refresh-unavailable; only unexpired cache can be used';apiFailed=true;}}
const overridesAfter=await hash('data/editorial-overrides.json'),withdrawalsAfter=await hash('data/withdrawals.json');
// The normaliser may merge new, separately checked core fragments. Existing user overrides
// must retain precedence; normaliser's own reconciliation receipt records those merges.
const result={checkedAt:new Date().toISOString(),mode:offline?'offline source-cache reconciliation':'incremental source-cache reconciliation and official YouTube metadata refresh',apiStatus,overridesBefore,overridesAfter,withdrawalsBefore,withdrawalsAfter,withdrawalsPreserved:withdrawalsBefore===withdrawalsAfter,sourceAcquisition:'Institution adapters are run explicitly when a new source snapshot is required; this command does not scrape video platforms.',nextCommand:'npm run validate && npm run build'};
await writeJSON('evaluation/refresh.json',result);console.log(JSON.stringify(result,null,2));if(!result.withdrawalsPreserved)throw Error('Withdrawal file changed unexpectedly.');
if(apiFailed)process.exitCode=1;
