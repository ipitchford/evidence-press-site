import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {ROOT,json,writeJSON} from './data.mjs';
import {accessToken} from './youtube-oauth.mjs';

export const API_RETENTION_DAYS=28;
const cacheFile='.cache/youtube/metadata.json';
export async function pruneYouTubeCache(now=Date.now()){
  const old=await json(cacheFile,{version:1,records:{}});
  const records=Object.fromEntries(Object.entries(old.records??{}).filter(([,r])=>Date.parse(r.expiresAt)>now&&Date.parse(r.checkedAt)+API_RETENTION_DAYS*86400000>now));
  if(Object.keys(old.records??{}).length||Object.keys(records).length)await writeJSON(cacheFile,{version:1,records});
  const batchDir=path.join(ROOT,'.cache/youtube/batches'),keep=new Set(Object.values(records).map(r=>path.basename(r.provenance.cachePath)));
  let removedBatches=0;for(const file of await fs.readdir(batchDir).catch(()=>[]))if(!keep.has(file)){await fs.unlink(path.join(batchDir,file));removedBatches++;}
  return {version:1,records,removedRecords:Object.keys(old.records??{}).length-Object.keys(records).length,removedBatches};
}
export function isoDuration(value){
  const m=/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(value??'');
  return m?Math.round(Number(m[1]??0)*86400+Number(m[2]??0)*3600+Number(m[3]??0)*60+Number(m[4]??0)):null;
}
export function apiAccessibility(item,region='GB'){
  if(!item)return {status:'unavailable',reason:'The official videos.list response did not return this identifier. Private and deleted states cannot be distinguished here.'};
  if(item.status?.privacyStatus==='private')return {status:'unavailable',reason:'The API reports a private video.'};
  if(!['public','unlisted'].includes(item.status?.privacyStatus)||item.status?.uploadStatus!=='processed')return {status:'unknown',reason:'The API does not establish a public, processed video.'};
  const restriction=item.contentDetails?.regionRestriction;
  if(restriction?.blocked?.includes(region)||(Array.isArray(restriction?.allowed)&&!restriction.allowed.includes(region)))return {status:'restricted',reason:`The API reports a restriction for ${region}.`};
  if(item.contentDetails?.contentRating?.ytRating==='ytAgeRestricted')return {status:'restricted',reason:'YouTube reports an age restriction; unrestricted access is not established.'};
  return {status:'accessible',reason:`YouTube API reports a public or source-linked unlisted, processed video with no reported ${region} or age restriction. This is metadata evidence, not observed playback; access can differ by location or account.`};
}
async function candidateIds(){
  const found=new Set();
  function walk(v){
    if(Array.isArray(v)){for(const row of v)walk(row);return;}
    if(!v||typeof v!=='object')return;
    for(const [key,value] of Object.entries(v)){
      if(typeof value==='string' && ['id','youtubeId','videoId','youtube_id','canonicalUrl','videoUrl','url','destinationUrl'].includes(key)){
        const id=/^(?:youtube:|yt:)?([\w-]{11})$/.exec(value)?.[1]??/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/))([\w-]{11})/.exec(value)?.[1];if(id)found.add(id);
      }else if(typeof value==='object')walk(value);
    }
  }
  for(const file of ['data/audits/courses/candidates.json','data/audits/nptel/candidates.json','data/audits/providers/candidate-observations.json','data/audits/providers/additional-candidate-observations.json','data/audits/hackertube/candidates.json'])walk(await json(file,[]));
  try{for(const line of (await fs.readFile(path.join(ROOT,'data/catalogue.jsonl'),'utf8')).split('\n').filter(Boolean))walk(JSON.parse(line));}catch(e){if(e.code!=='ENOENT')throw e;}
  return [...found].sort();
}
export async function refreshYouTube({force=false,limit=120,tokenFile=process.env.YOUTUBE_OAUTH_TOKEN_FILE??path.join(ROOT,'.private/youtube-token.json')}={}){
  // Public metadata only. The author's account is used for authentication; no subscriptions,
  // history, ratings, private playlists or private uploaded videos are requested.
  const now=Date.now(),old=await pruneYouTubeCache(now),records=old.records;
  const ids=await candidateIds(),pending=ids.filter(id=>force||!records[id]||Date.parse(records[id].checkedAt)<now-7*86400000);
  if(!pending.length){console.log(JSON.stringify({youtubeRefresh:'cache-current',ids:ids.length,requests:0}));return old;}
  const token=await accessToken(tokenFile);let requests=0;
  for(let offset=0;offset<pending.length;offset+=50){
    if(requests>=limit)break;
    const batch=pending.slice(offset,offset+50),url=new URL('https://www.googleapis.com/youtube/v3/videos');
    url.searchParams.set('part','snippet,contentDetails,status,recordingDetails');url.searchParams.set('id',batch.join(','));
    const response=await fetch(url,{headers:{Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(30000)});requests++;
    const raw=await response.text();let result;try{result=JSON.parse(raw);}catch{throw Error(`YouTube returned a non-JSON response (${response.status}).`);}
    if(!response.ok){
      const reason=String(result.error?.errors?.[0]?.reason??response.status).replace(/[^\w-]/g,'');
      await writeJSON(cacheFile,{version:1,records});throw Error(`YouTube metadata request stopped: ${reason}. No quota bypass or paid route attempted.`);
    }
    const checkedAt=new Date().toISOString(),expiresAt=new Date(Date.now()+API_RETENTION_DAYS*86400000).toISOString();
    const sha256=crypto.createHash('sha256').update(raw).digest('hex'),batchName=`${sha256.slice(0,20)}.json`;
    const batchDir=path.join(ROOT,'.cache/youtube/batches');await fs.mkdir(batchDir,{recursive:true});await fs.writeFile(path.join(batchDir,batchName),raw,{mode:0o600});
    const byId=new Map((result.items??[]).map(x=>[x.id,x]));
    for(const id of batch){
      const item=byId.get(id);const access=apiAccessibility(item);
      // An accidentally accessible private item is never retained for public catalogue use.
      const publicItem=item&&['public','unlisted'].includes(item.status?.privacyStatus)?item:null;
      records[id]={id,checkedAt,expiresAt,region:'GB',method:'authorised-api-metadata',publicMetadata:true,availability:access,item:publicItem??null,
        provenance:{id:`youtube-api-${id}`,url:url.href,retrievedAt:checkedAt,sha256,inspection:'Official videos.list response: status, restrictions and metadata; no playback observed.',cachePath:`.cache/youtube/batches/${batchName}`}};
    }
    await writeJSON(cacheFile,{version:1,records});
    if(requests%10===0)console.log(JSON.stringify({youtubeRefresh:'progress',requests,checked:Math.min(offset+50,pending.length),pending:pending.length}));
  }
  // Keep only current response bodies. Receipts retain hashes; expired API payloads are removed.
  const keep=new Set(Object.values(records).map(r=>path.basename(r.provenance.cachePath)));
  for(const file of await fs.readdir(path.join(ROOT,'.cache/youtube/batches')))if(!keep.has(file))await fs.unlink(path.join(ROOT,'.cache/youtube/batches',file));
  const receipt={checkedAt:new Date().toISOString(),method:'YouTube Data API v3 videos.list; OAuth read-only; batches of 50',requests,estimatedQuotaUnits:requests,requestedIds:ids.length,cacheRecords:Object.keys(records).length,remaining:ids.filter(id=>!records[id]).length,retentionDays:API_RETENTION_DAYS,playbackObserved:false};
  await writeJSON('data/audits/youtube/refresh-receipt.json',receipt);console.log(JSON.stringify(receipt));return {version:1,records};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)await refreshYouTube({force:process.argv.includes('--force')});
