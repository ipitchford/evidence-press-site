#!/usr/bin/env node
/** Build a redistributable, credential-free source snapshot. No network calls. */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import Ajv from 'ajv';

export const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const VERSION=1,MANIFEST='SOURCE_PACKAGE_MANIFEST.json';
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const stable=value=>JSON.stringify(value,null,2)+'\n';
const slash=value=>value.split(path.sep).join('/');
const own=(object,key)=>Object.prototype.hasOwnProperty.call(object,key);

// The normaliser's reviewed field-level reuse statements. A new statement needs
// a maintainer review here, even if its record says exportAllowed=true.
const REUSE_BASES=new Set([
 'Links, factual metadata and original navigation annotations only. No source page, transcript, image, video or restricted platform metadata is included in the reusable export.',
 'Factual metadata and original audit annotations derived from an attributed ODC-By database; individual content rights remain separate.'
]);
const ANNOTATION_LICENCE='Original atlas navigation only; source rights preserved.';
const OMIT_KEYS=new Set([
 'cachePath','localPath','privatePath','rawPath','sourceCachePath','apiEvidenceReference',
 'excerpt','excerpts','excerptForPrivateAudit','publisherExcerpt','publisherDescription',
 'sourceText','source_text','rawText','raw_text','rawHtml','html','commentText','comment_text',
 'transcriptText','transcript_text','inspectedExcerpts','rawResponse','responseBody','b64_string'
]);
const FORBIDDEN_KEYS=new Set([
 'apiMetadata','snippet','contentDetails','recordingDetails','etag','access_token',
 'refresh_token','client_secret','client_id','id_token','accessToken','refreshToken',
 'clientSecret','clientId','authorization','Authorization','token_uri','private_key'
]);
const PRIVATE_SEGMENTS=new Set(['.private','.cache','data/raw','private-cache','node_modules','dist','.git']);
const CODE_EXTENSIONS=new Set(['.mjs','.js','.py','.sh']);
const CORE_RECEIPTS=[
 'data/audits/courses/core-check-receipt.json',
 'data/audits/editorial-body/core-checks.json',
 'data/audits/editorial-body/core-supplement-checks.json',
 'data/audits/editorial-mind/core-check-receipts.json',
 'data/audits/providers/core-inspections.json',
 'data/audits/nptel/alternate-review/alternate-mappings.json',
 'data/audits/nptel/alternate-review/summary.json'
];
const ROOT_FILES=['package.json','package-lock.json','README.md','PROGRESS.md','CHANGELOG.md','EVALUATION.md','SEARCH_REVIEW.md','DATA.md','ATTRIBUTION.md','LICENSE','CONTENT-LICENCE.md','.gitignore','.env.example'];
const DATA_FILES=['data/catalogue.jsonl','data/sources.json','data/courses.json','data/supporting.json','data/taxonomy.json','data/editorial-overrides.json','data/withdrawals.json','data/normalisation-state.json'];
const REQUIRED=['scripts/build.mjs','scripts/data.mjs','scripts/validate.mjs','scripts/api-overlay.mjs','scripts/youtube-refresh.mjs','scripts/youtube-oauth.mjs','src/model.mjs','src/search.mjs','src/app.mjs','src/state.mjs','public/assets/style.css','data/schema/video.schema.json','evaluation/benchmark.json'];

function apiEvidence(value){
 if(!value||typeof value!=='object'||Array.isArray(value))return false;
 return /^youtube-api-/.test(value.id??'')||/^https:\/\/www\.googleapis\.com\/youtube\//.test(value.url??'')||value.method==='authorised-api-metadata';
}
function scanString(value,label,{code=false}={}){
 const secretPatterns=[/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,/\bya29\.[A-Za-z0-9_-]{15,}/,/\bGOCSPX-[A-Za-z0-9_-]{15,}/,/\bAIza[0-9A-Za-z_-]{30,}/,/\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}/,/\b\d{10,}-[a-z0-9-]+\.apps\.googleusercontent\.com\b/,/\b1\/\/[A-Za-z0-9_-]{30,}/];
 if(secretPatterns.some(p=>p.test(value)))throw Error(`${label}: credential-shaped value detected (value not logged).`);
 // Portable example paths and relative cache-directory names in source code are
 // instructions, not local filesystem disclosures. Real user/storage roots fail.
 const syntheticTestRoot=['','Users','example',''].join('/');
 const pathText=code&&label.startsWith('tests/')?value.replaceAll(syntheticTestRoot,'<synthetic-test-root>/'):value;
 if(/(?:file:\/\/)?(?:\/Users\/|\/Volumes\/|\/home\/|\/private\/var\/|[A-Z]:\\Users\\)/.test(pathText))throw Error(`${label}: machine-specific private path detected.`);
 if(!code&&/(?:[?&](?:access_token|refresh_token|client_secret|key)=)[^&#\s]+/i.test(value))throw Error(`${label}: credential-bearing URL detected (value not logged).`);
}

export function redactMetadata(value,stats={removed:{}},at='$'){
 if(Array.isArray(value))return value.map((x,i)=>redactMetadata(x,stats,`${at}[${i}]`)).filter(x=>x!==undefined);
 if(value&&typeof value==='object'){
  if(apiEvidence(value)){stats.removed.apiEvidenceObject=(stats.removed.apiEvidenceObject??0)+1;return undefined;}
  const result={};
  for(const [key,child] of Object.entries(value)){
   if(FORBIDDEN_KEYS.has(key))throw Error(`${at}.${key}: restricted payload/credential field cannot be packaged.`);
   if(OMIT_KEYS.has(key)){
    stats.removed[key]=(stats.removed[key]??0)+1;
    // Preserve the precise scope of an actual excerpt check without its text.
    if(key==='inspectedExcerpts'&&Array.isArray(child))result.inspectedSections=child.map(x=>Object.fromEntries(Object.entries({segment:x.segment,time:x.time,characterOffset:x.characterOffset,charactersInspected:typeof x.text==='string'?x.text.length:undefined}).filter(([,v])=>v!==undefined)));
    continue;
   }
   if(/(?:raw|private).*(?:payload|excerpt|text|html|response)|(?:transcript|comment).*(?:body|text|content)/i.test(key))throw Error(`${at}.${key}: unreviewed source-payload field.`);
   let reviewed=child;
   if(key==='note'&&typeof child==='string'){
    reviewed=child.replace(/\s*Individual receipt:\s*data\/audits\/[^\s]+\.json\.?\s*$/,'');
    if(reviewed!==child)stats.removed.internalReceiptSuffix=(stats.removed.internalReceiptSuffix??0)+1;
   }
   const next=redactMetadata(reviewed,stats,`${at}.${key}`);
   if(next!==undefined)result[key]=next;
  }
  return result;
 }
 if(typeof value==='string'){
  scanString(value,at);
  if(/^youtube-api-/.test(value)){stats.removed.apiEvidenceId=(stats.removed.apiEvidenceId??0)+1;return undefined;}
 }
 return value;
}

export function prepareRecord(record,allowedFields,stats){
 if(record.reuse?.exportAllowed!==true)throw Error(`${record.id}: redistribution not allowed.`);
 if(!REUSE_BASES.has(record.reuse.basis)||record.reuse.annotationLicence!==ANNOTATION_LICENCE)throw Error(`${record.id}: field-level reuse basis needs a new review.`);
 for(const key of Object.keys(record))if(!allowedFields.has(key))throw Error(`${record.id}: unexpected catalogue field ${key}.`);
 if(record.apiMetadata||Object.entries(record).some(([k,v])=>k.endsWith('Origin')&&v==='youtube-api')||apiEvidence(record.availability)||record.provenance.some(apiEvidence))throw Error(`${record.id}: API-enriched data supplied instead of the independent base catalogue.`);
 const result=redactMetadata(record,stats,record.id);
 // Media thumbnails are not needed to reconstruct the application and their
 // permission is not inferred from the factual-record reuse statement.
 if(result.thumbnail!==null){stats.removed.thumbnail=(stats.removed.thumbnail??0)+1;result.thumbnail=null;}
 return result;
}

async function safeRead(root,rel){
 const abs=path.resolve(root,rel);
 if(!abs.startsWith(root+path.sep))throw Error(`Unsafe input path: ${rel}`);
 let current=root;
 for(const part of rel.split('/')){
  current=path.join(current,part);const s=await fs.lstat(current);
  if(s.isSymbolicLink())throw Error(`Symlink input refused: ${rel}`);
 }
 if(!(await fs.stat(abs)).isFile())throw Error(`Not a regular file: ${rel}`);
 return fs.readFile(abs);
}
async function walk(root,rel,{optional=false,skip=new Set(),includePrivate=false}={}){
 let items;try{items=await fs.readdir(path.join(root,rel),{withFileTypes:true});}catch(e){if(optional&&e.code==='ENOENT')return [];throw e;}
 const files=[];
 for(const item of items.sort((a,b)=>a.name.localeCompare(b.name))){
  if(skip.has(item.name)||(!includePrivate&&['__pycache__','private-cache','.DS_Store'].includes(item.name)))continue;
  const next=slash(path.join(rel,item.name));
  if(item.isSymbolicLink())throw Error(`Symlink refused in selected source tree: ${next}`);
  if(item.isDirectory())files.push(...await walk(root,next,{skip,includePrivate}));
  else if(item.isFile())files.push(next);
 }
 return files;
}
function outputPathAllowed(rel){
 if(rel.startsWith('/')||rel.split('/').includes('..'))return false;
 if(rel.split('/').some(x=>PRIVATE_SEGMENTS.has(x))||rel.startsWith('data/raw/'))return false;
 if(/(?:^|\/)\.env(?:\.|$)/.test(rel)&&rel!=='.env.example')return false;
 return true;
}
function inspectJSON(value,label){
 if(Array.isArray(value)){value.forEach((x,i)=>inspectJSON(x,`${label}[${i}]`));return;}
 if(value&&typeof value==='object'){
  if(apiEvidence(value))throw Error(`${label}: API evidence remains in package.`);
  for(const [key,child] of Object.entries(value)){
   if(FORBIDDEN_KEYS.has(key)||OMIT_KEYS.has(key))throw Error(`${label}.${key}: excluded field remains in package.`);
   inspectJSON(child,`${label}.${key}`);
  }
 }else if(typeof value==='string')scanString(value,label);
}
async function checkImports(files){
 const names=new Set(files.map(x=>x.path));let checked=0;
 for(const file of files.filter(x=>x.path.endsWith('.mjs')||x.path.endsWith('.js'))){
  for(const m of file.bytes.toString('utf8').matchAll(/(?:^|\n)\s*(?:import\s+(?:[^'"\n;]*?\s+from\s*)?|export\s+[^'"\n;]*?\s+from\s*)['"](\.[^'"]+)['"]/g)){
   const target=slash(path.normalize(path.join(path.dirname(file.path),m[1])));
   if(!names.has(target))throw Error(`${file.path}: missing local import ${target}`);
   checked++;
  }
 }
 return checked;
}
async function inspectFiles(files){
 let jsonFiles=0,codeFiles=0;
 for(const file of files){
  if(!outputPathAllowed(file.path))throw Error(`Excluded output path: ${file.path}`);
  const ext=path.extname(file.path),text=file.bytes.toString('utf8');
  if(ext==='.json'||ext==='.jsonl'){
   const data=ext==='.jsonl'?text.split('\n').filter(Boolean).map(JSON.parse):JSON.parse(text);
   // Executable schemas name optional API fields, and manifests describe the
   // redaction policy. Their property names are not captured API payloads.
   if(!file.path.startsWith('data/schema/')&&file.path!==MANIFEST)inspectJSON(data,file.path);
   else scanString(text,file.path,{code:true});
   jsonFiles++;
  }else if(CODE_EXTENSIONS.has(ext)||['.md','.txt','.css','.svg'].includes(ext)||file.path.startsWith('.')){
   scanString(text,file.path,{code:true});if(CODE_EXTENSIONS.has(ext))codeFiles++;
  }
 }
 return {jsonFiles,codeFiles,relativeModuleImportsChecked:await checkImports(files),capturedAPIPayloads:0,credentialValues:0,machineSpecificPrivatePaths:0,rawSourcePayloadFiles:0};
}

export async function buildPackage(root=ROOT){
 const inputs=new Map(),entries=new Map(),stats={removed:{}};
 async function add(rel,{json=false,transform=null}={}){
  if(entries.has(rel))return;
  const original=await safeRead(root,rel);inputs.set(rel,sha(original));
  let bytes=original;
  if(json){const value=transform?transform(JSON.parse(original)):redactMetadata(JSON.parse(original),stats,rel);bytes=Buffer.from(stable(value));}
  entries.set(rel,{path:rel,bytes,inputSha256:sha(original),transform:json?'redacted-editorial-metadata':'unchanged-source'});
 }
 for(const file of ROOT_FILES)await add(file);
 await add('content/shop.json',{json:true});
 for(const directory of ['src','scripts','tests','public'])for(const file of await walk(root,directory))await add(file);
 for(const file of (await walk(root,'docs')).filter(x=>x.split('/').length===2&&x.endsWith('.md')))await add(file);
 for(const file of await walk(root,'data/schema'))await add(file);
 const schema=JSON.parse(await safeRead(root,'data/schema/video.schema.json'));
 const fields=new Set(Object.keys(schema.properties));
 const baseText=await safeRead(root,'data/catalogue.jsonl');inputs.set('data/catalogue.jsonl',sha(baseText));
 const originalRecords=baseText.toString('utf8').split('\n').filter(Boolean).map(JSON.parse);
 const records=originalRecords.map(x=>prepareRecord(x,fields,stats));
 const recordCheck=new Ajv({allErrors:true,strict:false}).compile(schema);
 for(const record of records)if(!recordCheck(record))throw Error(`${record.id}: transformed record fails schema: ${recordCheck.errors.map(x=>x.instancePath+' '+x.message).join('; ')}`);
 entries.set('data/catalogue.jsonl',{path:'data/catalogue.jsonl',bytes:Buffer.from(records.map(x=>JSON.stringify(x)).join('\n')+'\n'),inputSha256:sha(baseText),transform:'reviewed-base-fields; cache paths and thumbnails omitted'});
 for(const file of DATA_FILES.filter(x=>x!=='data/catalogue.jsonl'))await add(file,{json:true});
 for(const directory of ['content/guides','content/paths','data/editorial-checks/guides','data/editorial-checks/paths'])for(const file of (await walk(root,directory)).filter(x=>x.endsWith('.json')))await add(file,{json:true});
 // Only original adapter/authoring source and reviewed editorial metadata from
 // audit directories. Candidate snapshots, API receipts and raw excerpts are not
 // included by a broad audit-directory copy.
 for(const file of await walk(root,'data/audits')){
  const ext=path.extname(file);
  if(CODE_EXTENSIONS.has(ext)||file.endsWith('/requirements.txt'))await add(file);
  else if(file.endsWith('/core-overrides.json')||file.endsWith('/record-decisions.json')||CORE_RECEIPTS.includes(file)||/^data\/audits\/nptel\/core-checks\/[^/]+\.json$/.test(file))await add(file,{json:true});
 }
 await add('evaluation/benchmark.json',{json:true});
 for(const needed of REQUIRED)if(!entries.has(needed))throw Error(`Required rebuild dependency missing: ${needed}`);
 const guides=[...entries.values()].filter(x=>x.path.startsWith('content/guides/')&&x.path.endsWith('.json')).map(x=>JSON.parse(x.bytes));
 const paths=[...entries.values()].filter(x=>x.path.startsWith('content/paths/')&&x.path.endsWith('.json')).map(x=>JSON.parse(x.bytes));
 for(const doc of [...guides,...paths])if(doc.check?.receipt&&!entries.has(doc.check.receipt))throw Error(`${doc.slug}: editorial receipt not packaged.`);
 const files=[...entries.values()].sort((a,b)=>a.path.localeCompare(b.path));
 const safety=await inspectFiles(files);
 const fileManifest=files.map(x=>({path:x.path,bytes:x.bytes.length,sha256:sha(x.bytes),inputSha256:x.inputSha256,transform:x.transform}));
 const packageDigest=sha(stable({version:VERSION,files:fileManifest}));
 const packageRelative=`releases/source/mind-brain-behaviour-${packageDigest.slice(0,16)}`;
 const destination=path.join(root,packageRelative);
 const coreIds=new Set();
 for(const x of files.filter(x=>x.path.endsWith('/core-overrides.json')))for(const key of Object.keys(JSON.parse(x.bytes)))coreIds.add(key);
 const manifest={version:VERSION,packageDigest,identity:'SHA-256 of the ordered payload manifest; no build clock or private machine path is included.',boundary:'Original code and writing, reviewed factual base records and redacted editorial metadata. No source media, raw transcript/comment/provider text, credentials or captured YouTube API payloads.',rebuild:{node:'>=22',commands:['npm ci','npm run build','npm start'],credentialsRequired:false,networkForDependencyInstall:'npm ci requires access to the locked package registry or a populated npm cache; the build itself does not acquire sources.',apiEnrichedCountsReproduced:false},counts:{files:files.length,baseRecords:records.length,guides:guides.length,paths:paths.length,distinctCoreFragments:coreIds.size,editorialReceipts:files.filter(x=>x.path.startsWith('data/editorial-checks/')).length},reuseReview:{approvedBaseStatements:[...REUSE_BASES],annotationLicence:ANNOTATION_LICENCE,preserved:'Attribution and individual source-licence restrictions are retained; they do not license linked media.',courseAndProviderFields:'Factual identity/context, original audit judgements and provenance metadata; no copied source descriptions or raw page bodies.',auditDirectoryPolicy:'Source-code extensions plus explicitly selected editorial receipts/decisions only.'},redactions:stats.removed,verification:{...safety,catalogueSchemaValid:true,requiredBuildDependenciesPresent:true,allGuidePathReceiptsPresent:true},exclusions:['.private/','.cache/','node_modules/','dist/','data/raw/','private-cache/','populated environment files','raw acquisition/candidate/transcript/comment snapshots','API-bearing evaluation/search snapshots','docs/closeout-draft/','historical build and release counts as machine receipts'],files:fileManifest};
 const manifestBytes=Buffer.from(stable(manifest));
 // Fail rather than mixing a catalogue/content update made during packaging.
 for(const [rel,digest] of inputs)if(sha(await safeRead(root,rel))!==digest)throw Error(`Source changed while packaging: ${rel}. Re-run for a coherent snapshot.`);
 for(const rel of ['releases','releases/source']){
  const dir=path.join(root,rel);await fs.mkdir(dir,{recursive:true});
  if((await fs.lstat(dir)).isSymbolicLink())throw Error(`Symlink output directory refused: ${rel}`);
 }
 let reused=false;
 try{
  await fs.lstat(destination);await verifyPackage(destination);const old=await fs.readFile(path.join(destination,MANIFEST));if(!old.equals(manifestBytes))throw Error('Existing destination has a different manifest; refusing overwrite.');reused=true;
 }catch(error){if(error.code!=='ENOENT')throw error;}
 if(!reused){
  const staging=await fs.mkdtemp(path.join(root,'releases/source/.packaging-'));
  try{
   for(const file of files){const to=path.join(staging,file.path);await fs.mkdir(path.dirname(to),{recursive:true});await fs.writeFile(to,file.bytes,{flag:'wx',mode:0o644});}
   await fs.writeFile(path.join(staging,MANIFEST),manifestBytes,{flag:'wx'});
   await verifyPackage(staging);
   // This structural check imports only local modules. It does not refresh data,
   // require a token or invoke a network request.
   const [{loadData},{validate}]=await Promise.all([import(pathToFileURL(path.join(staging,'scripts/data.mjs'))),import(pathToFileURL(path.join(staging,'scripts/validate.mjs')))]);
   const result=await validate(await loadData({api:false}));
   if(result.errors.length)throw Error('Packaged no-API structural validation failed: '+result.errors.slice(0,8).join('; '));
   await verifyPackage(staging);
   await fs.rename(staging,destination);
  }catch(error){await fs.rm(staging,{recursive:true,force:true});throw error;}
 }
 const receipt={checkedAt:new Date().toISOString(),builder:'scripts/package-source.mjs',builderVersion:VERSION,packagePath:packageRelative,packageDigest,manifestSha256:sha(manifestBytes),reused,counts:manifest.counts,redactions:manifest.redactions,verification:{...manifest.verification,noAPIStructuralValidationPassed:true,cleanNpmCiBuild:'pending independent root execution'},networkAcquisitionPerformed:false,publicationPerformed:false,modifiedOriginalSourceFiles:false};
 const receiptPath=`evaluation/source-package-${packageDigest.slice(0,16)}.json`;
 await fs.mkdir(path.join(root,'evaluation'),{recursive:true});
 // A repeat invocation preserves the original receipt, just as it preserves the
 // content-addressed package. Its path and digest remain the same.
 await fs.writeFile(path.join(root,receiptPath),stable(receipt),{flag:'wx'}).catch(error=>{if(error.code!=='EEXIST')throw error;});
 return {...receipt,receiptPath};
}

export async function verifyPackage(directory){
 const root=await fs.realpath(directory),manifest=JSON.parse(await safeRead(root,MANIFEST));
 if(manifest.version!==VERSION||!Array.isArray(manifest.files))throw Error('Unsupported source-package manifest.');
 const expected=new Set([MANIFEST,...manifest.files.map(x=>x.path)]),actual=await walk(root,'',{skip:new Set(),includePrivate:true});
 if(actual.length!==expected.size||actual.some(x=>!expected.has(x)))throw Error('Package is not pristine: missing or unlisted files. Verify before installing dependencies or building.');
 const files=[];
 for(const item of manifest.files){
  const bytes=await safeRead(root,item.path);
  if(bytes.length!==item.bytes||sha(bytes)!==item.sha256)throw Error(`Package checksum mismatch: ${item.path}`);
  files.push({path:item.path,bytes});
 }
 const digest=sha(stable({version:manifest.version,files:manifest.files}));
 if(digest!==manifest.packageDigest)throw Error('Package digest does not match its manifest.');
 const safety=await inspectFiles(files);
 return {packageDigest:digest,files:files.length,...safety};
}

export function selfTest(){
 const stats={removed:{}};
 const out=redactMetadata({source:{url:'https://institution.example/lesson',sha256:'a'.repeat(64),cachePath:'data/raw/private.html'},inspectedExcerpts:[{segment:2,time:'03:20',text:'private transcript passage'}],selectionDecision:'Original reason'},stats);
 assert.deepEqual(out.inspectedSections,[{segment:2,time:'03:20',charactersInspected:26}]);
 assert.equal(out.source.cachePath,undefined);assert.equal(JSON.stringify(out).includes('private transcript passage'),false);
 assert.throws(()=>redactMetadata({snippet:{title:'API payload'}}),/restricted/);
 assert.throws(()=>redactMetadata({access_token:'not-a-real-token'}),/restricted/);
 assert.throws(()=>prepareRecord({id:'fixture',reuse:{exportAllowed:false}},new Set(),{removed:{}}),/redistribution/);
 assert.throws(()=>prepareRecord({id:'fixture',reuse:{exportAllowed:true,basis:'unreviewed',annotationLicence:ANNOTATION_LICENCE}},new Set(),{removed:{}}),/new review/);
 assert.equal(outputPathAllowed('.cache/youtube/metadata.json'),false);assert.equal(outputPathAllowed('data/raw/source.json'),false);assert.equal(outputPathAllowed('.env.production'),false);assert.equal(outputPathAllowed('.env.example'),true);
 const foreignRoot=['','Users','someone','private.txt'].join('/');assert.throws(()=>scanString(foreignRoot,'fixture'),/private path/);
 return {checks:12,passed:true,network:false,fixtures:'Synthetic in-memory values only; no files or real credentials used.'};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 try{
  if(process.argv.includes('--self-test'))console.log(JSON.stringify(selfTest(),null,2));
  else if(process.argv[2]==='--verify'){
   if(!process.argv[3])throw Error('Usage: node scripts/package-source.mjs --verify PACKAGE_DIRECTORY');
   console.log(JSON.stringify(await verifyPackage(path.resolve(process.argv[3])),null,2));
  }else if(process.argv.length===2)console.log(JSON.stringify(await buildPackage(),null,2));
  else throw Error('Usage: node scripts/package-source.mjs [--self-test | --verify PACKAGE_DIRECTORY]');
 }catch(error){console.error(error.message);process.exitCode=1;}
}
