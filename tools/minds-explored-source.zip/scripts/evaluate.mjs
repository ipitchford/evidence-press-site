import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {gzipSync} from 'node:zlib';
import {ROOT,json,writeJSON,loadData} from './data.mjs';
import {search} from '../src/search.mjs';
import {buildIndex} from './discovery.mjs';
import {maintainAPIData} from './api-maintenance.mjs';
await maintainAPIData();
const benchmark=await json('evaluation/benchmark.json');
const sourceData=await loadData();
const built={builtAt:new Date().toISOString()};
const index=buildIndex(sourceData);
const related={synonyms:true,diversify:true,communityWeight:.12};
const variants={keyword:{synonyms:false,diversify:false,communityWeight:0},enhanced:related,lighterTitle:{...related,weights:{title:5,terms:3},communityWeight:.06},strongerTitle:{...related,weights:{title:9,terms:3},communityWeight:.18},noCommunity:{...related,communityWeight:0}};
const rows=[];
for(const task of benchmark.tasks){
  const result={...task,variants:{}};
  for(const [name,options] of Object.entries(variants)){
    const start=performance.now(),found=search(index,task.query,options);const elapsedMs=performance.now()-start;
    const top=found.slice(0,5);const relevantRoute=found.find(r=>['guide','path'].includes(r.kind)&&r.topics?.includes(task.family));
    const counts=top.reduce((a,r)=>{const id=r.providerId??'unknown';a[id]=(a[id]??0)+1;return a;},{});
    result.variants[name]={elapsedMs,resultCount:found.length,firstFive:top.map(r=>({id:r.id,kind:r.kind,title:r.title,description:r.description,url:r.url,sourceUrl:r.sourceUrl,provider:r.provider,providerId:r.providerId,courseId:r.courseId,topics:r.topics,level:r.level,qualified:r.qualified,score:r.score})),route:relevantRoute?{id:relevantRoute.id,title:relevantRoute.title,url:relevantRoute.url,description:relevantRoute.description}:null,largestProviderShare:Math.max(0,...Object.values(counts))/Math.max(1,top.length),manualJudgement:'pending'};
  }
  rows.push(result);
}
const report={checkedAt:new Date().toISOString(),benchmarkSha256:crypto.createHash('sha256').update(await fs.readFile(path.join(ROOT,'evaluation/benchmark.json'))).digest('hex'),indexBuiltAt:built.builtAt,indexRecords:index.length,method:'Same fixed24tasks, first5results and one topic-relevant guide/path per variant. Machine output alone is not a relevance judgment.',tasks:rows};
await writeJSON('evaluation/search-results.json',report);
try{await fs.access(path.join(ROOT,'evaluation/pre-tuning-search-results.json'));}catch{await writeJSON('evaluation/pre-tuning-search-results.json',report);}
const fake=Array.from({length:10000},(_,i)=>({...index[i%index.length],id:`synthetic-performance:${i}`,title:`${index[i%index.length]?.title??'Synthetic'} [fixture${i}]`}));
const timings=[];for(const task of benchmark.tasks){const t=performance.now();search(fake,task.query);timings.push(performance.now()-t);}
const bytes=Buffer.byteLength(JSON.stringify(fake)),synthetic={checkedAt:new Date().toISOString(),records:10000,fixturePolicy:'In memory only. Synthetic IDs are not written to the catalogue or public build.',indexBytes:bytes,indexGzipBytes:gzipSync(JSON.stringify(fake)).length,queryMedianMs:timings.sort((a,b)=>a-b)[Math.floor(timings.length/2)],queryMaxMs:Math.max(...timings),node:process.version,platform:process.platform,architecture:process.arch,scope:'Local Node CPU timing; not a mobile browser benchmark.'};await writeJSON('evaluation/scale-test.json',synthetic);
const data=sourceData;const missing={records:data.records.length,duration:data.records.filter(r=>r.durationSeconds==null).length,speaker:data.records.filter(r=>!r.speaker).length,language:data.records.filter(r=>!r.language).length,level:data.records.filter(r=>r.level==='unknown').length,uploadDate:data.records.filter(r=>!r.uploadDate).length,recordingDate:data.records.filter(r=>!r.recordingDate).length,transcript:data.records.filter(r=>r.transcript?.status==='unknown').length};await writeJSON('evaluation/missingness.json',{checkedAt:new Date().toISOString(),missing,notGlobalCompleteness:true});
console.log(JSON.stringify({tasks:rows.length,results:'evaluation/search-results.json',manualRelevanceInspection:'pending',scale:synthetic,missing},null,2));
