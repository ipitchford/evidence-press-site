import fs from 'node:fs/promises';
import http from 'node:http';
import crypto from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

export const READ_SCOPE='https://www.googleapis.com/auth/youtube.readonly';
export function challenge(verifier){return crypto.createHash('sha256').update(verifier).digest('base64url');}
export function authorisedScope(scope){return String(scope??'').split(/\s+/).some(s=>[READ_SCOPE,'https://www.googleapis.com/auth/youtube','https://www.googleapis.com/auth/youtube.force-ssl'].includes(s));}
export async function readClient(file){
  const parsed=JSON.parse(await fs.readFile(file,'utf8'));const client=parsed.installed;
  if(!client?.client_id||!client.client_secret||client.token_uri!=='https://oauth2.googleapis.com/token')throw Error('Expected an existing Google desktop OAuth client with the official token endpoint.');
  return client;
}
async function privateWrite(file,data){await fs.mkdir(path.dirname(file),{recursive:true});const tmp=file+'.tmp';await fs.writeFile(tmp,JSON.stringify(data,null,2)+'\n',{mode:0o600});await fs.chmod(tmp,0o600);await fs.rename(tmp,file);}
async function exchange(body){
  const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body),signal:AbortSignal.timeout(30000)});
  const data=await response.json();
  if(!response.ok||!data.access_token)throw Error(`Google token exchange failed (${String(data.error??response.status).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,80)}). No token values were logged.`);
  return data;
}
export async function accessToken(tokenFile){
  const saved=JSON.parse(await fs.readFile(tokenFile,'utf8'));
  if(!authorisedScope(saved.scope))throw Error('Existing authorisation has no suitable YouTube read scope. Do not expand permissions automatically.');
  if(saved.access_token && saved.expires_at>Date.now()+60000)return saved.access_token;
  if(!saved.refresh_token||!saved.clientConfigPath)throw Error('A saved refresh token and existing client configuration are needed.');
  const client=await readClient(saved.clientConfigPath);
  const fresh=await exchange({client_id:client.client_id,client_secret:client.client_secret,refresh_token:saved.refresh_token,grant_type:'refresh_token'});
  const result={...saved,...fresh,expires_at:Date.now()+Number(fresh.expires_in??3600)*1000};
  await privateWrite(tokenFile,result);return result.access_token;
}
export async function authorise(clientFile,tokenFile){
  const client=await readClient(clientFile),state=crypto.randomBytes(32).toString('base64url'),verifier=crypto.randomBytes(64).toString('base64url');
  let status='waiting-for-user',redirectUri;
  const server=http.createServer(async(req,res)=>{
    const url=new URL(req.url,'http://127.0.0.1');
    if(url.pathname==='/status'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({status,scope:READ_SCOPE}));return;}
    if(url.pathname!=='/callback'||url.searchParams.get('state')!==state){res.writeHead(400);res.end('This authorisation callback is invalid.');return;}
    if(url.searchParams.has('error')){status='declined';res.end('Authorisation was declined. The atlas can continue with institutional alternatives.');server.close();clearTimeout(timer);return;}
    const code=url.searchParams.get('code');if(!code){res.writeHead(400);res.end('No authorisation code was supplied.');return;}
    try{
      const tokens=await exchange({client_id:client.client_id,client_secret:client.client_secret,code,code_verifier:verifier,redirect_uri:redirectUri,grant_type:'authorization_code'});
      if(!authorisedScope(tokens.scope))throw Error('Google did not grant the requested read scope.');
      await privateWrite(tokenFile,{...tokens,clientConfigPath:path.resolve(clientFile),expires_at:Date.now()+Number(tokens.expires_in??3600)*1000,createdAt:new Date().toISOString()});
      status='authorised';res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end('<!doctype html><title>Evidence Press connected</title><h1>Authorisation saved locally</h1><p>You can return to Codex. The atlas will use read-only metadata requests. No video upload, deletion or channel change is part of this task.</p>');
      console.log(JSON.stringify({status,tokenFile:path.resolve(tokenFile),scope:tokens.scope}));
    }catch(error){status='failed';res.writeHead(400);res.end('Authorisation could not be saved. Return to Codex for the error summary.');console.error(error.message);}
    finally{server.close();clearTimeout(timer);}
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  redirectUri=`http://127.0.0.1:${server.address().port}/callback`;
  const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');
  Object.entries({client_id:client.client_id,redirect_uri:redirectUri,response_type:'code',scope:READ_SCOPE,access_type:'offline',state,code_challenge:challenge(verifier),code_challenge_method:'S256',prompt:'consent'}).forEach(([key,value])=>url.searchParams.set(key,value));
  console.log(JSON.stringify({status,authorisationUrl:url.href,statusUrl:`http://127.0.0.1:${server.address().port}/status`,scope:READ_SCOPE,expiresInMinutes:15}));
  const timer=setTimeout(()=>{status='expired';console.log(JSON.stringify({status}));server.close();},15*60*1000);
  return server;
}
if(process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href){
  const [command,clientFile,tokenFile]=process.argv.slice(2);
  if(command!=='authorise'||!clientFile||!tokenFile){console.error('Usage: node scripts/youtube-oauth.mjs authorise EXISTING_CLIENT_JSON PRIVATE_TOKEN_FILE');process.exitCode=1;}
  else await authorise(clientFile,tokenFile);
}
