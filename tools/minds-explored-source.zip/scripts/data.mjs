import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {applyAPI} from './api-overlay.mjs';
import {resolveAlternateId} from '../src/model.mjs';
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export async function json(file, fallback) {
  try { return JSON.parse(await fs.readFile(path.join(ROOT,file),'utf8')); }
  catch(error) { if(error.code === 'ENOENT' && fallback !== undefined) return fallback; throw error; }
}
export async function readDocuments(directory) {
  const names = (await fs.readdir(path.join(ROOT,directory))).filter(f=>f.endsWith('.json')).sort();
  return Promise.all(names.map(f=>json(path.join(directory,f))));
}
// Resolve confirmed source-upload aliases for navigation only. Reviewed files,
// upload-specific metadata, and the source IDs behind each reference stay intact.
export function resolveResourceAliases(data) {
  const byId=new Map(data.records.map(r=>[r.id,r]));
  const aliases=new Map(data.records.map(r=>[r.id,resolveAlternateId(r.id,byId)]));
  const resolve=id=>aliases.get(id)??id;
  const reference=(entry,key)=>{const id=resolve(entry[key]);return id===entry[key]?entry:{...entry,[key]:id,sourceResourceId:entry.sourceResourceId??entry[key]};};
  return {...data,
    resourceAliases:Object.fromEntries([...aliases].filter(([id,parent])=>id!==parent)),
    courses:data.courses.map(c=>({...c,resourceIds:[...new Set((c.resourceIds??[]).map(resolve))],...(c.sequence?{sequence:c.sequence.map(x=>reference(x,'resourceId'))}:{})})),
    guides:data.guides.map(g=>({...g,startingResourceId:resolve(g.startingResourceId),...(resolve(g.startingResourceId)!==g.startingResourceId?{startingSourceResourceId:g.startingSourceResourceId??g.startingResourceId}:{}),resources:(g.resources??[]).map(x=>reference(x,'id'))})),
    paths:data.paths.map(p=>({...p,steps:(p.steps??[]).map(x=>reference(x,'resourceId'))})),
  };
}
export async function loadData({api=true}={}) {
  const text = await fs.readFile(path.join(ROOT,'data/catalogue.jsonl'),'utf8');
  const raw = text.split('\n').filter(x=>x.trim()).map((line,i)=>{try{return JSON.parse(line)}catch{throw Error(`Invalid catalogue JSON at line ${i+1}`)}});
  const overrides=await json('data/editorial-overrides.json',{}), withdrawals=await json('data/withdrawals.json',[]);
  const withdrawn=new Map(withdrawals.map(x=>[x.id,x]));
  const base=raw.map(r=>({...r,...overrides[r.id],qualification:{...r.qualification,...overrides[r.id]?.qualification},...(withdrawn.has(r.id)?{withdrawn:true,withdrawalReason:withdrawn.get(r.id).reason}: {})}));
  const records=api?applyAPI(base,await json('.cache/youtube/metadata.json',{records:{}})):base;
  return resolveResourceAliases({records,sources:await json('data/sources.json'),courses:await json('data/courses.json'),supporting:await json('data/supporting.json'),taxonomy:await json('data/taxonomy.json'),guides:await readDocuments('content/guides'),paths:await readDocuments('content/paths')});
}
export async function writeJSON(file,value) { await fs.mkdir(path.dirname(path.join(ROOT,file)),{recursive:true}); await fs.writeFile(path.join(ROOT,file),JSON.stringify(value,null,2)+'\n'); }
