# Change record

## 10 November 2026: shop

- Added `/shop/`: annotated book shelves for each of the fourteen fields, textbooks, Amazon trials and study kit, from `content/shop.json`.
- Added a short "Books on this topic" list to the home page and to topic, guide, path, course and resource pages, chosen by the page's first topic.
- Every Amazon link carries the Associates tag, sits under an "Ad" label and has `rel="sponsored"`. The build and `tests/shop.test.mjs` refuse an untagged link. No prices or Amazon images are stored.
- Privacy page and footer now disclose the advertising links. The atlas still sets no tracking and records no clicks.

## 2026-11-07 — first local release preparation

Built the Evidence Press atlas with a bounded institutional/HackerTube source audit, 14-family taxonomy, canonical catalogue and separate course/supporting-resource records. Added 51 original question-led guides, 20 ordered paths and 201 individually checked core annotations; source samples and independent agent reviews prompted exclusions, topic corrections and clinical/prerequisite clarifications.

The final catalogue retains 4,645 source identities and qualifies 4,202 accessible videos. A review of overlapping course versions conservatively holds 111 possible repeated uploads outside the distinct count without claiming equivalence. Added a genetics guide to repair an identified discovery gap. Corrected an API-language fallback so that the language of a title cannot be presented as the language spoken in the video.

Implemented static rendered routes, keyword/related-word search, local library/playlists/progress/import/export, explicit third-party player and thumbnail loading, light/dark responsive design, source attribution and educational limits. Replaced native confirmation dialogs after an actual in-app-browser control stall. Added private read-only OAuth metadata ingestion, expiring overlays, deterministic source-cache import, schema checks and verification artifacts. No production publication or audience-impact claim.

Search ranking was revised against the preserved 24-task benchmark: generic query operators, inherited topic keywords and long-body coverage had obscured more relevant resources. Every retained variant and residual limitation is recorded in SEARCH_REVIEW.md. Final operational gates remain governed by PROGRESS.md and docs/RELEASE_CHECKLIST.md.

## 2026-11-07 — browser verification and local closeout

Completed actual search/filter, keyboard/theme, library/reset/import, playlist, progress, source navigation and media-choice checks after the old preview tab was closed. Repaired dialog focus containment, the permanent source link when a player loads, and a small homepage overflow. Added static fallback regression checks for all player pages. Observed short institutional and explicitly approved YouTube playback, with watched status remaining a separate user choice. Controlled local failure fixtures exercised retry, unavailable media and expired metadata, then were removed.

Rebuilt the static site and completed a new offline credential-free install, build, all 56 tests and validation after these repairs. Regenerated content-addressed source/static packages and verified every archive member. Local delivery is complete; production publication and DNS changes remain unauthorised.
