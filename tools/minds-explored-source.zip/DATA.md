# Data, evidence and counting

The executable schema is `data/schema/video.schema.json`; `src/model.mjs` defines qualification, canonicalisation and duration totals. Documentation does not override those files. Final counts belong to a single matching validation/build snapshot, recorded in [PROGRESS.md](PROGRESS.md).

## Files and identifiers

| File | Role |
| --- | --- |
| `data/catalogue.jsonl` | One normalised base video record per line. |
| `data/sources.json` | Provider identity, counting groups, access boundaries and reuse conditions. |
| `data/courses.json` | Parent courses/series and ordered membership. |
| `data/supporting.json` | Reading, methods, datasets and context resources, outside video totals. |
| `data/taxonomy.json` | Editable subject families, terms and reader questions. |
| `data/editorial-overrides.json` | Maintainer corrections keyed by canonical ID, preserved across normalisation. |
| `data/withdrawals.json` | Withdrawn IDs with reasons. |
| `content/guides/`, `content/paths/` | Original editorial content and source-check references. |
| `data/audits/`, `data/editorial-checks/` | Acquisition/editorial evidence; not a blanket redistribution permission. |
| `.cache/youtube/`, `.private/` | Private expiring API data and credentials; excluded from distributions. |

Video IDs use `youtube:<11-character ID>`, `vimeo:<numeric ID>` or `institution:<16-character hash>`. Canonicalisation does not merge genuinely different lectures. `alternateOf`, `withdrawn` and unresolved distinctness affect counting. The current review holds 111 possible repeat uploads outside discovery and the distinct-qualified total; it does not assert they are confirmed duplicates. Source records and course positions remain inspectable. Courses, videos, guides, paths, supporting resources and source providers remain separate entities. Provider brands sharing an organisation use `countingProviderId`; a discovery service is not automatically a video publisher.

## Record interpretation

| Fields | Meaning and limits |
| --- | --- |
| `title`, `canonicalUrl`, `sourceUrl`, `providerId`, `courseId` | Resource identity and context. Institutional affiliation does not endorse every claim. |
| `topics`, `tags` | Relevance assignments with course-level versus individual evidence preserved. |
| `level`, `levelBasis` | `foundation`, `intermediate`, `advanced`, `mixed` or `unknown`; an editorial judgement, not an official qualification or quality score. |
| `speaker`, `language`, `uploadDate`, `recordingDate` | Unknowns remain null. A course instructor is not automatically an individual speaker; upload is not recording. |
| `durationSeconds`, `durationEvidence` | Only supported durations contribute to time totals; missing values are reported rather than guessed. |
| `description`, `descriptionCheck` | Annotation basis, checker, date and method. A title-only match is not a checked substantive description. |
| `selection` | Institutional, community or editorial basis and a specific checked reason where established. |
| `qualification`, `availability` | Substantive relevance and dated permitted accessibility evidence are separate conditions. |
| `provenance` | URL, retrieval time, SHA-256 and an accurate inspection account. A hash proves saved-file identity, not reading or correctness. |
| `scientificAssessment` | Defaults to `not-assessed`; source checking is not scientific validation. |
| `reuse` | Permission and attribution for the actual fields, without extending atlas rights to source media. |

Foundation introduces a topic without specialist preparation. Intermediate assumes introductory disciplinary or quantitative knowledge. Advanced requires specialised methods or substantial technical preparation. Record the particular prerequisite basis and leave difficulty unknown when it cannot be supported.

Qualified videos require the model’s inclusion conditions and permitted dated access evidence, and cannot be withdrawn, double-counted alternates or unresolved possible repeats. A source-page 200 response or oEmbed result is insufficient. Official API status, authorised media byte-range checks and actual browser playback are distinct methods. The API check records reported GB restrictions; it does not establish worldwide playback or imply that the lecture was watched. Explicit exclusions and unresolved identity, substance or distinctness cannot be cured by an accessible API item.

## Community observations

Only HackerTube `rec` and `strong_rec` labels count positively. Neutral mentions, jokes and criticism are not recommendations; creator promotion is excluded from the checked recommendation signal. The export retains at most twenty mentions per video, not lifetime history.

Use the public phrase **checked non-creator recommendation**. A checked case has a documented bounded source/context judgement, not verified financial independence or an assurance that no undisclosed affiliation exists. Legacy implementation fields such as `independentPositiveMentions` must be interpreted within this narrower boundary. Unknown authorship remains unknown, and one checked case does not validate the whole discussion corpus.

## API overlay, expiry and rebuilding

The base catalogue remains on disk independently of the YouTube overlay. Only unexpired API metadata is applied at build time, including any API-only availability, durations, dates, language and thumbnails. Spoken language uses `defaultAudioLanguage`; `defaultLanguage` describes title/description text and is not used as audio-language evidence. Independently established language values remain intact. See the [official field definitions](https://developers.google.com/youtube/data/reference/rest/v3/videos#snippet.defaultAudioLanguage). The current retention window is 28 days. A no-API build is expected to yield fewer qualified resources and more unknown values; the original editorial content and independently supported catalogue are still buildable. Numerical release targets may legitimately fail in that mode.

Record the earliest expiry of any API data included in each static build as its refresh deadline. Before that deadline, refresh and publish a replacement build, or rebuild without expired API data and replace affected deployed files. Updating the private cache alone does not remove old HTML or indexes from a static host. Rollback artifacts must meet the same deadline. The retention command runs before refresh, build, evaluation and CLI validation; see [maintenance](docs/MAINTENANCE.md) and [retention](docs/API_RETENTION.md) for its bounded manifest and receipts.

## Distribution boundary

`dist/data/index.json` is the compact discovery index; rendered resource pages carry detail. `dist/exports/catalogue.json` is built without the API overlay and contains only fields allowed for redistribution. Ordered path exports live under `dist/exports/paths/`. These outputs do not grant rights to linked videos or readings.

A distributable source package must use reviewed permitted base records, original code/content, schemas, the lockfile and redacted evidence metadata. Exclude `.private/`, populated environment files, tokens, `.cache/youtube/`, raw source snapshots under `data/raw/`, private audit excerpts, full transcripts/comments, and API-bearing evaluation/search snapshots. Do not assume everything under `data/audits/` or `evaluation/` is public merely because it is JSON. Provide adapters and source URLs so a maintainer can reacquire permitted evidence; do not redistribute private payloads as a shortcut to a reproducible build.

The fixed first-release targets remain 3,000 qualified videos, fifty reviewed guides, twenty reviewed paths, two hundred individually checked core resources, twelve families and twenty verified groups supplying qualified videos. Meeting these structural targets does not establish a representative corpus, scientific accuracy, usability or audience impact.
