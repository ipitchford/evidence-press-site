# Search review

The selected public default is **keyword search**. The optional related-word mode is the inspected enhanced variant. This review covers the exact **2026-11-07T18:52:07.121Z** snapshot: all 24 fixed tasks, all five variants, each first five results and every selected guide/path.

Keyword task outcomes: **19 pass, 5 partial, 0 fail**. Enhanced: **20 pass, 4 partial, 0 fail**. A pass means a usable first-page answer, not five perfect results.

Keyword has **53 direct / 61 partial / 6 irrelevant** placements; enhanced has **52 / 60 / 8**. These small differences do not establish a general winner. Keyword is the simpler, less drifting default. Enhanced is a worthwhile explicit option because it improves cognitive ageing and some terminology matches. Keyword T12 is only partial: its mixed-age path is useful, but the other four hits are biological ageing. This limitation must not be hidden by the aggregate counts.

The reviewer is an agent who also authored 15 guides and six paths. This is not a user study, full-viewing audit or scientific validation. There are 4,198 reviewed placements across seven frozen runs, backed by 362 task-specific result judgements. The JSON contains every placement, rationale, source basis, selected-route judgement and concentration calculation.

The preserved 50-guide run at **2026-11-07T18:15:12.632Z** was equivalent to the inspected 18:08 run, as recorded in the [historical ranking-equivalence receipt](evaluation/ranking-equivalence.json). The intentional 51st-guide repair at **2026-11-07T18:33:05.805Z** changed T18 in all five modes and is preserved separately. The final **2026-11-07T18:52:07.121Z** run follows 111 unresolved distinctness holds and the audio-language correction: the index is now **4,398 records**, with **51 guides and 20 paths**. Four first pages changed, 116 retained the same identities/order, and all 120 selected routes are unchanged. These are development diagnostics and a targeted content repair, not held-out performance evidence.

## Recommendation and residual defects

Retain the separation of broad taxonomy from actual record evidence, conservative morphology, the final reduced credit for long guide/course bodies, and removal of age→ageing normalisation. Do not make related-word expansion/diversification the default. Keep it available as an explicit option; this is a combined feature comparison, not proof that a particular synonym alone caused each change. No further ranking tuning is requested in this review.

- **T18 is repaired through an intentional 51st guide:** it now ranks first and is the selected route in all five variants. Its explanation and fictional-estimate exercise distinguish association, population heritability, development and intervention. No ranking change produced this repair. Expanded modes still admit workplace safety lower down.
- **T12 cognitive ageing is partial in keyword:** its leading path does contain adult-cognition tasks and an ageing reading, but begins with adolescence; biological senescence fills the other four places. Enhanced finds the direct cognitive-ageing guide and adult-development lecture. The earlier communication-age error is gone.
- **T01, T14, T17 and T21 remain partial:** broad brain entry is too specialist; neural reward is under-described; animal tracking substitutes for a focused primate-cognition route; predictive processing is diluted by generic philosophy.
- Residual word-sense errors include emotional-intelligence “vision”, inclusive-design/mindfulness “practice”, statistical “Motivation”, single-trial fMRI for clinical trials, and mortality/identity for predictive processing. These are actual observed items, not hypothetical risks.
- The 18:02 all-guide failure for advanced decisions is repaired in 18:08. The checked specialist talk returns first in keyword, second in enhanced. Lighter title weighting additionally finds a checked recurrent-network decision model.
- Selected routes sometimes differ from the visible five. Keyword selects the better general language guide; enhanced selects a narrow bilingual-control guide. Both select a membrane/circuit route for Python beginners, although Neuromatch itself is a valid first result.

## Variant and snapshot comparison

Counts are direct / partial / irrelevant placements, not clicks, completions or learning gains. “Lighter” and “stronger” also use different community weights, so they are not pure title-weight ablations.

| Snapshot / variant | Direct | Partial | Irrelevant | Placements | Mean largest provider share | Mean largest known course share |
|---|---:|---:|---:|---:|---:|---:|
| current / keyword | 53 | 61 | 6 | 120 | 0.57 | 0.34 |
| current / enhanced | 52 | 60 | 8 | 120 | 0.47 | 0.26 |
| current / lighterTitle | 52 | 62 | 6 | 120 | 0.47 | 0.26 |
| current / strongerTitle | 49 | 61 | 10 | 120 | 0.48 | 0.27 |
| current / noCommunity | 52 | 60 | 8 | 120 | 0.47 | 0.26 |
| preOverlap / keyword | 53 | 61 | 6 | 120 | 0.57 | 0.34 |
| preOverlap / enhanced | 52 | 60 | 8 | 120 | 0.48 | 0.26 |
| preOverlap / lighterTitle | 52 | 62 | 6 | 120 | 0.47 | 0.26 |
| preOverlap / strongerTitle | 49 | 61 | 10 | 120 | 0.48 | 0.27 |
| preOverlap / noCommunity | 52 | 60 | 8 | 120 | 0.48 | 0.26 |
| preGenetics / keyword | 52 | 62 | 6 | 120 | 0.58 | 0.35 |
| preGenetics / enhanced | 51 | 61 | 8 | 120 | 0.48 | 0.26 |
| preGenetics / lighterTitle | 51 | 63 | 6 | 120 | 0.47 | 0.26 |
| preGenetics / strongerTitle | 48 | 62 | 10 | 120 | 0.48 | 0.27 |
| preGenetics / noCommunity | 51 | 61 | 8 | 120 | 0.48 | 0.26 |
| coverage / keyword | 48 | 68 | 4 | 120 | 0.57 | 0.28 |
| coverage / enhanced | 50 | 65 | 5 | 120 | 0.51 | 0.25 |
| coverage / lighterTitle | 48 | 66 | 6 | 120 | 0.53 | 0.23 |
| coverage / strongerTitle | 46 | 68 | 6 | 120 | 0.52 | 0.25 |
| coverage / noCommunity | 50 | 65 | 5 | 120 | 0.51 | 0.25 |
| noiseFilter / keyword | 43 | 64 | 13 | 120 | 0.64 | 0.42 |
| noiseFilter / enhanced | 50 | 58 | 12 | 120 | 0.52 | 0.27 |
| noiseFilter / lighterTitle | 46 | 61 | 13 | 120 | 0.44 | 0.28 |
| noiseFilter / strongerTitle | 46 | 63 | 11 | 120 | 0.49 | 0.29 |
| noiseFilter / noCommunity | 50 | 58 | 12 | 120 | 0.52 | 0.27 |
| intermediate / keyword | 40 | 57 | 23 | 120 | 0.64 | 0.42 |
| intermediate / enhanced | 47 | 52 | 21 | 120 | 0.53 | 0.27 |
| intermediate / lighterTitle | 46 | 59 | 15 | 120 | 0.47 | 0.28 |
| intermediate / strongerTitle | 44 | 59 | 17 | 120 | 0.52 | 0.30 |
| intermediate / noCommunity | 47 | 52 | 21 | 120 | 0.53 | 0.27 |
| baseline / keyword | 24 | 65 | 29 | 118 | 0.77 | 0.53 |
| baseline / enhanced | 31 | 61 | 28 | 120 | 0.52 | 0.28 |
| baseline / lighterTitle | 29 | 65 | 26 | 120 | 0.51 | 0.28 |
| baseline / strongerTitle | 29 | 59 | 32 | 120 | 0.56 | 0.30 |
| baseline / noCommunity | 31 | 61 | 28 | 120 | 0.52 | 0.28 |

Final overlap regression: T10 enhanced/noCommunity replace a partial cognitive-process lecture with the partial strategic-choice guide at fifth; the direct Churchland talk remains second. T21 enhanced/noCommunity swap the bottom two entries, moving the irrelevant mortality course to fourth: a small ordering regression, with the direct predictive account still third. All task verdicts and relevance totals remain unchanged. The [hold-integrity receipt](evaluation/editorial-review/overlap-readback.json) records 111 unresolved holds, zero confirmed equivalence mappings and no affected guide selections or path steps. No new ranking changes were made by this reviewer.

The 51st guide received a separate [independent agent substantive review](evaluation/editorial-review/packets/guides/genes-environment-and-behaviour.json), recorded as a pass for the current file hash in [reviews.jsonl](evaluation/editorial-review/reviews.jsonl). This search evaluator read the entire guide and its inference exercise; the independent reviewer read the specified underlying source sections. Neither check is human peer review or full-video viewing.

Snapshot dates: current 2026-11-07T18:52:07.121Z (4398 records); preOverlap 2026-11-07T18:33:05.805Z (4509 records); preGenetics 2026-11-07T18:15:12.632Z (4508 records); coverage 2026-11-07T18:02:25.812Z (4508 records); noiseFilter 2026-11-07T17:49:09.696Z (4508 records); intermediate 2026-11-07T17:46:55.183Z (4508 records); baseline 2026-11-07T15:59:25.022Z (4736 records).

The original baseline has 4,736 index records, the 50-guide stage 4,508, the first 51-guide stage 4,509 and the final post-hold stage 4,398, so its improvement cannot be assigned solely to ranking. Later tuning also followed inspection of these same tasks: this benchmark is a development diagnostic, not held-out performance evidence. Earlier task verdicts are preserved; the final task-level calibration allows useful first-page routes despite lower-result defects. Use the result-level labels for the consistent cross-snapshot comparison.

Current enhanced and noCommunity are identical in first-five order on all 24 tasks. There is no observed first-page benefit from the community factor here. LighterTitle matches keyword’s six irrelevant placements but has one fewer direct placement; strongerTitle has fewer direct and more irrelevant placements. Neither weight setting is a uniformly better replacement.

Producer balance is not relevance. Keyword’s cultural page is NPTEL-heavy but includes three scoped cultural lectures. Enhanced’s therapy page is less Evidence Press-heavy because it replaces a useful evidence guide with an irrelevant fMRI toolbox. Conversely, enhanced’s cognitive-ageing diversification produces a real subfield repair. Detailed per-page source/course/family counts and their caveats are in the JSON.

## Task-by-task findings

### T01 — How does the brain work?

**Keyword: PARTIAL; enhanced: PARTIAL.** One checked foundation lecture remains at fifth place, but the first four are methods, bilingual representation or a specialist brain discussion. Keyword retains two foundation lectures and is the more useful first page.

Criterion: An accessible substantial introduction, not a short promotional clip.

Manual comparison: **keyword** — Retains two accessible foundation lectures; expansion inserts a bilingual specialist.

Keyword first five:

1. **partial — How can we study what a human brain is doing?** (guide:how-to-study-a-human-brain): Measurement and experimental-design route assumes introductory psychology; useful follow-up rather than an account of basic brain function.
2. **partial — From a brain question to an experiment** (path:questions-to-brain-experiments): A substantial ordered Human Brain route, but its purpose is experimental questions and methods and it expects introductory psychology, rather than supplying the requested basic mechanism overview.
3. **partial — BI 249 Michael Cole: Brain Flows are the Units of Cognition** (youtube:jbqLZoRGuUM): Attributed network-flow theory is relevant to brain function but is a specialist proposal, not a general foundation.
4. **direct — Lecture 2 - Foundations: This Is Your Brain** (youtube:vg01Q1BI4WM): Checked foundation overview explicitly introduces basic neurophysiology alongside mind–body accounts.
5. **direct — Lecture 3: Brain I** (youtube:SjjGiqf96rI): Checked introductory transcript covers neurons, organisation and functional specialisation.

Enhanced first five:

1. **partial — How can we study what a human brain is doing?** (guide:how-to-study-a-human-brain): Measurement and experimental-design route assumes introductory psychology; useful follow-up rather than an account of basic brain function.
2. **partial — Lec 9: Bilingual brain: neural representation of languages** (youtube:bdfJ8pXYnfo): Course context supports bilingual neural representation only; individual description and introductory suitability are unestablished.
3. **partial — From a brain question to an experiment** (path:questions-to-brain-experiments): A substantial ordered Human Brain route, but its purpose is experimental questions and methods and it expects introductory psychology, rather than supplying the requested basic mechanism overview.
4. **partial — BI 249 Michael Cole: Brain Flows are the Units of Cognition** (youtube:jbqLZoRGuUM): Attributed network-flow theory is relevant to brain function but is a specialist proposal, not a general foundation.
5. **direct — Lecture 2 - Foundations: This Is Your Brain** (youtube:vg01Q1BI4WM): Checked foundation overview explicitly introduces basic neurophysiology alongside mind–body accounts.

Selected routes:

- keyword, enhanced, noCommunity: **partial — How can we study what a human brain is doing?**. Concrete two-experiment exercise is useful after basic psychology; it answers how to study brains rather than how brains work. First-five membership: keyword=yes; enhanced=yes; noCommunity=yes.
- lighterTitle, strongerTitle: **partial — From a brain question to an experiment**. Coherent introductory Human Brain sequence, focused mainly on questions, methods and experiments rather than basic mechanisms. First-five membership: lighterTitle=yes; strongerTitle=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | partial | 2/3/0 | 0.40 | 0.20 |
| enhanced | partial | 1/4/0 | 0.40 | 0.20 |
| lighterTitle | partial | 0/5/0 | 0.60 | 0.20 |
| strongerTitle | partial | 0/5/0 | 0.40 | 0.20 |
| noCommunity | partial | 1/4/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/5/0; intermediate: 2/3/0; noiseFilter: 2/3/0; coverage: 1/4/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Enhanced uses two authored methods routes plus three specialist/foundation sources. Keyword retains both MIT and Yale foundation lectures; adding the NPTEL bilingual source diversifies providers but worsens introductory fit. Lighter/stronger lose both direct foundation choices.

Concrete fix: Do not give additive brain/neural/neuroscience synonym rewards to specialised records. Keep the accessible brain lectures ahead of research-methods and bilingual continuations for this broad entry query.

### T02 — neurons and synapses course

**Keyword: PASS; enhanced: PASS.** The cellular lecture, ordered modelling path, synapse guide and checked Neuromatch introduction now appear in both keyword and enhanced. Prerequisites are explicit; the glia guide is a narrower companion.

Criterion: A course or full lecture explaining cellular mechanisms and prerequisites.

Manual comparison: **tie** — Same four direct entries and one glia companion; only order changes.

Keyword first five:

1. **direct — Lecture 02 : Networks of Neurons and Synapses** (youtube:SewdFR9rmrU): Official computational-neuroscience course context places this early lecture on neurons and synapses; individual depth remains unchecked.
2. **direct — From neurons and spike data to network models** (path:neurons-data-and-models): Ordered current/circuit/synapse route explicitly states mathematics and neuroscience prerequisites.
3. **direct — How do synapses change a circuit’s response?** (guide:synapses-and-changing-circuits): Explicitly separates transmission, temporary changes and learning rules, with a circuit-response exercise and mathematical/notebook prerequisites.
4. **partial — What do glial cells contribute beyond supporting neurons?** (guide:glia-and-the-living-circuit): Explains microglial roles in developing connections and distinguishes cell types, but presupposes neuron/synapse vocabulary and is a specialised companion.
5. **direct — Intro** (youtube:MAOOPv3whZ0): Checked Neuromatch description introduces neuronal and synaptic biological complexity and connects it to the practical model sequence.

Enhanced first five:

1. **direct — Lecture 02 : Networks of Neurons and Synapses** (youtube:SewdFR9rmrU): Official computational-neuroscience course context places this early lecture on neurons and synapses; individual depth remains unchecked.
2. **direct — From neurons and spike data to network models** (path:neurons-data-and-models): Ordered current/circuit/synapse route explicitly states mathematics and neuroscience prerequisites.
3. **direct — How do synapses change a circuit’s response?** (guide:synapses-and-changing-circuits): Explicitly separates transmission, temporary changes and learning rules, with a circuit-response exercise and mathematical/notebook prerequisites.
4. **direct — Intro** (youtube:MAOOPv3whZ0): Checked Neuromatch description introduces neuronal and synaptic biological complexity and connects it to the practical model sequence.
5. **partial — What do glial cells contribute beyond supporting neurons?** (guide:glia-and-the-living-circuit): Explains microglial roles in developing connections and distinguishes cell types, but presupposes neuron/synapse vocabulary and is a specialised companion.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — From neurons and spike data to network models**. Eight ordered steps connect currents, circuit models, synapses and spike data; prerequisites and omitted derivations are explicit. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 4/1/0 | 0.60 | 0.20 |
| enhanced | pass | 4/1/0 | 0.60 | 0.20 |
| lighterTitle | pass | 4/1/0 | 0.60 | 0.20 |
| strongerTitle | pass | 4/1/0 | 0.60 | 0.20 |
| noCommunity | pass | 4/1/0 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 2/3/0; intermediate: 4/1/0; noiseFilter: 4/1/0; coverage: 4/1/0; preGenetics: 4/1/0; preOverlap: 4/1/0.

Source/course/subfield balance: Three authored routes give Evidence Press a 60% share, but their underlying teaching sources differ. NPTEL and Neuromatch supply the two video entries. All weights preserve this coherent cellular/synaptic focus; equal provider shares are not needed.

Concrete fix: Retain the cellular/synaptic sequence and its prerequisites; present glia and neuroscience history as optional companions rather than interchangeable starting courses.

### T03 — how vision works

**Keyword: PASS; enhanced: PASS.** The first page supplies three substantial visual-processing introductions or continuations, so the task is usable despite an emotional-intelligence metaphor at fourth place. A pass does not mean that every result is relevant.

Criterion: Introductory perception material about visual processing.

Manual comparison: **enhanced** — Replaces a mid-level continuation with a checked introductory vision/memory account.

Keyword first five:

1. **partial — 10: Mid-Level Vision** (youtube:-I6-wJuPXk4): Real perception-course material, but mid-level processing is not an introductory starting point and description is unchecked.
2. **partial — 11: Mid-Level Vision (cont'd)** (youtube:4FXDthnSA5c): Continuation within perception needs the preceding mid-level lecture; introductory fit is not established.
3. **direct — Vision** (youtube:EybTJ85iv24): Vision within Introduction to Brain and Behaviour matches the beginner topic, with course-context rather than individual-description evidence.
4. **irrelevant — Lecture 23 : EI New Vision for Learning** (youtube:kWFkpAL3HhA): Emotional-intelligence teaching uses vision metaphorically; course context is not visual perception.
5. **direct — Lecture 5: Vision I** (youtube:v4ur5mna060): First vision lecture in introductory psychology is a plausible starting point; record evidence is course context only.

Enhanced first five:

1. **partial — 10: Mid-Level Vision** (youtube:-I6-wJuPXk4): Real perception-course material, but mid-level processing is not an introductory starting point and description is unchecked.
2. **direct — Vision** (youtube:EybTJ85iv24): Vision within Introduction to Brain and Behaviour matches the beginner topic, with course-context rather than individual-description evidence.
3. **direct — Lecture 7 - Conscious of the Present; Conscious of the Past: Language (cont.); Vision and Memory** (youtube:DmWrOUK2zgA): Checked introductory overview moves into perception and attention, although language and memory share the lecture.
4. **irrelevant — Lecture 23 : EI New Vision for Learning** (youtube:kWFkpAL3HhA): Emotional-intelligence teaching uses vision metaphorically; course context is not visual perception.
5. **direct — Lecture 5: Vision I** (youtube:v4ur5mna060): First vision lecture in introductory psychology is a plausible starting point; record evidence is course context only.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — How does attention shape what we notice?**. Clear tasks and illusion exercise support perception study, but the specialist attention start is narrower and harder than a first account of vision. First-five membership: keyword=no; enhanced=no; lighterTitle=no; strongerTitle=no; noCommunity=no.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 2/2/1 | 0.60 | 0.40 |
| enhanced | pass | 3/1/1 | 0.40 | 0.20 |
| lighterTitle | pass | 3/1/1 | 0.40 | 0.20 |
| strongerTitle | pass | 3/1/1 | 0.40 | 0.20 |
| noCommunity | pass | 3/1/1 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 2/2/1; intermediate: 3/1/1; noiseFilter: 3/1/1; coverage: 3/1/1; preGenetics: 3/1/1; preOverlap: 3/1/1.

Source/course/subfield balance: Enhanced has two MIT, two NPTEL and one Yale slot. Keyword concentrates three slots at MIT, including two adjacent mid-level lectures. Enhanced improves introductory breadth, but the emotional-intelligence metaphor is an irrelevant subfield shift under every weight.

Concrete fix: Prefer the introductory vision entry before the mid-level continuation and keep metaphorical “vision for learning” from matching the visual-processing sense.

### T04 — attention and consciousness difference

**Keyword: PASS; enhanced: PASS.** The directly relevant attention guide and checked awareness lecture occupy the first two enhanced places. Animal consciousness, predictive experience and a GWT/AI talk provide optional theoretical context.

Criterion: Material that distinguishes the concepts and links to consciousness.

Manual comparison: **enhanced** — Adds the checked attention-and-awareness lecture next to the direct guide.

Keyword first five:

1. **direct — How does attention shape what we notice?** (guide:attention-and-perception): Purpose explicitly separates selection, perceptual performance and awareness; includes a discriminating task exercise.
2. **partial — How can we investigate consciousness in other animals?** (guide:other-animals-and-consciousness): Distinguishes behaviour from experience in animals, but is not principally about attention versus consciousness.
3. **partial — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Embodied predictive consciousness account is relevant background but does not explicitly establish the attention distinction.
4. **partial — From experience to competing theories of consciousness** (path:consciousness-theories-route): Contrasts theories and measurement of experience, but is not primarily an attention-versus-awareness route.
5. **partial — Can Theories of Consciousness Supercharge AI?** (youtube:TXlfCY4m9jU): The checked description names Global Workspace Theory in an AI architecture discussion, not a direct comparison of attention with awareness.

Enhanced first five:

1. **direct — How does attention shape what we notice?** (guide:attention-and-perception): Purpose explicitly separates selection, perceptual performance and awareness; includes a discriminating task exercise.
2. **direct — Lecture 24: Attention and Awareness** (youtube:B4a0WdGp52g): Checked publisher account compares consciously experienced and unexperienced perceptual information.
3. **partial — How can we investigate consciousness in other animals?** (guide:other-animals-and-consciousness): Distinguishes behaviour from experience in animals, but is not principally about attention versus consciousness.
4. **partial — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Embodied predictive consciousness account is relevant background but does not explicitly establish the attention distinction.
5. **partial — Can Theories of Consciousness Supercharge AI?** (youtube:TXlfCY4m9jU): The checked description names Global Workspace Theory in an AI architecture discussion, not a direct comparison of attention with awareness.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How does attention shape what we notice?**. The guide explicitly separates performance from reported awareness and links to the checked Attention and Awareness lecture. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.60 | 0.20 |
| enhanced | pass | 2/3/0 | 0.40 | 0.20 |
| lighterTitle | pass | 2/3/0 | 0.40 | 0.20 |
| strongerTitle | pass | 2/3/0 | 0.40 | 0.20 |
| noCommunity | pass | 2/3/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 2/3/0; intermediate: 2/1/2; noiseFilter: 2/3/0; coverage: 2/3/0; preGenetics: 2/3/0; preOverlap: 2/3/0.

Source/course/subfield balance: Enhanced combines two authored guides, a checked MIT attention lecture, Oxford and World Science Festival. Keyword instead returns a third authored theory path. The additional awareness lecture improves specificity; provider diversity by itself does not establish that improvement.

Concrete fix: Keep the attention/awareness guide and lecture together; a generic consciousness or AI-theory match should not displace either simply through additional related words.

### T05 — how memory works introduction

**Keyword: PASS; enhanced: PASS.** The direct memory guide and three checked introductory lectures make a usable first page. Enhanced replaces another checked introduction with a neurobiology course whose outline is relevant but whose entry requirements are unknown.

Criterion: A serious accessible account of memory with an identified starting point.

Manual comparison: **keyword** — Keeps the checked introductory memory continuation rather than an entry-level-unknown neurobiology course.

Keyword first five:

1. **direct — Why can one kind of memory fail while another remains?** (guide:remembering-and-forgetting): Accessible task-based memory explanation specifies an amnesia starting lecture and preparatory Memory I material.
2. **direct — Lecture 10: Memory I** (youtube:76O3rulk844): Checked foundation session covers categories, retention and interference and explicitly introduces memory.
3. **direct — Lecture 11: Memory II: Amnesia and Memory Systems** (youtube:kD3CswjYb2E): Checked amnesia-based introduction makes memory-system distinctions concrete after Memory I.
4. **direct — Lecture 7 - Conscious of the Present; Conscious of the Past: Language (cont.); Vision and Memory** (youtube:DmWrOUK2zgA): Checked introductory account includes different kinds of memory alongside perception and language; mixed scope is disclosed.
5. **direct — Lecture 8 - Conscious of the Present; Conscious of the Past: Vision and Memory (cont.)** (youtube:Yuwqr5o58Z0): Checked foundation lecture explicitly reviews memory types, limitations, strategies and suggestibility.

Enhanced first five:

1. **direct — Why can one kind of memory fail while another remains?** (guide:remembering-and-forgetting): Accessible task-based memory explanation specifies an amnesia starting lecture and preparatory Memory I material.
2. **direct — Lecture 10: Memory I** (youtube:76O3rulk844): Checked foundation session covers categories, retention and interference and explicitly introduces memory.
3. **direct — Lecture 7 - Conscious of the Present; Conscious of the Past: Language (cont.); Vision and Memory** (youtube:DmWrOUK2zgA): Checked introductory account includes different kinds of memory alongside perception and language; mixed scope is disclosed.
4. **partial — Learning about Learning : A Course on Neurobiology of Learning and Memory** (course:nptel:102108071): The inspected ordered outline moves from history/classification to associative learning, Rescorla–Wagner models and molecular memory; it is relevant but the prerequisites and accessibility of the full course are unstated.
5. **direct — Lecture 11: Memory II: Amnesia and Memory Systems** (youtube:kD3CswjYb2E): Checked amnesia-based introduction makes memory-system distinctions concrete after Memory I.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — Why can one kind of memory fail while another remains?**. The guide separates memory tasks, gives an explicit case-based start and optional preparation, and uses an interpretable recall exercise. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 5/0/0 | 0.40 | 0.40 |
| enhanced | pass | 4/1/0 | 0.40 | 0.40 |
| lighterTitle | pass | 4/1/0 | 0.40 | 0.40 |
| strongerTitle | pass | 4/1/0 | 0.40 | 0.40 |
| noCommunity | pass | 4/1/0 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 5/0/0; intermediate: 5/0/0; noiseFilter: 5/0/0; coverage: 4/1/0; preGenetics: 4/1/0; preOverlap: 4/1/0.

Source/course/subfield balance: Enhanced uses two MIT lectures, Yale, NPTEL and the guide. Keyword keeps two MIT and two Yale introductory lectures. Diversifying into an outline-only neurobiology course sacrifices known introductory fit; lighter/stronger promote that course further.

Concrete fix: Keep the checked introductory lectures before the mathematical/molecular course when the user asks for an introduction; retain the latter as an explicitly scoped continuation.

### T06 — evidence for retrieval practice

**Keyword: PASS; enhanced: PASS.** The evidence-focused practice guide and study/teaching path now occupy the first two positions and provide a useful answer route. The last two entries are still wrong senses of “practice”.

Criterion: Educational learning evidence with a methods or review route.

Manual comparison: **tie** — Identical useful first two routes and identical two practice-sense errors.

Keyword first five:

1. **direct — How can practice produce lasting learning?** (guide:practice-that-lasts): Directly addresses recall practice, feedback and a retrieved institutional evidence synthesis with explicit study limits.
2. **direct — From a study attempt to a teaching design** (path:evidence-informed-study-and-teaching): Retrieval attempt, monitoring, alignment and feedback sequence includes a specific teaching-evidence reading.
3. **partial — Retrieval from Long-Term Memory** (youtube:eb8iyzFq3lc): Retrieval mechanisms in cognitive psychology are relevant background; outline does not establish testing-effect evidence.
4. **irrelevant — Inclusive Design: From Principles to Practice** (youtube:8EKQgM1rjuc): Inclusive design practice in a user-research course is not retrieval practice.
5. **irrelevant — Lec 10:Mindfulness: Mechanisms, benefits and practice** (youtube:qFsay1SgBsc): Mindfulness practice is a different intervention with no established retrieval-learning evidence.

Enhanced first five:

1. **direct — How can practice produce lasting learning?** (guide:practice-that-lasts): Directly addresses recall practice, feedback and a retrieved institutional evidence synthesis with explicit study limits.
2. **direct — From a study attempt to a teaching design** (path:evidence-informed-study-and-teaching): Retrieval attempt, monitoring, alignment and feedback sequence includes a specific teaching-evidence reading.
3. **partial — Retrieval from Long-Term Memory** (youtube:eb8iyzFq3lc): Retrieval mechanisms in cognitive psychology are relevant background; outline does not establish testing-effect evidence.
4. **irrelevant — Inclusive Design: From Principles to Practice** (youtube:8EKQgM1rjuc): Inclusive design practice in a user-research course is not retrieval practice.
5. **irrelevant — Lec 10:Mindfulness: Mechanisms, benefits and practice** (youtube:qFsay1SgBsc): Mindfulness practice is a different intervention with no established retrieval-learning evidence.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How can practice produce lasting learning?**. The reading supplies an evidence route; the exercise is accurately separated from a controlled effect estimate. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 2/1/2 | 0.60 | 0.20 |
| enhanced | pass | 2/1/2 | 0.60 | 0.20 |
| lighterTitle | pass | 2/1/2 | 0.60 | 0.20 |
| strongerTitle | pass | 2/1/2 | 0.60 | 0.20 |
| noCommunity | pass | 2/1/2 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/3/2; intermediate: 1/0/4; noiseFilter: 2/1/2; coverage: 2/1/2; preGenetics: 2/1/2; preOverlap: 2/1/2.

Source/course/subfield balance: Three NPTEL courses accompany the guide and path in every variant. Two are wrong senses of practice. These source differences do not constitute useful educational evidence diversity.

Concrete fix: Preserve the useful guide/path pair and suppress inclusive-design and mindfulness matches for the compound retrieval-practice concept. No extra unrelated result is needed to fill a page.

### T07 — language in the brain

**Keyword: PASS; enhanced: PASS.** All five enhanced videos concern language and neural organisation. However, enhanced selects a narrower bilingual-control guide, while keyword selects the better-matched speech-and-language introduction.

Criterion: A route connecting language research and neuroscience.

Manual comparison: **keyword** — Same five direct videos, but keyword selects the broad language route rather than bilingual control.

Keyword first five:

1. **direct — Lec 13: Language in the brain** (youtube:X_kV21ZJ5jI): The official language/culture/cognition course explicitly places this lecture on language in the brain; individual explanation remains unchecked.
2. **direct — Lec 14: Language in the brain contd.** (youtube:s2RPH0bKYpU): Continuation of the explicit language-in-brain unit, supported by course sequence.
3. **direct — Lecture 6 - How Do We Communicate?: Language in the Brain, Mouth and the Hands** (youtube:Uf9tlbMckS0): Checked foundation account connects linguistic structure, acquisition and specialisation.
4. **direct — Language in the Human Brain** (youtube:kVi8uMDZh2s): Official introductory brain-and-behaviour course has a directly relevant language unit; inspection remains outline-only.
5. **direct — Lec 51: Language areas in the Brain** (youtube:KYrnbrsXsOw): Language areas within an acquisition course directly connects linguistic development and brain organisation.

Enhanced first five:

1. **direct — Lec 13: Language in the brain** (youtube:X_kV21ZJ5jI): The official language/culture/cognition course explicitly places this lecture on language in the brain; individual explanation remains unchecked.
2. **direct — Lecture 6 - How Do We Communicate?: Language in the Brain, Mouth and the Hands** (youtube:Uf9tlbMckS0): Checked foundation account connects linguistic structure, acquisition and specialisation.
3. **direct — Lec 14: Language in the brain contd.** (youtube:s2RPH0bKYpU): Continuation of the explicit language-in-brain unit, supported by course sequence.
4. **direct — Language in the Human Brain** (youtube:kVi8uMDZh2s): Official introductory brain-and-behaviour course has a directly relevant language unit; inspection remains outline-only.
5. **direct — Lec 51: Language areas in the Brain** (youtube:KYrnbrsXsOw): Language areas within an acquisition course directly connects linguistic development and brain organisation.

Selected routes:

- keyword: **direct — How is speech different from language?**. The guide connects structure and context to MIT neural questions, while cautioning that naming a region is not an explanation. First-five membership: keyword=no.
- enhanced, lighterTitle, strongerTitle, noCommunity: **partial — What does bilingual language control involve?**. The switching exercise is rigorous but narrows the query to bilingual control; keyword’s speech-and-language guide provides the better general entry. First-five membership: enhanced=no; lighterTitle=no; strongerTitle=no; noCommunity=no.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 5/0/0 | 0.80 | 0.40 |
| enhanced | pass | 5/0/0 | 0.80 | 0.40 |
| lighterTitle | pass | 5/0/0 | 0.80 | 0.40 |
| strongerTitle | pass | 5/0/0 | 0.80 | 0.40 |
| noCommunity | pass | 5/0/0 | 0.80 | 0.40 |

Earlier enhanced D/P/I: baseline: 5/0/0; intermediate: 5/0/0; noiseFilter: 5/0/0; coverage: 5/0/0; preGenetics: 5/0/0; preOverlap: 5/0/0.

Source/course/subfield balance: Four NPTEL slots span three courses, including a consecutive pair, alongside one Yale lecture. All five fit the neural-language topic. This 80% provider concentration persists across all final variants. The changed bilingual-control route is narrower despite unchanged video source/course concentration.

Concrete fix: Keep the broad language guide as the selected route; bilingual control is a continuation, and neural synonym expansion should not turn it into the general entry.

### T08 — children learning language

**Keyword: PASS; enhanced: PASS.** The acquisition guide and three developmental-language entries give a useful route. Keyword adds a fourth specific acquisition lesson, while enhanced replaces it with a broader child-development introduction.

Criterion: Developmental language explanation, not generic language-learning tips.

Manual comparison: **keyword** — Keeps a dedicated acquisition lesson instead of general child development.

Keyword first five:

1. **direct — How do children acquire a language?** (guide:how-children-acquire-language): Theories, infant methods and utterance exercise directly address developmental acquisition without diagnostic claims.
2. **direct — How do children learn language?** (youtube:aHyIgP6Qlc0): Official language-and-society course includes a directly named child-acquisition explanation; individual details remain unchecked.
3. **direct — Lec 38: Successive bilingualsim among children** (youtube:gr53HeRKOwI): Successive bilingual acquisition is a specific developmental case within an acquisition course.
4. **direct — Lecture 6: Do children talk?... And How?** (youtube:qg9sgkpbp1E): Early introductory psycholinguistics lecture explicitly studies children’s language production.
5. **direct — Lec 4: Bilingual acquisition among children: simultaneous bilingualism** (youtube:0rhvnbkdKJ8): Simultaneous bilingual acquisition is directly developmental, with official course context.

Enhanced first five:

1. **direct — How do children acquire a language?** (guide:how-children-acquire-language): Theories, infant methods and utterance exercise directly address developmental acquisition without diagnostic claims.
2. **direct — How do children learn language?** (youtube:aHyIgP6Qlc0): Official language-and-society course includes a directly named child-acquisition explanation; individual details remain unchecked.
3. **direct — Lec 38: Successive bilingualsim among children** (youtube:gr53HeRKOwI): Successive bilingual acquisition is a specific developmental case within an acquisition course.
4. **direct — Lecture 6: Do children talk?... And How?** (youtube:qg9sgkpbp1E): Early introductory psycholinguistics lecture explicitly studies children’s language production.
5. **partial — Lecture 17: Child Development** (youtube:yBYebcVw8Zk): Checked introduction covers infancy, cognitive development, historical theories and learning; it is useful background but not a dedicated language-acquisition account.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How do children acquire a language?**. Methods appear early; the guide connects infant responses to narrow inferences and provides a concrete child-utterance comparison. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 5/0/0 | 0.80 | 0.20 |
| enhanced | pass | 4/1/0 | 0.60 | 0.20 |
| lighterTitle | pass | 4/1/0 | 0.60 | 0.20 |
| strongerTitle | pass | 4/1/0 | 0.60 | 0.20 |
| noCommunity | pass | 4/1/0 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 1/4/0; intermediate: 5/0/0; noiseFilter: 5/0/0; coverage: 4/1/0; preGenetics: 4/1/0; preOverlap: 4/1/0.

Source/course/subfield balance: Keyword is 80% NPTEL across four acquisition courses, which is concentrated but topically coherent. Enhanced is 60% NPTEL and adds broader MIT child development. LighterTitle adds bilingual control instead. Those changes diversify or broaden the page without improving the specific acquisition fit.

Concrete fix: Keep the acquisition route first and label control as a separate continuation; a checked developmental methods lecture would be a better fifth result.

### T09 — why people make biased decisions

**Keyword: PASS; enhanced: PASS.** The correct judgement-bias guide is selected and visible third. Two financial-bias entries and two action/intention interpretations provide narrower context; the guide is the clearest route to limits and alternatives.

Criterion: An explanation of judgement and biases with limits or competing accounts.

Manual comparison: **enhanced** — Same set, with the general bias guide one place higher.

Keyword first five:

1. **partial — Lecture 15: Biases and Financial Decision-Making** (youtube:V4jLDpJzvs8): Financial decision biases match the subject, but source outline does not establish explanations or competing-account limits.
2. **partial — Lecture 16: Biases and Financial Decision-Making (Contd.)** (youtube:PUUoAyXW3XI): Relevant financial-bias continuation; no checked individual account of mechanisms or qualifications.
3. **partial — Bias and Intention** (youtube:vtyhYf-3IjY): Checked bias-toward-action versus settled-intention argument is a specific experimental interpretation, not the general judgement-bias question.
4. **direct — When are choices biased, and what is the comparison standard?** (guide:when-is-a-choice-biased): Explicitly connects bias examples to normative standards, alternative goals, assumptions and limits.
5. **partial — Do brain recordings show that free will is an illusion?** (guide:free-will-and-brain-recordings): It audits experimental interpretation and a specific action/intention bias, but concerns agency and free will rather than general judgement heuristics.

Enhanced first five:

1. **partial — Lecture 15: Biases and Financial Decision-Making** (youtube:V4jLDpJzvs8): Financial decision biases match the subject, but source outline does not establish explanations or competing-account limits.
2. **partial — Lecture 16: Biases and Financial Decision-Making (Contd.)** (youtube:PUUoAyXW3XI): Relevant financial-bias continuation; no checked individual account of mechanisms or qualifications.
3. **direct — When are choices biased, and what is the comparison standard?** (guide:when-is-a-choice-biased): Explicitly connects bias examples to normative standards, alternative goals, assumptions and limits.
4. **partial — Bias and Intention** (youtube:vtyhYf-3IjY): Checked bias-toward-action versus settled-intention argument is a specific experimental interpretation, not the general judgement-bias question.
5. **partial — Do brain recordings show that free will is an illusion?** (guide:free-will-and-brain-recordings): It audits experimental interpretation and a specific action/intention bias, but concerns agency and free will rather than general judgement heuristics.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — When are choices biased, and what is the comparison standard?**. The guide explicitly compares judgement with a specified standard, examines alternatives and provides a controlled framing thought exercise. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.40 | 0.40 |
| enhanced | pass | 1/4/0 | 0.40 | 0.40 |
| lighterTitle | pass | 1/4/0 | 0.40 | 0.40 |
| strongerTitle | pass | 1/4/0 | 0.40 | 0.40 |
| noCommunity | pass | 1/4/0 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 0/4/1; intermediate: 1/3/1; noiseFilter: 1/4/0; coverage: 1/4/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: The two financial-bias lectures share one NPTEL course; two authored guides and a World Science U intention-bias lesson supply the rest. Different producers still represent distinct meanings of bias. The general judgement guide is the useful anchor.

Concrete fix: Prefer the checked general bias guide above unchecked financial continuations; keep judgement heuristics distinct from intention-timing and free-will debates.

### T10 — decision making mathematical models

**Keyword: PASS; enhanced: PASS.** The checked specialist decision talk remains first in keyword and second in enhanced. After the final holds, enhanced/noCommunity replace a partial advanced-cognition lecture at fifth with the already-reviewed introductory strategic-choice guide; the task still passes. LighterTitle still finds the checked recurrent-network decision model.

Criterion: An advanced computational or experimental decision-making resource.

Manual comparison: **keyword** — Both restore the specialist decision talk; keyword puts it first instead of a probability foundation.

Keyword first five:

1. **direct — Anne Churchland (CSHL) 2: Connecting movements & neural activity during decision-making** (youtube:cFpGbmqXWOI): Publisher description explicitly connects measured movement and neural activity in experimental decision-making.
2. **partial — Classical Theory of Decision Making** (youtube:MLdhRkUB9GI): Classical decision theory is relevant, but advanced mathematical depth is not established by the introductory course outline.
3. **partial — Lecture 03: Economics of Decision Making** (youtube:fQb4zXcAjuw): Finance-course economics of decisions is relevant but advanced computational/experimental content is unverified.
4. **partial — Lecture 04: Economics of Decision Making (Contd.)** (youtube:eU524VR58Ww): Continuation of economics-of-decisions material; mathematical model depth remains unverified.
5. **partial — Lecture 05: Decision Making Under Risk and Uncertainty** (youtube:0KmgdWooYo0): Risk and uncertainty provide a modelling context, but the record does not establish advanced treatment.

Enhanced first five:

1. **partial — Probability models and human judgement** (path:uncertainty-and-judgement): An ordered probability-to-judgement foundation with a later auction example, not a dedicated advanced computational/experimental decision sequence.
2. **direct — Anne Churchland (CSHL) 2: Connecting movements & neural activity during decision-making** (youtube:cFpGbmqXWOI): Publisher description explicitly connects measured movement and neural activity in experimental decision-making.
3. **partial — Classical Theory of Decision Making** (youtube:MLdhRkUB9GI): Classical decision theory is relevant, but advanced mathematical depth is not established by the introductory course outline.
4. **partial — Lecture 03: Economics of Decision Making** (youtube:fQb4zXcAjuw): Finance-course economics of decisions is relevant but advanced computational/experimental content is unverified.
5. **partial — What changes when decisions depend on other people?** (guide:choices-that-depend-on-others): Introduces payoff tables, best responses and equilibrium with realistic Yale prerequisites; the selected route is introductory strategic modelling, not the requested advanced computational or experimental decision resource.

Selected routes:

- keyword: **partial — What changes when decisions depend on other people?**. Concrete payoff modelling is useful but introductory and strategic rather than advanced experimental modelling. First-five membership: keyword=no.
- enhanced, lighterTitle, strongerTitle, noCommunity: **partial — Probability models and human judgement**. Good probability-to-judgement foundations, but not an advanced decision-model sequence. First-five membership: enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.80 | 0.60 |
| enhanced | pass | 1/4/0 | 0.40 | 0.20 |
| lighterTitle | pass | 2/3/0 | 0.40 | 0.20 |
| strongerTitle | pass | 1/4/0 | 0.60 | 0.20 |
| noCommunity | pass | 1/4/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 1/4/0; intermediate: 1/4/0; noiseFilter: 1/4/0; coverage: 0/5/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Keyword concentrates four slots at NPTEL but begins with the checked specialist iBiology experiment. Final enhanced has two authored routes, two NPTEL courses and the iBiology talk; its fifth strategic guide replaces another NPTEL lecture. StrongerTitle retains that lecture, while lighterTitle adds the checked MIT recurrent-network model. The source-share change does not make the introductory routes direct advanced resources.

Concrete fix: Keep the specialist resource ahead of general foundations for an advanced query. The final fifth-place substitution is partial-for-partial and changes no verdict; no ranking repair is requested in this regression review.

### T11 — early experience development

**Keyword: PASS; enhanced: PASS.** The checked nature/nurture pair now leads, followed by a developmental-methods path. Enhanced also returns infant cognition; keyword/strongerTitle instead admit the unrelated conscious-experience guide.

Criterion: Substantive developmental material without deterministic claims.

Manual comparison: **enhanced** — Infant cognition replaces an unrelated conscious-experience guide.

Keyword first five:

1. **direct — Lecture 10: Development, Nature & Nurture I** (youtube:kAX_PRnliMo): Checked account explicitly concerns cortical development, genes and experience.
2. **direct — Lecture 11: Development, Nature & Nurture II (2018)** (youtube:xA00vkxG3lE): Checked publisher description continues the genes/experience/cortical-organisation discussion and extends early development to adult change.
3. **direct — Development from behaviour to brain and study design** (path:development-across-levels): Ordered child/adult and cortical-development sequence repeatedly separates developmental observations from measurement demands and deterministic interpretations.
4. **partial — Fundamentals of Language Acquisition** (course:nptel:109103753): Actual description and syllabus cover early language development, environmental/input histories, competing acquisition theories and observational methods; this is a useful but language-specific developmental case.
5. **irrelevant — What do we mean by conscious experience?** (guide:conscious-experience): The experience/content/report distinction concerns consciousness, not early experience as an influence on development.

Enhanced first five:

1. **direct — Lecture 10: Development, Nature & Nurture I** (youtube:kAX_PRnliMo): Checked account explicitly concerns cortical development, genes and experience.
2. **direct — Lecture 11: Development, Nature & Nurture II (2018)** (youtube:xA00vkxG3lE): Checked publisher description continues the genes/experience/cortical-organisation discussion and extends early development to adult change.
3. **direct — Development from behaviour to brain and study design** (path:development-across-levels): Ordered child/adult and cortical-development sequence repeatedly separates developmental observations from measurement demands and deterministic interpretations.
4. **partial — Fundamentals of Language Acquisition** (course:nptel:109103753): Actual description and syllabus cover early language development, environmental/input histories, competing acquisition theories and observational methods; this is a useful but language-specific developmental case.
5. **direct — Lecture 5 - What Is It Like to Be a Baby: The Development of Thought** (youtube:eznq75eBy2o): Checked infant-cognition overview asks how different kinds of development relate.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — Development from behaviour to brain and study design**. Contrasts behavioural and brain observations, recruitment and task demands, with explicit rejection of individual developmental timetables. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 3/1/1 | 0.40 | 0.40 |
| enhanced | pass | 4/1/0 | 0.40 | 0.40 |
| lighterTitle | pass | 4/1/0 | 0.40 | 0.40 |
| strongerTitle | pass | 3/1/1 | 0.40 | 0.40 |
| noCommunity | pass | 4/1/0 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 3/1/1; intermediate: 3/1/1; noiseFilter: 3/1/1; coverage: 3/2/0; preGenetics: 4/1/0; preOverlap: 4/1/0.

Source/course/subfield balance: Enhanced has two MIT lectures from the same Human Brain sequence, plus Yale, NPTEL and a path. The pair is a useful ordered discussion of nature/nurture. Keyword and strongerTitle replace infant cognition with a consciousness guide, reducing topical fit without adding useful developmental perspective.

Concrete fix: Retain the strong nature/nurture ordering and developmental route. Distinguish childhood experience from subjective conscious experience; the latter is a residual generic-word mismatch.

### T12 — ageing and cognition

**Keyword: PARTIAL; enhanced: PASS.** Enhanced supplies the checked adult-development lecture at third and the direct cognitive-ageing guide at fifth. Keyword instead has four biological-ageing lectures; the communication-age false match is removed.

Criterion: Cognitive ageing material distinguishable from advice marketing.

Manual comparison: **enhanced** — Repairs the cognitive-ageing gap; keyword remains a biological-ageing page.

Keyword first five:

1. **partial — Studying change from adolescence to ageing** (path:studying-adolescence-and-ageing): Later steps address cognitive outcomes and adult methods, but half the route concerns adolescence and the direct cognition guide would be more efficient.
2. **partial — Evolutionary Theories of Aging: Part 1** (youtube:bXFcCyAAnQI): Evolutionary senescence is ageing biology, not an established cognitive-ageing explanation.
3. **partial — Evolutionary Theories of Aging: Part 2** (youtube:ezX8LsA5JqI): Second evolutionary-ageing lecture repeats that biological focus without established cognition coverage.
4. **partial — Introduction to Aging** (youtube:G98eevRim3w): General ageing introduction in evolutionary biology supplies background, not cognitive outcomes.
5. **partial — Mechanistic Theories of Aging** (youtube:dRdsACbcdYM): Mechanistic ageing biology is relevant background but not a cognitive-ageing route.

Enhanced first five:

1. **partial — Studying change from adolescence to ageing** (path:studying-adolescence-and-ageing): Later steps address cognitive outcomes and adult methods, but half the route concerns adolescence and the direct cognition guide would be more efficient.
2. **partial — Evolutionary Theories of Aging: Part 1** (youtube:bXFcCyAAnQI): Evolutionary senescence is ageing biology, not an established cognitive-ageing explanation.
3. **direct — Lecture 18: Adult Development** (youtube:Qw4SkvZ03cc): Checked MIT overview explicitly covers cognitive, emotional and physical change across adulthood and ageing.
4. **partial — Lec 15: Successful aging: Part 1** (youtube:n-7InBUU2Uk): Successful-ageing framing belongs to positive psychology; cognitive measurement content is not established.
5. **direct — What changes in cognition as we age?** (guide:cognition-and-ageing): Defines cognitive tasks and separates cross-sectional age differences from longitudinal change, cohort and task-familiarity explanations; its exercise directly serves cognitive ageing.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — Studying change from adolescence to ageing**. Useful developmental-methods tasks, but the learner must pass through an adolescent strand before the requested ageing material. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | partial | 0/5/0 | 0.80 | 0.80 |
| enhanced | pass | 2/3/0 | 0.40 | 0.20 |
| lighterTitle | pass | 2/3/0 | 0.40 | 0.20 |
| strongerTitle | pass | 1/4/0 | 0.60 | 0.40 |
| noCommunity | pass | 2/3/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/0/5; intermediate: 0/5/0; noiseFilter: 0/5/0; coverage: 2/2/1; preGenetics: 2/3/0; preOverlap: 2/3/0.

Source/course/subfield balance: Keyword concentrates four biological-ageing entries at NPTEL, mainly one evolutionary course, and lacks the cognitive guide. Enhanced adds MIT adult development and the cognitive guide while retaining two NPTEL sources. StrongerTitle drops the guide again; lighterTitle prioritises adult development. The subfield shift matters more than the provider count.

Concrete fix: Retain ageing/aging spelling equivalence without age→ageing. Prioritise the cognitive guide and adult-development entry over biological senescence, and prefer the specific guide to the mixed adolescent route.

### T13 — what happens during sleep

**Keyword: PASS; enhanced: PASS.** The sleep-specific guide now leads and is selected as the route; all first-page entries concern sleep or a clearly scoped sleep-led sequence.

Criterion: A substantial scientific explanation of sleep.

Manual comparison: **tie** — Identical page and selected route.

Keyword first five:

1. **direct — How are sleep and biological clocks studied?** (guide:sleep-and-biological-clocks): Purpose and tasks distinguish sleep, clock mechanisms and measurement, supported by current explanatory readings.
2. **direct — Lecture 17 - A Person in the World of People: Self and Other, Part II; Some Mysteries: Sleep, Dreams, and Laughter** (youtube:S6OfFaBWtx4): Checked foundation overview contains a sleep/dream explanation, with its mixed-topic scope explicitly disclosed.
3. **partial — Sleep, hunger and the circumstances of motivation** (path:sleep-hunger-and-reward): Starts with a verified sleep/rhythms topic and a current clock reading, then broadens to food and motivation.
4. **partial — Personal Growth Series: Dr. William Dement on Healthy Sleep and Optimal Perfo...** (youtube:8hAw1z8GdE8): Specialist sleep lecture is plausible, but the community card does not establish explanatory depth beyond healthy-sleep framing.
5. **direct — The Science of Sleep** (youtube:J9cVSnCVzbk): Official description directly identifies sleep research and brain activity during sleep.

Enhanced first five:

1. **direct — How are sleep and biological clocks studied?** (guide:sleep-and-biological-clocks): Purpose and tasks distinguish sleep, clock mechanisms and measurement, supported by current explanatory readings.
2. **direct — Lecture 17 - A Person in the World of People: Self and Other, Part II; Some Mysteries: Sleep, Dreams, and Laughter** (youtube:S6OfFaBWtx4): Checked foundation overview contains a sleep/dream explanation, with its mixed-topic scope explicitly disclosed.
3. **partial — Sleep, hunger and the circumstances of motivation** (path:sleep-hunger-and-reward): Starts with a verified sleep/rhythms topic and a current clock reading, then broadens to food and motivation.
4. **partial — Personal Growth Series: Dr. William Dement on Healthy Sleep and Optimal Perfo...** (youtube:8hAw1z8GdE8): Specialist sleep lecture is plausible, but the community card does not establish explanatory depth beyond healthy-sleep framing.
5. **direct — The Science of Sleep** (youtube:J9cVSnCVzbk): Official description directly identifies sleep research and brain activity during sleep.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How are sleep and biological clocks studied?**. Separates sleep from circadian timing, supplies current explanatory readings and a measurement exercise without sleep-deprivation advice. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 3/2/0 | 0.40 | 0.20 |
| enhanced | pass | 3/2/0 | 0.40 | 0.20 |
| lighterTitle | pass | 3/2/0 | 0.40 | 0.20 |
| strongerTitle | pass | 3/2/0 | 0.40 | 0.20 |
| noCommunity | pass | 3/2/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 2/1/2; intermediate: 3/1/1; noiseFilter: 3/2/0; coverage: 3/2/0; preGenetics: 3/2/0; preOverlap: 3/2/0.

Source/course/subfield balance: Two authored routes count as Evidence Press while combining several institutions. Yale, the community-listed Dement lecture and Bristol add different sleep entries. All final variants return the same order, so this benchmark shows no title/community sensitivity for this task.

Concrete fix: Keep the direct guide and official sleep explanation above broader motivation material; retain the mixed-content note on Yale’s lecture.

### T14 — reward and motivation neuroscience

**Keyword: PARTIAL; enhanced: PARTIAL.** The food/reward guide and risk/reward entry offer useful context, but the page still lacks a focused checked neural-reward route. The fifth “Motivation” entry is demonstrably an introduction to statistical testing.

Criterion: A course or lecture that identifies reward/motivation mechanisms.

Manual comparison: **tie** — Same useful narrow example and same statistics-motivation false match.

Keyword first five:

1. **partial — Sleep, hunger and the circumstances of motivation** (path:sleep-hunger-and-reward): Regulation and food-reward route is useful context but begins with sleep and does not concentrate on reward circuits.
2. **partial — Lecture 34 : Risk & Reward** (youtube:W7azb6DybqM): Risk and reward in beginner neuroscience is promising, but identified mechanisms are not established in the unchecked record.
3. **direct — How do hunger and reward interact?** (guide:hunger-reward-and-food-environments): Connects internal regulation, rewarding cues and learning with explanatory limits and a concrete eating-research setting.
4. **partial — Lecture 15: Emotion & Motivation** (youtube:t73rjeOj0eY): Checked opening defines emotion and brain mechanisms, but does not establish a focused reward explanation.
5. **irrelevant — Motivation** (youtube:4m7_2qorThU): The checked transcript excerpts concern manufacturing means, population parameters and statistical tests. “Motivation” introduces a statistics course; it is not psychological or neural motivation.

Enhanced first five:

1. **partial — Sleep, hunger and the circumstances of motivation** (path:sleep-hunger-and-reward): Regulation and food-reward route is useful context but begins with sleep and does not concentrate on reward circuits.
2. **partial — Lecture 34 : Risk & Reward** (youtube:W7azb6DybqM): Risk and reward in beginner neuroscience is promising, but identified mechanisms are not established in the unchecked record.
3. **partial — Lecture 15: Emotion & Motivation** (youtube:t73rjeOj0eY): Checked opening defines emotion and brain mechanisms, but does not establish a focused reward explanation.
4. **direct — How do hunger and reward interact?** (guide:hunger-reward-and-food-environments): Connects internal regulation, rewarding cues and learning with explanatory limits and a concrete eating-research setting.
5. **irrelevant — Motivation** (youtube:4m7_2qorThU): The checked transcript excerpts concern manufacturing means, population parameters and statistical tests. “Motivation” introduces a statistics course; it is not psychological or neural motivation.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — Sleep, hunger and the circumstances of motivation**. Coherent regulation route with meaningful tasks, but the initial sleep strand and food-environment ending make it broader than reward neuroscience. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | partial | 1/3/1 | 0.40 | 0.20 |
| enhanced | partial | 1/3/1 | 0.40 | 0.20 |
| lighterTitle | partial | 1/3/1 | 0.40 | 0.20 |
| strongerTitle | partial | 1/3/1 | 0.40 | 0.20 |
| noCommunity | partial | 1/3/1 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/2/3; intermediate: 1/4/0; noiseFilter: 1/4/0; coverage: 1/4/0; preGenetics: 1/3/1; preOverlap: 1/3/1.

Source/course/subfield balance: Two authored regulation routes, a MIT emotion lecture and two different NPTEL courses look balanced. One NPTEL source is actually statistical-test motivation. That wrong subject remains under every variant; no diversity measure detects its semantic mismatch.

Concrete fix: Use the checked description to disambiguate the statistics “Motivation” title. Prioritise an individually described neural reward source and retain the food guide as a specific example.

### T15 — measuring intelligence

**Keyword: PASS; enhanced: PASS.** The exact psychometric guide and checked MIT intelligence session now lead. The lower page is largely on topic, with an emotional-intelligence/happiness false match remaining.

Criterion: Psychometric methods and interpretation, not an online IQ quiz.

Manual comparison: **keyword** — Avoids the emotional-intelligence/happiness construct mismatch.

Keyword first five:

1. **direct — What do intelligence test scores measure?** (guide:what-intelligence-tests-measure): Directly distinguishes performance, score, construct and causal explanation with a measurement-design exercise.
2. **direct — Lecture 14: Intelligence** (youtube:bihrpOS0qtY): Checked session explicitly covers tests, validity and interpretations with historical limits.
3. **partial — Intelligence - I** (youtube:4Kx3yFkEj-U): Intelligence introduction is relevant, but measurement and interpretation content are unverified in the outline-only record.
4. **partial — Intelligence - II** (youtube:aNDWylBMzn0): Intelligence continuation is on topic but specific psychometric methods are not described.
5. **partial — Lec 15: Intelligence: Nature and Theories** (youtube:8xCReYaJu2M): Nature and theories of intelligence are conceptual preparation rather than explicit measurement methods.

Enhanced first five:

1. **direct — What do intelligence test scores measure?** (guide:what-intelligence-tests-measure): Directly distinguishes performance, score, construct and causal explanation with a measurement-design exercise.
2. **direct — Lecture 14: Intelligence** (youtube:bihrpOS0qtY): Checked session explicitly covers tests, validity and interpretations with historical limits.
3. **partial — Intelligence - I** (youtube:4Kx3yFkEj-U): Intelligence introduction is relevant, but measurement and interpretation content are unverified in the outline-only record.
4. **partial — Lec 15: Intelligence: Nature and Theories** (youtube:8xCReYaJu2M): Nature and theories of intelligence are conceptual preparation rather than explicit measurement methods.
5. **irrelevant — Lecture 29 : Emotional Intelligence and Happiness Positive Psychology** (youtube:4eZh8AfN2dM): Emotional intelligence and happiness in positive psychology do not establish psychometric intelligence-testing methods.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — What do intelligence test scores measure?**. Score/construct/cause distinctions, reliability/validity glossary and task-design exercise answer the benchmark. Its absence from the visible first five is the defect. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 2/3/0 | 0.60 | 0.40 |
| enhanced | pass | 2/2/1 | 0.60 | 0.20 |
| lighterTitle | pass | 2/2/1 | 0.60 | 0.20 |
| strongerTitle | pass | 2/2/1 | 0.60 | 0.20 |
| noCommunity | pass | 2/2/1 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 1/2/2; intermediate: 0/1/4; noiseFilter: 2/2/1; coverage: 2/2/1; preGenetics: 2/2/1; preOverlap: 2/2/1.

Source/course/subfield balance: Enhanced has three NPTEL entries from different courses, MIT and the guide. Keyword uses a repeated general-intelligence unit instead of emotional-intelligence happiness. The enhanced course diversification introduces a construct mismatch.

Concrete fix: Preserve the guide and checked testing session; distinguish intelligence psychometrics from emotional-intelligence wellbeing topics and promote the dedicated Intelligence Testing lecture.

### T16 — culture and human behaviour

**Keyword: PASS; enhanced: PASS.** Both variants now offer scoped culture material. Keyword has three explicitly cultural lectures; enhanced substitutes a useful social/cultural path and a broad human-origins symposium. The selected evolutionary guide is still narrower than the query.

Criterion: Cross-cultural or social-science material that states its scope.

Manual comparison: **trade-off** — Keyword has three scoped cultural lectures; enhanced supplies the useful cultural path and broader source coverage.

Keyword first five:

1. **partial — Human Behaviour** (course:nptel:109103142): Actual outline covers general psychology and social influence/cognition, but no specific cultural comparison is identified.
2. **partial — How can evolutionary explanations of human behaviour be tested?** (guide:testing-evolutionary-explanations): Its ethnology example explicitly discusses cross-cultural comparison and alternative histories, but the main goal is testing evolutionary explanations of bonding/care.
3. **direct — Lecture 24: Influence of Culture on Consumer Behaviour** (youtube:-Ymq9p9QFbc): Explicit culture effects in consumer behaviour have a stated applied scope, supported at course-outline level.
4. **direct — Lecture-08 Culture and Self: Implications for Social Behaviour** (youtube:VqyAoYtLCLs): Culture, self and social behaviour directly match the requested relationship, at course-context confidence.
5. **direct — Lecture-09 Cultural and organizational behaviour** (youtube:p6xXsSTvpYY): The actual ordered psychology outline places cultural/organisational behaviour after culture-and-self and Indian-psychology topics; its declared applied social scope fits, while individual claims remain unchecked.

Enhanced first five:

1. **partial — Human Behaviour** (course:nptel:109103142): Actual outline covers general psychology and social influence/cognition, but no specific cultural comparison is identified.
2. **partial — How can evolutionary explanations of human behaviour be tested?** (guide:testing-evolutionary-explanations): Its ethnology example explicitly discusses cross-cultural comparison and alternative histories, but the main goal is testing evolutionary explanations of bonding/care.
3. **direct — Lecture 24: Influence of Culture on Consumer Behaviour** (youtube:-Ymq9p9QFbc): Explicit culture effects in consumer behaviour have a stated applied scope, supported at course-outline level.
4. **direct — From close bonds to groups and cultural expectations** (path:bonds-groups-culture-route): The path states its shifts from relationships to groups and culturally valued feelings, includes an attributed Tsai framework, and separates description from policy judgement.
5. **partial — Comparative Anthropogeny and Other Approaches to Human Origins** (course:carta-comparative-anthropogeny-2023): Actual symposium summary spans molecular through societal traits and one ethnology/cross-cultural session; it is scoped human-origins context rather than a dedicated cultural-behaviour route.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — How can evolutionary explanations of human behaviour be tested?**. Its ethnology start is relevant, but the full task concerns rival evolutionary explanations of attachment and care rather than culture broadly. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 3/2/0 | 0.80 | 0.40 |
| enhanced | pass | 2/3/0 | 0.40 | 0.20 |
| lighterTitle | pass | 1/4/0 | 0.40 | 0.20 |
| strongerTitle | pass | 2/3/0 | 0.40 | 0.20 |
| noCommunity | pass | 2/3/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 2/3/0; intermediate: 0/4/1; noiseFilter: 0/4/1; coverage: 2/3/0; preGenetics: 2/3/0; preOverlap: 2/3/0.

Source/course/subfield balance: Keyword has four NPTEL slots, including two neighbouring cultural-psychology lessons, but three lectures have explicit cultural scope. Enhanced uses two NPTEL, two authored routes and CARTA; it supplies a helpful cultural path but also broad human-origins context. LighterTitle further broadens to a Western-philosophy course. Both concentration and substance should be shown.

Concrete fix: Prefer the social/cultural path as the route and keep explicit cultural lecture topics visible. Do not use a generic human-behaviour course or comparative-origin collection as a substitute for stated cultural scope.

### T17 — animal cognition primates

**Keyword: PARTIAL; enhanced: PARTIAL.** Animal communication is second and the animal-experience guide fifth, but tracking methods and historical locomotion remain prominent. A described primate cognitive-task route is still missing.

Criterion: Comparative cognition grounded in non-human research.

Manual comparison: **enhanced** — Replaces a self-communication/body-language detour with a careful animal-experience guide, though primate specificity remains weak.

Keyword first five:

1. **partial — Decoding Animal Behavior Through Pose Tracking** (youtube:zwCf1pGnBUw): Pose tracking is a useful behavioural measurement method, not itself an account of animal cognition.
2. **partial — Exiting Flatland: Measuring, Modeling, and Synthesizing Animal Behavior in 3D** (youtube:JjFKGQmcgJw): 3D behavioural measurement supplies methodology but does not establish primate cognitive content.
3. **direct — Lecture 49 : Lessons from Animal Communication** (youtube:ylgPeY_MzpI): Animal communication within a cognition course is directly relevant comparative material, though the individual account is unchecked.
4. **partial — Charles Sherrington - quiet mind expt, Neuroplasiticity, animal locomotion studies** (youtube:BgTiCcj9C_M): Historical locomotion and plasticity studies concern animals but not an established cognitive comparison.
5. **irrelevant — Intracommunication with self: instinct and animal lessons, body language and tactile communication** (youtube:DcaYxy1tGpc): Sports-psychology communication and animal lessons are not identified comparative cognition research.

Enhanced first five:

1. **partial — Decoding Animal Behavior Through Pose Tracking** (youtube:zwCf1pGnBUw): Pose tracking is a useful behavioural measurement method, not itself an account of animal cognition.
2. **direct — Lecture 49 : Lessons from Animal Communication** (youtube:ylgPeY_MzpI): Animal communication within a cognition course is directly relevant comparative material, though the individual account is unchecked.
3. **partial — Exiting Flatland: Measuring, Modeling, and Synthesizing Animal Behavior in 3D** (youtube:JjFKGQmcgJw): 3D behavioural measurement supplies methodology but does not establish primate cognitive content.
4. **partial — Charles Sherrington - quiet mind expt, Neuroplasiticity, animal locomotion studies** (youtube:BgTiCcj9C_M): Historical locomotion and plasticity studies concern animals but not an established cognitive comparison.
5. **partial — How can we investigate consciousness in other animals?** (guide:other-animals-and-consciousness): A careful evidence grid separates behavioural capacity from experience; the primary question is consciousness and the route is not primate-specific.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — How can we investigate consciousness in other animals?**. Evidence-grid task carefully distinguishes capacity from experience, but consciousness is a neighbouring question and primate specificity is missing. First-five membership: keyword=no; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | partial | 1/3/1 | 0.60 | 0.40 |
| enhanced | partial | 1/4/0 | 0.40 | 0.40 |
| lighterTitle | partial | 1/4/0 | 0.40 | 0.40 |
| strongerTitle | partial | 1/4/0 | 0.40 | 0.40 |
| noCommunity | partial | 1/4/0 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 2/1/2; intermediate: 1/3/1; noiseFilter: 1/3/1; coverage: 1/4/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Two MIT tracking tutorials share one computational collection; two NPTEL courses add animal communication and historical locomotion, with an authored consciousness guide fifth. LighterTitle replaces locomotion with CARTA neuronal maturation. Sources vary, but a focused primate cognitive-task account remains absent.

Concrete fix: Surface a checked behavioural comparison or primate cognitive-task source. Tracking, locomotion history and consciousness theory are related continuations, not an answer to the same research question.

### T18 — genes and environment behaviour

**Keyword: PASS; enhanced: PASS.** The intentional 51st guide is now first and the selected route in all five variants. Its full explanation and fictional-estimate exercise directly address association, heritability and determinism, repairing the earlier coverage failure. Expanded modes still retain the unrelated workplace-safety result lower down.

Criterion: A resource distinguishing genetic association from determinism.

Manual comparison: **keyword** — Both now lead with the direct genetics-inference guide; keyword avoids the workplace-safety sense of environment that persists in enhanced.

Keyword first five:

1. **direct — How do genes and environment influence behaviour?** (guide:genes-environment-and-behaviour): The complete guide distinguishes family resemblance from genetic causation, population heritability from individual composition or inevitability, developmental mechanisms from variation, and association from intervention effects. Its fictional 0.6 exercise directly tests those inference limits; supporting readings and historical exclusions are explicit.
2. **partial — Lec 4: Heredity, Environment and Behavior** (youtube:BZuHRRuETuU): Official psychology topic covers heredity/environment/behaviour, but the unchecked record cannot establish its treatment of association and determinism.
3. **partial — Lecture 31: Behavioral Genetics I** (youtube:ZKtFqHhR7XE): The actual ordered psychology outline places this between Nature vs Nurture and Behavioural Genetics II; no individual account establishes the required association-versus-determinism distinction.
4. **partial — Lecture 2 - Basic Transmission Genetics** (youtube:lRBlEV8QR4A): The actual Yale overview concerns DNA, chromosomes, replication, Mendel’s laws and mutation. It is genetics preparation, not an account of behavioural association and determinism.
5. **partial — Lecture 4 - Neutral Evolution: Genetic Drift** (youtube:zIftg3cM4BM): Actual Yale overview explains neutral mutations, genetic drift and molecular clocks; it is population-genetic background rather than behavioural association versus determinism.

Enhanced first five:

1. **direct — How do genes and environment influence behaviour?** (guide:genes-environment-and-behaviour): The complete guide distinguishes family resemblance from genetic causation, population heritability from individual composition or inevitability, developmental mechanisms from variation, and association from intervention effects. Its fictional 0.6 exercise directly tests those inference limits; supporting readings and historical exclusions are explicit.
2. **partial — Lec 4: Heredity, Environment and Behavior** (youtube:BZuHRRuETuU): Official psychology topic covers heredity/environment/behaviour, but the unchecked record cannot establish its treatment of association and determinism.
3. **partial — Lecture 31: Behavioral Genetics I** (youtube:ZKtFqHhR7XE): The actual ordered psychology outline places this between Nature vs Nurture and Behavioural Genetics II; no individual account establishes the required association-versus-determinism distinction.
4. **partial — Lecture 2 - Basic Transmission Genetics** (youtube:lRBlEV8QR4A): The actual Yale overview concerns DNA, chromosomes, replication, Mendel’s laws and mutation. It is genetics preparation, not an account of behavioural association and determinism.
5. **irrelevant — Lec 59: Strategies for fostering safe environment at work** (youtube:FK0sb2AHoeo): Safe workplace environment is not gene–environment explanation.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How do genes and environment influence behaviour?**. The first-ranked guide pairs a plain-language heritability reading with a developmental lecture, then asks readers to reject three unsupported inferences from a hypothetical estimate. Prerequisites and the optional historical comparison are clear. It excludes personal genetic prediction and genome-wide methods rather than pretending to cover them. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.40 | 0.40 |
| enhanced | pass | 1/3/1 | 0.60 | 0.20 |
| lighterTitle | pass | 1/4/0 | 0.40 | 0.20 |
| strongerTitle | pass | 1/3/1 | 0.60 | 0.20 |
| noCommunity | pass | 1/3/1 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/2/3; intermediate: 0/3/2; noiseFilter: 0/3/2; coverage: 0/5/0; preGenetics: 0/4/1; preOverlap: 1/3/1.

Source/course/subfield balance: All variants now lead with the same direct inference guide. Keyword then has two NPTEL psychology entries and two Yale inheritance/drift entries. Enhanced has three NPTEL entries, including irrelevant workplace safety, and one Yale inheritance lecture. LighterTitle instead retains the broader food-environment guide and the historical Yale differences lecture. The new guide repairs the inference gap; extra provider variety does not make the workplace result relevant.

Concrete fix: Keep the new inference guide as the entry and preserve its population/context and historical-source limits. The lower workplace-environment false match remains a word-sense defect in expanded modes; no further ranking change was made for this repair.

### T19 — how clinical trials test psychological therapy

**Keyword: PASS; enhanced: PASS.** The exact trial-design guide leads in both variants. Keyword retains the useful depression-evidence guide; enhanced replaces it with an irrelevant single-trial fMRI toolbox.

Criterion: Methods or evidence explanation; not personalised clinical advice.

Manual comparison: **keyword** — Retains depression-evidence methods instead of a single-trial fMRI toolbox.

Keyword first five:

1. **direct — What makes a therapy trial informative?** (guide:what-makes-a-therapy-trial-informative): Comparison, random assignment, masking, outcomes and generalisation are explicitly explained and practised in a hypothetical protocol.
2. **partial — Lec 31: Positive Psychological Interventions and Models of Therapy** (youtube:tFmpZbEGK2M): Therapy models and positive interventions are relevant objects of evaluation, but trial methods are unestablished.
3. **direct — Lecture 11: Case Studies and Experiments in Clinical and Health Psychology** (youtube:QE7dBhrM0io): Clinical and health-psychology experiments within a research course directly match methods, at outline confidence.
4. **partial — How are fear, avoidance and anxiety connected?** (guide:fear-avoidance-and-anxiety): Educational fear-learning and clinical-context guide, but its central exercise tests an avoidance hypothesis rather than therapy-trial design.
5. **direct — How is evidence for depression treatment assessed?** (guide:depression-treatment-evidence): Explicit population/intervention/comparator/outcome/follow-up and harms exercise explains how a treatment claim is assessed, including limits of applying average results to individuals.

Enhanced first five:

1. **direct — What makes a therapy trial informative?** (guide:what-makes-a-therapy-trial-informative): Comparison, random assignment, masking, outcomes and generalisation are explicitly explained and practised in a hypothetical protocol.
2. **partial — Lec 31: Positive Psychological Interventions and Models of Therapy** (youtube:tFmpZbEGK2M): Therapy models and positive interventions are relevant objects of evaluation, but trial methods are unestablished.
3. **direct — Lecture 11: Case Studies and Experiments in Clinical and Health Psychology** (youtube:QE7dBhrM0io): Clinical and health-psychology experiments within a research course directly match methods, at outline confidence.
4. **partial — How are fear, avoidance and anxiety connected?** (guide:fear-avoidance-and-anxiety): Educational fear-learning and clinical-context guide, but its central exercise tests an avoidance hypothesis rather than therapy-trial design.
5. **irrelevant — GLMsingle: A Toolbox for Improving Single-Trial fMRI Response Estimates** (youtube:OvxOUn0-tn0): Single-trial fMRI response estimation uses “trial” in an experimental-event sense; it is not a clinical therapy trial.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — What makes a therapy trial informative?**. The protocol exercise specifies comparator, assignment, follow-up, missingness and harms while explicitly excluding real recruitment or personal treatment advice. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 3/2/0 | 0.60 | 0.20 |
| enhanced | pass | 2/2/1 | 0.40 | 0.20 |
| lighterTitle | pass | 2/3/0 | 0.40 | 0.20 |
| strongerTitle | pass | 2/1/2 | 0.40 | 0.20 |
| noCommunity | pass | 2/2/1 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/4/1; intermediate: 2/2/1; noiseFilter: 2/2/1; coverage: 2/3/0; preGenetics: 2/2/1; preOverlap: 2/2/1.

Source/course/subfield balance: Keyword has three authored guides and two NPTEL lectures, with two guides plus the clinical-experiments lesson directly useful. Enhanced lowers the authored share by adding an irrelevant MIT single-trial fMRI toolbox. StrongerTitle adds psychometric background; lighterTitle adds historical eating-disorder context. The more concentrated keyword page is better suited to therapy trials.

Concrete fix: Preserve the trial guide and distinguish a clinical trial from a repeated experimental trial. Prefer the depression-evidence guide to the fMRI toolbox for this question.

### T20 — theories of consciousness global workspace

**Keyword: PASS; enhanced: PASS.** The explicitly attributed GWT/AI discussion leads, followed by the comparison guide and path. The global-food false match is gone; the remaining predictive and IIT sources are clearly different theoretical positions.

Criterion: A resource representing the named theoretical position with attribution.

Manual comparison: **tie** — Same direct GWT core; fifth item is a different but legitimate theoretical comparator.

Keyword first five:

1. **direct — Can Theories of Consciousness Supercharge AI?** (youtube:TXlfCY4m9jU): Checked official programme explicitly attributes a Global Workspace Theory application to Rufin VanRullen.
2. **direct — How can competing theories of consciousness be tested?** (guide:testing-consciousness-theories): Names the distinct theories, starts with the GWT discussion and adds a preregistered prediction-table exercise.
3. **direct — From experience to competing theories of consciousness** (path:consciousness-theories-route): Sequence explicitly includes workspace, integrated-information and predictive accounts with attribution and comparison tasks.
4. **partial — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Seth’s predictive embodied account is a competing position, not a representation of GWT itself.
5. **partial — How can we investigate consciousness in other animals?** (guide:other-animals-and-consciousness): Useful inference boundaries for animal experience and theory comparisons, but not an exposition of Global Workspace Theory.

Enhanced first five:

1. **direct — Can Theories of Consciousness Supercharge AI?** (youtube:TXlfCY4m9jU): Checked official programme explicitly attributes a Global Workspace Theory application to Rufin VanRullen.
2. **direct — How can competing theories of consciousness be tested?** (guide:testing-consciousness-theories): Names the distinct theories, starts with the GWT discussion and adds a preregistered prediction-table exercise.
3. **direct — From experience to competing theories of consciousness** (path:consciousness-theories-route): Sequence explicitly includes workspace, integrated-information and predictive accounts with attribution and comparison tasks.
4. **partial — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Seth’s predictive embodied account is a competing position, not a representation of GWT itself.
5. **partial — The Biology of Consciousness** (course:wsu-biology-consciousness): Actual Koch course overview and four-unit outline concern consciousness, neural correlates and IIT. This is an attributed comparator, not an identified GWT account.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How can competing theories of consciousness be tested?**. Directly useful comparison guide: named commitments, predictions, measurements and a concrete preregistered-test reading. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 3/2/0 | 0.60 | 0.20 |
| enhanced | pass | 3/2/0 | 0.40 | 0.20 |
| lighterTitle | pass | 3/2/0 | 0.40 | 0.20 |
| strongerTitle | pass | 3/2/0 | 0.40 | 0.20 |
| noCommunity | pass | 3/2/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/5/0; intermediate: 3/1/1; noiseFilter: 3/1/1; coverage: 3/2/0; preGenetics: 3/2/0; preOverlap: 3/2/0.

Source/course/subfield balance: The direct GWT source, comparison guide and comparison path form the useful core. Oxford prediction and Koch/IIT are attributed alternatives. Keyword has an extra authored animal-consciousness guide instead of Koch’s course. Source diversity is interpretative comparison, not multiple confirmations of GWT.

Concrete fix: Retain named-theory matching and the direct GWT source; label the IIT and predictive entries as comparisons rather than further evidence for GWT.

### T21 — predictive processing philosophy mind

**Keyword: PARTIAL; enhanced: PARTIAL.** The explicit predictive account remains third and the broad consciousness guide remains the selected route. Enhanced/noCommunity now move the irrelevant mortality course from fifth to fourth, ahead of identity theory: a small ordering regression without a change in result-level totals or the partial task verdict.

Criterion: A theoretical or philosophical position, explicitly labelled as such.

Manual comparison: **keyword** — Avoids the unrelated mortality course; both still need a tighter predictive-processing entry.

Keyword first five:

1. **partial — What do we mean by conscious experience?** (guide:conscious-experience): Contrasts attributed consciousness perspectives including prediction, but is a broad conceptual introduction.
2. **partial — Contemporary Issues in Philosophy of Mind & Cognition** (course:nptel:109101004): Official outline establishes philosophy of mind, but supplies no checked predictive-processing unit or substantive course description.
3. **direct — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Checked description explicitly attributes an embodied predictive account of consciousness and self to Anil Seth.
4. **partial — L13-Mind-Body Identity Theory** (youtube:21FYpcCbWC4): Identity theory is a distinct philosophical position, useful background but not predictive processing.
5. **partial — L15-Different Models of Cognitive Mind** (youtube:Excq32DjvxY): General cognitive models could provide context; the named predictive approach is not established.

Enhanced first five:

1. **partial — What do we mean by conscious experience?** (guide:conscious-experience): Contrasts attributed consciousness perspectives including prediction, but is a broad conceptual introduction.
2. **partial — Contemporary Issues in Philosophy of Mind & Cognition** (course:nptel:109101004): Official outline establishes philosophy of mind, but supplies no checked predictive-processing unit or substantive course description.
3. **direct — Consciousness in Humans and in Other Things** (institution:8f45ed61b58eb1db): Checked description explicitly attributes an embodied predictive account of consciousness and self to Anil Seth.
4. **irrelevant — Death: mind, personal identity and mortality** (course:yale-death-mind): Actual course overview and syllabus examine mortality, souls, identity and ethics; no predictive-processing position is identified.
5. **partial — L13-Mind-Body Identity Theory** (youtube:21FYpcCbWC4): Identity theory is a distinct philosophical position, useful background but not predictive processing.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — What do we mean by conscious experience?**. The guide distinguishes experiences and explanations and includes Seth, but the route is broad and should not be labelled a predictive-processing course. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | partial | 1/4/0 | 0.60 | 0.60 |
| enhanced | partial | 1/3/1 | 0.40 | 0.40 |
| lighterTitle | partial | 1/3/1 | 0.40 | 0.40 |
| strongerTitle | partial | 1/3/1 | 0.40 | 0.40 |
| noCommunity | partial | 1/3/1 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 0/3/2; intermediate: 1/3/1; noiseFilter: 1/3/1; coverage: 1/4/0; preGenetics: 1/3/1; preOverlap: 1/3/1.

Source/course/subfield balance: Keyword returns a NPTEL course and two of its philosophy members, alongside the guide and Oxford predictive account. Enhanced reduces repeated-course share by including irrelevant Yale mortality/identity. The final overlap run moves that course up to fourth without changing provider/course counts. LighterTitle moves the direct predictive source second but still retains mortality.

Concrete fix: Prefer the explicit predictive account and retain the mortality/identity mismatch as a known defect. The final rank swap makes the lower page slightly worse; this review records it without tuning the ranking.

### T22 — computational neuroscience Python beginner

**Keyword: PASS; enhanced: PASS.** Neuromatch remains first with explicit Python/mathematics preparation and exercises. The remaining resources are computational continuations; the selected membrane/circuit path presupposes Python and is not the best beginner route.

Criterion: A structured course with realistic maths/coding prerequisites and exercises.

Manual comparison: **tie** — Both lead with Neuromatch and state continuation prerequisites; lower items trade breadth for specialist repetition.

Keyword first five:

1. **direct — Neuromatch Academy: Computational Neuroscience** (course:neuromatch-compneuro): Official curriculum explicitly supplies optional neuroscience refreshers, Python from scratch, linear algebra/calculus/probability preparation and modelling exercises.
2. **partial — Computational Neuroscience** (course:nptel:102105100): Official course covers basic neuronal modelling through plasticity and requires first-year mathematics/biology, but Python exercises are not established.
3. **partial — From membranes to interacting circuits** (path:from-membranes-to-circuits): A coherent mechanism-to-model sequence with explicit calculus/linear-algebra/Python requirements and optional notebooks; it is not a beginner Python course.
4. **partial — Brain and Cognitive Sciences Computational Tutorial Series** (course:mit-bcs-computational-tutorials): Actual description supplies code, datasets and exercises but assumes computational background; useful later, not a Python-from-scratch course.
5. **partial — Lecture 5: Cognitive Neuroscience Methods II** (youtube:YD7QG4G7WVg): Methods comparison is neuroscience preparation, not a structured Python modelling course.

Enhanced first five:

1. **direct — Neuromatch Academy: Computational Neuroscience** (course:neuromatch-compneuro): Official curriculum explicitly supplies optional neuroscience refreshers, Python from scratch, linear algebra/calculus/probability preparation and modelling exercises.
2. **partial — Computational Neuroscience** (course:nptel:102105100): Official course covers basic neuronal modelling through plasticity and requires first-year mathematics/biology, but Python exercises are not established.
3. **partial — Brain and Cognitive Sciences Computational Tutorial Series** (course:mit-bcs-computational-tutorials): Actual description supplies code, datasets and exercises but assumes computational background; useful later, not a Python-from-scratch course.
4. **partial — Recurrent Neural Networks for Cognitive Neuroscience** (youtube:k5bQnPtX3wY): Relevant recurrent-network tutorial is specialist; MIT’s series assumes computational background rather than beginning Python.
5. **partial — From membranes to interacting circuits** (path:from-membranes-to-circuits): A coherent mechanism-to-model sequence with explicit calculus/linear-algebra/Python requirements and optional notebooks; it is not a beginner Python course.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **partial — From membranes to interacting circuits**. Coherent biological-mechanism route offers optional notebooks but does not teach Python from the beginning. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.40 | 0.20 |
| enhanced | pass | 1/4/0 | 0.40 | 0.40 |
| lighterTitle | pass | 1/4/0 | 0.40 | 0.40 |
| strongerTitle | pass | 1/4/0 | 0.40 | 0.40 |
| noCommunity | pass | 1/4/0 | 0.40 | 0.40 |

Earlier enhanced D/P/I: baseline: 2/3/0; intermediate: 1/4/0; noiseFilter: 1/4/0; coverage: 1/4/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Enhanced has the MIT computational collection and one recurrent-network member, creating a course/member duplication. Neuromatch is the documented Python-from-scratch route; the NPTEL course and membrane path are further foundations. Lighter/stronger alter order but do not add a better beginner exercise sequence.

Concrete fix: Select the entering-computational-neuroscience guide for the beginner route and preserve Neuromatch first. Keep the membrane/circuit path and MIT computational tutorials as prerequisite-labelled continuations.

### T23 — fMRI what can it tell us

**Keyword: PASS; enhanced: PASS.** The first-page results are now all imaging-related and the leading checked connectivity resource addresses a measurement/inference distinction. The direct methods guide is selected separately; a newcomer would still benefit from seeing it on the page.

Criterion: Brain-imaging measurement and inference limits.

Manual comparison: **enhanced** — Provides a separately selected direct methods route and more specific imaging entries; keyword returns no route.

Keyword first five:

1. **direct — fMRI Connectivity** (youtube:1VOKsWWLgjk): Official CBU training description explicitly concerns functional and effective fMRI connectivity, a directly relevant measurement/inference distinction.
2. **partial — GLMsingle: A Toolbox for Improving Single-Trial fMRI Response Estimates** (youtube:OvxOUn0-tn0): Single-trial response-estimation toolbox is relevant but specialised; broad inference limits are not established by the record.
3. **partial — Lecture 08 : EEG, fMRI, MEG** (youtube:KTroNcl_Pdw): Official cognitive-science course compares imaging methods, but detailed limits are unverified.
4. **partial — Brain and Cognitive Sciences Computational Tutorial Series** (course:mit-bcs-computational-tutorials): Actual series includes code/data methods but assumes computational background and ranges far beyond fMRI.
5. **partial — Cognition and its Computation** (course:nptel:108105185): Broad cognitive-computation syllabus includes methods, but is not an identified fMRI inference route.

Enhanced first five:

1. **direct — fMRI Connectivity** (youtube:1VOKsWWLgjk): Official CBU training description explicitly concerns functional and effective fMRI connectivity, a directly relevant measurement/inference distinction.
2. **partial — GLMsingle: A Toolbox for Improving Single-Trial fMRI Response Estimates** (youtube:OvxOUn0-tn0): Single-trial response-estimation toolbox is relevant but specialised; broad inference limits are not established by the record.
3. **partial — Lecture 08 : EEG, fMRI, MEG** (youtube:KTroNcl_Pdw): Official cognitive-science course compares imaging methods, but detailed limits are unverified.
4. **partial — Lecture 39 : Neuroimaging - 1** (youtube:-bhCFwUoGM8): Neuroimaging within experimental design is relevant, but the specific measurement/inference discussion is unchecked.
5. **partial — Neurology: Foundations of Brain Imaging** (youtube:jE14ACcIXic): The historical-neuroscience outline places brain imaging among neurology foundations; an individual description of fMRI measurement or inference limits has not been checked.

Selected routes:

- keyword: no route returned.
- enhanced, lighterTitle, strongerTitle, noCommunity: **direct — How can we study what a human brain is doing?**. Two-experiment design exercise explicitly tests competing interpretations rather than treating an image as an explanation. First-five membership: enhanced=no; lighterTitle=yes; strongerTitle=no; noCommunity=no.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 1/4/0 | 0.40 | 0.40 |
| enhanced | pass | 1/4/0 | 0.60 | 0.20 |
| lighterTitle | pass | 2/3/0 | 0.40 | 0.20 |
| strongerTitle | pass | 1/4/0 | 0.60 | 0.20 |
| noCommunity | pass | 1/4/0 | 0.60 | 0.20 |

Earlier enhanced D/P/I: baseline: 1/4/0; intermediate: 2/3/0; noiseFilter: 2/3/0; coverage: 1/4/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Enhanced has three NPTEL imaging entries from different courses, one CBU training item and one MIT toolbox. Keyword instead has course/member overlap in MIT and NPTEL. LighterTitle adds the direct methods guide fifth. All are closer than earlier ethnology/free-will detours, but checked inferential coverage is uneven.

Concrete fix: Bring the measurement-and-inference guide onto the first page before toolbox/history continuations. Keep the current exact fMRI training match; do not confuse the broad imaging outline with checked inferential coverage.

### T24 — causal inference reproducibility psychology

**Keyword: PASS; enhanced: PASS.** The causal guide leads and satisfies the identification branch. Keyword additionally retains the quantitative-paper route with transparency checks; enhanced replaces it with generic Bayesian-inference tutorials.

Criterion: Methods material addressing identification or reproducibility, not unsupported certainty.

Manual comparison: **keyword** — Retains the quantitative-paper/transparency path rather than another general inference tutorial.

Keyword first five:

1. **direct — When can a study support a causal explanation?** (guide:from-association-to-causation): Specifies intervention contrasts, competing causal stories and assumptions not settled by observed associations.
2. **partial — What do intelligence test scores measure?** (guide:what-intelligence-tests-measure): Measurement-versus-causation distinctions and reliability/validity are useful background, but the task is psychometric construction rather than causal identification or reproducibility.
3. **direct — Read a quantitative paper critically** (path:read-a-quantitative-paper): The explicit appraisal sequence identifies causal assumptions, missing methods/data/analysis plans, and linked causal/transparency readings; it supplies a usable methods route without claiming independent reanalysis.
4. **partial — What a score says about a person** (path:measuring-individual-differences): Explicit score/construct/causal distinctions support critical reading, but the sequence concerns measurement of personality/intelligence rather than identifying interventions or reproducing analyses.
5. **partial — Bayesian Inference in Generative Models** (youtube:PRY2NbOXbHk): Generative-model Bayesian inference is statistical background, not an established causal-identification or reproducibility treatment.

Enhanced first five:

1. **direct — When can a study support a causal explanation?** (guide:from-association-to-causation): Specifies intervention contrasts, competing causal stories and assumptions not settled by observed associations.
2. **partial — What do intelligence test scores measure?** (guide:what-intelligence-tests-measure): Measurement-versus-causation distinctions and reliability/validity are useful background, but the task is psychometric construction rather than causal identification or reproducibility.
3. **partial — Bayesian Inference in Generative Models** (youtube:PRY2NbOXbHk): Generative-model Bayesian inference is statistical background, not an established causal-identification or reproducibility treatment.
4. **partial — Lecture 16: Bayesian Inference** (youtube:mIGiBWz56VI): Bayesian inference for behavioural data is relevant statistics but not the named causal/reproducibility problem.
5. **partial — Lecture 21: Bayesian Statistical Inference I** (youtube:1jDBM9UM9xk): General probability-course Bayesian estimation does not establish causal identification.

Selected routes:

- keyword, enhanced, lighterTitle, strongerTitle, noCommunity: **direct — When can a study support a causal explanation?**. The intervention-and-rival-stories exercise and What If reading directly support causal identification; a reproducibility continuation is still needed for the full query. First-five membership: keyword=yes; enhanced=yes; lighterTitle=yes; strongerTitle=yes; noCommunity=yes.

| Variant | Verdict | D/P/I | Largest provider share | Largest known course share |
|---|---|---:|---:|---:|
| keyword | pass | 2/3/0 | 0.80 | 0.20 |
| enhanced | pass | 1/4/0 | 0.40 | 0.20 |
| lighterTitle | pass | 1/4/0 | 0.60 | 0.20 |
| strongerTitle | pass | 1/4/0 | 0.40 | 0.20 |
| noCommunity | pass | 1/4/0 | 0.40 | 0.20 |

Earlier enhanced D/P/I: baseline: 0/2/3; intermediate: 1/4/0; noiseFilter: 1/4/0; coverage: 2/3/0; preGenetics: 1/4/0; preOverlap: 1/4/0.

Source/course/subfield balance: Enhanced mixes two authored guides, two MIT inference sources and NPTEL. Keyword is 80% authored navigation but retains the direct critical-paper/transparency path. Less producer concentration therefore does not imply better causal or reproducibility coverage.

Concrete fix: Keep the exact causal guide first and retain the critical-paper/transparency path for the reproducibility branch. Statistical estimation should not replace causal identification merely through inference synonyms.

## Inspection boundary

The review did not modify ranking, the benchmark or the application. Current result and route judgements cover every task and all five variants. Courses were assessed against their actual cached overview/outline; a named topic does not establish detailed arguments or current scientific correctness. No full videos were watched, no user behaviour was measured and no unseen transcripts were treated as read. The public default change was implemented by the parent and checked through the historical equivalence receipt. The earlier repair pass ran evaluate once after the independently reviewed 51st guide was added and read that guide in full. This final pass ran evaluate once after the distinctness holds and audio-language correction, inspected all changed placements and reused unchanged relevance judgements transparently.

Machine-readable detail: [evaluation/search-manual-review.json](evaluation/search-manual-review.json). Frozen snapshots, source records, manual decisions and report builder: [evaluation/search-review-inputs/](evaluation/search-review-inputs/).
