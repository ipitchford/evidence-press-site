# Corrections and withdrawal

The correction form creates a text file on the reader’s device. It does not send a message or open a support ticket. Confirm a working public contact route before publication; no response time is promised by the local application.

Ask for the resource URL or ID, disputed wording or broken behaviour, proposed correction and a supporting source where available. Do not request medical information, account credentials or personal viewing history.

## Maintainer workflow

1. Record a dated issue with the stable ID, report, source and current build. Distinguish unavailable media, misleading annotation, rights concern and scientific dispute.
2. Inspect the actual source and retain a permitted receipt. Record exactly what was read or tested. A search snippet or imported annotation is not that inspection.
3. Correct `data/editorial-overrides.json`, keyed by canonical ID, or the relevant guide/path and receipt. Preserve complete nested objects and evidence references: the loader uses a top-level override, not an arbitrary deep merge.
4. To remove a resource, add its ID and reason to `data/withdrawals.json`. Retain the permitted change record. Withdrawn items must leave future release counts and builds.
5. Reconcile, validate, test and rebuild. Inspect the affected page, guides/paths, exports and search results. Preserve the decision, evidence, checker, date and changed files in the correction record.
6. If publication is authorised, replace the deployed build and reopen the affected public page. A local repair is not a published repair.

The normaliser preserves local overrides and withdrawals. Do not make an authoritative fix only in generated `dist/` files. Refresh must not erase a checked annotation or restore a withdrawn item. Source-boundary decisions and description checks remain separate: correcting a tag does not earn checked-core credit.

Descriptions, selection reasons and scientific assessment have different evidence requirements. A stronger factual or clinical claim needs appropriate supporting research, not merely a reputable uploader. If unresolved, narrow the claim, expose uncertainty or withdraw the annotation. Do not turn source checking into a numerical quality score. Community corrections must preserve the bounded wording “checked non-creator recommendation”; public identity evidence does not prove financial independence.
