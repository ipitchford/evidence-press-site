# Release checklist

Status: 7 November 2026, completed local release. Pass applies only to the recorded scope. Local delivery gates are complete; production publication and human evaluation remain separate. No publication is authorised.

| Gate | Status | Evidence and remaining boundary |
| --- | --- | --- |
| Numerical breadth | Pass | Matching validation/build: 4,645 source identities; 4,202 qualified accessible videos; 118 courses/series; 28 verified source entries; 21 video-provider groups; 14 families; 127 supporting resources. |
| Distinctness | Pass within conservative boundary | 111 possible repeats held outside discovery/count; zero confirmed equivalences. Source/course positions retained; no selected route/core affected. |
| Editorial targets | Pass | 51 guides, 20 paths, 201 qualified checked-core resources. All 71 hashes match substantive review; no requested repair remains unresolved. Agent checks are not human peer review. |
| Editorial access | Pass with disclosed limit | 250 selected resources: 249 with recorded access evidence and one optional restricted historical comparison with alternatives. No full-viewing claim. |
| Source sample | Pass within scope | Exactly 100 frozen stratified inspections, separate critical-comment supplement and actual repair readback. Not an accuracy estimate. |
| Normalisation / preservation | Pass | Actual final import twice byte-identical; overrides, withdrawals, reviewed content and course bytes preserved; additive evidence hashes checked. API status cannot clear source holds. |
| Unit/schema checks | Pass | 56/56 tests; release validation zero errors or warnings. |
| Search | Pass with residuals | All 24 × 5 first-five/route sets reviewed. Keyword 19 pass/5 partial/0 fail; enhanced 20/4/0. Weight sensitivity, concentration and false matches disclosed. Not a user study. |
| Browser / personal state | Pass within scope | Actual search/filter controls, no-result/retry recovery, library/playlist/path persistence and exact export/reset/import roundtrip. Thumbnail choices, consent cancellation, approved YouTube and institutional short playback, controlled failure and expiry states observed. |
| Accessibility | Pass within measured scope | Desktop/390px homepages without overflow; 24 contrast pairs pass. Keyboard search, visible skip focus, both dialogs' forward/reverse Tab containment, Escape cancellation and dark-mode persistence observed. No full WCAG claim. |
| Performance | Pass within configuration | Initial + discovery 637,993 bytes gzip. Actual local Chromium desktop/mobile-viewport timings and 10,000-record Node fixture measured. No physical-phone/throttling claim; synthetic public records zero. |
| API lifecycle | Pass on recorded snapshot | Original retrieval +28-day expiry; 11 focused tests; 22-file dry run without due redactions/blocks. Static deadline 5 December 2026, 15:41:34 UTC. |
| Clean source installation | Pass | Fresh offline install, build, 56 tests and schema validation without token/API cache. 1,608 qualified videos/88 qualified core; 51 guides/20 paths. Final executable/data payload matched to tested copy. |
| Static artifact | Pass | 4,573 files; 102,788 references; 4,691 fragments; zero errors. 4,209 source-only export rows. Local-canonical warning requires approved-address rebuild. |
| Source distribution | Pass within stated boundary | Allowlisted, redacted, content-addressed source snapshot; code/data matched to the tested clean copy. Source/private-data checks and static ZIP member hashes verified. No credentials, API caches or raw third-party payloads in source distribution. |
| £0 constraint | Maintained | No new paid service/resource. Checked files/assets fit current Free Pages limits; account/plan still need confirmation before authorised deployment. |
| Production / DNS authority | Not authorised | No deployment or DNS change may proceed from this checklist. |
| Public readback | Not applicable yet | Required after separately authorised deployment. |
| Human feedback / impact | Pending, separate | Pilot prepared; no recruitment, feedback, adoption or learning benefit observed. Not a prerequisite for software completion. |

[EVALUATION.md](../EVALUATION.md) summarises receipts and boundaries. Source selection, software behaviour, scientific assessment and learning impact are distinct.
