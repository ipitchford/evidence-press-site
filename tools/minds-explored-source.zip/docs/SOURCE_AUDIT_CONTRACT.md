# Initial source-audit contract

Use only public, permitted retrieval within £0 additional spending. No accounts, paid API calls, full-video downloads, bypassing access controls or publisher-wide indiscriminate channel imports.

Write independent reports and machine-readable observations to data/audits/<assigned-name>/. Preserve source URL, retrieval UTC, status, SHA-256 and a concise inspected-material note. Raw HTML/data may be cached privately in data/raw/<assigned-name> with original licence recorded; do not assume it is redistributable. Use bounded requests, caching and conservative concurrency.

Audit the actual schema, source ownership, reuse/attribution conditions, useful in-scope course/topic collections, and concrete video destinations. Report verified candidates separately from qualified accessible videos. A 200 page or oEmbed response is not playback verification. Record whether official player metadata indicates playable, a real media endpoint is accessible, or only a source/embedding page was seen. Keep unknowns explicit.

Each candidate observation should include: id if established; title; sourceUrl; canonicalUrl; providerId; speaker; parentCourse; subjectFamilies; level; language; durationSeconds; uploadDate; recordingDate; transcriptStatus; descriptionEvidence; selectionBasis; selectionReason; availability evidence; source/licence notes. Unknown fields must be null or labelled unknown. Do not manufacture missing metadata, quotations or positive recommendation counts.

Stop unproductive or blocked routes after a documented attempt and move to feasible gaps. No external publication or outreach.
