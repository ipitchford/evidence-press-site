# Design direction

The atlas serves a reader with a question, not a spectator in a feed. Its memorable element is a subject map: a compact, typographic set of intersecting fields with ordinary-language entry questions. Topic guides explain connections; catalogue rows prioritise the title, learning level, duration and selection reason.

Palette: aubergine `#382b42`, sage `#637861`, warm ivory `#f8f5ed`, dark ink `#282331`, muted plum `#716378`, pale sage `#e3eadf`. Dark mode reverses surfaces while keeping readable sage and plum accents. Colour never carries status by itself.

Type: a readable literary serif for questions and long guide text, a clear sans-serif for navigation and controls. Both are self-hosted when an appropriately licensed asset is actually available; robust system fallbacks remain. Text columns stay below 76 characters.

Structure: left-aligned question-led home; three clear routes (topics, paths, search); a broad reading column beside a quiet contents panel; catalogue lists with diverse actual source material rather than equal-size promotional tiles. Sequential numbering is reserved for learning-path steps.

Plan review: the requested warm ivory is retained, but the generic editorial card grid and decorative brain/network art are rejected. The subject map and route explanations carry the atlas's identity. No invented video stills, auto-playing backgrounds, hidden tracking or ornamental motion. Focus, keyboard controls, responsive layouts, reduced motion and light/dark themes are requirements.
