# Atlas pilot feedback form

Blank form — no participant responses are implied.

Participant code: __________  Date: __________  Facilitator: __________

Role: independent learner / educator / prefer not to say

Device and browser: __________  Input: pointer / keyboard / touch / other

Prior familiarity with the selected subject: none / some / substantial

Consent confirmed: yes / no. Recording separately authorised: no / yes. Agreed deletion date for raw notes: __________

| Task and fixed criterion | Approach: atlas/usual | Time | Met/partly/not/skipped | Selected resource and reason | Assistance or confusion |
| --- | --- | --- | --- | --- | --- |
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |

For the selected resource:

- What did you expect to learn? __________
- What preparation would you need? __________
- What did “source checked” mean to you? __________
- What would you try next? __________
- What information was missing or misleading? __________

Personal-library task: saved / playlist created / path step marked / exported / not completed. What was confusing? __________

Compared with your usual method, what was easier and what was harder? __________

Would this route be useful for a real learning or teaching task? Why? __________

One change you would make first: __________

May an anonymised quotation be used publicly? no / yes, only this wording: __________

Observer notes and participant quotations must be labelled separately. Do not put credentials, medical details or unrelated browsing history into this form.

