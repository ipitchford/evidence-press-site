# Local evaluation snapshot retention

`scripts/api-retention.mjs` removes expired YouTube API values from an explicit allowlist of local evaluation files. It makes no network requests, reads no OAuth credentials and publishes nothing. The maximum lifetime is **28 days from the original metadata retrieval**, not the time a snapshot was copied, inspected or rewritten.

The evaluation files mix API data with independent source inspections. Deleting whole files would destroy the required review trail. This command therefore purges the API-derived fields **in place**, while retaining original descriptions, source text, editorial conclusions, identifiers, provenance and hashes. It does not delete directories or whole review documents.

## Commands and integration

From the project root:

```sh
node scripts/api-retention.mjs --manifest
node scripts/api-retention.mjs --dry-run
node scripts/api-retention.mjs --apply
```

No flag means dry run. The CLI does not offer an arbitrary target path, retention extension or simulated date. Tests use the exported function with temporary fixture roots and an explicit clock.

The installed `scripts/api-maintenance.mjs` helper invokes the apply step **before metadata refresh, build, evaluation and CLI validation**. It writes `evaluation/api-retention.json` and stops on blocked inputs. It redacts the evaluation copies before pruning the YouTube cache, so original cache clocks remain available for legacy projections. These calls are present in `scripts/refresh.mjs`, `scripts/build.mjs`, `scripts/evaluate.mjs` and the CLI branch of `scripts/validate.mjs`.

The helper uses this bounded API:

```js
import {purgeEvaluationAPIData} from './api-retention.mjs';

const retention = await purgeEvaluationAPIData({apply: true});
if (retention.blocked.length) {
  throw new Error('Evaluation API retention needs attention; inspect the bounded report.');
}
```

After that call, the helper invokes `pruneYouTubeCache()` from `youtube-refresh.mjs`, which enforces the same original `checkedAt` plus 28-day ceiling for `.cache/youtube/metadata.json` and raw response batches. The API overlay separately refuses invalid or expired clocks and ignores an overlong expiry in favour of the hard limit. Public build freshness is a separate responsibility: the retention module never edits `dist` or public exports.

## Actual file scope

The source-coded `EVALUATION_API_MANIFEST` is the authoritative bounded manifest. It covers:

| Local artifact | Expiring material | Material retained |
|---|---|---|
| `evaluation/source-sample/snapshot.json` | API overlay, origin-labelled language/duration/upload/recording fields, API-derived access/qualification status | Institutional fields, identity/substance holds, explicit scope exclusions, source and API receipt hashes |
| `evaluation/source-sample/access-inspection.json` | Embedded API item interpretation and API access status | Independent media-range/header/body observations |
| `evaluation/source-sample/records.jsonl` | Embedded API access data and API-dependent qualification status | All 100 original semantic assessments and source provenance |
| `evaluation/source-sample/inspection-packet.json` | API-derived copied attributes, identified using the frozen record's origin flags | Actual publisher text blocks, source identifiers and hashes, publisher-derived attributes |
| `evaluation/source-sample/repair-readback.json` | The few qualification statuses explicitly linked to API evidence | Topic, scope, transcript and source-date correction conclusions |
| `evaluation/editorial-review/current-resources.json` | API overlay and API-derived attributes/status | Independent resource descriptions and provenance |
| `evaluation/editorial-review/access-checks.json` | API inspection values/status | Official-file range evidence and receipt hashes |
| `evaluation/editorial-review/reviews.jsonl` | API access status/notes in resource checks | All 70 reviews, source checks, revised-file hashes and independent conclusions |
| Fixed search-result files and `evaluation/search-review-inputs/manual-review-NNNNNN.json` | Copied YouTube `qualified` flags whose evaluation relied on the API overlay | Result order/scores, institutional titles/descriptions, task criteria, manual relevance judgements and supporting source hashes |
| `evaluation/search-review-inputs/selected-records.json` | Any origin-labelled API overlay fields in full selected-record copies | Institutional descriptions, source-derived attributes, authored guide/path content and source receipts |

The search inputs were inspected rather than assumed to contain raw API metadata. The initially inspected `selected-records.json` had 295 pre-overlay institutional records and authored guides/paths, with no API-origin values. It is included because regeneration may copy the current overlay; source-derived values are unchanged. The saved pre-genetics files (`pre-genetics-search-results.json`, `manual-review-pre-genetics.json`) and pre-overlap files (`pre-overlap-search-results.json`, `manual-review-pre-overlap.json`) are explicit manifest entries that retain their original report clocks. The guide-reading packets contain authored content and publisher-source extracts and are outside the purge scope.

The manifest also protects all Markdown/TSV/manual notes, the frozen sample design, aggregate evaluation counts, benchmark definitions, source caches and registries, `data/catalogue.jsonl`, editorial overrides, guide/path source files, and credentials. Dated aggregate outcomes and original reviewer conclusions remain historical evaluation records; they are not live access assertions or a store of the removed API fields. An unlisted file is never silently added to the purge scope because its text mentions YouTube. New snapshot formats must receive an explicit manifest entry and a preservation test.

## Time and provenance rules

For a dated API block the deadline is:

```text
min(original checkedAt + 28 days, valid earlier declared expiresAt)
```

A later or malformed `expiresAt` cannot extend the hard limit. Expiry applies at the exact boundary. A record copied after day 28 remains expired even if its file modification time or enclosing review timestamp is new. Original API retrieval receipts may establish the clock when the overlay's own timestamp was omitted.

Some legacy search/repair projections contain a video identifier and a derived flag but omit the API clock. For these, the implementation uses the earliest evidenced original retrieval for that identifier in the dated overlay snapshots or local API cache, bounded by the report's **original generation timestamp**. The report timestamp is only an upper bound; it never becomes the retention start. A cache response retrieved after that report cannot authorise retaining the older projection. This can expire a projection earlier than necessary; it cannot make a dated original payload young again. Copying a report must preserve its original generation timestamp. A producer that imports old values must preserve their original API receipt rather than relabel them as newly generated observations.

If no original retrieval can be established, or a source-reading projection has lost the frozen origin information needed to distinguish source-derived values from API-derived values, the command reports the exact file/JSON pointer and blocks apply. It does not guess a new lifetime, delete source facts or silently claim successful cleanup. Recover the original receipt or explicitly regenerate the projection from current permitted inputs. Never “repair” this by replacing an old timestamp with today's date.

Each removed field receives a small `apiRetention` receipt containing its field name, original retrieval date, effective expiry, removal date and value hash. Removed values are not copied into a backup or log. Existing provenance stays intact. A second apply is a no-op unless another genuinely dated payload has since expired or been added.

## Filesystem and operational boundaries

Only fixed manifest files and a six-digit manual-review filename pattern within one fixed directory are considered. Symlink targets/ancestors, non-files, malformed JSON and concurrent input changes are refused. All proposed changes are planned before writing; unresolved provenance prevents the run from applying a partial cleanup. Each changed file is replaced through a private temporary file containing only the redacted result. An I/O failure remains an error and must not be reported as completed cleanup.

The local command reports file paths, counts, original-file hashes and first expiry dates. It does not print API payloads or secrets. A dry run against the current workspace found **22 present manifest files, zero due redactions and zero blocked inputs** on 7 November 2026. A simulated future dry run is read-only; it must not be confused with a live purge.

Run the fixture tests with:

```sh
node --test tests/api-retention.test.mjs
```

The tests cover exact 28-day expiry, shorter declared expiry, no extension from a new copy timestamp, fresh/expired records in one file, independent official-range evidence, JSONL review preservation, origin-aware source projections, original search clocks, mixed selected-record maps, missing provenance, idempotence, manifest exclusions and symlink refusal. All mutations in those tests occur under disposable temporary roots.
