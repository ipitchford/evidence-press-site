# Maintenance plan

Visitors do not trigger acquisition or model calls. Maintenance runs locally, within £0 additional spending and provider access rules. Do not provision paid APIs, storage, trials or hosting add-ons.

## Routine refresh

```sh
npm run refresh
npm run verify
npm run evaluate
```

Refresh reconciles the maintainer’s saved institutional snapshots and requests official YouTube metadata using existing authorisation. It does not silently crawl all institutions or scrape YouTube watch pages. Run a relevant institutional adapter explicitly for a new snapshot, preserving bounded retrievals and source licences. `npm run refresh -- --offline` reconciles existing source snapshots only; it does not create missing acquisition inputs in a distributable source copy.

Inspect `evaluation/refresh.json`, normalisation reconciliation and API expiry data. A failed requested API refresh now exits nonzero and records `refresh-unavailable`; an unexpired old cache is not reported as successful renewal. A later build can still use any unexpired cache, so inspect dates rather than assuming a build renewed them. Missing credentials do not justify guessed availability or platform scraping. Use `--offline` only when deliberately reconciling saved source data without an API request.

The API overlay uses a 28-day retention window and refreshes older entries incrementally. Check at least weekly, with the **earliest expiry among API fields included in the deployed build** as the binding deadline. Before that deadline, renew the evidence and publish a replacement build, or rebuild without expired data and replace affected public files. An unchanged static HTML page or search index cannot renew itself. Updating private cache alone is insufficient. Apply the same check to backup/rollback builds and API-bearing evaluation snapshots.

The final retention commands, static-build deadline receipt and deletion/revocation workflow are being integrated. Their implementation and tests must be linked here and cleared in the release checklist before publication; do not infer that the current local build has an automatic hosted expiry service.

The implementation reads `YOUTUBE_OAUTH_TOKEN_FILE`, defaulting to `.private/youtube-token.json`. Keep tokens, caches, full source snapshots and API-bearing evaluation snapshots out of both public builds and source distributions. The public build needs no credential. An installation without API cache builds the permitted base catalogue with fewer qualified resources and more unknown fields. See [DATA.md](../DATA.md).

## Priorities

- Fix unavailable essential path steps, misleading annotations, rights problems and accidental private-data exposure first.
- With each source refresh, inspect additions, exclusions, duplicates, missingness, date changes and identity conflicts. Recheck affected guides and paths. Never promote an explicit scope exclusion merely because the API reports a playable item.
- Before a release, inspect fixed-task search results and route usefulness; test state/export round-trips, representative desktop/mobile behaviour and failure states. Run the final clean installation and artifact scan.
- Revisit time-sensitive clinical framing, source terms and hosting limits. Historical teaching requires dated context; source affiliation is not scientific validation.

Preserve useful non-sensitive receipts and failed-attempt records without retaining expired API payloads. Do not normalise from an incomplete snapshot that silently discards editorial work. No automated schedule, recruitment or production deployment has been created by this plan.

## Static release archives

The ZIP under `releases/static/` is a static display artifact, not a reusable API-data export. Its adjacent receipt records the earliest API expiry. Refresh/rebuild and replace or remove this archive, extracted copies and any deployed copies before that deadline. The current candidate deadline is 5 December 2026, 15:41:34 UTC. The cache/evaluation retention command does not rewrite ZIP archives or deployed HTML. Credential-free source packages contain no captured API data.
