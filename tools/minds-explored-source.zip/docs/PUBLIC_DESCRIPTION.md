# Public description draft

Mind, Brain & Behaviour is an Evidence Press learning atlas for independent learners, students and educators. Start with a question, find a substantive lecture at an appropriate level, and follow a documented route into related courses, reading and exercises. Source notes explain why a resource was selected, what was inspected and what remains unassessed. Personal reading lists and progress stay in your browser.

The atlas provides educational navigation, not personalised clinical advice or a guarantee that every linked scientific claim is correct. No claim of comprehensive coverage or demonstrated learning impact is made.

## For educators

Use a guide’s audience and prerequisites to choose a starting point, then adapt a path’s ordered tasks to your teaching. Download the reading list or export a browser-local playlist. Keep original source links, dates, attribution and limitations attached. Reuse the atlas’s original explanatory writing under its stated licence; third-party videos and readings retain their own terms. Opening a source does not prove that a student watched it, and local progress is not an assessment result.

This text is prepared for review. No announcement, invitation or publication has been sent.

