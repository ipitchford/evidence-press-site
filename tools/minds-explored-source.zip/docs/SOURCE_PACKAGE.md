# Rebuildable source packages

The source package rebuilds the atlas from its permitted, independent base catalogue. It contains the original application, editorial writing, executable schemas, dependency lockfile, attribution and source-check metadata. It requires no credentials or private API cache. Its counts can differ from a maintainer’s API-enriched build: omitted API-only availability, durations and dates remain unknown. Neither the package nor its checks claim that the videos have all been watched.

Create a package from a stable working copy with Node.js 22 or later and the project’s existing npm dependencies:

```sh
node scripts/package-source.mjs --self-test
node scripts/package-source.mjs
```

The builder makes no network requests and does not publish anything. It writes a new directory under `releases/source/`, named `mind-brain-behaviour-` followed by the first sixteen characters of its content digest. It also writes an independent receipt at `evaluation/source-package-<digest>.json`. The package includes `SOURCE_PACKAGE_MANIFEST.json`, with the full digest, every payload file’s checksum, original-input checksum, transformations, counts and checks.

The payload manifest has no build clock or machine-specific path. Identical inputs produce the same bytes and destination. A repeat run verifies and reuses an unchanged destination; it never overwrites an existing package. Changed inputs produce a new directory. A source file changing during packaging stops the operation. Temporary staging directories belong to the builder and are removed on failure; unrelated files and previous packages are preserved.

## Verify and build a received copy

Before installing dependencies or building, verify the pristine directory with the builder from a working copy that has its dependencies installed:

```sh
node scripts/package-source.mjs --verify releases/source/mind-brain-behaviour-<digest>
```

Then, from the received package directory:

```sh
npm ci
npm run build
npm start
```

Open `http://127.0.0.1:4173/`. `npm ci` needs the locked packages from the npm registry or an existing local npm cache; it makes no source-provider acquisition. The build itself needs no account, credential or network acquisition. A clean install/build in a separate copy is an independent verification step, recorded by the maintainer rather than implied by successful packaging. `npm run validate` and `npm test` can also run from the copy. Numerical release checks can legitimately fail without the private API overlay.

Verification is intentionally strict about an untouched distribution. Added `node_modules/`, `dist/` or generated evaluation files make a working copy non-pristine. Keep the original package unchanged and use a separate working copy for installation and building when a later distribution-integrity check is needed.

## Included data and field review

The builder reads `data/catalogue.jsonl` directly, without applying the API overlay. It requires both `reuse.exportAllowed: true` and one of the explicitly reviewed field-level reuse statements in the builder. A new or changed statement stops packaging until its rights boundary is reviewed. It retains factual resource identities, source URLs, titles, course membership, topic assignments, independently sourced metadata, original descriptions and selection reasons, precise check scopes, source hashes and attribution. The full video schema must still validate after transformation.

The normalised provider/course/supporting registers retain their factual context, original audit judgements and individual source restrictions. All guide and path receipts are included as their actual redacted records, along with selected core-check and scope-decision metadata. Counts are derived from the current input and are not fixed success targets. The builder preserves original and transformed checksums separately, so redaction is not disguised as the original source snapshot.

`cachePath` and similar local cache pointers are removed. Transcript-excerpt arrays are replaced with their existing segment/timing/character-count metadata; the text itself is omitted. Internal receipt-path suffixes are removed from description notes. Author-written inspection accounts, limitations and selection decisions remain. A retained source SHA-256 identifies evidence previously retrieved by the maintainer; the absence of that private payload means a recipient cannot independently recompute its hash from this package alone. Source URLs and the precise inspection scope remain available for later permitted retrieval.

No blanket licence is applied to external teaching. The atlas’s code and original writing retain their own licences; a university, provider or reading’s licence and exceptions remain distinct. Bundled font files retain their supplied Open Font Licence notices.

## Excluded material

The builder uses an allowlist, not a recursive copy of the workspace. It excludes credentials, populated environment files, private API caches, source media, raw HTML/PDF/transcript/comment files, acquisition candidate snapshots, private audit caches, build output and API-bearing evaluation/search snapshots. It omits thumbnails rather than inferring image-reuse permission from factual metadata. Only the original fixed search-task benchmark is included from prior evaluation data; prior result snapshots are excluded.

Original audit, acquisition and editorial-authoring scripts are included as code. They are not their downloaded payloads. The package also contains deliberately synthetic test inputs in source code; these are not captured API responses or real credentials. A synthetic macOS home path for a user named “example” is permitted only in test source because it tests leak detection and does not identify a real machine or user. Checks reject captured API fields in distributable JSON, credential-shaped values, actual machine-specific filesystem paths, unlisted package files and symlink inputs. These checks provide concrete bounded evidence, not a general security or legal certification.

## Refresh remains a maintainer operation

Ordinary `npm run build` uses the supplied normalised catalogue and needs none of the omitted acquisition files. The source adapters remain available to maintainers, but reacquiring evidence requires reviewing provider terms, supplying their public source configuration or saved acquisition inputs, installing adapter-specific dependencies, and respecting current access limits. No paid service or access-control bypass is introduced by this package.

Do not run `npm run refresh -- --offline` on a distribution expecting it to reconstruct the missing maintainer snapshots. Reconciliation is designed for a maintained acquisition workspace, and absent inputs can legitimately withdraw records. Preserve a copy, restore or reacquire the reviewed evidence, then reconcile and review changes. A future authorised API refresh requires independently configured credentials and retention handling; copying the maintainer’s token or historical cache is not part of this workflow.

The authoritative boundary is [DATA.md](../DATA.md). The package receipt distinguishes successful source preparation from the separate clean build, static release verification and publication steps.
