# Editorial files and checks

All original writing uses UK English. A source check is an agent's inspection of retrieved material, not human peer review. Do not infer full viewing from a publisher page. Default resource scientific assessment remains `Not assessed`.

`content/guides/<slug>.json`:

```json
{
  "slug": "remembering-and-forgetting", "title": "How does remembering work?",
  "question": "How does remembering work?", "topics": ["learning-memory"],
  "audience": "A reader beginning systematic study of memory",
  "scope": "A short specific introduction to the question and scope.",
  "status": "draft", "startingResourceId": "youtube:XXXXXXXXXXX",
  "startingReason": "A concrete source-grounded reason.",
  "resources": [{"id": "youtube:YYYYYYYYYYY", "purpose": "Compare methods", "reason": "Why this resource helps here."}],
  "body": "Original substantive Markdown with inline links to actually retrieved sources. Explain the learning question, conceptual connections, competing explanations or limits where relevant; do not merely enumerate links.",
  "courseId": "actual-course-id",
  "supporting": [{"id": "optional-stable-id", "title": "Reading title", "url": "https://official.example/reading", "kind": "reading", "reason": "What to read for and why."}],
  "methodsOrExercise": {"title": "A specific task", "instructions": "Concrete original exercise, with limits on what it can establish.", "url": "https://official.example/method"},
  "prerequisites": ["No prior neuroscience"],
  "keyTerms": [{"term": "Term", "meaning": "Plain-language explanation supported by cited material."}],
  "neighbours": ["methods", "neuroscience"],
  "nextStep": "Specific continuation, not a generic encouragement.",
  "limits": "Source dates, inspection limits and evidential cautions specific to this guide.",
  "sources": [{"id": "source-1", "title": "Page title", "url": "https://official.example/page", "retrievedAt": "ISO timestamp", "sha256": "actual digest", "inspection": "Exactly what was read"}],
  "check": {"date": "YYYY-MM-DD", "checker": "agent", "materialInspected": "Accurate source and inspection summary", "receipt": "data/editorial-checks/guides/remembering-and-forgetting.json"}
}
```

Normally include four to eight further video resources. Set `status` to `reviewed` only after completing and recording the check. `sources` may include `cachePath`, which is private audit metadata and must not be emitted in public pages. Source receipts must be real, not invented hashes or generated attestations of inspections that did not happen. A saved hash establishes retrieval identity, not substantive inspection. Record claims and selection decisions in each receipt, with source basis and limits. Unavailable resources remain explicit; do not quietly count a guide as a finished accessible route when its essential starting resources are inaccessible.

`content/paths/<slug>.json`:

```json
{
  "slug": "a-first-course-in-memory", "title": "A first route through memory", "topics": ["learning-memory"],
  "audience": "Specific audience", "description": "What this sequence adds and how it differs from other paths.",
  "prerequisites": ["Specific prerequisites"], "objectives": ["Observable learning objective"], "status": "draft",
  "steps": [{"resourceId": "youtube:XXXXXXXXXXX", "reason": "Why this step follows the preceding one", "task": "A concrete reflection or exercise after this step"}],
  "shortRoute": {"stepNumbers": [1, 2], "reason": "Why these form a useful short start"},
  "continuation": {"text": "Specific deeper route", "url": "https://official.example/course"},
  "sources": [{"title": "Source", "url": "https://official.example/page", "retrievedAt": "ISO timestamp", "sha256": "actual digest", "inspection": "Exactly what was read"}],
  "limits": "What the source check does and does not establish.",
  "check": {"date": "YYYY-MM-DD", "checker": "agent", "materialInspected": "Accurate inspection account", "receipt": "data/editorial-checks/paths/a-first-course-in-memory.json"}
}
```

Five to ten ordered steps, actual canonical IDs. The site computes duration totals only from verified durations, and reports missing values. Do not estimate video lengths. Path overlap is allowed when the question, sequence and learner tasks are materially distinct.

Core fragments belong to each agent's audit directory as `core-overrides.json`, an object keyed by canonical ID. Each value should hold `description`, `descriptionCheck` and `selection`, plus a separate `checkSources` list to allow normalisation of evidence IDs. The normaliser will merge real evidence into provenance and stable override fields. Do not overwrite another author's main override file. Use `method: publisher-description` only when actual descriptive material beyond a title or generic listing was inspected; otherwise preserve an unchecked record. For each core resource, document the concrete inspected content, description decision, specific selection reason and limits in an individual receipt or individually addressable row.

Prototype first: finish five guides and three paths, inspect their usefulness and rendering, and record findings before scaling to fifty/twenty. Source research and evidence packs for later guides can proceed in parallel.
