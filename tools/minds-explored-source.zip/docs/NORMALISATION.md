# Rebuilding the source catalogue

Run `node scripts/normalise.mjs` from the project directory. `npm run refresh` calls the same importer before subsequent refresh/build steps. The normaliser does not fetch websites, make paid calls or read credentials. It consumes saved source-audit outputs, verifies receipt relationships, merges the catalogue and writes `evaluation/normalisation-reconciliation.json`.

The reusable catalogue and the live accessibility view are different artefacts. `data/catalogue.jsonl` contains institutional/HackerTube-derived factual metadata, original annotations and source receipts. The authorised YouTube metadata cache is private and expiring. `scripts/api-overlay.mjs`, called by the data loader, supplies its current fields at runtime/build time; these fields are never written back by this normaliser. Consequently the normalisation report's accessibility/core counts can be lower than `npm run validate` counts.

## Inputs and ownership

The importer consumes the courses audit's candidates and registers; the providers audit's original/additional observations, source and course registers, supporting readings and institutional range checks; the twenty reviewed HackerTube discovery candidates; and NPTEL's frozen `qualified-candidates.json` plus `pending-accessibility.json`. It does not import NPTEL's pre-review raw candidates. The two NPTEL lists must be disjoint and exactly cover the reviewed candidate register, and consumed frozen files must match the handoff manifest hashes.

It also discovers each audit directory's `core-overrides.json`, `record-decisions.json` and `supporting-resources.json`. Core fragments may be keyed objects or arrays. Source checks must resolve to real dated receipt IDs. Existing `data/editorial-overrides.json` and `data/withdrawals.json` are read, applied for effective validation and never rewritten. Explicit local overrides remain authoritative, while withdrawals always remove a record from qualification.

The normaliser owns `data/catalogue.jsonl`, `data/sources.json`, `data/courses.json`, `data/supporting.json`, `data/normalisation-state.json` and its reconciliation report. Raw caches and agent audit inputs remain unchanged. Do not run concurrent normaliser writers. Each output replacement is atomic, but the set of output files is not a database transaction; run validation after a completed import before building.

## Evidence and missingness

Persisted access qualification requires an exact source-listed official media alternative and a successful bounded HTTP 206 byte range, matching content range, saved-body length/hash, MP4 container signature and recognised MP4 brand. A generic binary response additionally needs an `.mp4` destination. An old HTTP Archive.org source link is accepted only through its exact evidenced HTTPS equivalent. HEAD 200, a retrieved source page, oEmbed and historical watch-page metadata do not qualify. No playback is claimed from a range response.

The official source mapping must have dated provenance as well as the media sample. Unknown accessibility remains unknown. Individually ambiguous title/destination associations and unresolved auxiliary lesson fragments remain unqualified even when an endpoint exists. The private API overlay separately respects these flags and explicit exclusions.

Course instructor, course language and stated course level are retained on the course entity. They do not become individual speaker, audio language or difficulty assertions. Core authors may supply explicitly identified editorial levels grounded in inspected material. Unknown recording dates, upload dates, durations, language and transcripts remain unknown unless supported by the permitted source evidence.

All automatic navigation descriptions remain unchecked. A title-level topic correction or a course-boundary decision creates no selected-core credit. Checked descriptions require an actual beyond-title publisher description, inspected transcript material or viewing, a dated individual selection decision and resolving source evidence. Transcript excerpts remain labelled as excerpts; none of these checks automatically assess scientific claims.

## Identity, ordering and conflicts

YouTube and Vimeo destinations use canonical platform identifiers. Other safe HTTPS institutional destinations use a deterministic URL hash. Signed URLs, embedded credentials and unsafe schemes are rejected. Original input IDs are retained as import aliases so a source fragment can resolve to the same canonical record. Duplicate canonical IDs merge source evidence and all known course memberships; field disagreements appear in the reconciliation report. The deterministic primary course is the lexically first registered membership, not a claim that it is the only source context.

Course `resourceIds` follows evidenced order: NPTEL unit/lesson order, explicit MIT/Yale lecture numbers, World Science U lesson positions, or known Neuromatch day/tutorial structure. Unresolved within-page order and discovery-order fallbacks are labelled in `sequence` and `orderBasis`. Alphabetic IDs are only the final deterministic tie-breaker, never evidence of pedagogical order.

An audit may additionally provide `alternate-mappings.json`, either directly in its directory or in `alternate-review/`. Its `mappings` and `unresolved` arrays are separate decisions. A confirmed mapping requires an existing `id`, existing `alternateOf`, status `confirmed-equivalent`, a concrete reason, dated checker and complete `checkSources`. Self-maps, missing parents, conflicting parents, cycles and title-only guesses are rejected before writing. Both upload records remain; only the canonical parent contributes to the qualified count. Upload-specific title, duration, accessibility and descriptive checks are never copied across identities. Each affected course sequence resolves `resourceId` to the canonical parent while retaining `sourceResourceId`, the original source URL and lesson order.

Unresolved groups explicitly name the held secondary `ids` and may record `primaryIds`, source positions, relationship and release condition. They set `qualification.distinctnessResolved` to false; neither official media access nor the API overlay clears this hold. The original records, source links, course memberships and review evidence remain available. A hold means that distinctness has not been established, not that equivalence has been proved. Unrelated topical similarities outside these explicit IDs do not change counts. The current NPTEL follow-up holds 111 secondary uploads and confirms zero equivalent pairs.

The data loader resolves confirmed aliases in memory for guide/path references and course membership, retaining the original reference IDs. It does not rewrite reviewed guide or path files. Discovery and reusable catalogue exports omit confirmed alternates and explicit identity, substance or distinctness holds. Local overrides remain authoritative; partial qualification overrides preserve omitted source flags, and withdrawal files are never changed by import.

Previously managed records missing from a refreshed reviewed source are preserved as withdrawn pending reconciliation. Records belonging to an unrefreshed source or a local editor are preserved. Excluded source-boundary records remain traceable, including their original course membership, but do not contribute to qualified counts. Useful background items may also appear separately in supporting resources; clearly unrelated source-list anomalies do not become recommended supporting material.

## Source-boundary decisions

`record-decisions.json` is an object with a `records` map keyed by canonical ID. Optional top-level `clusters` documents retained-course rationales. Each decision contains:

```json
{
  "action": "retain",
  "reason": "A concrete source-grounded inclusion or exclusion reason.",
  "checkedAt": "2026-11-07T16:00:00Z",
  "checker": "agent",
  "clusterId": "optional-reviewed-cluster",
  "topics": ["methods"],
  "topicMode": "replace",
  "checkSources": [{
    "id": "actual-source-receipt-id",
    "url": "https://official.example/source",
    "retrievedAt": "actual retrieval timestamp",
    "sha256": "actual SHA-256",
    "inspection": "Exactly what was inspected"
  }]
}
```

Actions are `retain`, `supporting`, `exclude` or `topic-correction`. Retain never upgrades accessibility or description status. Supporting and exclude set qualification to excluded after core merging; only supporting creates a contextual supporting link. Topic changes may replace or add taxonomy IDs and are explicitly separate from scientific appraisal. The example is a schema illustration, not evidence.

## Community history

HackerTube's `rec`/`strong_rec` counts are historical sampled positive labels, limited to twenty retained mentions per video. They are neither exhaustive nor scientific validation. The bounded `community-context-review.json` records exact HN comment IDs, inspected parent context, public profile/identity evidence and original decisions. No comment bodies, profile contacts or private excerpts enter the catalogue.

Only a manually checked positive, non-promotional case with a documented bounded non-creator identity/context basis contributes to the checked lower-bound count. Unresolved authorship remains null; creator promotions remain excluded. The current public-identity check does not prove financial independence or rule out undisclosed affiliations. One checked case cannot support corpus-wide claims about recommendation independence.

## Repeatability and verification

Inputs are read once with hashes and rechecked before output replacement. If a source changes during the run, the importer stops and a new run reads the updated snapshot. Stable inputs produce stable catalogue/register/state bytes, preserve local override/withdrawal bytes, and skip rewriting identical output. The reconciliation report records hashes, rejected rows, unknown topic labels, merge conflicts, orphan fragments and counts. Rejection of an explicit short recap is a recorded source decision, not an ingestion failure.

Run `node --test tests/normalise.test.mjs` for the importer checks and `npm run validate` for the complete API-aware catalogue. The tests cover sample integrity, HEAD rejection, source mapping, legacy URL handling, unknown metadata, qualification gates, canonical identity, credential rejection, duplicate reconciliation, editorial evidence, scope exclusions, bounded community counts, local override preservation and repeatable course order. `python3 data/audits/normalisation/verify_saved_evidence.py` additionally hashes every concrete provenance cache path and writes a dated integrity receipt tied to the four input-file hashes. Receipts without a local cache path are reported separately. Passing these checks establishes data-processing and saved-file integrity properties, not scientific correctness or video playback.
