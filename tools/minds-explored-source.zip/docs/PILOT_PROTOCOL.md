# Voluntary prototype pilot — proposed, not yet conducted

The pilot asks whether independent learners and educators can find a suitable starting resource, understand why it was selected and continue productively. It does not test scientific accuracy, clinical outcomes or long-term learning impact.

Recruitment and invitations require separate authorisation. No participants have been recruited by this protocol, no feedback has been collected, and no incentives or paid services are budgeted.

## Participants and consent

Aim for a small formative group, for example four independent adult learners and two educators, with varied prior knowledge and at least two people using a small screen. This is purposive usability feedback, not a representative population sample.

Explain that participation is voluntary, any task can be skipped, and stopping has no consequence. Use participant codes. Do not request medical history, passwords, private playlists or complete browser history. Use written observer notes by default; recording a screen or voice requires separate explicit consent. Agree the local storage location, access and deletion date before collecting data. A proposed default is deletion of raw notes after ninety days, with only anonymised themes retained; that policy must be enacted by the maintainer, not merely stated here.

## Session, approximately 35 minutes

1. Ask about prior subject knowledge and the participant’s usual discovery method. Do not teach the atlas interface first.
2. Give two matched discovery tasks using the atlas and two using the participant’s usual method. Alternate which approach comes first across participants. Use different but comparable questions to reduce repetition effects.
3. Ask the participant to choose a starting resource, explain its level and source basis, and find a plausible next step. Allow up to six minutes per task; record a skip or failure rather than extending time until success.
4. Use one short task to save an item, add it to a playlist, mark a path step complete and export the list. Explain that opening and watching are different states only after observing whether the distinction is understood.
5. Complete the feedback form and a short debrief. An educator can substitute assembling a reusable seminar list for one discovery task.

Suggested matched pairs: an introduction to memory versus attention; a route into brain-imaging methods versus neural-data modelling. The questions and relevance criteria should be fixed before the session. Draw from `evaluation/benchmark.json`, but do not show expected answers or preselect a preferred provider for the participant.

## Record and compare

For each task, record approach, device, elapsed time, completion category, selected URLs, stated reason, understood prerequisite and next step. Categories are **met / partly met / not met / skipped**, using the prewritten task criterion. Also record assistance requested, confusing wording and the participant’s confidence. Confidence is a self-report, not evidence of scientific quality.

Compare the two approaches descriptively: which tasks were completed, time to a defensible choice, rationale clarity, source understanding and continuation quality. With a small formative sample, report individual patterns and recurring difficulties; do not present precise population effects or a causal learning-benefit estimate. Keep observer judgements separate from participants’ words.

Afterward, log concrete defects and proposed changes, make bounded repairs, and repeat affected tasks where feasible. Preserve failures and dissenting feedback. Report who actually participated, what was observed and what remains uncertain. Any public quotation needs explicit permission and should omit identifying details.

