# Architecture and boundaries

Node.js (22 or later), an explicit dependency lockfile, JSON/JSONL source data, Markdown writing and a static HTML builder. Markdown-it parses original guide prose with raw HTML disabled; Ajv validates records. Browser JavaScript enhances meaningful rendered pages with local search and personal state. No server database, account, paid model call, third-party analytics or refresh job runs for visitors.

Raw retrievals are private cache, never the public payload. Adapters retain retrieval receipts and source conditions. Normalised records and append-only observations are separate from editorial overrides. Refresh must preserve reviewed writing, stable IDs and withdrawals. An interrupted adapter can resume from its cache without creating duplicates.

Canonical videos, alternate uploads, courses, providers, topic families, supporting reading, guides and paths have distinct identifiers and totals. Publication eligibility requires both in-scope qualification and documented accessibility evidence; source-page success alone is insufficient. Unknowns are first-class values. Scientific assessment defaults to not assessed.

A compact discovery index is separate from full records and provenance. One rendered HTML file per resource avoids duplicating 10,000 detail JSON files and keeps a 10,000-record expansion under the documented free Pages 20,000-file limit. Large catalogue exports are split before any file approaches 25 MiB. These are implementation limits checked against Cloudflare's official documentation on 7 November 2026: https://developers.cloudflare.com/pages/platform/limits/. Production publication still requires explicit authorisation for this atlas.

Resource and route pages have stable URLs, titles, descriptions and sitemap entries. Search has an ordinary keyword fallback; any more elaborate ranking must beat the preserved 24-task benchmark. Synthetic scale-test records remain outside the public build.
