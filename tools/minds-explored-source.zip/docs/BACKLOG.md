# Prioritised continuation backlog

Updated 7 November 2026 after final catalogue, search, browser, clean-install and package checks. All numerical/editorial targets are met. Use [PROGRESS.md](../PROGRESS.md) and dated receipts for gate status.

| Priority | Work | Completion evidence |
| --- | --- | --- |
| P1 | Refresh/remove API data before expiry and replace affected static artifacts. | Original clocks retained; current build deadline 5 December 2026, 15:41:34 UTC. Public readback only after authorised deployment. |
| P1 | Resolve 111 held possible repeated uploads when permitted evidence exists. | Paired content evidence for equivalence or distinct teaching; titles/duration alone are insufficient. |
| P1 | Confirm an authorised free publication destination and rebuild canonicals. | Explicit approval, confirmed free account/project, current limits, new build and public readback. |
| P1 | Maintain the optional restricted historical resource and source fallbacks. | No essential route depends on it; alternatives remain usable and labelled. |
| P2 | Improve documented search gaps without overfitting the benchmark. | Better broad-brain, reward, primate-cognition and predictive-processing entry routes; fresh tasks for later evaluation. |
| P2 | Improve sparse metadata and provider/subject balance. | Supported levels, speakers, dates/audio language and suitable teaching beyond the NPTEL-heavy corpus; no count-padding imports. |
| P2 | Run the voluntary pilot when recruitment is authorised. | Genuine consented feedback, usual-method comparison and documented repairs. |

Already evidenced: the 100-record source sample/readback; 51-guide/20-path review; repeatable import; 56 tests; fixed-task search review; retention, actual static audit, credential-free clean source execution and distribution verification. The browser checks also passed, including exact reset/import restoration and approved short playback. These checks do not establish scientific accuracy or audience impact.
