# Static deployment preparation at £0

**No deployment is authorised by this document.** This new atlas remains local until the user approves production publication in the current conversation. No Cloudflare account, project, domain or DNS access is assumed, and no external project has been created by this documentation task.

The application is static. Publish only `dist/`; acquisition, private metadata and editorial work stay local. It requires no Functions, Workers, R2, database, paid add-on or purchased domain.

## Provider limits checked 7 November 2026

Cloudflare’s current Free Pages limits include 20,000 files per site and 25 MiB per asset. Git-based builds have a 500-per-month allowance and a twenty-minute timeout. [Official limits](https://developers.cloudflare.com/pages/platform/limits/).

Use Wrangler Direct Upload for this project’s thousands of generated files: the dashboard drag-and-drop route is limited to 1,000 files, while Wrangler supports 20,000. Direct Upload projects cannot later switch to Git integration without a new project. [Official Direct Upload guide](https://developers.cloudflare.com/pages/get-started/direct-upload/).

These are dated limits, not an assurance about the user’s account. Recheck the free plan and current limits before approval. If the static build exceeds them, reduce/split assets within the architecture; do not silently upgrade or add paid storage.

## Local preparation

Complete the [release checklist](RELEASE_CHECKLIST.md) and preserve the resulting receipts. Source, search, retention and static checks are recorded. Clean source execution and package verification have also passed. The bounded browser interaction checks are complete, including short playback and controlled failure states. Production publication still needs explicit authorisation and a confirmed destination. Confirm all source/publication rights, metadata retention and current source fallbacks. Ensure the final `dist/` has fewer than 20,000 files, no asset over 25 MiB, no `_worker.js` or Functions bundle, and no private caches or credentials. Recheck `_headers` against every authorised media host. Record the earliest expiry of API-derived fields included in the build and the exact replacement deadline. The deployed HTML and search index must be replaced before that deadline; refreshing a local cache alone is insufficient. Do not upload API-bearing audit or evaluation snapshots.

The default build base URL is local. After a free Pages project address is confirmed, rebuild with its actual address so canonical URLs and the sitemap are correct. Do not use a guessed hostname in the final artifact.

Retain private tokens, caches, raw source snapshots and restricted evaluation snapshots outside both `dist/` and any distributable source package. See [DATA.md](../DATA.md) and [maintenance](MAINTENANCE.md). A source package must rebuild without the private API overlay, with an honestly smaller qualified-access count.

## Commands only after publication approval

Use an installed, verified Wrangler version or the official npm-distributed CLI. Record its version in the deployment receipt. The following commands are a manual future workflow, not commands executed by this task:

```sh
npx wrangler login
npx wrangler pages project create
ATLAS_BASE_URL='https://CONFIRMED-PROJECT.pages.dev' npm run build
npx wrangler pages deploy dist --project-name='CONFIRMED-PROJECT'
```

Choose the confirmed free account and the project’s production branch interactively. The resulting `pages.dev` address avoids a domain purchase. The official deployment command accepts a prebuilt directory and project name. [Cloudflare’s Wrangler workflow](https://developers.cloudflare.com/pages/how-to/use-direct-upload-with-continuous-integration/).

Upload only the final reviewed build. A successful CLI response is not the end of verification: reopen the public home, one resource, each flagship guide/path, source fallbacks, catalogue/path exports, the sitemap and headers. Record deployment ID, UTC time, base URL, build/source hashes and readback results. No publication-success claim should appear until that readback exists.

For updates or rollback, use a preserved reviewed static artifact with current metadata, then repeat the readback. Do not roll back to a build containing expired API data. Further DNS or custom-domain changes need their own explicit authorisation.

