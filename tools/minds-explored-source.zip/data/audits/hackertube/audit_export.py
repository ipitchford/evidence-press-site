#!/usr/bin/env python3
"""Offline audit/extractor for the official HackerTube 2026-10-31 export.

No network requests, API credentials, video downloads or third-party dependencies.
Outputs discovery observations, never qualified accessible catalogue records.
Run from any directory: python3 data/audits/hackertube/audit_export.py
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import unicodedata

ROOT = Path(__file__).resolve().parents[3]
SOURCE_URL = "https://hackertube.org/download/hackertube-data.zip"
DOC_URL = "https://hackertube.org/download/DATA.md"
EXPORT_DATE = "2026-10-31"
RETRIEVED_AT = "2026-11-07T15:11:39.667395+00:00"
POSITIVE = {"rec", "strong_rec"}
STANCES = POSITIVE | {"reference", "joke", "critical"}
FORMATS = {"talk", "lecture", "course", "interview", "documentary", "explainer", "podcast", "tutorial"}
CORE_CATEGORIES = {
    "neuroscience-brain", "psychology-behavior", "mental-health-neurodiversity",
    "consciousness-mind", "evolution-genetics", "education-learning", "language-linguistics",
}
ADJACENT_CATEGORIES = {
    "machine-learning", "llms-generative-ai", "ai-safety-impact", "robotics",
    "computer-vision-speech", "data-science-statistics", "probability-game-theory",
    "science-method-communication", "philosophy-ethics", "microeconomics-behavioral",
    "fitness-sleep-longevity", "animals-nature",
}
VIDEO_KEYS = {"vid", "url", "title", "channel", "summary", "why_hn", "content_type", "level", "shelf_life", "primary_topic", "tags", "categories", "quote", "hn", "score"}
MENTION_KEYS = {"hn_comment_id", "hn_url", "vid", "author", "month", "story_title", "stance", "why", "quote", "text"}
ATTRIBUTION = {
    "databaseName": "HackerTube",
    "databaseUrl": "https://hackertube.org",
    "upstreamDataset": "https://huggingface.co/datasets/open-index/hacker-news",
    "databaseLicence": "ODC-By-1.0",
    "licenceUrl": "https://opendatacommons.org/licenses/by/1-0/",
    "notice": "Contains information from HackerTube, derived from open-index/hacker-news, made available under the Open Data Commons Attribution License v1.0. Hacker News data is provided by Y Combinator. Individual comments, videos and creator names retain their respective rights. No affiliation is implied.",
    "separateRights": "Database rights do not license individual comments, videos, thumbnails, transcripts, application code or separately obtained YouTube metadata. This output contains factual metadata and original audit annotations, with no reproduced HN comment body or video media.",
}

# These observations were inspected against complete imported card summaries and
# retained HN comment context. They are not transcript/viewing/scientific checks.
# Tuple: speaker, parent course, provisional subject families, editorial reason, limit.
REVIEWED = {
    "NNnIGh9g6fA": ("Robert Sapolsky", "Human Behavioral Biology", ["evolution-genetics-comparative-cognition", "neuroscience"], "Introduces a coherent behavioural biology course and connects explanations across biological and environmental scales.", "Course membership and speaker are supported by the imported card; recover the official course page and current destination before qualification."),
    "WwslBPj8GgI": ("Eric Mazur", None, ["learning-memory-education", "research-methods"], "Uses a teaching problem to introduce peer instruction and questions about measuring understanding.", "Reported improvements require examination of the underlying education research; this is not a validation of every claim."),
    "8hAw1z8GdE8": ("William Dement", None, ["emotion-motivation-sleep"], "Provides an entry into sleep research through a specialist lecture.", "Historical clinical and performance advice needs dating and comparison with current evidence."),
    "n8m7lFQ3njk": ("Douglas Hofstadter", None, ["reasoning-decision-making", "computational-cognition"], "Presents a developed account of analogy, concepts and cognition that can be compared with alternative theories.", "Attribute the central role assigned to analogy to Hofstadter; do not present it as established consensus."),
    "D9H9qTdserM": ("Robert Sapolsky", None, ["emotion-motivation-sleep", "neuroscience"], "Connects stress physiology with the contrast between short-lived threats and persistent psychological stress.", "An older educational lecture is not current clinical guidance; verify original date and assess any guide-level health claims separately."),
    "xRel1JKOEbI": ("Anil Seth", None, ["consciousness-philosophy-of-mind", "neuroscience"], "Distinguishes questions about conscious states, contents and selfhood while introducing a neuroscientific research programme.", "Predictive accounts of consciousness are theoretical proposals; current scientific assessment remains Not assessed."),
    "GcJxRqTs5nk": ("Frans de Waal", None, ["evolution-genetics-comparative-cognition", "social-cultural-behaviour"], "Introduces comparative questions about cooperation and fairness using animal behaviour examples.", "A concise public talk requires supporting research and distinctions between observed behaviour and interpretations of morality."),
    "TTFoJQSd48c": ("Daniel Dennett", None, ["consciousness-philosophy-of-mind", "computational-cognition", "evolution-genetics-comparative-cognition"], "Offers an explicit philosophical account connecting brains, evolution and culture, suitable for comparison with competing positions.", "Present Dennett's argument as a philosophical/theoretical position, not as a settled explanation."),
    "Y0Oa4Lp5fLE": ("Robert Sapolsky", "Human Behavioral Biology", ["evolution-genetics-comparative-cognition"], "Continues the same course into evolutionary explanations of behaviour and should preserve the course sequence.", "This is a distinct lecture, not a separate course or provider."),
    "9vpqilhW9uI": ("James Flynn", None, ["personality-intelligence-individual-differences", "social-cultural-behaviour"], "Introduces historical change in intelligence-test scores and questions about interpretation.", "Check dates, population coverage and later findings before making guide-level claims about current score trends."),
    "CjVQJdIrDJ0": ("Daniel Kahneman", None, ["reasoning-decision-making"], "Provides a starting point for the speaker's account of judgement and decision-making.", "A book talk is not a systematic review; individual empirical examples may need updating or replication context."),
    "SIOQgY1tqrU": ("Robert Sapolsky", "Human Behavioral Biology", ["language-communication", "evolution-genetics-comparative-cognition"], "Connects language acquisition and comparative communication within a wider behavioural biology course.", "Maintain its original course position and investigate any dated claims about language research."),
    "lKQ0yaEJjok": ("Joscha Bach", None, ["computational-cognition", "consciousness-philosophy-of-mind"], "Presents a computational account of mind useful as an attributed theoretical position.", "The presentation's explanatory ambitions do not establish empirical support or consensus."),
    "NIu_dJGyIQI": ("Karl Friston", None, ["computational-cognition", "neuroscience"], "Gives a proponent's introduction to the free-energy principle that could precede technical reading.", "Imported prose gives a duration, but it is not independently established here; duration remains null."),
    "CAOnSbDSaOw": ("Robert Sapolsky", "Human Behavioral Biology", ["neuroscience", "emotion-motivation-sleep"], "Supplies a systems-neuroscience lecture within a coherent course.", "Only one of four retained mentions is positive; the other three are neutral references."),
    "_njf8jwEGRo": ("Robert Sapolsky", "Human Behavioral Biology", ["research-methods", "computational-cognition"], "Uses chaos and reductionism to examine the explanatory limits of breaking biological systems into parts.", "Only one of five retained mentions is positive; do not count the four neutral references as endorsements."),
    "dmeRQN9z504": ("Andy Matuschak", None, ["learning-memory-education"], "Connects memory, understanding and the design of learning tools through a sustained interview.", "Practitioner interpretation needs separation from evidence for specific learning interventions."),
    "fnUc_W3xE1w": ("Stephen Krashen", None, ["language-communication", "learning-memory-education"], "Introduces an influential historical account of language acquisition in the proponent's own presentation.", "The source is a secondary upload; verify provenance, original date and possible overlap with other clips before qualification."),
    "jaoQh6BoH3c": ("Joseph Henrich", None, ["social-cultural-behaviour", "evolution-genetics-comparative-cognition"], "Connects cultural transmission and collective learning with human evolutionary explanations.", "Present the book's explanatory account as the speaker's argument and assess specific empirical claims separately."),
    "Ecvv-EvOj8M": ("Jack Gallant", None, ["research-methods", "neuroscience", "perception-attention-action"], "Offers an accessible entry into brain-imaging and decoding methods.", "All four retained mentions are neutral references: this resource has zero observed positive recommendations and must not be labelled community recommended."),
}

# Bounded, manually considered exclusions/holds. No identity merge is automatic.
EXCLUSIONS = {
    "YnWhqhNdYyk": ("exclude-off-topic", "Teaching C++ conventions is not substantive mind/brain/behaviour material."),
    "k6U-i4gXkLM": ("exclude-off-topic", "A programming course is not qualified by an education label alone."),
    "KkMDCCdjyW8": ("exclude-off-topic", "A programming course is not qualified by an education label alone."),
    "TfYf_rPWUdY": ("exclude-weak-scope", "A molecular translation animation needs a specific behavioural-neuroscience learning purpose; not a core atlas video by keyword association."),
    "s_fkpZSnz2I": ("exclude-weak-scope", "Ancient flood-text archaeology is not a cognitive or linguistic explanation merely because writing appears."),
    "PfYYraMgiBA": ("hold-scope-review", "Cuneiform decipherment may support a specialised language-history guide but is not automatically cognition material."),
    "F0_q-fD_lyU": ("exclude-weak-scope", "A bacterial genetic-engineering tutorial does not by itself address behavioural genetics or neuroscience."),
    "fCd6B5HRaZ8": ("exclude-weak-scope", "A sequencing product workflow does not by itself supply a behavioural-science learning resource."),
    "U3EEmVfbKNs": ("hold-scope-review", "A consumer-genotyping lab visit needs a defined behavioural-genetics or research-methods role before inclusion."),
    "ji5_MqicxSo": ("exclude-weak-scope", "A life-lessons lecture is not a substantive scientific treatment of learning or behaviour solely through general inspiration."),
    "Lp7E973zozc": ("exclude-weak-scope", "Motivational advice does not establish a substantive research-grounded atlas resource."),
    "tybOi4hjZFQ": ("exclude-guided-practice", "A breathing exercise is not an explanatory science resource; do not count practice footage as a lecture."),
    "SdQRkmdhwJs": ("exclude-instructional-fragment", "A one-minute driving-test instruction is not a substantive treatment of perception research."),
    "wSF82AwSDiU": ("hold-clinical-claim-review", "The imported annotation itself reports an academic-evidence warning; inspect original warning and appropriate research before any educational use."),
    "xjEFo3a1AnI": ("hold-clinical-claim-review", "Treatment claims about nutrition and severe mental illness require current evidence assessment before use as a treatment-learning recommendation."),
    "zNT8Zo_sfwo": ("exclude-anecdotal-treatment-clip", "A single patient's treatment response clip is not evidence of effectiveness and should not pad the educational catalogue."),
    "BzhbAK1pdPM": ("hold-excerpt-parent", "A segmented Barkley lecture clip needs its parent identified; prefer a complete authorised source."),
    "_tpB-B8BXk0": ("hold-excerpt-parent", "The source explicitly identifies this as part of the 2012 Burnett lecture; link to the complete parent where usable."),
    "sPFmKu2S5XY": ("hold-excerpt-parent", "Inspect relationship to the complete Barkley lecture before treating the clip as a distinct educational resource."),
    "wg6cfsnmqyg": ("hold-excerpt-parent", "Inspect relationship to the complete Barkley lecture before treating the clip as a distinct educational resource."),
    "meiU6TxysCg": ("hold-excerpt-parent", "The unequal-pay monkey clip is an excerpt associated with Frans de Waal's full talk; do not count both as independent full presentations."),
    "hXgqik6HXc0": ("hold-excerpt-parent", "A Penrose AI interview excerpt needs comparison with its full parent before inclusion."),
    "ipRvjS7q1DI": ("hold-excerpt-parent", "An excerpt of a historical Feynman Q&A should be linked to its parent and not padded into a full-lecture count."),
    "Hi63rXnuWbw": ("hold-excerpt-parent", "This is a documentary chapter, not an independent documentary; investigate its parent and educational role."),
    "lFIYKmos3-s": ("hold-excerpt-parent", "A brief Feynman film excerpt should not be counted as a distinct full lecture."),
}
MANUAL_DUPLICATE_GROUPS = [
    {"ids": ["SCAGc-rkIfo", "YSfCdBBqNXY"], "reason": "Barkley Essential Ideas for Parents: likely alternate uploads; original source/duration required before merging."},
    {"ids": ["pqzcCfUglws", "Jv7sLrON7QY"], "reason": "Munger Psychology of Human Misjudgement: likely alternate uploads of the speech; inspect recording identity."},
    {"ids": ["tiJVJ5QRRUE", "cVaTc15plVs"], "reason": "Gender Equality Paradox documentary: possible alternate uploads; verify episode and cut."},
    {"ids": ["fnUc_W3xE1w", "NiTsduRreug"], "reason": "Krashen language-acquisition material: possible overlapping excerpts rather than distinct lectures; unresolved."},
]
SELF_PROMO = re.compile(r"\b(?:my|our)\s+(?:video|talk|lecture|channel|course|documentary|podcast)\b|\bi\s+(?:made|created|recorded|uploaded|gave|produced)\s+(?:(?:this|a|the|that)\s+)?(?:video|talk|lecture|course|documentary|podcast)\b", re.I)
PROMOTION_CONTEXT_REVIEW = {
    27099783: ("self-identified-creator-promotion", "Commenter describes making the linked explanation."),
    42307993: ("lexical-false-positive", "The possessive refers to a personal archive of video files, not creating the linked video."),
    9833022: ("self-identified-creator-promotion", "Commenter identifies as the library author and links their own conference presentation."),
    32016410: ("lexical-false-positive", "The possessive is part of a quoted documentary title."),
    35311028: ("lexical-false-positive", "The possessive is part of a quoted documentary title."),
    39038417: ("lexical-false-positive", "The possessive is part of a quoted documentary title."),
    45783444: ("self-identified-creator-promotion", "A presenter describes their team's talk and demonstration."),
    8571529: ("self-identified-creator-promotion", "Commenter links two of their own presentations."),
    35982590: ("self-identified-creator-promotion", "The source labels a creator's recommendation of their own transformer explanation as strong_rec."),
    26431380: ("self-identified-creator-promotion", "Commenter explicitly describes making the linked demonstration."),
    28363030: ("self-identified-creator-promotion", "Commenter explicitly describes making the linked demonstration."),
    18305144: ("quoted-creator-promotion-no-independent-endorsement-established", "The comment reproduces a creator's first-person pitch; do not treat the quoted passage as independent praise."),
    41760192: ("self-identified-creator-promotion", "Commenter identifies as a member of the team that made the linked video."),
    45720269: ("lexical-false-positive", "The possessive refers to the commenter's viewing diet, not creating the linked talk."),
    18286534: ("lexical-false-positive", "The commenter mentions giving a talk but recommends a different presenter's talk."),
    37294125: ("self-identified-creator-promotion", "Commenter explicitly describes making the linked video."),
    17980155: ("self-identified-creator-promotion", "The retained text calls the linked presentation the commenter's own talk; enthusiastic praise also refers to another talk, so stance-target ambiguity is an additional concern."),
    12375309: ("self-identified-creator-promotion", "Commenter explicitly links a talk they gave and their accompanying site."),
    23819270: ("self-identified-creator-promotion", "Commenter explicitly links a talk they gave."),
}


def read_jsonl(path):
    with path.open(encoding="utf-8") as fh:
        return [json.loads(line) for line in fh if line.strip()]


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input-export", type=Path, default=ROOT / "data/raw/hackertube/export")
    ap.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    src, out = args.input_export, args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    videos = read_jsonl(src / "videos.jsonl")
    mentions = read_jsonl(src / "mentions.jsonl")
    related = read_jsonl(src / "related.jsonl")
    taxonomy = json.loads((src / "taxonomy.json").read_text())
    embedding_ids = json.loads((src / "embedding_ids.json").read_text())
    index = {v["vid"]: v for v in videos}
    by_vid = defaultdict(list)
    failures = []
    check = lambda condition, message: failures.append(message) if not condition else None
    check(len(index) == len(videos), "duplicate video IDs")
    check(all(set(v) == VIDEO_KEYS for v in videos), "unexpected video fields")
    check(all(set(m) == MENTION_KEYS for m in mentions), "unexpected mention fields")
    check(all(re.fullmatch(r"[A-Za-z0-9_-]{11}", v["vid"]) for v in videos), "invalid video ID")
    check(all(v["url"] == "https://www.youtube.com/watch?v=" + v["vid"] for v in videos), "noncanonical export URL")
    check(len({(m["hn_comment_id"], m["vid"]) for m in mentions}) == len(mentions), "duplicate mention key")
    check(all(m["vid"] in index for m in mentions), "mention with missing video")
    check(all(m["stance"] in STANCES for m in mentions), "unexpected stance")
    check(all(re.fullmatch(r"\d{4}-\d{2}", m["month"]) for m in mentions), "invalid month")
    for m in mentions:
        by_vid[m["vid"]].append(m)
    check(all(len(by_vid[v["vid"]]) <= 20 for v in videos), "retained mention cap exceeded")
    cat_index = {c["id"]: (a, c) for a in taxonomy["areas"] for c in a["categories"]}
    check(all(c["id"] in cat_index for v in videos for c in v["categories"]), "unknown category")
    aggregate_mismatches = []
    promotion_queue = []
    aggregates = {}
    for v in videos:
        ms = by_vid[v["vid"]]
        positive = [m for m in ms if m["stance"] in POSITIVE]
        strong = [m for m in ms if m["stance"] == "strong_rec"]
        agg = {
            "mentions": len(ms), "recommenders": len({m["author"] for m in positive}),
            "rec_months": len({m["month"] for m in positive}), "strong_recs": len(strong),
            "stances": dict(Counter(m["stance"] for m in ms)),
            "first_year": min(int(m["month"][:4]) for m in ms),
            "last_year": max(int(m["month"][:4]) for m in ms),
        }
        score = agg["rec_months"] + .5 * len({m["month"] for m in strong})
        if v["hn"] != agg or v["score"] != score:
            aggregate_mismatches.append({"vid": v["vid"], "computed": agg, "computedScore": score})
        flagged = []
        for m in positive:
            if SELF_PROMO.search(m["text"]):
                flagged.append(m["hn_comment_id"])
                disposition, reason = PROMOTION_CONTEXT_REVIEW.get(m["hn_comment_id"], ("unreviewed-lexical-flag", "Needs original context inspection."))
                promotion_queue.append({"vid": v["vid"], "hnCommentId": m["hn_comment_id"], "hnUrl": m["hn_url"], "stance": m["stance"], "status": disposition, "reviewReason": reason, "reviewMaterial": "retained export comment text, truncated at source; original HN page and author identity not independently verified", "countsAsVerifiedIndependentRecommendation": False, "excludeFromIndependentSignal": disposition != "lexical-false-positive"})
        aggregates[v["vid"]] = {
            "retainedMentions": len(ms), "retainedMentionCap": 20,
            "positiveMentionCount": len(positive), "positiveCommenterCount": agg["recommenders"],
            "positiveMonths": agg["rec_months"], "strongPositiveMentionCount": len(strong),
            "stanceCounts": agg["stances"], "sourceCommunityHistoryScore": score,
            "verifiedIndependentRecommenders": None,
            "independenceStatus": "unknown; uploader/author relationships not established",
            "possibleSelfPromotionCommentIds": flagged,
            "limit": "Sampled historical observations, not exhaustive or scientifically validated endorsements. No positive count is claimed to be independent.",
        }
    check(not aggregate_mismatches, "source HN aggregates or score do not recompute")
    check(len({r["vid"] for r in related}) == len(related), "duplicate related row")
    check(all(r["vid"] in index and len(r["related"]) <= 20 and all(x["vid"] in index and isinstance(x["shared_recommenders"], int) and x["shared_recommenders"] > 0 for x in r["related"]) for r in related), "invalid related graph row")
    check(len(embedding_ids) == len(videos) and len(set(embedding_ids)) == len(embedding_ids) and set(embedding_ids) == set(index), "embedding ID mapping mismatch")
    with (src / "embeddings.npy").open("rb") as fh:
        check(fh.read(6) == b"\x93NUMPY", "invalid NPY magic")
        major, minor = fh.read(2)
        length = struct.unpack("<H" if major == 1 else "<I", fh.read(2 if major == 1 else 4))[0]
        header = ast.literal_eval(fh.read(length).decode("latin1").strip())
        offset = fh.tell()
    check(header["shape"] == (len(videos), 384) and header["descr"] == "<f2" and not header["fortran_order"], "unexpected embedding shape/dtype/order")
    check((src / "embeddings.npy").stat().st_size - offset == len(videos) * 384 * 2, "embedding payload size mismatch")

    def eligible(v, cats):
        return v["content_type"] in FORMATS and v["shelf_life"] != "news" and bool({c["id"] for c in v["categories"]} & cats)

    core = [v for v in videos if eligible(v, CORE_CATEGORIES)]
    adjacent = [v for v in videos if eligible(v, ADJACENT_CATEGORIES) and v["vid"] not in {x["vid"] for x in core}]
    norm_groups = defaultdict(list)
    for v in videos:
        normal = " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", v["title"]).casefold()))
        norm_groups[normal].append(v["vid"])
    duplicate_groups = [{"normalisedTitle": t, "ids": ids, "action": "review-recording-identity; no automatic merge"} for t, ids in norm_groups.items() if len(ids) > 1]

    availability_file = Path(__file__).resolve().parent / "availability-sample.json"
    probes = {x["vid"]: x for x in json.loads(availability_file.read_text())} if availability_file.exists() else {}
    candidates = []
    for vid, (speaker, course, families, reason, limit) in REVIEWED.items():
        v = index[vid]
        probe = probes.get(vid)
        candidates.append({
            "id": "youtube:" + vid, "videoId": vid, "title": v["title"],
            "sourceUrl": SOURCE_URL, "canonicalUrl": v["url"],
            "providerId": None, "channelAsImported": v["channel"],
            "providerVerification": "not independently verified by this audit",
            "speaker": speaker, "speakerEvidence": "imported card annotation; not independently credential-checked",
            "parentCourse": course, "parentCourseId": None,
            "parentCourseStatus": "imported annotation; verify official course membership" if course else "unknown",
            "subjectFamilies": families, "subjectTaxonomyStatus": "provisional audit labels, not shared application schema",
            "format": v["content_type"], "formatBasis": "imported model label",
            "level": v["level"], "levelBasis": "imported weak model label",
            "language": None, "durationSeconds": None, "uploadDate": None, "recordingDate": None,
            "transcriptStatus": "unknown", "description": reason,
            "descriptionEvidence": [{"sourceUrl": SOURCE_URL, "retrievedAt": RETRIEVED_AT, "material": "Complete imported video card summary and retained HN comment context; no transcript or video viewing", "videoId": vid, "sampledCommentIds": [m["hn_comment_id"] for m in by_vid[vid][:2]], "sourceAnnotationIsModelGenerated": True}],
            "descriptionCheck": "agent checked against attributed imported annotations and sampled retained comments; not independent publisher/transcript verification",
            "selectionBasis": "editorial-selection", "selectionReason": reason,
            "communitySignals": aggregates[vid],
            "availability": {
                "status": "player-metadata-reported-playable" if probe else "unknown",
                "checkedAt": probe["retrievedAt"] if probe else None,
                "method": "bounded watch-page player metadata observation, prior to identifying automated-access restriction; route not approved for scaling" if probe else "not checked",
                "sourceUrl": v["url"] if probe else None,
                "playerStatus": "OK" if probe else None,
                "playableInEmbed": True if probe else None,
                "playbackWatched": False, "mediaDownloaded": False,
                "receipt": "data/audits/hackertube/availability-sample.json" if probe else None,
                "qualifiesAsAccessibleInThisAudit": False,
            },
            "qualified": False, "qualificationStatus": "candidate-only; verify destination through permitted route, source identity and distinctness",
            "scientificAssessment": "Not assessed", "limits": limit,
            "licence": ATTRIBUTION, "exportDate": EXPORT_DATE, "retrievedAt": RETRIEVED_AT,
        })

    exclusions = [{"videoId": vid, "title": index[vid]["title"], "canonicalUrl": index[vid]["url"], "decision": decision, "reason": reason, "evidence": "imported title/card summary; source scientific claims not independently assessed", "qualified": False} for vid, (decision, reason) in EXCLUSIONS.items() if vid in index]
    queue = []
    for v in core:
        decision = "reviewed-shortlist-candidate" if v["vid"] in REVIEWED else EXCLUSIONS.get(v["vid"], ("unreviewed-inclusion", "Taxonomy/format screening only; no qualification"))[0]
        queue.append({"videoId": v["vid"], "title": v["title"], "canonicalUrl": v["url"], "channelAsImported": v["channel"], "sourceCategories": [c["id"] for c in v["categories"]], "sourceFormat": v["content_type"], "sourcePrimaryTopic": v["primary_topic"], "decision": decision, "qualified": False, "availability": "unknown; consult separate bounded observations only for two sampled IDs", "sourceUrl": SOURCE_URL, "retrievedAt": RETRIEVED_AT})
    stats = {
        "generatedAt": datetime.now(timezone.utc).isoformat(), "exportDate": EXPORT_DATE,
        "inputHashes": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(src.iterdir()) if p.is_file()},
        "counts": {"canonicalIds": len(videos), "mentionVideoPairs": len(mentions), "distinctHnComments": len({m["hn_comment_id"] for m in mentions}), "relatedRows": len(related), "taxonomyAreas": len(taxonomy["areas"]), "taxonomyCategories": len(cat_index), "zeroPositiveVideos": sum(v["hn"]["recommenders"] == 0 for v in videos), "videosAtMentionCap": sum(len(by_vid[v["vid"]]) == 20 for v in videos), "positiveRetainedMentions": sum(m["stance"] in POSITIVE for m in mentions), "coreCategoryFormatTriage": len(core), "adjacentCategoryFormatTriageExcludingCore": len(adjacent), "reviewedCandidates": len(candidates), "exclusionOrHoldCases": len(exclusions), "qualifiedAccessibleVideos": 0, "independentlySourceCheckedCoreResources": 0, "verifiedProviders": 0, "verifiedCourses": 0, "normalisedTitleDuplicateGroups": len(duplicate_groups), "possibleSelfPromotionPositiveMentions": len(promotion_queue)},
        "validationFailures": failures, "aggregateMismatches": aggregate_mismatches,
        "stanceCounts": dict(Counter(m["stance"] for m in mentions)),
        "formatCounts": dict(Counter(v["content_type"] for v in videos)),
        "levelCounts": dict(Counter(v["level"] for v in videos)),
        "shelfLifeCounts": dict(Counter(v["shelf_life"] for v in videos)),
        "categoryCountsMultiAssignment": dict(Counter(c["id"] for v in videos for c in v["categories"])),
        "coreTriageDecisions": dict(Counter(v["decision"] for v in queue)),
        "schema": {"videoFields": sorted(VIDEO_KEYS), "mentionFields": sorted(MENTION_KEYS), "hnFields": sorted(videos[0]["hn"]), "videoFieldTypes": {k: dict(Counter(type(v[k]).__name__ for v in videos)) for k in sorted(VIDEO_KEYS)}, "embeddingHeader": header},
        "missingness": {"durationSeconds": len(videos), "uploadDate": len(videos), "recordingDate": len(videos), "language": len(videos), "transcriptStatus": len(videos), "availabilityInExport": len(videos), "note": "These fields are absent from the export. English titles do not prove language; HN years are not upload/recording dates."},
        "embeddingLimit": "Header, dimensions, payload byte count and complete ID mapping checked. L2 normalisation and retrieval usefulness not benchmarked.",
        "selfPromotionLimit": "Lexical flagging is a non-exhaustive triage aid with false positives. No source field establishes independence and this audit claims no verified independent recommender counts.",
        "selfPromotionContextReview": {"dispositions": dict(Counter(x["status"] for x in promotion_queue)), "positiveMentionPairsExcludedFromIndependentSignal": sum(x["excludeFromIndependentSignal"] for x in promotion_queue), "remainingPositiveMentionPairsAreNotVerifiedIndependent": True, "inspector": "Codex source-audit agent; not human peer review"},
        "triageLimit": "Category/format matches are discovery queues, not verified in-scope or accessible records. Adjacent queue is especially broad and must not inflate coverage.",
        "attribution": ATTRIBUTION,
    }
    save(out / "audit-summary.json", stats)
    save(out / "candidates.json", {"status": "discovery-only", "attribution": ATTRIBUTION, "records": candidates})
    save(out / "triage-queue.json", {"status": "not-qualified", "criterion": {"categoriesAny": sorted(CORE_CATEGORIES), "formats": sorted(FORMATS), "excludeShelfLife": "news"}, "attribution": ATTRIBUTION, "records": queue})
    save(out / "exclusions-and-holds.json", {"status": "bounded-manual-triage", "records": exclusions, "possibleAlternateUploads": MANUAL_DUPLICATE_GROUPS})
    save(out / "normalised-title-review.json", duplicate_groups)
    save(out / "self-promotion-review.json", {"status": "lexical-flags-context-reviewed-in-export", "method": SELF_PROMO.pattern, "notExhaustive": True, "originalHnPagesNotRetrieved": True, "records": promotion_queue})
    print(json.dumps({"validationFailures": failures, "counts": stats["counts"]}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
