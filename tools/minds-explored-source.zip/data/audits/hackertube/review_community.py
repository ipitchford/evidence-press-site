"""Save a bounded, explicitly reasoned community-context review.

No copied comment/profile text is emitted. Public metadata and original decisions
only; the underlying API responses remain in the private raw cache.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
AUDIT = ROOT / "data/audits/hackertube"
RAW = ROOT / "data/raw/hackertube/community-checks"
all_receipts = []
for filename in ["community-retrievals.json", "community-identity-retrievals.json", "community-parent-retrievals.json"]:
    all_receipts += json.loads((AUDIT / filename).read_text())

def proof(cache, inspection):
    r = next(x for x in all_receipts if x.get("cachePath") == f"data/raw/hackertube/community-checks/{cache}")
    assert hashlib.sha256((ROOT / r["cachePath"]).read_bytes()).hexdigest() == r["sha256"]
    return {"id":"community-"+cache.replace(".","-"), "url":r["url"], "retrievedAt":r["retrievedAt"], "sha256":r["sha256"], "cachePath":r["cachePath"], "inspection":inspection, "checker":"agent context/identity review"}

decisions = {
    1021658: {
        "positiveRationale":"Recommends the named Mazur lecture and explains its peer-instruction relevance in a discussion of misconceptions and rote learning.",
        "selfPromotion":None, "independenceChecked":False,
        "independenceRationale":"The current HN profile links to a differently named GitHub identity, but this bounded check does not establish continuity with the historical comment or the author's relationship to the lecturer/publisher. Positive wording is not enough to infer independence.",
        "identityFile":"identity-mquander.html",
    },
    35719191: {
        "positiveRationale":"Responds to an education/grading discussion by explicitly recommending Mazur's explanation of peer instruction, alongside a relevant third-party article.",
        "selfPromotion":False, "independenceChecked":True,
        "independenceRationale":"The public HN account self-links to the personal site of a software author distinct from the named lecturer. The inspected parent discussion and comment contain a third-person recommendation, no ownership claim, commercial call to action or creator promotion. This is one manually checked non-creator recommendation under a bounded public-identity/context criterion; it is not proof of financial independence or an investigation of undisclosed affiliations.",
        "identityFile":"identity-TehShrike.html",
    },
    3659734: {
        "positiveRationale":"Explicitly recommends Hofstadter's analogy lecture in a discussion of language, concepts and phrases.",
        "selfPromotion":None, "independenceChecked":False,
        "independenceRationale":"The public profile's linked identity route returned HTTP 429. The route was stopped. Authorship and relationship to the speaker/publisher remain unresolved despite explicit recommendation wording.",
        "identityFile":None,
    },
    15813123: {
        "positiveRationale":"Recommends Sapolsky's behavioural-biology course from an asserted learner perspective, in a book discussion, with the first lecture as the linked destination.",
        "selfPromotion":None, "independenceChecked":False,
        "independenceRationale":"The self-linked personal site and learner wording are consistent with a third-party recommendation, but the bounded check does not establish the author's relationship to the course/publisher. Independence remains unknown.",
        "identityFile":"identity-yesenadam.html",
    },
}
mentions = {}
for line in (ROOT / "data/raw/hackertube/export/mentions.jsonl").read_text().splitlines():
    row = json.loads(line)
    if row["hn_comment_id"] in decisions:
        mentions[row["hn_comment_id"]] = row

reviews = []
for comment_id, d in decisions.items():
    row = mentions[comment_id]
    live = json.loads((RAW / f"item-{comment_id}.json").read_text())
    assert live["by"] == row["author"] and row["vid"] in live["text"]
    evidence = [
        proof(f"item-{comment_id}.json", "Read the actual HN comment and confirmed its author and exact video link; no full comment text exported."),
        proof(f"parent-{live['parent']}.json", "Read the actual parent story/comment to distinguish recommendation context from creator promotion."),
        proof(f"user-{row['author']}.json", "Inspected the public profile's self-linked identity route. Contact details and full profile text remain private."),
    ]
    if d["identityFile"]:
        evidence.append(proof(d["identityFile"], "Inspected the profile-linked public identity page; exported only an original bounded identity/context conclusion, not contact information."))
    review = {"commentId":comment_id, "videoId":f"youtube:{row['vid']}", "sourceUrl":row["hn_url"], "author":row["author"], "stance":row["stance"], "positiveContextConfirmed":True, "positiveRationale":d["positiveRationale"], "selfPromotion":d["selfPromotion"], "independenceChecked":d["independenceChecked"], "independenceRationale":d["independenceRationale"], "checkedAt":"2026-11-07T16:18:19Z", "checker":"agent", "checkSources":evidence}
    if comment_id == 3659734:
        failed = next(r for r in all_receipts if r["url"] == "https://observablehq.com/@jrus")
        review["failedIdentityAttempt"] = {"url":failed["url"], "retrievedAt":failed["retrievedAt"], "httpStatus":429, "exitCode":failed["exit"], "receipt":"data/audits/hackertube/community-identity-retrievals.json", "action":"Stopped; no bypass or repeated probing."}
    reviews.append(review)

output = {
    "schemaVersion":1,
    "scope":"Four selected positive HN mentions covering three shortlisted videos; explicit context and public identity checks. This is not a representative sample or an exhaustive independence investigation.",
    "policy":"Only rec/strong_rec mentions with independently inspected positive context, a bounded public non-creator identity check and selfPromotion=false contribute to the checked lower-bound count. Unknown authorship/relationships remain unknown. Creator-promotion findings from self-promotion-review.json remain excluded; no blanket independence assumption for other mentions.",
    "limitations":["A public self-linked identity is not identity verification or proof of financial independence.","Historical identities or undisclosed affiliations may differ; the exact limited basis is recorded per case.","One blocked identity route was stopped at HTTP 429.","Four reviewed mentions cannot establish the coverage or independence of the remaining source corpus.","Recommendation history is a discovery signal, not scientific validation."],
    "attribution":"HackerTube and open-index/hacker-news, ODC-By 1.0 for source database metadata. Individual comments, profiles and identity pages retain their separate rights; this file contains factual metadata and original review annotations only.",
    "counts":{"reviewed":4,"positiveContextConfirmed":4,"checkedNonCreatorRecommendations":1,"independenceUnknown":3},
    "reviews":reviews,
}
(AUDIT / "community-context-review.json").write_text(json.dumps(output,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(output["counts"]))
