"""Write only the new genetics guide, its receipt and this follow-up's audit files."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[4]
AUDIT = ROOT / 'data/audits/editorial-body/genetics-followup'
SLUG = 'genes-environment-and-behaviour'
GUIDE = ROOT / f'content/guides/{SLUG}.json'
RECEIPT = ROOT / f'data/editorial-checks/guides/{SLUG}.json'
NOW = datetime.now(timezone.utc).isoformat()

def read_json(path):
    return json.loads(path.read_text())

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

assert not GUIDE.exists(), 'Do not overwrite an existing guide.'
assert not RECEIPT.exists(), 'Do not overwrite an existing receipt.'
candidates = {r['id']: r for r in read_json(ROOT / 'data/audits/courses/candidates.json')}
catalogue = {r['id']: r for r in map(json.loads, (ROOT / 'data/catalogue.jsonl').read_text().splitlines())}
retrievals = {r['id']: r for r in read_json(AUDIT / 'retrievals.json')}
api = read_json(ROOT / '.cache/youtube/metadata.json')['records']
sources = []

def retrieved(key, title, inspection):
    r = retrievals[key]
    s = {'id': f'genetics-{key}', 'title': title, 'url': r['url'],
         'retrievedAt': r['retrievedAt'], 'sha256': r['sha256'],
         'inspection': inspection, 'cachePath': r['cachePath']}
    sources.append(s)
    return s

noba = retrieved('noba-nature-nurture', 'The nature–nurture question — Eric Turkheimer, Noba',
    'Read the introduction and the main What Have We Learned About Nature–Nurture? discussion, through its conclusion before Outside Resources. Used family resemblance, non-random adoption, twin-comparison logic, the parental-reading confounding example and the distinction between population variation and developmental processes. The module’s broad universals, dated claims about gene discovery, candidate-gene violence example, epigenetic inheritance paragraph and clinical examples are not adopted or treated as current validated evidence. References were not independently reviewed.')
medline = retrieved('medline-heritability', 'What is heritability? — MedlinePlus Genetics',
    'Read the complete explanatory text, including population/environment specificity, the 0.7 example, familial versus heritable, the distinction from individual trait composition, and the warning that heritability does not measure ease of change. Page update shown as 16 September 2021. Its categorical illustrative claims about spoken language/religion and simplified single-gene examples are not used; linked papers were not independently reviewed.')
interaction = retrieved('nhgri-interaction', 'Gene–environment interaction — National Human Genome Research Institute',
    'Read the definition and narration. Used physical/social environments and the definition in which an environmental effect differs by genotype, or conversely. The glossary’s disease example is not generalised into evidence for a particular behavioural interaction. The rendered update date is not treated as the publication date of a research finding.')
mit1_transcript = retrieved('kAX_PRnliMo-transcript', 'MIT Nature & Nurture I — official transcript opening',
    'Read the first 12,000 characters after removing VTT cue numbers/times and normalising whitespace: framing innate structure versus experience, early brain development, the face-perception example, motion as an alternative explanation, and the warning that an early response is not zero experience. This is a partial transcript check, not full viewing or a current review of the cited developmental findings.')
mit2_transcript = retrieved('xA00vkxG3lE-transcript', 'MIT Nature & Nurture II (2018) — official transcript opening',
    'Read the first 14,000 characters after removing VTT cue numbers/times and normalising whitespace: recap of alternative accounts of face perception, connectivity as a developmental hypothesis, diffusion tractography and its limitations, and adult connectivity/function prediction. Partial transcript only; this guide does not assert the lecture’s dated research conclusions as current consensus.')

def course_source(video_id, inspection):
    c = candidates['youtube:' + video_id]
    r = c['retrieval']
    s = {'id': 'genetics-publisher-' + video_id, 'title': c['title'] + ' — official publisher page',
         'url': c['sourceUrl'], 'retrievedAt': r['retrievedAt'], 'sha256': r['sha256'],
         'inspection': inspection, 'cachePath': r['cachePath']}
    sources.append(s)
    return s

mit1_page = course_source('kAX_PRnliMo', 'Read the individual MIT summary identifying infancy/childhood cortical organisation and genes versus experience; matched the exact video and linked official transcript. No full-video viewing.')
mit2_page = course_source('xA00vkxG3lE', 'Read the individual MIT summary identifying genes/experience, cortical organisation and adult change; matched exact video and transcript. Preserved the title’s 2018 recording label within the 2019 course. No full-video viewing.')
yale = course_source('piDznzrNymE',
    'Read the publisher overview, all of transcript Chapter 5 beginning 36:33, and the first 6,500 characters of Chapter 6 beginning 51:16. Selected only the variance-versus-person distinction, family-comparison cautions and within-/between-group logical contrast. Explicitly excluded broad claims about negligible parenting effects, universal high heritability, and separated twins having no environmental similarity. This is 2007 teaching, not a current genetics review; no full-video viewing.')

def existing_session(slug, inspection):
    s = dict(read_json(ROOT / f'content/guides/{slug}.json')['sources'][0])
    s['id'] = 'genetics-' + s['id']
    s['inspection'] = inspection
    sources.append(s)
    return s

intelligence = existing_session('what-intelligence-tests-measure',
    'Read the official Session Overview, chapter headings and Check Yourself answers. Used the distinction between a test score and the wider construct it measures, and the session’s explicit nature/nurture question. No lecture transcript or full video inspected for this selection. Its historical intervention, stereotype-threat and group-comparison claims are not endorsed here.')
personality = existing_session('personality-dimensions-without-boxes',
    'Read the official Session Overview, chapter headings and Check Yourself answers, including the explicit population-variance warning for heritability. Used trait measurement and the genetics/environment framing; did not adopt its birth-order generalisations, temperament invariance or other dated causal claims. No lecture transcript or full video inspected for this selection.')

body = """A child may resemble a parent in talkativeness, reading or problem solving. That resemblance does not, by itself, explain how it arose. Three questions need separating: how an ability develops, why people differ on a measure, and what would happen if their circumstances changed. A genetic explanation of differences does not automatically answer the other two.

First specify the behaviour and how it was measured. A questionnaire rating, a test score and an observed action are different kinds of evidence. The MIT [intelligence](https://ocw.mit.edu/courses/9-00sc-introduction-to-psychology-fall-2011/pages/intelligence/) and [personality](https://ocw.mit.edu/courses/9-00sc-introduction-to-psychology-fall-2011/pages/personality/) sessions are useful for this preparatory step. An explanation of differences in one measure should not silently become an explanation of the whole person.

Families share experiences as well as genetic relationships. [Noba’s nature–nurture chapter](https://nobaproject.com/modules/the-nature-nurture-question) explains why adoption and twin comparisons help researchers separate possible influences. Adoption separates biological parentage from being raised by those parents, but placement is not a random experiment. Identical and non-identical twin comparisons provide different degrees of genetic relatedness; interpreting their resemblance also requires attention to their environments. These designs are informative comparisons, not automatic proof that every observed family resemblance is genetic.

Heritability concerns variation across people in a specified population and set of circumstances. In a hypothetical study, an estimate of 0.6 would attribute 60% of the measured variation to genetic variation under the study’s model. It would not mean that 60% of each person’s behaviour comes from genes. Nor would it identify the responsible genes, explain the developmental process, or tell us how readily the trait could change. The [MedlinePlus explanation](https://medlineplus.gov/genetics/understanding/inheritance/heritability/) makes these boundaries explicit. The estimate can change when the population or circumstances change.

Variation within groups and differences between their averages are also separate questions. A high within-group heritability estimate cannot by itself establish why two groups have different averages. The optional [2007 Yale lecture’s Chapter 5](https://oyc.yale.edu/psychology/psyc-110/lecture-13) illustrates that logical distinction. Use it as a historical methods comparison: its later sweeping conclusions about parenting are not conclusions of this guide.

Environment includes physical and social conditions, not merely parenting. Genes and environments can also interact. In the narrower research sense, this means that the effect of an exposure differs with genetic background, or the effect of genetic differences depends on the exposure. The [NHGRI glossary](https://www.genome.gov/genetics-glossary/Gene-Environment-Interaction) explains this using disease risk. It supplies a definition, not evidence that a particular behavioural interaction exists. Saying that both genes and experience matter does not demonstrate an interaction; a specific claim needs a specified outcome, comparison and evidence.

The starting MIT lecture asks a different, complementary question: how does organised brain function develop? Its [opening discussion of face perception](https://ocw.mit.edu/courses/9-13-the-human-brain-spring-2019/resources/lecture-10-development-nature-nurture-i/) considers whether a young animal’s response reflects faces specifically, movement more generally, or experience already acquired. This is an example of turning a nature–nurture slogan into competing explanations and a better comparison. It is not a heritability calculation. The continuation examines how connectivity might constrain development, while explaining limitations of the imaging method.

Finally, evidence about existing differences is not a direct test of an intervention. Noba’s example of parents reading to children shows the problem: an association with later reading scores leaves several possible pathways open. A suitable intervention study addresses a different question. High heritability alone neither establishes that change is impossible nor shows that a proposed programme works. The exercise below practises keeping those conclusions separate."""

resources = [
    {'id': 'youtube:bihrpOS0qtY', 'purpose': 'Define the measured outcome',
     'reason': 'The 2011 MIT session distinguishes an intelligence test score from the wider construct and explicitly considers nature/nurture. Use its measurement questions before interpreting a genetic estimate; this guide does not endorse its dated intervention or group-comparison claims.'},
    {'id': 'youtube:Vko17una2Zw', 'purpose': 'Compare a different kind of behavioural measure',
     'reason': 'The 2011 MIT personality session covers trait dimensions and questionnaires; its answer key explicitly warns that heritability describes population variation, not an inherited percentage of a person. Its birth-order generalisations are not adopted.'},
    {'id': 'youtube:xA00vkxG3lE', 'purpose': 'Follow a developmental mechanism question',
     'reason': 'The opening of this 2018 continuation compares explanations for face perception and asks how long-range connectivity might shape cortical organisation. Read its imaging limitations alongside that hypothesis; these developmental questions differ from estimating heritability.'},
    {'id': 'youtube:piDznzrNymE', 'purpose': 'Optional historical comparison of inference limits',
     'reason': 'Chapter 5, beginning at 36:33, distinguishes variation among people from individual trait composition and within-group from between-group explanations. This 2007 lecture also makes sweeping later claims about parenting and separated twins that this guide does not endorse; it is a bounded comparison, not a current evidence summary.'},
]

exercise = {
    'title': 'Audit three conclusions from one hypothetical estimate',
    'instructions': 'Imagine a study of a specified reading test reports heritability of 0.6 in one population. No intervention was tested. Evaluate these fictional claims: “60% of Alex’s reading ability is genetic”; “a tutoring programme cannot help”; and “a difference in average scores between two schools must be genetic”. For each, identify the extra inference and explain why the estimate alone does not establish it. Then write a defensible two-sentence summary naming the measured outcome, population and study assumptions. List what you would need to know about sampling, comparable measurement and environments; for the tutoring claim, describe a comparison that would actually test the programme. The 0.6 is invented for reasoning practice, not an estimate of reading heritability or an assessment of a real person.',
    'url': medline['url'],
}

guide = {
    'slug': SLUG, 'title': 'How do genes and environment influence behaviour?',
    'question': 'How do genes and environment influence behaviour?',
    'topics': ['individual-differences', 'development', 'methods', 'evolution-comparative'],
    'audience': 'Readers evaluating claims that behavioural differences are inherited or produced by upbringing.',
    'scope': 'Interpret family and twin comparisons, population heritability and developmental experiments without turning them into percentages of a person or claims of inevitable outcomes. This route explains foundational inference, not personal genetic risk or modern genome-wide prediction.',
    'status': 'reviewed', 'startingResourceId': 'youtube:kAX_PRnliMo',
    'startingReason': 'The opening of Nancy Kanwisher’s MIT lecture turns “genes versus experience” into concrete questions about developing brain organisation and face perception, including alternative explanations for an early response. Pair it with the short MedlinePlus reading to distinguish a developmental question from population heritability.',
    'resources': resources, 'body': body, 'courseId': 'mit-human-brain-2019',
    'supporting': [
        {'id': s['id'], 'title': s['title'], 'url': s['url'], 'kind': 'reading', 'reason': reason}
        for s, reason in [
            (medline, 'Read the definition and misconception list first: the estimate concerns population variation and does not divide a person into genetic and environmental percentages.'),
            (noba, 'Read the adoption/twin-design discussion and parental-reading example for confounding. Its older candidate-gene and epigenetic examples are outside this guide’s evidence claims.'),
            (interaction, 'Use the definition and narration to distinguish an interaction from the general statement that both genes and environment matter. Its disease example is not a behavioural finding.'),
        ]
    ],
    'methodsOrExercise': exercise,
    'prerequisites': [
        'No prior genetics required. Keep a group average separate from variation among the people in that group; proportions such as 0.6 are explained in the guide.',
        'The MIT brain lectures use basic visual-cortex and MRI vocabulary. The second is an optional continuation after the first, not necessary for the heritability exercise.',
    ],
    'keyTerms': [
        {'term': 'Heritability', 'meaning': 'An estimate of the share of variation in a measured trait attributed to genetic variation in a specified population and set of circumstances, under the study’s model; not a fraction of an individual.'},
        {'term': 'Familial', 'meaning': 'Seen among members of a family; family resemblance alone does not identify a genetic cause.'},
        {'term': 'Gene–environment interaction', 'meaning': 'A pattern in which an environmental effect differs by genetic background, or the effect of genetic differences depends on the environment.'},
        {'term': 'Confounding', 'meaning': 'When linked influences leave an observed association open to more than one causal explanation, as with genetic and environmental pathways in a family comparison.'},
    ],
    'neighbours': ['neuroscience', 'learning-memory'],
    'nextStep': 'Return to the intelligence or personality session and identify the exact measure and comparison behind one claim. Separate the population-difference question from the evidence needed to establish a developmental mechanism or an effective intervention.',
    'limits': 'The selected teaching dates from Yale 2007, MIT psychology 2011, and the MIT 2019 brain course, whose continuation is explicitly labelled 2018. The two brain transcript openings were read, not the full recordings; the psychology selections were checked against session pages, and Yale against the specified transcript sections. MedlinePlus’s page is dated September 2021; the NHGRI definition was retrieved for this check. Noba is used for study-design reasoning, not as a current review of genetic discovery, candidate-gene effects or epigenetic inheritance. Yale’s broad parenting claims and MIT’s birth-order claims are not adopted. No claim is made that all family-design assumptions are satisfied in any particular study. Genome-wide association, polygenic prediction, clinical testing and personal genetic advice are outside scope. Agent source inspection is not full-video viewing, human peer review or independent scientific validation.',
    'sources': sources,
    'check': {'date': '2026-11-07', 'checker': 'agent',
              'materialInspected': 'Three directly retrieved educational/institutional readings; two partial official MIT transcripts and matching publisher summaries; two MIT psychology session pages; Yale lecture 13 overview and specified transcript sections. Selection and substantive claim limits recorded separately from current access metadata.',
              'receipt': f'data/editorial-checks/guides/{SLUG}.json'},
}

selections = [
    ('youtube:kAX_PRnliMo', [mit1_page, mit1_transcript], guide['startingReason']),
    ('youtube:bihrpOS0qtY', [intelligence], resources[0]['reason']),
    ('youtube:Vko17una2Zw', [personality], resources[1]['reason']),
    ('youtube:xA00vkxG3lE', [mit2_page, mit2_transcript], resources[2]['reason']),
    ('youtube:piDznzrNymE', [yale], resources[3]['reason']),
]
claims = [
    ('Family resemblance alone does not separate genetic from environmental pathways; twin/adoption designs help but are not random environmental experiments.', [noba, yale], 'The guide describes the comparison logic, not the adequacy of every assumption or a quantitative effect estimate.'),
    ('Heritability concerns variation in a specified population/context; 0.6 is not 60% of an individual and does not identify genes or ease of change.', [medline, personality], 'The number is fictional. No estimate is assigned to a real behavioural trait or person.'),
    ('Within-group heritability does not by itself explain a difference between group averages.', [yale], 'This is a logical limitation, not a claim about any particular ethnic or social group. The lecture’s broad parenting, twin-environment and universal heritability claims are excluded.'),
    ('Gene–environment interaction has a more specific meaning than saying that both matter.', [interaction], 'The source illustrates the definition with disease risk; no specific behavioural interaction or clinical conclusion is inferred.'),
    ('The MIT opening uses alternative explanations for an early response to motivate controlled developmental comparisons.', [mit1_transcript, mit2_transcript], 'Partial transcript inspection; no current consensus claim or full appraisal of the developmental studies cited in the recordings.'),
    ('An observational family association or heritability estimate alone does not establish the effect of an intervention.', [noba, medline], 'The guide proposes a reasoning exercise, not a real educational trial, treatment recommendation or individual assessment.'),
    ('A questionnaire score and a performance-test score require explicit measurement interpretation before claims about their origins.', [intelligence, personality], 'Only session pages inspected; no unqualified endorsement of historical intervention, birth-order or group-comparison claims.'),
]

resource_decisions = []
for rid, basis, reason in selections:
    c = catalogue[rid]
    resource_decisions.append({
        'resourceId': rid, 'sourceTitle': c['title'], 'courseId': c['courseId'],
        'sourceIds': [s['id'] for s in basis], 'sourceUrls': [s['url'] for s in basis],
        'sourceSha256': [s['sha256'] for s in basis],
        'inspection': ' '.join(s['inspection'] for s in basis), 'selectionDecision': reason,
    })

errors = []
ids = [guide['startingResourceId']] + [r['id'] for r in resources]
assert len(set(ids)) == 5
assert 4 <= len(resources) <= 8
for source in sources:
    actual = hashlib.sha256((ROOT / source['cachePath']).read_bytes()).hexdigest()
    if actual != source['sha256']:
        errors.append('Source hash mismatch: ' + source['id'])
for rid in ids:
    if rid not in catalogue:
        errors.append('Unresolved resource: ' + rid)
    r = api[rid.split(':')[1]]
    if r['availability']['status'] != 'accessible':
        errors.append('Not currently API-accessible: ' + rid)
    if datetime.fromisoformat(r['expiresAt'].replace('Z', '+00:00')) <= datetime.now(timezone.utc):
        errors.append('Expired access check: ' + rid)
source_urls = {s['url'] for s in sources}
inline_urls = re.findall(r'\]\((https://[^)]+)\)', body)
if set(inline_urls) - source_urls:
    errors.append('Inline citation missing retrieved source')
assert not errors, errors

receipt = {
    'slug': SLUG, 'checkedAt': NOW, 'checker': 'agent', 'kind': 'guide',
    'question': guide['question'],
    'claimDecisions': [{'claim': c, 'basis': [s['id'] for s in b], 'limit': l} for c, b, l in claims],
    'resourceDecisions': resource_decisions, 'sourceChecks': sources,
    'exerciseDecision': {'title': exercise['title'], 'purpose': exercise['instructions'],
                         'boundary': 'Invented estimate and fictional claims for inference practice; not a reported result, genetic test, clinical recommendation or validated assessment.'},
    'bodyReview': 'Read the full original guide against the inspected passages. The route distinguishes developmental mechanisms, population variation and intervention effects; unsupported historical examples are excluded explicitly. All citations have retrieved, hash-verified source files. No source inspection is represented as watching a recording.',
    'structuralChecks': {'canonicalIdsResolved': len(ids), 'distinctResources': len(set(ids)),
                         'furtherVideoSelections': len(resources), 'inlineLinksBackedByRetrievedSources': len(set(inline_urls)),
                         'sourceHashesVerified': len(sources), 'bodyWords': len(body.split())},
    'scientificAssessment': 'Not assessed',
    'accessibility': {'basis': 'Existing authorised YouTube Data API overlay, checked separately from source inspection; no observed playback.',
                      'cacheReference': '.cache/youtube/metadata.json',
                      'referenceIds': [rid.split(':')[1] for rid in ids],
                      'assessment': 'All five records were accessible and unexpired at this editorial check. The site must use the live permitted overlay rather than treating this receipt as permanent API metadata.'},
    'scopeControl': 'Only this new guide, its receipt and new genetics-followup audit files are written. No existing catalogue, source file, core fragment or guide is overwritten.',
}
save(GUIDE, guide)
save(RECEIPT, receipt)
save(AUDIT / 'validation.json', {'checkedAt': NOW, 'guide': str(GUIDE.relative_to(ROOT)),
    'receipt': str(RECEIPT.relative_to(ROOT)), **receipt['structuralChecks'], 'errors': errors})
print(json.dumps({'guide': str(GUIDE), 'receipt': str(RECEIPT), **receipt['structuralChecks'], 'errors': errors}, indent=2))
