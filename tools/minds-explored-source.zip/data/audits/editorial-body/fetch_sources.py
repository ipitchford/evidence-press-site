import concurrent.futures, datetime, hashlib, json, pathlib, subprocess
ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / 'data/raw/editorial-body'
OUT.mkdir(exist_ok=True, parents=True)
requests = json.loads((ROOT / 'data/audits/editorial-body/fetch-requests.json').read_text())
prior_file = ROOT / 'data/audits/editorial-body/retrievals.json'
prior = {r['url']: r for r in json.loads(prior_file.read_text())} if prior_file.exists() else {}
def fetch(row):
    if row['url'] in prior:
        old = prior[row['url']]
        if old.get('exitCode') != 0 or (ROOT / old['cachePath']).exists():
            return old
    digest = hashlib.sha256(row['url'].encode()).hexdigest()
    file = OUT / (digest + '.' + row['kind'])
    headers = OUT / (digest + '.headers')
    result = subprocess.run(['curl', '-L', '--fail', '--silent', '--show-error', '--max-time', '45', '--retry', '1', '--max-filesize', '3000000', '-D', str(headers), '-o', str(file), row['url']], capture_output=True, text=True)
    data = file.read_bytes() if file.exists() else b''
    return {**row, 'retrievedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': result.returncode, 'error': result.stderr[:400] or None, 'cachePath': str(file.relative_to(ROOT)), 'sha256': hashlib.sha256(data).hexdigest() if data else None, 'bytes':len(data)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    receipts = list(pool.map(fetch, requests))
(ROOT / 'data/audits/editorial-body/retrievals.json').write_text(json.dumps(receipts, indent=2)+'\n')
print(json.dumps({'retrieved':sum(r['exitCode']==0 for r in receipts),'failed':[{'id':r['id'],'error':r['error']} for r in receipts if r['exitCode']]}))
