"""Package individually authored notes with the source material actually inspected.

This does not infer scientific correctness or accessibility. It verifies that each
manual note has a real source receipt and that the cached bytes still match it.
"""
import datetime, hashlib, json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[3]
HERE = ROOT / 'data/audits/editorial-body'
records = {r['id']:r for r in json.loads((ROOT/'data/audits/courses/candidates.json').read_text())}
notes = json.loads((HERE/'core-notes.json').read_text())
reservations = {r['id'] for r in json.loads((HERE/'reservations.json').read_text())}
retrievals = {r['id']:r for r in json.loads((HERE/'retrievals.json').read_text())}
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
overrides, checks = {}, []
for short, description, reason, topics, limits in notes:
    identity = 'youtube:'+short
    record = records[identity]
    source = record['retrieval']
    method = 'publisher-description'
    inspected = 'Individually inspected the institutional publisher overview and exact lecture identity.'
    if record['parentCourse']=='mit-psychology-2011':
        source = retrievals[identity+'-transcript']
        assert source['exitCode']==0
        method = 'transcript'
        inspected = 'Read the opening transcript: first 6,000 cleaned characters for Emotion/Stress, first 8,500 for Brain I/II and Psychopathology I/II. No full-transcript or full-video review.'
    elif identity=='youtube:Ts0cWwnVnNw':
        method = 'transcript'
        inspected = 'Read the transcript opening, approximately 15,000 characters, and compared it with the duplicated publisher overview; description follows the distinct transcript.'
    elif record['providerId']=='neuromatch':
        inspected = 'Read the exact video heading/description and its adjacent tutorial explanation, stated assumptions and relevant exercises. No video viewing or notebook execution.'
    data=(ROOT/source['cachePath']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==source['sha256'],identity
    evidence_id='body-core-'+short+'-source'
    evidence={k:source[k] for k in ['url','retrievedAt','sha256','cachePath']}
    evidence.update(id=evidence_id,inspection=inspected,checker='agent')
    if record['parentCourse']=='mit-neural-computation-2018':
        level='advanced'
        level_basis='Editorial judgement from the inspected description: this continuation uses mathematical neural models, linear algebra or Fourier methods and assumes earlier course material. It is not an official difficulty rating.'
    elif record['providerId']=='neuromatch':
        level='intermediate'
        level_basis='Editorial judgement from the inspected tutorial context: basic neuron concepts and comfort with plotted models are needed; the associated exercises use Python and quantitative reasoning. It is not an official difficulty rating.'
        if short in ['KKMlWWU83Jg','GCpQmh45crM','V2SBAK2Xf8Y','jIx26iQ69ps']:
            level='advanced'
            level_basis='Editorial judgement from the inspected section: coupled differential equations, phase-plane or stability reasoning requires calculus and dynamical-systems preparation; Jacobian/eigenvalue extensions require linear algebra. It is not an official difficulty rating.'
    else:
        level='foundation'
        level_basis='Editorial judgement from the inspected introductory course overview or transcript opening: conceptual explanations do not presuppose specialist mathematical or clinical training. Historical claims still need the stated source-date cautions; this is not an official difficulty rating.'
    item={
      'id':identity,'description':description,'topics':topics,
      'level':level,'levelBasis':level_basis,
      'descriptionCheck':{'status':'checked','method':method,'checkedAt':now,'checker':'agent','evidenceIds':[evidence_id],'note':inspected+' '+limits},
      'selection':{'basis':'institutional-collection','reason':reason,'evidenceIds':[evidence_id],'checkedAt':now,'checker':'agent','topicAssignment':'Individual editorial topic refinement based on inspected material.'},
      'checkSources':[evidence],'provenance':[evidence],
      'editorialDecision':{'descriptionDecision':description,'selectionDecision':reason,'limits':limits,'receipt':'data/audits/editorial-body/core-checks.json#'+identity}
    }
    overrides[identity]=item
    checks.append({'id':identity,'title':record['title'],'checkedAt':now,'checker':'agent','method':method,'source':evidence,'description':description,'selectionReason':reason,'level':level,'levelBasis':level_basis,'limits':limits,'scientificAssessment':'Not assessed','accessibilityDecision':'Retain independently established availability; this source check does not qualify playback.'})
assert set(overrides)==reservations,(set(overrides)^reservations)
assert len(overrides)==50
supplement_path=HERE/'core-supplement.json'
if supplement_path.exists():
    supplement=json.loads(supplement_path.read_text())
    assert not (set(overrides)&set(supplement)), 'Supplement duplicates an existing annotation'
    for item in supplement.values():
        for s in item['checkSources']:
            assert hashlib.sha256((ROOT/s['cachePath']).read_bytes()).hexdigest()==s['sha256']
    overrides.update(supplement)
    checks.extend(json.loads((HERE/'core-supplement-checks.json').read_text())['records'])
(HERE/'core-overrides.json').write_text(json.dumps(overrides,indent=2,ensure_ascii=False)+'\n')
(HERE/'core-checks.json').write_text(json.dumps({'checkedAt':now,'checker':'agent','records':checks,'count':len(checks),'boundary':'Individual editorial checks of source scope and selection; not human peer review, scientific validation or observed playback.'},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'sourceChecks':len(checks),'sourceHashesVerified':len(checks),'methods':{m:sum(r['method']==m for r in checks) for m in sorted({r['method'] for r in checks})}}))
