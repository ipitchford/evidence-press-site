"""Package original editorial writing with the precise, already inspected sources.

The text is authored in editorial-content.json. This script checks identities and
cache hashes; it does not purport to perform the substantive source reading.
"""
import datetime, hashlib, json, pathlib, re

ROOT = pathlib.Path(__file__).resolve().parents[3]
HERE = ROOT / 'data/audits/editorial-body'
BUILT_AT = datetime.datetime.now(datetime.timezone.utc).isoformat()
REVIEW = json.loads((HERE/'review-record.json').read_text()) if (HERE/'review-record.json').exists() else None
NOW = REVIEW['checkedAt'] if REVIEW else BUILT_AT
DATE = NOW[:10]

def read(path):
    return json.loads((ROOT/path).read_text())

def digest(path):
    return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()

def source(title, r, inspection):
    path = r.get('cachePath', r.get('rawPath'))
    assert path and digest(path)==r['sha256'], (title,path)
    return {'id':'body-source-'+r['sha256'][:16], 'title':title,
            'url':r['url'], 'retrievedAt':r['retrievedAt'], 'sha256':r['sha256'],
            'inspection':inspection, 'cachePath':path}

videos={r['id']:r for r in read('data/audits/courses/candidates.json')}
provider={r['id']:r for r in read('data/audits/providers/candidate-observations.json')}
nptel={r['id'].replace('yt:','youtube:'):r for r in read('data/audits/nptel/reviewed-candidates.json')}
ours={r['id']:r for r in read('data/audits/editorial-body/core-checks.json')['records']}
retrieved={r['id']:r for r in read('data/audits/editorial-body/retrievals.json') if r['exitCode']==0}
for r in read('data/audits/editorial-body/supplemental-retrievals.json'):
    if r['exitCode']==0 and r.get('contentStatus')!='challenge-page-not-source':
        retrieved[r['id']]=r
existing_sources={}
for name in ['development-across-the-lifespan','remembering-and-forgetting']:
    for r in read('content/guides/'+name+'.json')['sources']:
        existing_sources[r['url']]=r

session_map={'Qw4SkvZ03cc':'adult-development','yBYebcVw8Zk':'child-development',
             '76O3rulk844':'memory-i','kD3CswjYb2E':'memory-ii'}
provider_inspections={
 'HD2QGCu-GIk':'Read the full two-part publisher talk overview: microglial states, imaging, development, health/disease, and synaptic pruning; not the videos or cited reviews.',
 'M3bNorPiYS8':'Read the full two-part publisher talk overview, especially the distinct second-talk account of microglia and synaptic pruning; not the videos or cited reviews.',
 'HMa56658fGU':'Read the opening approximately 13,000 characters of the 13 November 2024 publisher transcript: research framing, relational/transactional models, measurement of mobile-media use and bidirectional observational associations. The later talk and whole video were not reviewed.',
 'vGcFqzZYJxQ':'Read the individual publisher description, date and duration, including the description meta field; a short 2014 explanation, not a transcript or current consensus review.',
 'gw9GrgNcYcg':'Read the individual publisher description, including its description meta field about the adolescent transition to adulthood; no transcript or viewing.'}

def video_source(ident):
    short=ident.split(':',1)[1]
    if ident in ours:
        r=ours[ident]
        inspection=r['source']['inspection']
        if short=='t73rjeOj0eY':
            inspection+=' For the emotion guide, also read the selected James–Lange/body-and-feeling discussion later in this transcript; historical demonstrations were not independently validated.'
        return source(r['title'],r['source'],inspection)
    if short in session_map:
        url='https://ocw.mit.edu/courses/9-00sc-introduction-to-psychology-fall-2011/pages/'+session_map[short]+'/'
        return source(videos[ident]['title']+' — session page',existing_sources[url],
            'Read the complete session overview and lecture chapter list, plus visible discussion/self-check context; not a full transcript or viewing. Historical 2011 teaching.')
    if short=='SBrCPDC21f4':
        r=read('data/audits/editorial-mind/core-overrides.json')[ident]['checkSources'][0]
        return source(videos[ident]['title']+' — session page',r,
            'Read session overview, full-video identity, chapter sequence, generalisation/discrimination explanations and limits-of-conditioning context; not a full transcript or viewing.')
    if ident in videos:
        r=videos[ident]
        return source(r['title'],r['retrieval'],
            'Read the individual MIT publisher description beyond the title and checked the exact lecture identity. Scope and selection checked; no full transcript or viewing.')
    if ident in provider:
        r=provider[ident]
        return source(r['title'],r['descriptionEvidence'][0],provider_inspections[short])
    if ident in nptel:
        r=nptel[ident]; cid=r['parentCourse'].split(':')[1]
        c=read('data/audits/nptel/course-'+cid+'.json')['course']
        e=dict(c['sourceEvidence'],cachePath='data/raw/nptel/course-'+cid+'.html')
        inspected='Read the official course abstract and relevant week syllabus, and checked this specific ordered lecture entry: '+r['title']+'. The syllabus gives course-level context, not an individual lecture description, transcript or viewing.'
        if not c['courseDescription']:
            inspected='Read the official ordered lecture outline and checked this specific entry: '+r['title']+'. This page supplies no explanatory course abstract. Selection is based on the named sequence only; the individual lecture content has not been reviewed.'
        if cid=='109104108':
            inspected='Read the exact Sleep 1–3 IDs/titles and embedded concepts_covered descriptions. Sleep 1/2 descriptions discuss consciousness and appear shifted or inconsistent; their numerical mind-division claim is not relied on. Sleep 3 explicitly describes biological rhythms, sleep and polysomnography. Checked that authorised API titles match all three IDs. No individual lecture transcript or playback was reviewed; use Sleep 3’s descriptive scope only, with NIGMS as the clock-account source.'
        return source(c['title']+' — '+r['title'],e,inspected)
    raise KeyError(ident)

support_specs={
 'depression-nimh':('Depression — NIMH','National Institute of Mental Health','Read the introductory definition, symptom/assessment context, multifactorial explanation and treatment overview, approximately the first 10,000 cleaned characters; not every linked treatment page.','A current institutional overview of depression and broad treatment options.'),
 'psychotherapies-nimh':('Psychotherapies — NIMH','National Institute of Mental Health','Read the explanatory text on therapy goals, evidence-based approaches, CBT/exposure examples and evaluating treatment, approximately the first 10,000 cleaned characters; not every external resource.','Distinguishes therapy aims and evidence from individual testimonials.'),
 'anxiety-nimh':('Anxiety disorders — NIMH','National Institute of Mental Health','Read the full main page: disorder types, functional impact and research on genetic, developmental and environmental factors; last reviewed December 2024.','Separates everyday anxiety from impairing disorders and identifies research questions.'),
 'teen-brain-nimh':('The teen brain: 7 things to know — NIMH','National Institute of Mental Health','Read the complete main fact sheet, revised 2023, including development, adaptation, social experience, stress, sleep and resilience.','A concise institutional account to compare with older adolescent-brain explanations.'),
 'circadian-nigms':('Circadian rhythms — NIGMS','National Institute of General Medical Sciences','Read the complete main fact sheet: approximately 24-hour rhythms, environmental cues, SCN coordination, feedback mechanisms and experimental methods. Content reviewed September 2023; page updated May 2025.','Connects clocks, environmental timing and experimental manipulation.'),
 'depression-nice':('Depression in adults: treatment and management — NICE NG222','National Institute for Health and Care Excellence','Read recognition/assessment, informed choice and less-severe-depression recommendations including 1.5.3 and the treatment comparison table; also inspected treatment discussion passages. Not a complete guideline evidence review.','Shows how symptom severity, function, preferences, benefits and harms enter recommendations.'),
 'anxiety-nice':('Generalised anxiety disorder and panic disorder in adults — NICE CG113','National Institute for Health and Care Excellence','Read assessment, stepped care and selected CBT/applied-relaxation/medicine recommendations, including the benzodiazepine restriction. This is the GAD/panic guideline; not guidance for all anxiety diagnoses.','A diagnosis-specific example of a clinical recommendation framework.'),
 'rdoc-nimh':('About Research Domain Criteria — NIMH','National Institute of Mental Health','Read the full main explanatory page about dimensions, domains, units of analysis, development and environment, and its explicit research-not-diagnosis boundary.','Contrasts research dimensions with existing diagnostic categories.'),
 'noba-neurons':('Neurons — Noba','Noba / Diener Education Fund','Read the first approximately 14,000 cleaned characters: neuron structure, types of glia and opening membrane-potential explanation. Numerical cell counts and broad glia claims were not adopted.','A vocabulary bridge for cell types, membranes and neural communication.'),
 'noba-the-brain':('The brain — Noba','Noba / Diener Education Fund','Read introduction, broad anatomy, grey/white matter, lateralisation and methods overview. This is an introductory module, not a complete current neuroanatomy review; broad behavioural claims were not adopted.','Connects anatomy with the kinds of observations different methods support.'),
 'noba-aging':('Aging — Noba','Noba / Diener Education Fund','Read the opening approximately 14,000 cleaned characters: lifespan/life-course framing, cross-sectional/longitudinal designs, cohort effects, fluid/crystallised abilities, experience, compensation, personality and social context.','Provides a concrete basis for separating age, cohort and within-person change.'),
 'noba-the-healthy-life':('The healthy life — Noba','Noba / Diener Education Fund','Read the opening approximately 14,000 cleaned characters, particularly measurement of stress and the virus-exposure example. The guide does not endorse every broad causal claim in this module.','A worked example for asking which variable was assigned and which was only measured.'),
 'noba-functions-of-emotions':('Functions of emotions — Noba','Noba / Diener Education Fund','Read the introductory framing and selected explanatory passages distinguishing within-person, interpersonal and social/cultural functions of emotion; not every underlying study or the full module.','An explicitly functional perspective to compare with bodily and social explanations.'),
 'noba-drive-states':('Drive states — Noba','Noba / Diener Education Fund','Read introduction, properties of drive states, homeostasis and hunger/internal-external cues. Did not adopt the module’s stronger generalisations, anecdotal nutritional claims or simplified hypothalamic localisation.','Frames the distinction between biological regulation and the circumstances of eating.'),
 'noba-adolescent-development':('Adolescent development — Noba','Noba / Diener Education Fund','Read the opening approximately 14,000 cleaned characters on physical, cognitive and social change, identity and peers. The guide avoids the simplified engine/brake and dopamine-image captions.','Adds relationships, identity and peer selection/influence to brain-development accounts.'),
 'motor-unit-uth':('Motor units and muscle receptors — Neuroscience Online','UTHealth Houston, Department of Neurobiology and Anatomy','Read sections 1.1–1.4 on motor-control requirements and the specific motor-unit/motor-neuron-pool definition passage around Figure 1.4. The definition groups an individual motor neuron with all muscle fibres it innervates. No complete textbook or clinical rehabilitation review.','An authoritative introductory definition of a motor unit, with sensory-input and feedback context.')}
supports={}
for k,(title,provider_name,inspection,reason) in support_specs.items():
    s=source(title,retrieved[k],inspection)
    supports[k]=dict(s,providerName=provider_name,reason=reason)
bundle='data/raw/editorial-body/nih-web-reader.json'
b=read(bundle)
supports['clinical-research-nih']={
 'id':'body-source-'+digest(bundle)[:16], 'title':'Clinical research trials: the basics — NIH',
 'url':'https://www.nih.gov/health-information/nih-clinical-research-trials-you/basics',
 'retrievedAt':b['retrievedAt'],'sha256':digest(bundle),'cachePath':bundle,
 'inspection':'Read the successful NIH reader-text result in this four-URL bundle: clinical research types, protocols, consent, randomisation/masking, participation and risks; page reviewed 24 April 2025. Hash identifies the saved reader-response bundle, not original HTML. Three other requests in that bundle failed and are not treated as sources.',
 'providerName':'National Institutes of Health',
 'reason':'Defines the intervention, comparison and protocol questions needed to interpret a trial.'}

def unique_sources(items):
    seen=set();result=[]
    for x in items:
        key=(x['url'],x['sha256'])
        if key not in seen:
            seen.add(key);result.append({k:v for k,v in x.items() if k not in ['reason','providerName']})
    return result

def vid(short): return short if ':' in short else 'youtube:'+short

def identity_sources(identities):
    # The public citation may link to a lecture page, while substantive reading
    # was of the officially linked transcript. Preserve both real receipts.
    results=[]
    for ident in identities:
        if ident in ours and videos[ident]['parentCourse']=='mit-psychology-2011':
            r=videos[ident]
            results.append(source(r['title']+' — institutional resource identity',r['retrieval'],
                'Checked the institutional resource identity and its linked transcript URL. The page does not provide a substantive description; the paired transcript receipt records the text actually inspected.'))
    return results

spec=read('data/audits/editorial-body/editorial-content.json')
catalogue={r['id']:r for r in map(json.loads,(ROOT/'data/catalogue.jsonl').read_text().splitlines())}
courses=read('data/courses.json')
if isinstance(courses,dict): courses=courses.get('courses',courses)
course_ids={x['id'] for x in courses} if isinstance(courses,list) else set(courses)
all_sources=[]
for kind in ['guides','paths']:
    (ROOT/'content'/kind).mkdir(parents=True,exist_ok=True)
    (ROOT/'data/editorial-checks'/kind).mkdir(parents=True,exist_ok=True)
    for data in spec[kind]:
        d=dict(data)
        assert d['status']!='reviewed' or REVIEW, 'Reviewed output needs the actual editorial review record.'
        notes=d.pop('claimChecks')
        selected=d.pop('supportIds')
        if kind=='guides':
            d['startingResourceId']=vid(d['startingResourceId'])
            for r in d['resources']: r['id']=vid(r['id'])
            identities=[d['startingResourceId']]+[r['id'] for r in d['resources']]
            assert d['courseId'] in course_ids,d['courseId']
            d['supporting']=[{'id':'reading:body-'+k,'title':supports[k]['title'],'url':supports[k]['url'],'kind':'reading','reason':supports[k]['reason']} for k in selected]
        else:
            for r in d['steps']:r['resourceId']=vid(r['resourceId'])
            identities=[r['resourceId'] for r in d['steps']]
        assert len(identities)==len(set(identities)),d['slug']
        assert all(i in catalogue for i in identities),[i for i in identities if i not in catalogue]
        d['sources']=unique_sources([video_source(i) for i in identities]+identity_sources(identities)+[supports[k] for k in selected])
        all_sources+=d['sources']
        receipt='data/editorial-checks/'+kind+'/'+d['slug']+'.json'
        d['check']={'date':DATE,'checker':'agent','materialInspected':'Individually inspected publisher descriptions, stated course outlines and the specified transcript/reading sections. Exact scope and limits are recorded per source. No claim of complete viewing, human peer review or independent scientific validation.','receipt':receipt}
        claims=[]
        for statement,basis,status in notes:
            urls=[supports[k]['url'] if k in supports else video_source(vid(k))['url'] for k in basis]
            claims.append({'claimOrDecision':statement,'basis':urls,'status':status})
        selections=[{'id':identities[0],'reason':d['startingReason']}] + d['resources'] if kind=='guides' else d['steps']
        checks={'guide' if kind=='guides' else 'path':d['slug'],'checkedAt':NOW,'checker':'agent','checkType':'Source-grounded agent editorial check; not human peer review, scientific validation or observed viewing','claimsAndDecisions':claims,'selectionDecisions':selections,'sourceReceipts':d['sources'],'limitations':d['limits'],'identityChecks':{'allResourceIdsExist':True,'sourceHashesVerified':True,'distinctOrderedResources':True},'availabilityBoundary':'Availability belongs to the separately refreshed catalogue; this editorial check does not assert playback or overwrite access evidence.'}
        (ROOT/receipt).write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
        (ROOT/'content'/kind/(d['slug']+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

used={k for kind in ['guides','paths'] for d in spec[kind] for k in d['supportIds']}
additions=[]
for k in sorted(used):
    r=supports[k]
    additions.append({'id':'reading:body-'+k,'title':r['title'],'kind':'reading','providerName':r['providerName'],'url':r['url'],'reason':r['reason'],'evidence':{x:r[x] for x in ['url','retrievedAt','sha256','inspection','cachePath']},'rightsNote':'Link and original annotation only. Source prose, images and cached evidence are not republished.'})
(HERE/'supporting-resources.json').write_text(json.dumps(additions,ensure_ascii=False,indent=2)+'\n')
manifest={'checkedAt':NOW,'guides':[d['slug'] for d in spec['guides']],'paths':[d['slug'] for d in spec['paths']],'supportingReadings':len(additions),'uniqueRetrievedSources':len(unique_sources(all_sources)),'sourceChecks':'Each emitted source has a verified cached SHA-256; substantive scope is recorded separately and does not follow from the hash.','reviewBoundary':'Original editorial work checked against cited material; no claim of systematic review, clinical advice or playback.'}
(HERE/'editorial-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
