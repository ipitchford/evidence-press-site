"""Package four manually inspected transcript additions; no automatic checking."""
import datetime,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
HERE=ROOT/'data/audits/editorial-body'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
records={r['id']:r for r in json.loads((ROOT/'data/audits/courses/candidates.json').read_text())}
retrievals={r['id']:r for r in json.loads((HERE/'supplemental-retrievals.json').read_text())}
api=json.loads((ROOT/'.cache/youtube/metadata.json').read_text())['records']
notes=[
 ('5XHGEOOYnzw',12500,
  'Connects retinal and cortical receptive fields with visual population codes. The inspected opening compares centre–surround and orientation-selective responses, then uses the tilt aftereffect to motivate a population-response hypothesis.',
  'A concrete sensory-system continuation for the brain-systems guide: compare anatomical pathways, recorded responses and a model that explains an ambiguous single-neuron response.',
  ['neuroscience','perception-action','methods'],'intermediate',
  'Editorial judgement from the inspected opening: assumes earlier retina/receptive-field material and interpretation of tuning-curve graphs; no claim of an official difficulty rating.',
  'Read the first 12,500 cleaned transcript characters and the individual publisher description. No video viewing or full-transcript review. The underlying adaptation mechanism is presented as a hypothesis; numerical/clinical claims were not independently audited.'),
 ('ReKjU4ZUAjg',12500,
  'Examines how local visual-motion measurements can be combined. The inspected opening reviews delayed-input detectors and the aperture problem, then compares component- and pattern-motion responses using plaid stimuli and V1/MT examples.',
  'Useful for separating perception of a moving target from the motor command used to follow it, and for connecting a circuit model to competing predictions about recorded neuronal responses.',
  ['perception-action','neuroscience','computation-ai'],'intermediate',
  'Editorial judgement from the inspected opening: needs prior receptive-field concepts, two-dimensional vectors and interpretation of tuning curves. It is a continuation, not a first lesson in vision.',
  'Read the first 12,500 cleaned transcript characters plus the broad publisher description. The transcript provides the specific motion content that the generic description does not. No full viewing or independent audit of the physiological studies.'),
 ('Mre84EsXY_Y',14000,
  'Introduces smell and taste, distinguishing an odorant from the resulting sensation. The inspected opening follows olfactory receptors to bulb/cortical projections, discusses a scent-tracking experiment and connects smell with flavour.',
  'Adds sensory mechanisms to the hunger/reward guide, allowing food-related cues to be considered separately from appetite, access and actual consumption.',
  ['perception-action','neuroscience','emotion-motivation-sleep'],'intermediate',
  'Editorial judgement from the inspected opening: assumes basic neuron and sensory-system vocabulary; the speaker explains the olfactory structures but compares them with earlier sensory lectures.',
  'Read the first 14,000 cleaned transcript characters and the individual publisher description. This opening is mainly olfaction; the later gustation discussion was not read. Exact receptor numbers, causal evolutionary speculation and transcript unit slips are not endorsed.'),
 ('phbw9r1iUDI',14000,
  'Introduces parametric hypothesis testing through a running-time example. The inspected opening distinguishes estimation from testing and shows how choices about a distribution, variance and alternative hypothesis constrain the question being answered.',
  'An advanced methods continuation for treatment-evidence readers: understand the assumptions behind a statistical test without confusing a test result with clinical importance or a complete causal explanation.',
  ['methods'],'advanced',
  'Editorial judgement from the inspected opening: presupposes probability distributions, expectation/variance, maximum-likelihood estimation and the central limit theorem; mathematical study needs the preceding statistics material.',
  'Read the first 14,000 cleaned transcript characters. No full lecture or later clinical-trial example was inspected. The lecturer explicitly uses a simplifying variance assumption known to fail for the later data; the annotation retains the modelling lesson rather than endorsing that assumption.')
]
overrides={};checks=[]
for short,n,description,reason,topics,level,level_basis,limits in notes:
    ident='youtube:'+short;r=records[ident];t=retrievals['supplement-'+short+'-transcript']
    assert t['exitCode']==0 and api[short]['availability']['status']=='accessible'
    sources=[]
    for src,inspection in [(t,f'Read the first {n:,} cleaned characters of the official MIT VTT transcript; specific topics and limitations are documented in the individual receipt. No full viewing.'),(r['retrieval'],'Read the individual institutional resource identity and publisher description where supplied; verified the official transcript link. The substantive check uses the paired transcript receipt.')]:
        assert hashlib.sha256((ROOT/src['cachePath']).read_bytes()).hexdigest()==src['sha256']
        sources.append({k:src[k] for k in ['url','retrievedAt','sha256','cachePath']}|{'id':'body-supplement-'+short+'-'+('transcript' if src is t else 'page'),'inspection':inspection,'checker':'agent'})
    ids=[s['id'] for s in sources]
    overrides[ident]={'id':ident,'description':description,'topics':topics,'level':level,'levelBasis':level_basis,
      'descriptionCheck':{'status':'checked','method':'transcript','checkedAt':now,'checker':'agent','evidenceIds':ids,'note':limits},
      'selection':{'basis':'institutional-collection','reason':reason,'evidenceIds':ids,'checkedAt':now,'checker':'agent'},
      'checkSources':sources,'provenance':sources,
      'editorialDecision':{'descriptionDecision':description,'selectionDecision':reason,'limits':limits,'receipt':'data/audits/editorial-body/core-supplement-checks.json#'+ident}}
    checks.append({'id':ident,'title':r['title'],'checkedAt':now,'checker':'agent','method':'transcript','source':sources[0],'sources':sources,'description':description,'selectionReason':reason,'topics':topics,'level':level,'levelBasis':level_basis,'limits':limits,'scientificAssessment':'Not assessed','accessibilityDecision':'The existing authorised API cache reports accessible for GB without a reported age restriction; no playback was observed and this editorial fragment does not overwrite access evidence.','apiEvidenceReference':{'checkedAt':api[short]['checkedAt'],'sourceEvidenceId':api[short]['provenance']['id']}})
(HERE/'core-supplement.json').write_text(json.dumps(overrides,ensure_ascii=False,indent=2)+'\n')
(HERE/'core-supplement-checks.json').write_text(json.dumps({'checkedAt':now,'checker':'agent','records':checks,'count':4},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'id':r['id'],'sha256':r['source']['sha256']} for r in checks],indent=2))
