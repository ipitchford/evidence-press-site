#!/usr/bin/env python3
"""Cache-only corrections. Does not contact YouTube or any other network service."""
import json,re
from pathlib import Path
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from fetch import ROOT
OUT=ROOT/'data/audits/courses'
rows=json.loads((OUT/'candidates.json').read_text())
courses={c['id']:c for c in json.loads((OUT/'course-register.json').read_text())}
for row in rows:
    row['courseInstructor']=courses[row['parentCourse']].get('speaker')
    row['speaker']=None
    row['speakerEvidence']=None
    row['subjectAssignmentBasis']='Selected course collection; individual topic refinement is pending.'
    row['authorisedMediaAlternatives']=[urljoin(row['sourceUrl'],u) for u in row['authorisedMediaAlternatives']]
    text=row['descriptionEvidence']['excerptForPrivateAudit']
    if row['providerId']=='mit-ocw':
        m=re.search(r'\bSpeaker:\s*(.+?)(?:\s*\bLicense:|$)',text)
        if m:
            row['speaker']=m.group(1).strip()
            row['speakerEvidence']={'sourceUrl':row['sourceUrl'],'basis':'Explicit Speaker label in retrieved official resource description.'}
    row['qualificationStatus']='candidate'
(OUT/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'records':len(rows),'explicitSpeakers':sum(r['speaker'] is not None for r in rows),'relativeMediaURLs':sum(u.startswith('/') for r in rows for u in r['authorisedMediaAlternatives'])}))
