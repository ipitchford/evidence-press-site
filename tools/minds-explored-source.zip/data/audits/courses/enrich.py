#!/usr/bin/env python3
"""Cache-only enrichment after collect/refine/probe_media/context_titles.

Makes source-specific limitations explicit. It does not turn candidates into
scientifically reviewed or fully qualified records and performs no network I/O.
"""
import json,re,hashlib
from pathlib import Path
from urllib.parse import urlparse,unquote
from bs4 import BeautifulSoup
from fetch import ROOT
OUT=ROOT/'data/audits/courses';RAW=ROOT/'data/raw/courses'
rows=json.loads((OUT/'candidates.json').read_text())
contexts=json.loads((OUT/'video-title-contexts.json').read_text())
page_titles={r['url']:r['title'] for r in json.loads((OUT/'page-queue.json').read_text())}
def cached(url):
    key=hashlib.sha256(url.encode()).hexdigest();p=RAW/(key+'.html');m=RAW/(key+'.json')
    return (p.read_text(),json.loads(m.read_text())) if p.exists() and m.exists() else (None,None)
def duration(text):
    try:
        parts=str(text).split(':')
        value=0
        for part in parts:value=value*60+float(part)
        return value
    except (TypeError,ValueError):return None
for row in rows:
    usable=next((x for x in row.get('mediaEndpointChecks',[]) if x['mediaEndpointAccessible']),None)
    if usable and row['availability']['status']=='accessible_alternative_endpoint':
        row['availability']['url']=usable.get('requestUrl',usable['url'])
    row['title']=' '.join(row['title'].replace('\u200b','').split())
    if row['youtubeId'] in contexts:
        cs=contexts[row['youtubeId']];titles=list(dict.fromkeys(c['title'] for c in cs))
        row['videoSectionContexts']=cs
        if len(titles)==1:
            row['lessonTitle']=page_titles.get(row['sourceUrl'],row['title']);row['title']=titles[0]
            row['titleStatus']='official_video_section_heading_matched_by_widget_model'
    if any('nano recap' in c['title'].lower() for c in contexts.get(row['youtubeId'],[])):
        row['qualificationStatus']='excluded'
        row['exclusionReason']='Explicitly labelled nano recap; retained as a supporting course asset, excluded from substantive-video target.'
    if row['parentCourse']=='mit-bcs-computational-tutorials':
        soup=BeautifulSoup((ROOT/row['retrieval']['cachePath']).read_text(),'html.parser')
        main=soup.find(id='main-content') or soup.find('main')
        if main:
            text=main.get_text(' ',strip=True)
            row['descriptionEvidence']['excerptForPrivateAudit']=text[:2400]
            instructor=re.search(r'Taught by:\s*(.+?)\s*\(',text)
            if instructor:
                row['sourceInstructorText']=instructor.group(1)
            if row['titleStatus']=='source_page_title':
                d=re.search(r'Video:.*?\((\d{1,2}:\d{2}(?::\d{2})?)\)',text)
                if d:
                    row['durationSeconds']=duration(d.group(1))
                    row['durationEvidence']={'url':row['sourceUrl'],'basis':'Duration explicitly printed beside the video on the official tutorial page.','retrievedAt':row['retrieval']['retrievedAt'],'sha256':row['retrieval']['sha256']}
    text=row['descriptionEvidence']['excerptForPrivateAudit']
    if row['providerId']=='mit-ocw' and row['speaker'] is None:
        m=re.search(r'\bInstructor:\s*(.+?)(?:\s*\bLicense:|$)',text)
        if m:
            row['speaker']=m.group(1).strip()
            row['speakerEvidence']={'sourceUrl':row['sourceUrl'],'basis':'Explicit Instructor label in official video description.'}
    for url in row['authorisedMediaAlternatives']:
        path=urlparse(url).path
        m=re.search(r'/(?:download|items)/([^/]+)/(.+)',path)
        if not m:continue
        item,filename=m.groups();metadata_url='https://archive.org/metadata/'+item
        raw,receipt=cached(metadata_url)
        if raw is None:continue
        data=json.loads(raw);entry=next((f for f in data.get('files',[]) if f.get('name')==unquote(filename)),None)
        if entry and entry.get('length'):
            row['durationSeconds']=duration(entry['length'])
            row['durationEvidence']={'url':metadata_url,'fileName':filename,'reportedLength':entry['length'],'basis':'Internet Archive metadata for the exact MP4 filename linked by MIT. Not an independent timing measurement.','retrievedAt':receipt['retrievedAt'],'sha256':receipt['sha256']}
            break
    if row['youtubeId'] in ('P3FKHH2RzjI','F8gTfydUFjc'):
        raw,receipt=cached(row['canonicalUrl'])
        if raw:
            match=re.search(r'(?:var\s+)?ytInitialPlayerResponse\s*=\s*',raw)
            player=json.JSONDecoder().raw_decode(raw[match.end():])[0] if match else {}
            status=player.get('playabilityStatus',{})
            details=player.get('videoDetails',{})
            row['boundedPlayerObservation']={'url':row['canonicalUrl'],'retrievedAt':receipt['retrievedAt'],'sha256':receipt['sha256'],'status':status.get('status'),'playableInEmbed':player.get('playabilityStatus',{}).get('playableInEmbed'),'hasStreamingMetadata':bool(player.get('streamingData')),'playbackObserved':False,'limitation':'One of two bounded initial audit observations; not a scalable update method. No signed media URLs copied into this record.'}
            if status.get('status')=='OK' and player.get('streamingData'):
                row['availability']={'status':'official_player_metadata_playable','method':'Bounded initial-player response observation; status OK and streaming metadata present','checkedAt':receipt['retrievedAt'],'playbackObserved':False,'limitation':'Metadata only; not a watched or decoded video. Further YouTube checks require the permitted API/player route.'}
                if row['qualificationStatus']!='excluded':row['qualificationStatus']='access_evidence_present_editorial_check_pending'
            if details.get('lengthSeconds'):
                row['durationSeconds']=int(details['lengthSeconds'])
                row['durationEvidence']={'url':row['canonicalUrl'],'basis':'lengthSeconds in the bounded official player response','retrievedAt':receipt['retrievedAt'],'sha256':receipt['sha256']}
    if row['providerId']=='neuromatch':
        row['substanceCheck']='Pending individual duration and content check; notebook tutorials may contain short recaps or exercise walkthroughs.'
        row['reuse']['scope']='Neuromatch course website/repository content states CC BY 4.0; software additionally BSD 3-Clause. This does not independently establish a separate reuse licence for every hosted video or third-party asset. Link by default.'
    if row['providerId']=='open-yale':
        row['reuse']['scope']='Most course material under CC BY-NC-SA 3.0 with excluded third-party material. Terms page links both US and Unported variants; retain terms URL and inspect per-lecture credits before copying. Link by default.'
(OUT/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'records':len(rows),'excludedRecaps':sum(r['qualificationStatus']=='excluded' for r in rows),'durations':sum(r['durationSeconds'] is not None for r in rows),'explicitSpeakers':sum(r['speaker'] is not None for r in rows),'availabilityEvidence':sum(r['availability']['status']!='unknown' for r in rows)}))
