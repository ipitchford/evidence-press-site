#!/usr/bin/env python3
"""Structural, citation and receipt verification of this agent's actual artifacts.

This is not a substitute for the separately recorded editorial reading/review.
"""
import json,re,hashlib,datetime
from pathlib import Path
from fetch import ROOT
OUT=ROOT/'data/audits/courses'
pack=json.loads((OUT/'editorial-pack.json').read_text());videos={r['id'] for r in json.loads((OUT/'candidates.json').read_text())}
errors=[];results=[]
for item,kind in [(x,'guide') for x in pack['topics']]+[(x,'path') for x in pack['paths']]:
    file=item.get('guideFile') or item['file'];data=json.loads((ROOT/file).read_text())
    receipt=json.loads((ROOT/data['check']['receipt']).read_text())
    fields=['slug','title','audience','prerequisites','sources','check']+(['question','scope','startingResourceId','startingReason','resources','body','courseId','supporting','methodsOrExercise','keyTerms','neighbours','nextStep','limits'] if kind=='guide' else ['description','objectives','steps','shortRoute','continuation','limits'])
    for field in fields:
        if not data.get(field):errors.append(file+': missing '+field)
    ids=[data['startingResourceId']]+[r['id'] for r in data['resources']] if kind=='guide' else [s['resourceId'] for s in data['steps']]
    if len(ids)!=len(set(ids)):errors.append(file+': repeated video')
    if any(x not in videos for x in ids):errors.append(file+': unknown video')
    if kind=='guide' and not 4<=len(data['resources'])<=8:errors.append(file+': further-resource count')
    if kind=='path' and not 5<=len(data['steps'])<=10:errors.append(file+': step count')
    source_urls={s['url'] for s in data['sources']}
    for u in re.findall(r'\]\((https://[^\s)]+)\)',data.get('body','')):
        if u not in source_urls:errors.append(file+': inline citation lacks source receipt '+u)
    for s in data['sources']:
        path=ROOT/s['cachePath']
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=s['sha256']:errors.append(file+': source hash mismatch '+s['url'])
        if not s.get('inspection'):errors.append(file+': source inspection missing')
    if data['check']['checker']!='agent' or receipt['checker']!='agent':errors.append(file+': inaccurate checker')
    results.append({'file':file,'kind':kind,'videoSelections':len(ids),'sourceReceipts':len(data['sources']),'proseWords':len(data.get('body','').split()) if kind=='guide' else None,'status':data['status']})
core=json.loads((OUT/'core-overrides.json').read_text())
if len(core)!=40:errors.append('Core does not contain exactly 40 distinct keys')
for key,r in core.items():
    if key not in videos or key!=r['id']:errors.append('Invalid core ID '+key)
    if not r.get('description') or not r.get('selection',{}).get('reason') or not r.get('checkSources'):errors.append('Incomplete core '+key)
    source_ids={s['id'] for s in r['provenance']}
    if any(e not in source_ids for e in r['descriptionCheck']['evidenceIds']+r['selection']['evidenceIds']):errors.append('Broken core evidence reference '+key)
    for s in r['checkSources']:
        if hashlib.sha256((ROOT/s['cachePath']).read_bytes()).hexdigest()!=s['sha256']:errors.append('Core hash mismatch '+key)
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checker':'agent-written local verifier','guides':sum(r['kind']=='guide' for r in results),'paths':sum(r['kind']=='path' for r in results),'individualCoreFragments':len(core),'artifacts':results,'errors':errors,'passed':not errors,'boundary':'Checks real IDs, per-file fields, cited receipt coverage and SHA-256 identity. Editorial source reading is recorded separately. This does not establish playback, scientific correctness, human review, usability or learning impact.'}
(OUT/'editorial-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));raise SystemExit(1 if errors else 0)
