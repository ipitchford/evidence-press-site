#!/usr/bin/env python3
"""Bounded, cached, read-only public source retrieval for this audit."""
from pathlib import Path
import datetime,hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parents[3]
RAW=ROOT/'data/raw/courses';RAW.mkdir(parents=True,exist_ok=True)
RECEIPTS=ROOT/'data/audits/courses/retrievals.jsonl'
def fetch(url,force=False):
 key=hashlib.sha256(url.encode()).hexdigest();path=RAW/(key+'.html');meta=RAW/(key+'.json')
 if path.exists() and meta.exists() and not force:
  m=json.loads(meta.read_text());return path.read_text(errors='replace'),m
 time.sleep(.3)
 headers=RAW/(key+'.headers')
 p=subprocess.run(['curl','-L','--fail','--silent','--show-error','--max-time','40','--max-filesize','8000000','--retry','1','--retry-delay','2','-D',str(headers),url],capture_output=True)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 m={'url':url,'retrievedAt':now,'method':'HTTP GET via curl; source text retrieval, not video playback','exitCode':p.returncode,'sha256':hashlib.sha256(p.stdout).hexdigest(),'bytes':len(p.stdout),'cachePath':str(path.relative_to(ROOT)),'error':p.stderr.decode(errors='replace')[:800] or None}
 if p.returncode==0:path.write_bytes(p.stdout)
 meta.write_text(json.dumps(m,indent=2)+'\n')
 with RECEIPTS.open('a') as f:f.write(json.dumps(m)+'\n')
 return p.stdout.decode(errors='replace'),m
if __name__=='__main__':
 import sys
 for u in sys.argv[1:]:
  _,m=fetch(u);print(json.dumps(m))
