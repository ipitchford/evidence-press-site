#!/usr/bin/env python3
"""Bounded institutional-course candidate audit; no YouTube bulk fetching."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin,urlparse
import sys,json,re,hashlib,datetime
from bs4 import BeautifulSoup
from fetch import fetch,ROOT
OUT=ROOT/'data/audits/courses'
COURSES=[
 {'id':'mit-human-brain-2019','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/9-13-the-human-brain-spring-2019/video_galleries/lecture-videos/','title':'The Human Brain','families':['neuroscience','perception-action','development'],'speaker':'Nancy Kanwisher','year':2019,'level':'undergraduate'},
 {'id':'mit-neural-computation-2018','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/9-40-introduction-to-neural-computation-spring-2018/video_galleries/lecture-videos/','title':'Introduction to Neural Computation','families':['neuroscience','computation-ai'],'speaker':None,'year':2018,'level':'undergraduate'},
 {'id':'mit-perception-2024','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/9-35-perception-spring-2024/resources/lecture-videos/','title':'Perception','families':['perception-action','neuroscience'],'speaker':None,'year':2024,'level':'undergraduate'},
 {'id':'mit-psychology-2011','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/9-00sc-introduction-to-psychology-fall-2011/resources/lecture-videos/','title':'Introduction to Psychology','families':['learning-memory','mental-health','development','individual-differences'],'speaker':'John D. E. Gabrieli','year':2011,'level':'introductory','fullLectureOnly':True},
 {'id':'mit-statistics-2016','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/18-650-statistics-for-applications-fall-2016/resources/lecture-videos/','title':'Statistics for Applications','families':['methods'],'speaker':'Philippe Rigollet','year':2016,'level':'undergraduate'},
 {'id':'mit-probability-2010','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/resources/lecture-videos/','title':'Probabilistic Systems Analysis and Applied Probability','families':['methods','computation-ai'],'speaker':'John Tsitsiklis','year':2010,'level':'undergraduate'},
 {'id':'mit-bcs-computational-tutorials','provider':'mit-ocw','url':'https://ocw.mit.edu/courses/res-9-008-brain-and-cognitive-sciences-computational-tutorials/','title':'Brain and Cognitive Sciences Computational Tutorial Series','families':['computation-ai','methods','neuroscience'],'speaker':None,'year':None,'level':'advanced','seminar':True},
 {'id':'yale-psychology-2007','provider':'open-yale','url':'https://oyc.yale.edu/introduction-psychology/psyc-110','title':'Introduction to Psychology','families':['learning-memory','development','individual-differences','mental-health'],'speaker':'Paul Bloom','year':2007,'level':'introductory'},
 {'id':'yale-food','provider':'open-yale','url':'https://oyc.yale.edu/psychology/psyc-123','title':'The Psychology, Biology and Politics of Food','families':['emotion-motivation-sleep','social-cultural','mental-health'],'speaker':None,'year':None,'level':'undergraduate'},
 {'id':'yale-human-nature','provider':'open-yale','url':'https://oyc.yale.edu/philosophy/phil-181','title':'Philosophy and the Science of Human Nature','families':['consciousness-philosophy','reasoning-decisions','social-cultural'],'speaker':'Tamar Gendler','year':2011,'level':'undergraduate'},
 {'id':'yale-death-mind','provider':'open-yale','url':'https://oyc.yale.edu/death/phil-176','title':'Death: mind, personal identity and mortality','families':['consciousness-philosophy'],'speaker':'Shelly Kagan','year':None,'level':'undergraduate','lectureMax':14},
 {'id':'yale-social-theory','provider':'open-yale','url':'https://oyc.yale.edu/sociology/socy-151','title':'Foundations of Modern Social Theory','families':['social-cultural'],'speaker':None,'year':None,'level':'undergraduate'},
 {'id':'yale-game-theory','provider':'open-yale','url':'https://oyc.yale.edu/economics/econ-159','title':'Game Theory','families':['reasoning-decisions','social-cultural'],'speaker':None,'year':None,'level':'undergraduate'},
 {'id':'yale-evolution-behaviour','provider':'open-yale','url':'https://oyc.yale.edu/ecology-and-evolutionary-biology/eeb-122','title':'Principles of Evolution, Ecology and Behavior: evolution and behaviour selections','families':['evolution-comparative'],'speaker':None,'year':None,'level':'undergraduate','evolutionSelection':True},
 {'id':'neuromatch-compneuro','provider':'neuromatch','url':'https://compneuro.neuromatch.io/tutorials/intro.html','title':'Neuromatch Academy: Computational Neuroscience','families':['computation-ai','methods','neuroscience'],'speaker':None,'year':None,'level':'advanced'},
]
excluded=[];queue=[];course_records=[]
for c in COURSES:
 h,m=fetch(c['url']);s=BeautifulSoup(h,'html.parser');c['sourceCheck']=m
 links={}
 for a in s.find_all('a',href=True):
  url=urljoin(c['url'],a['href']).split('#')[0];t=a.get_text(' ',strip=True)
  if c['provider']=='mit-ocw':
   match=('/resources/' in url and url!=c['url'] and '/courses/' in url and ('resource-list-title' in a.get('class',[]) or '/video_galleries/' in c['url']))
   if c.get('seminar'):match='/pages/' in url and '/courses/res-9-' in url and t and not re.fullmatch(r'\d{4}[–-]\d{4}',t) and t!='Seminar Series'
   if match and c.get('fullLectureOnly') and not re.match(r'^Lecture \d+',t):
    excluded.append({'sourceUrl':url,'title':t,'courseId':c['id'],'reason':'Clip/repeated excerpt or auxiliary item; full lectures only for this collection.'});match=False
  elif c['provider']=='open-yale':
   match=bool(re.search(r'/(lecture|guest-lecture)-\d+',url))
   n=re.search(r'/lecture-(\d+)',url)
   if match and c.get('lectureMax') and n and int(n.group(1))>c['lectureMax']:
    excluded.append({'sourceUrl':url,'title':t,'courseId':c['id'],'reason':'Beyond the selected mind and personal-identity segment of this course.'});match=False
   if match and c.get('evolutionSelection') and n and 20<=int(n.group(1))<=28:
    excluded.append({'sourceUrl':url,'title':t,'courseId':c['id'],'reason':'Ecology-specific segment outside this bounded evolution and behaviour selection.'});match=False
  else:
   match=url.startswith('https://compneuro.neuromatch.io/tutorials/') and '/student/' in url and url.endswith('.html') and not any(x in url for x in ['DaySummary','Outro','outro'])
  if match:links[url]=t
 c['discoveredPages']=len(links);course_records.append(c)
 queue.extend((c,u,t) for u,t in links.items())
 print(c['id'],len(links),flush=True)
(OUT/'course-register.json').write_text(json.dumps(course_records,indent=2)+'\n')
(OUT/'excluded-pages.json').write_text(json.dumps(excluded,indent=2)+'\n')
(OUT/'page-queue.json').write_text(json.dumps([{'courseId':c['id'],'url':u,'title':t} for c,u,t in queue],indent=2)+'\n')

def inspect(item):
 c,url,title=item;h,m=fetch(url);s=BeautifulSoup(h,'html.parser')
 if m['exitCode']!=0:return [],{'url':url,'error':m['error']}
 ids=list(dict.fromkeys(re.findall(r'(?:youtube(?:-nocookie)?\.com/(?:embed/|watch\?v=)|youtu\.be/)([A-Za-z0-9_-]{11})',h)))
 records=[]
 for i,vid in enumerate(ids):
  desc=s.select_one('.video-page > .description') if c['provider']=='mit-ocw' else s.select_one('.session-full__body') if c['provider']=='open-yale' else s.select_one('article.bd-article')
  if c['provider']=='neuromatch':
   # Notebook/widget text is source material, not an individually checked annotation.
   desc_text=' '.join(x.get_text(' ',strip=True) for x in s.select('article.bd-article > section > p')[:4])
  else:desc_text=desc.get_text(' ',strip=True) if desc else None
  media=[];transcripts=[]
  for v in s.find_all('video'):
   if vid in str(v):
    if v.get('data-downloadlink'):media.append(urljoin(url,v['data-downloadlink']))
    if v.get('data-transcriptlink'):transcripts.append(urljoin(url,v['data-transcriptlink']))
    for tr in v.find_all('track',src=True):transcripts.append(urljoin(url,tr['src']))
  page_title=title
  if c['provider']=='mit-ocw' and not c.get('seminar'):
   hh=s.select_one('h2.pb-1');page_title=hh.get_text(' ',strip=True) if hh else title
  if c['provider']=='open-yale':
   hh=s.select_one('.session-full__title');page_title=hh.get_text(' ',strip=True) if hh else title
   if s.find(id='transcript') or s.find(id='transcript-top') or 'Lecture Transcript' in h:transcripts.append(url+'#transcript')
  # Multiple clips need individual title inspection and must not be invented as separately named lectures.
  title_status='source_page_title' if len(ids)==1 else 'page_context_only_multiple_videos'
  records.append({'id':'youtube:'+vid,'title':page_title,'titleStatus':title_status,'canonicalUrl':'https://www.youtube.com/watch?v='+vid,'youtubeId':vid,'sourceUrl':url,'providerId':c['provider'],'speaker':None,'courseInstructor':c['speaker'],'parentCourse':c['id'],'parentCourseTitle':c['title'],'subjectFamilies':c['families'],'level':c['level'],'language':'en','languageEvidence':'English-language institutional course page; audio language not independently inspected','durationSeconds':None,'uploadDate':None,'recordingDate':None,'courseYear':c['year'],'recordingDateNote':'Course year is not asserted to be the exact recording date.','format':'tutorial' if c['provider']=='neuromatch' or c.get('seminar') else 'lecture','transcriptStatus':'linked' if transcripts else 'unknown','transcriptUrls':list(dict.fromkeys(transcripts)),'authorisedMediaAlternatives':list(dict.fromkeys(media)),'descriptionEvidence':{'type':'institutional_page','url':url,'retrievedAt':m['retrievedAt'],'sha256':m['sha256'],'excerptForPrivateAudit':(desc_text or '')[:1600],'inspection':'Page retrieved and fields extracted by agent-written adapter; no full-video viewing and no individual scientific assessment.'},'selectionBasis':'institutional_collection','selectionReason':'Part of the selected '+c['title']+' course or seminar collection; individual feature rationale not yet checked.','descriptionCheckStatus':'not_individually_checked','scientificAssessment':'Not assessed','availability':{'status':'unknown','method':'institutional_source_and_embedded_identifier_only','checkedAt':m['retrievedAt'],'playbackObserved':False},'qualificationStatus':'candidate','retrieval':m,'reuse':{'licence':'CC-BY-NC-SA-4.0' if c['provider']=='mit-ocw' else 'CC-BY-NC-SA-3.0' if c['provider']=='open-yale' else 'CC-BY-4.0','scope':'Institutional course material subject to source-specific and third-party exceptions; link by default. Private evidence excerpt is not an automatic public annotation.'}})
 return records,({'url':url,'reason':'No embedded video identifier found'} if not records else None)
allrecords=[];failures=[]
with ThreadPoolExecutor(max_workers=2) as pool:
 for ix,(records,error) in enumerate(pool.map(inspect,queue),1):
  allrecords+=records
  if error:failures.append(error)
  if ix%25==0:
   (OUT/'candidates.partial.json').write_text(json.dumps(allrecords,indent=2)+'\n');print('inspected',ix,'of',len(queue),'observations',len(allrecords),flush=True)
# Canonical IDs are deduplicated; retain all source/course contexts.
canonical={}
for record in allrecords:
 key=record['id']
 if key not in canonical:
  canonical[key]=record;record['additionalSourceContexts']=[]
 else:
  old=canonical[key];old['additionalSourceContexts'].append({'sourceUrl':record['sourceUrl'],'parentCourse':record['parentCourse'],'title':record['title']})
  old['authorisedMediaAlternatives']=list(dict.fromkeys(old['authorisedMediaAlternatives']+record['authorisedMediaAlternatives']))
  old['transcriptUrls']=list(dict.fromkeys(old['transcriptUrls']+record['transcriptUrls']))
  old['subjectFamilies']=list(dict.fromkeys(old['subjectFamilies']+record['subjectFamilies']))
rows=list(canonical.values())
(OUT/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'page-failures.json').write_text(json.dumps(failures,indent=2)+'\n')
(OUT/'candidate-youtube-ids.json').write_text(json.dumps([r['youtubeId'] for r in rows],indent=2)+'\n')
print(json.dumps({'queuedPages':len(queue),'sourceObservations':len(allrecords),'canonicalVideos':len(rows),'pagesWithoutVideosOrFailed':len(failures),'providers':len(set(r['providerId'] for r in rows))},indent=2),flush=True)
