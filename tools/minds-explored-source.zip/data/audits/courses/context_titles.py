#!/usr/bin/env python3
"""Recover official video section headings from cached Neuromatch widget graphs.

Only links explicitly present in each displayed widget's child output models are
associated with its preceding heading. No ordering-only ID/title pairing occurs.
"""
import json,re
from pathlib import Path
from collections import defaultdict
from bs4 import BeautifulSoup
from fetch import ROOT
OUT=ROOT/'data/audits/courses'
rows=json.loads((OUT/'candidates.json').read_text())
pages={r['sourceUrl']:r for r in rows if r['providerId']=='neuromatch'}
contexts=defaultdict(list)
pattern=r'(?:youtube(?:-nocookie)?\.com/(?:embed/|watch\?v=)|youtu\.be/)([A-Za-z0-9_-]{11})'
for url,row in pages.items():
    soup=BeautifulSoup((ROOT/row['retrieval']['cachePath']).read_text(),'html.parser')
    tag=soup.find('script',type='application/vnd.jupyter.widget-state+json')
    states=json.loads(tag.string or '{}').get('state',{}) if tag else {}
    def ids_in_model(model_id,seen=None):
        seen=set() if seen is None else seen
        if model_id in seen:return set()
        seen.add(model_id);state=states.get(model_id,{}).get('state',{})
        texts=[]
        for o in state.get('outputs',[]):
            texts.append(o.get('text',''))
            texts.append(o.get('data',{}).get('text/html',''))
        ids=set(re.findall(pattern,' '.join(texts)))
        for child in state.get('children',[]):
            if isinstance(child,str) and child.startswith('IPY_MODEL_'):
                ids.update(ids_in_model(child[len('IPY_MODEL_'):],seen))
        return ids
    for tag in soup.find_all('script',type='application/vnd.jupyter.widget-view+json'):
        ids=ids_in_model(json.loads(tag.string or '{}').get('model_id'))
        if not ids:continue
        heading=tag.find_previous(['h1','h2','h3','h4'])
        if not heading:continue
        title=heading.get_text(' ',strip=True).removesuffix(' #').strip()
        if not re.match(r'^Video\s+\d+:',title):continue
        section=heading.find_parent('section')
        section_id=section.get('id') if section else None
        paragraphs=[]
        if section:
            paragraphs=[p.get_text(' ',strip=True) for p in section.find_all('p',recursive=False)]
        for vid in sorted(ids):
            contexts[vid].append({'title':title,'sourceUrl':url,'sourceAnchor':section_id,'method':'Official section heading matched through displayed Jupyter widget child-model outputs to exact YouTube identifier.','retrievedAt':row['retrieval']['retrievedAt'],'sha256':row['retrieval']['sha256'],'sectionParagraphs':paragraphs[:4]})
out=dict(contexts)
(OUT/'video-title-contexts.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'exactWidgetSectionTitles':len(out),'nanoRecaps':sum(any('nano recap' in c['title'].lower() for c in v) for v in out.values())}))
