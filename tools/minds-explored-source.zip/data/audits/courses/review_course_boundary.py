#!/usr/bin/env python3
"""Recreate explicit editorial boundary decisions; does not edit frozen imports."""
from pathlib import Path
import collections, datetime, hashlib, json, re

ROOT = Path(__file__).resolve().parents[3]
AUDIT = ROOT / 'data/audits/courses'
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
candidate_path = AUDIT / 'candidates.json'
candidates = json.loads(candidate_path.read_text())
courses = {c['id']: c for c in json.loads((AUDIT / 'course-register.json').read_text())}

clusters = {
 'yale-social-theory': {
  'rationale': 'Retain selected historical explanations of social motivation, socialisation, authority, collective representations and socially patterned outcomes. Do not treat a whole sociology course as automatically in scope: constitutional design, general political history and labour-value theory are outside this mind-and-behaviour collection unless the inspected content supplies a direct behavioural route.',
  'limit': 'These are attributed historical theories, not contemporary empirical consensus. Freud and Durkheim materials are not present clinical guidance. The original full course remains available at Yale; the atlas collection is a selection.'},
 'yale-human-nature': {
  'rationale': 'The official course explicitly connects philosophy with cognitive science. Retain direct material on self-regulation, attachment, moral judgement, social influence and decision-making, plus bounded philosophical prerequisites to those units. A lecture concerned predominantly with normative property rights is excluded. Lecture 21 is retained after reading its classroom choice-under-risk exercise, not simply because it discusses Rawls.',
  'limit': 'Philosophical positions and older psychological examples remain attributed and unassessed. Normative arguments do not establish empirical findings, and classroom demonstrations do not establish population effects.'},
 'yale-death-mind': {
  'rationale': 'Keep the already bounded lectures 2–14 on mind/body theories, arguments concerning mental capacities, free will and personal identity. Lecture 1 is supporting course orientation. The subsequent value-of-death unit was never imported and is not added.',
  'limit': 'The material is philosophical argument, including critiques of dualism and historical arguments about souls. Inclusion does not assert that souls exist or treat a metaphysical argument as scientific evidence.'},
 'yale-game-theory': {
  'rationale': 'Keep this coherent 24-lecture introduction to strategic decision-making. Each inspected overview develops a transferable model of choices, beliefs, coordination, incentives, bargaining, cooperation or signalling, even when the example comes from firms or auctions. This is a selected methods course, not a general economics import.',
  'limit': 'Formal rational-agent predictions require their assumptions and are not automatically descriptive of actual people. The provider flags a notation error in lecture 11 and supplies supplemental notes.'},
 'mit-statistics-2016': {
  'rationale': 'Keep the 22 available lectures as a bounded mathematical-methods course. The inspected official syllabus maps the lecture sequence to inference, estimation, testing, regression, Bayesian statistics, PCA and generalised linear models, and expressly includes method assumptions and limitations. These are foundations for analysing behavioural and neural data.',
  'limit': 'Most individual video pages contain titles but no substantive description; this is a course-boundary judgement supported by the actual syllabus, not 22 new individual description checks. Probability and linear algebra prerequisites apply. Lecture 1 is from 2017; the remainder are labelled 2016.'},
 'mit-probability-2010': {
  'rationale': 'Keep the 25-lecture sequence as a bounded foundation for uncertainty, statistical reasoning and computational models. Individual institutional descriptions cover random variables, dependence, stochastic processes, limit theorems and inference. Counting and queueing examples teach those methods rather than opening a general engineering collection.',
  'limit': 'The course assumes college calculus; beginner probability does not mean beginner mathematics. The official description notes that the first few minutes of lecture 21 are missing.'}
}

# These reasons are authored after inspecting the cached institutional overviews.
social = {
 1: ('supporting', 'Course orientation and biographies of the selected thinkers; retain as supporting context rather than a separately qualified substantive resource.'),
 2: ('retain', 'Historical model of self-interest, security, cooperation and social order; the overview explicitly connects Hobbes to rational-choice explanation.'),
 3: ('exclude', 'The inspected overview centres on property, consent and separation of governmental powers. Its general political theory is outside the selected behavioural route.'),
 4: ('exclude', 'The inspected overview centres on division of governmental powers and constitutional organisation; a brief environmental claim does not make this a substantive behavioural resource.'),
 5: ('exclude', 'The inspected overview centres on popular sovereignty, legislative legitimacy and Rousseau biography; this constitutional-political material is outside the selected behavioural route.'),
 6: ('retain', 'The overview connects social self-regard and collective obligations with Rousseau’s theory of education and learning how to think.'),
 7: ('retain', 'The overview examines sympathy, self-interest and utilitarian accounts of motivation as historical ideas relevant to social and moral judgement.'),
 8: ('exclude', 'Publisher-internal mismatch: page title names Smith and the invisible hand, while its overview, transcript opening and chapter sequence concern Mill, happiness, liberty and women, followed by exam review. Hold outside qualification until the official video and description are matched; do not guess a replacement title.'),
 9: ('retain', 'Historical account of alienation as arising from material and social conditions, relevant to relationships between experience and social organisation.'),
 10: ('retain', 'The overview and inspected opening/chapter structure revisit alienation, agency and lack of control under apparently free choice before introducing historical materialism.'),
 11: ('retain', 'The overview explicitly addresses how experience and activity relate to knowledge and how material conditions are claimed to shape consciousness; retain as attributed historical theory.'),
 12: ('exclude', 'The inspected overview is primarily a history of property relations and transitions among economic modes of production. It does not provide a sufficiently direct mind-or-behaviour route for this collection.'),
 13: ('exclude', 'The overview and inspected chapter structure focus on labour theory of value, surplus value, commodity production and class formation. This general political-economy treatment is outside the bounded behavioural collection.'),
 14: ('retain', 'Genealogical analysis of moral ideas and critical scrutiny of consciousness and assumptions; relevant historical background for moral and social thought.'),
 15: ('retain', 'Explicit historical account of Freud’s motivational and psychoanalytic ideas and their extension to civilisation. Retain with historical, unassessed and non-clinical limits.'),
 16: ('retain', 'Historical explanation connecting religious beliefs, individual motives and patterns of work and social organisation.'),
 17: ('retain', 'Introduces how leaders seek legitimacy and how authority shapes social relations; a direct conceptual route into social influence.'),
 18: ('retain', 'Explains tradition, personal loyalty and hierarchical social relations as historical authority mechanisms.'),
 19: ('retain', 'Explains followers’ beliefs, changes in values and succession problems in charismatic authority; directly relevant to social influence.'),
 20: ('retain', 'Examines how organisational rules and roles constrain behaviour in bureaucracies, as an attributed sociological model.'),
 21: ('retain', 'Contrasts status and class as explanations of life chances and social position; retained as historical context for social structure and behaviour.'),
 22: ('retain', 'Explains collective conscience and forms of social solidarity, with explicit attention to what holds groups together.'),
 23: ('retain', 'Historical account of regulation, anomie and social consequences of changing social relations, not a current diagnostic framework.'),
 24: ('retain', 'Historical investigation of socially patterned suicide and multivariate reasoning; do not present its historical associations as current causal or clinical guidance.'),
 25: ('retain', 'Historical methodological account of collective representations and the identification of social facts.'),
}
human = {
 1:'Interdisciplinary introduction with examples connecting human nature, psychology and philosophical questions.',
 2:'Connects moral reputation and fairness with philosophical thought experiments and an attributed behavioural experiment.',
 3:'Compares historical and psychological models of divisions within the person.',
 4:'Discusses sampling bias, dual processing, belief bias and decision heuristics.',
 5:'Relates philosophical accounts of flourishing to psychological research on goals and adaptation.',
 6:'Examines conflict between commitments and experience through habituation and historical trauma narratives; not present treatment guidance.',
 7:'Directly discusses obedience, social proximity and attachment evidence.',
 8:'Historical philosophical strategies for interpreting and regulating desires and attitudes; not a claim of current therapeutic efficacy.',
 9:'Connects habit formation with conditioning and self-regulation.',
 10:'Connects virtue, flow and situationist challenges to stable character.',
 11:'Connects delayed gratification, discounting and procrastination with self-regulation.',
 12:'A bounded conceptual prerequisite to subsequent moral-judgement tasks: distinguishes the normative theory that those tasks probe.',
 13:'A bounded conceptual prerequisite to the trolley and punishment units: distinguishes intentions from outcome-based moral evaluation.',
 14:'Introduces conflicting moral intuitions through the trolley task and competing interpretations.',
 15:'Compares empirical and other methodological responses to moral-judgement puzzles.',
 16:'Connects risk heuristics, moral luck and responsibility judgements.',
 17:'Introduces justifications and intuitions concerning punishment, setting up the subsequent empirical discussion.',
 18:'Includes empirical research on punishment intuitions and moral outrage.',
 19:'Connects parenting and rehabilitation research with cooperation and social-order arguments; retained for that behavioural bridge.',
 20:'Direct examination of collective-choice problems and cooperation.',
 21:'Retain after reading the Testing Rawls classroom exercise: compares choices under uncertainty across course, housing and hospital scenarios, making risk attitudes and framing explicit. The broader Rawls discussion remains normative philosophy, and the classroom poll is not population evidence.',
 22:'The overview and chapter headings centre on property rights, holdings, the Lockean proviso and redistribution. This predominantly normative political-philosophy lecture is outside the bounded mind-and-behaviour route.',
 23:'Direct discussion of cultural context, social structure and the limits of WEIRD psychological samples.',
 24:'Examines non-rational persuasion, fiction and regulation of emotional responses, with the censorship argument attributed to Plato.',
 25:'Discusses willingness-to-pay/accept and heuristic reasoning before a political-philosophy synthesis.',
 26:'Substantive synthesis of the course’s interdisciplinary explanations of human behaviour and the relationship between individuals and society.'
}

def receipt(m, inspection):
 p = ROOT / m['cachePath']
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == m['sha256'], m['url']
 return {'id':'source:'+hashlib.sha256(m['url'].encode()).hexdigest()[:16], 'url':m['url'], 'retrievedAt':m['retrievedAt'], 'sha256':m['sha256'], 'cachePath':m['cachePath'], 'inspection':inspection}

def cached_receipt(url, inspection):
 p = ROOT / 'data/raw/courses' / (hashlib.sha256(url.encode()).hexdigest()+'.json')
 m=json.loads(p.read_text()); assert m['exitCode']==0
 return receipt(m,inspection)

extra = {
 'mit-statistics-2016': cached_receipt('https://ocw.mit.edu/courses/18-650-statistics-for-applications-fall-2016/pages/syllabus/', 'Read complete course description, topic sequence and prerequisites; mathematical-methods scope judgement, not individual transcript review.'),
 'mit-probability-2010': cached_receipt('https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/pages/syllabus/', 'Read course goals, lecture/recitation/tutorial roles and calculus prerequisite; individual lecture descriptions inspected separately.')
}
records={}
for x in candidates:
 c=x['parentCourse']
 if c not in clusters: continue
 n=int(re.search(r'Lecture (\d+)',x['title'])[1])
 action='retain'
 if c=='yale-social-theory': action,reason=social[n]
 elif c=='yale-human-nature': reason=human[n]; action='exclude' if n==22 else 'retain'
 elif c=='yale-death-mind':
  action='supporting' if n==1 else 'retain'
  reason=('Orientation to the full course, including a later value-theory unit outside the selected set; supporting context rather than separately qualified substance.' if n==1 else 'The inspected official overview directly addresses mind/body metaphysics, mental capacities, free will or personal identity within the already bounded first-half selection.')
 elif c=='yale-game-theory': reason='The inspected individual overview develops strategic decision-making concepts in the coherent course progression. Economic or political examples illustrate those models; retention does not imply descriptive validity of rational-agent assumptions.'
 elif c=='mit-statistics-2016': reason='Course-level methods foundation: the inspected syllabus locates this named lecture in the inference, estimation, regression or multivariate-statistics sequence. Most individual video pages lack descriptions, so no new individual description-check status is claimed.'
 else: reason='The inspected institutional lecture description places this item in the probability, stochastic-process or inference sequence needed for quantitative models. Applied examples do not change that bounded methods purpose.'
 inspection='Read official individual lecture overview for scope; no viewing or full-transcript reading.'
 if c=='mit-statistics-2016': inspection='Checked official resource title and available description/note against the substantive course syllabus; individual content beyond that was not inspected.'
 if c=='yale-social-theory' and n==8: inspection='Read official title, full overview, chapter headings and transcript opening/selected paragraphs; detected publisher-internal Smith/Mill mismatch. No video viewing.'
 if c=='yale-social-theory' and n in (10,13): inspection='Read official overview, transcript chapter headings and opening/selected paragraphs for boundary clarification; no full transcript or video viewing.'
 if c=='yale-human-nature' and n==21: inspection='Read overview, chapter headings and the Testing Rawls classroom-exercise passage covering decisions across course, housing and hospital scenarios; no full transcript or video viewing.'
 if c=='yale-human-nature' and n==22: inspection='Read overview, chapter headings and transcript opening; no full transcript or video viewing.'
 sources=[receipt(x['retrieval'],inspection), receipt(courses[c]['sourceCheck'],'Read official course purpose and structure; used to bound the selected collection.')]
 if c in extra:sources.append(extra[c])
 records[x['id']]={'action':action,'reason':reason,'checkedAt':now,'checker':'agent','clusterId':c,'checkSources':sources}

out={'checkedAt':now,'checker':'agent','purpose':'Source-grounded topical boundary review; not an accessibility recheck, scientific assessment or new checked-core audit.',
 'input':{'path':'data/audits/courses/candidates.json','sha256':hashlib.sha256(candidate_path.read_bytes()).hexdigest()},
 'method':'Read cached official course descriptions and individual Yale/probability overviews. For statistics, read its substantive official syllabus and reconcile named lectures; most individual video pages have no description. Selected transcript passages were read only where explicitly recorded. No YouTube scraping or video viewing.',
 'policy':'Retain does not upgrade description-check or access status. Supporting and excluded records remain outside qualified-video totals. Original candidate receipts are unchanged.',
 'clusters':clusters,'counts':dict(collections.Counter(x['action'] for x in records.values())), 'records':records}
(AUDIT/'record-decisions.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'records':len(records),'counts':out['counts'],'checkedAt':now}))
