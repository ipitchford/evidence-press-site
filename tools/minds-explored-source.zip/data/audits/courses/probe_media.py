#!/usr/bin/env python3
"""Bounded, cached 32-byte checks of alternatives linked by official MIT pages.

No full video is fetched; HTTP 206 plus MP4 ftyp establishes a reachable media
endpoint, not successful playback, full-file integrity, or global availability.
"""
import json,hashlib,subprocess,datetime,re,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from fetch import ROOT
OUT=ROOT/'data/audits/courses';RAW=ROOT/'data/raw/courses'
rows=json.loads((OUT/'candidates.json').read_text())
queue=list(dict.fromkeys(u for r in rows for u in r['authorisedMediaAlternatives']))
assert len(queue)<=150, 'Reaudit scope before increasing the bounded media probe.'
def probe(url):
    host=urlparse(url).hostname or ''
    assert host=='ocw.mit.edu' or host in ('archive.org','www.archive.org') or host.endswith('.us.archive.org')
    request_url=url.replace('http://www.archive.org/','https://archive.org/').replace('http://ia','https://ia')
    key='media-'+hashlib.sha256(url.encode()).hexdigest()
    body=RAW/(key+'.bin');head=RAW/(key+'.headers');meta=RAW/(key+'.json')
    if meta.exists():return json.loads(meta.read_text())
    time.sleep(.3)
    p=subprocess.run(['curl','-L','--fail','--silent','--show-error','--max-time','25','--range','0-31','--max-filesize','64','-D',str(head),request_url,'-o',str(body)],capture_output=True)
    data=body.read_bytes() if body.exists() else b''
    headers=head.read_text(errors='replace') if head.exists() else ''
    statuses=re.findall(r'^HTTP/\S+\s+(\d+)',headers,re.M)
    ranges=re.findall(r'^content-range:\s*(.+)',headers,re.M|re.I)
    types=re.findall(r'^content-type:\s*(.+)',headers,re.M|re.I)
    ok=p.returncode==0 and statuses[-1:] == ['206'] and len(data)==32 and data[4:8]==b'ftyp'
    result={'url':url,'requestUrl':request_url,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'HTTP GET Range bytes=0-31; 64-byte transfer ceiling; no full media download','exitCode':p.returncode,'httpStatus':int(statuses[-1]) if statuses else None,'contentRange':ranges[-1].strip() if ranges else None,'contentType':types[-1].strip() if types else None,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'bodyCachePath':str(body.relative_to(ROOT)) if body.exists() else None,'headerCachePath':str(head.relative_to(ROOT)),'mediaEndpointAccessible':ok,'playbackObserved':False,'error':p.stderr.decode(errors='replace')[:800] or None}
    meta.write_text(json.dumps(result,indent=2)+'\n');return result
results=[]
with ThreadPoolExecutor(max_workers=2) as pool:
    for i,result in enumerate(pool.map(probe,queue),1):
        results.append(result)
        if i%10==0:print(i,'of',len(queue),'checked',flush=True)
(OUT/'media-probes.json').write_text(json.dumps(results,indent=2)+'\n')
byurl={r['url']:r for r in results}
for row in rows:
    row['mediaEndpointChecks']=[byurl[u] for u in row['authorisedMediaAlternatives']]
    usable=next((x for x in row['mediaEndpointChecks'] if x['mediaEndpointAccessible']),None)
    if usable:
        row['availability']={'status':'accessible_alternative_endpoint','method':usable['method'],'checkedAt':usable['checkedAt'],'url':usable.get('requestUrl',usable['url']),'playbackObserved':False,'limitation':'32-byte MP4 endpoint check only; no playback, decoding or full-file validation; source embedding may differ.'}
        row['qualificationStatus']='access_evidence_present_editorial_check_pending'
(OUT/'candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'checkedURLs':len(results),'accessibleMediaEndpoints':sum(r['mediaEndpointAccessible'] for r in results),'playbackObserved':0}),flush=True)
