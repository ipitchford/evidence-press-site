import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadData} from '../../../scripts/data.mjs';
import {validate} from '../../../scripts/validate.mjs';
import {isQualified} from '../../../src/model.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const audit=path.join(root,'data/audits/providers');
const data=await loadData();
const manifest=JSON.parse(await fs.readFile(path.join(audit,'editorial-delivery.json'),'utf8'));
const guideSlugs=new Set(manifest.guides.map(x=>x.slug));
const pathSlugs=new Set(manifest.paths.map(x=>x.slug));
const guides=data.guides.filter(g=>guideSlugs.has(g.slug));
const paths=data.paths.filter(p=>pathSlugs.has(p.slug));
const records=new Map(data.records.map(r=>[r.id,r]));
const result=await validate({...data,guides,paths});
const startingResources=guides.map(g=>{
 const r=records.get(g.startingResourceId);
 return {guide:g.slug,id:g.startingResourceId,present:!!r,qualified:r?isQualified(r):false,availability:r?.availability?.status,method:r?.availability?.method,checkedAt:r?.availability?.checkedAt,playbackObserved:r?.availability?.playbackObserved};
});
const ids=new Set([...guides.flatMap(g=>[g.startingResourceId,...g.resources.map(x=>x.id)]),...paths.flatMap(p=>p.steps.map(s=>s.resourceId))]);
const unqualified=[...ids].filter(id=>!records.has(id)||!isQualified(records.get(id))).map(id=>({id,present:records.has(id),reason:records.get(id)?.qualification?.reason}));
const out={checkedAt:new Date().toISOString(),structuralErrors:result.errors,warnings:result.warnings,guideCount:guides.length,pathCount:paths.length,startingResources,referencedDistinctVideos:ids.size,unqualified,scope:'Own guides and paths validated against the current complete schema/catalogue/API overlay. Source inspection is separate from metadata accessibility and playback. No global release-target assertion.'};
await fs.writeFile(path.join(audit,'editorial-effective-validation.json'),JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({checkedAt:out.checkedAt,structuralErrors:out.structuralErrors,warnings:out.warnings,guideCount:out.guideCount,pathCount:out.pathCount,referencedDistinctVideos:out.referencedDistinctVideos,unqualified:out.unqualified},null,2));
if(result.errors.length)process.exitCode=1;
