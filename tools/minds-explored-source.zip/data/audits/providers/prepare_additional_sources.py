#!/usr/bin/env python3
"""Offline assembly of additional official-page candidates; availability stays unverified."""
from pathlib import Path
import json,re,datetime
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'data/audits/providers'
rows=json.loads((OUT/'retrievals.json').read_text());byurl={r['url']:r for r in rows}
def links(r):return json.loads((ROOT/r['linksPath']).read_text()) if r.get('linksPath') else []
def txt(r):return (ROOT/r['textPath']).read_text() if r.get('textPath') else ''
def ev(r,note):return {'url':r['url'],'retrievedAt':r['retrievedAt'],'httpStatus':r['httpStatus'],'sha256':r['sha256'],'rawPath':r['rawPath'],'inspectedMaterial':note}
def youtube_ids(r):
 out=[]
 for x in r.get('embeds',[]):
  m=re.search(r'/embed/([\w-]{11})',x or '')
  if m:out.append(m[1])
 s=BeautifulSoup((ROOT/r['rawPath']).read_bytes(),'html.parser')
 for x in s.select('script[type="application/ld+json"]'):
  out.extend(re.findall(r'embedUrl.{0,6}https://www.youtube.com/embed/([\w-]{11})',x.get_text()))
 return list(dict.fromkeys(out))
out=[]
def make(vid,r,title,speaker,course,topics,description,recording=None,duration=None,level='intermediate',note='Official description or session abstract inspected; destination awaits authorised API validation.'):
 item={'id':'youtube:'+vid,'title':title,'sourceUrl':r['url'],'canonicalUrl':'https://www.youtube.com/watch?v='+vid,'providerId':r['providerId'],'speaker':speaker,'parentCourse':course,'subjectFamilies':topics,'level':level,'levelBasis':'Editorial inference from described scope.','language':None,'durationSeconds':duration,'durationBasis':'Official item metadata, not independently timed.' if duration else None,'uploadDate':None,'recordingDate':recording,'transcriptStatus':'unknown','descriptionEvidence':[ev(r,note)],'originalSynopsis':description,'selectionBasis':'publisher-description','selectionReason':description,'scientificAssessment':'Not assessed','editorialRole':'substantial','availability':{'status':'official-source-and-destination-seen','checkedAt':r['retrievedAt'],'method':'Official institutional page only','playbackObserved':False,'youtubeRequested':False},'qualificationStatus':'pending-authorised-API-validation','releaseEligible':False,'sourceLicenceNotes':'Link-only; no blanket reuse licence established. Raw cache remains private.'};out.append(item);return item

wsumeta={
'MfV5GReJOas':('Power Laws, Scale Invariance, and Diversity','Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative','methods'],'Introduces proportional and non-proportional changes in biological scaling.'),
'9g6CzEMeDbk':('Constraints and Diversity','Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative','neuroscience'],'Presents physical and metabolic constraints as possible explanations of biological scaling.'),
'TdYQTCm6nFo':('Brain Soup: The Isotropic Fractionator','Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative','methods'],'A course segment on a method for comparing the cellular composition of brains; detailed annotation pending summary inspection.'),
'VVIAcQ9xtPM':('Multiple Ways of Making a Cortex','Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative','neuroscience'],'A course segment on comparative cortical organisation; detailed annotation pending summary inspection.'),
'vDKFDuVTodQ':('Implications for Humans and Future Research','Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative','neuroscience'],'The concluding comparative-brain course segment; detailed annotation pending summary inspection.'),
'vtyhYf-3IjY':('Bias and Intention','Alfred Mele','Free Will and Neuroscience',['consciousness-philosophy','reasoning-decisions'],'Examines whether signals preceding reported choices establish a settled decision or a bias toward an action.'),
'38tnoeU8b1Q':('Decision-Making in the Real World','Alfred Mele','Free Will and Neuroscience',['consciousness-philosophy','reasoning-decisions'],'Questions how far arbitrary button-press tasks generalise to choices made after deliberation.'),
'sUYZzQHspbA':('Integrated Information Theory','Christof Koch','The Biology of Consciousness',['consciousness-philosophy','neuroscience'],'Presents integrated information theory as Koch’s proposed account, with implications for animal and machine consciousness.')}
for r in rows:
 if r['providerId']=='world-science-u' and r.get('role')=='editorial-item':
  for vid in youtube_ids(r):
   title,speaker,course,topics,desc=wsumeta[vid];m=re.search(r'This lecture was (?:recorded|filmed) on ([A-Za-z]+ \d+, \d{4})',txt(r));date=datetime.datetime.strptime(m[1],'%B %d, %Y').date().isoformat() if m else None
   make(vid,r,title,speaker,course,topics,desc,date,note='Official lesson and parent course establish identity. Detailed source check, when completed, is in the separate core-overrides file.')

cartameta={
'6vU_22bGrXM':('Love, monogamy, and fatherhood in Latin American monkeys','Eduardo Fernandez-Duque','The Origin of Love',['evolution-comparative','social-cultural'],'Uses long-term field research on titi and owl monkeys to examine competing explanations of pair bonds and paternal care.','2025-02-14'),
'kQpojCIGGaY':('The biology of hatred: Why love turns to hatred and what we can do about it','Ruth Feldman','The Origin of Love',['social-cultural','emotion-motivation-sleep'],'Presents Feldman’s model linking social synchrony and group attachment, alongside her team’s intergroup intervention research. It is an attributed research account, not an established universal mechanism.','2025-02-14'),
'EQR4Svzdatg':('The biology of fatherhood in humans: Evolutionary origins and cross-cultural perspectives','Lee Gettler','The Origin of Love',['social-cultural','evolution-comparative'],'Examines how hormonal changes associated with fatherhood vary with ecological conditions, culture and family roles.','2025-02-14'),
'BHQ0dTNKjyE':('Delayed neuronal maturation in humans','Carol Marchetto','Comparative Anthropogeny and Other Approaches to Human Origins',['evolution-comparative','development','neuroscience'],'Examines molecular hypotheses about prolonged neuronal maturation in humans and explicitly unresolved regulatory mechanisms.','2023-11-03'),
'y1iB6E96tBo':('Digging with documents: Ethnology as a tool for understanding human evolution','Mark Collard','Comparative Anthropogeny and Other Approaches to Human Origins',['evolution-comparative','social-cultural','methods'],'Argues for cross-cultural comparisons as one tool for interpreting archaeological patterns.','2023-11-03'),
'M0fCKp5_Yss':('Social complexity: Why modern humans are more like certain ants than chimpanzees','Mark Moffett','Comparative Anthropogeny and Other Approaches to Human Origins',['evolution-comparative','social-cultural'],'Uses ant-human comparisons to examine group identity, coordination and organisation. Similarities are the speaker’s comparative argument, not a claim of identical minds.','2023-11-03')}
for r in rows:
 if r['providerId']=='carta-ucsd' and r.get('role')=='editorial-media-wrapper':
  session=byurl[r['sourceSession']]
  for vid in youtube_ids(r):
   title,speaker,course,topics,desc,date=cartameta[vid];item=make(vid,session,title,speaker,course,topics,desc,date);item['descriptionEvidence'].append(ev(r,'Official session-linked media wrapper establishes the exact embedded video ID.'))

for r in rows:
 if r['providerId']=='world-science-festival' and '/videos/' in r['url']:
  vids=youtube_ids(r)
  for vid in vids:
   if vid=='W5kikQ2tjhQ':title='My Neurons, My Self';speaker='Bill Blakemore; Martha Farah; Joy Hirsch; Jesse Prinz; Daphna Shohamy';desc='A multidisciplinary discussion of self-awareness, memory, emotion and what brain measurements can reveal about the self.'
   elif vid=='06-iq-0yJNM':title='What Creates Consciousness?';speaker='Brian Greene; David Chalmers; Anil Seth';desc='A science-and-philosophy conversation about explaining experience and the possibility of consciousness in artificial systems.'
   elif vid=='TXlfCY4m9jU':title='Can Theories of Consciousness Supercharge AI?';speaker='Brian Greene; Rufin VanRullen';desc='Rufin VanRullen discusses an artificial-intelligence architecture inspired by Global Workspace Theory. This is an attributed proposal about applying a consciousness theory, not evidence that an AI has conscious experience.'
   else:continue
   t=txt(r);m=re.search(r'Video Duration: (\d+):(\d+):(\d+)',t);duration=sum(int(x)*k for x,k in zip(m.groups(),[3600,60,1])) if m else None;date=None;m=re.search(r'Original Program Date: (?:\w+, )?([A-Za-z]+ \d+, \d{4})',t)
   if m:date=datetime.datetime.strptime(m[1],'%B %d, %Y').date().isoformat()
   item=make(vid,r,title,speaker,'World Science Festival Big Ideas',['consciousness-philosophy','neuroscience'],desc,date,duration);item['providerParent']='World Science Foundation; same institutional family as World Science U'
   if vid=='TXlfCY4m9jU':item['subjectFamilies']=['consciousness-philosophy','computation-ai'];item['tags']=['global workspace theory','Rufin VanRullen','consciousness theories','artificial intelligence']

# University additions: exact official links, no invented upload dates or approximate durations.
universityspec=[
('cambridge','1VOKsWWLgjk','https://www.mrc-cbu.cam.ac.uk/people/rik.henson/mytalks/','fMRI Connectivity','Rik Henson','CBU COGNESTIC summer school',['methods','neuroscience'],'An official CBU training lecture on functional and effective connectivity measured with fMRI.','2022-09'),
('cambridge','6b35VvQpPDU','https://www.mrc-cbu.cam.ac.uk/people/rik.henson/mytalks/','M/EEG Connectivity','Rik Henson','CBU COGNESTIC summer school',['methods','neuroscience'],'An official CBU training lecture on functional and effective connectivity from M/EEG; the publisher explicitly excludes dynamic causal modelling.','2022-09'),
('cambridge','kTVtc7kjVQg','https://www.mrc-cbu.cam.ac.uk/people/rik.henson/mytalks/','Open (Cognitive Neuro)science','Rik Henson','CBU COGNESTIC summer school',['methods'],'An extended CBU summer-school lecture on open cognitive neuroscience. The source supplies setting and approximate length, not a detailed contents list.',None),
('bristol','J9cVSnCVzbk','https://www.bristol.ac.uk/alumni/events/digital-event-recordings/','The Science of Sleep','Matt Jones','Bristol alumni research lectures',['emotion-motivation-sleep','neuroscience'],'Bristol Neuroscience’s director discusses his sleep research and brain activity during sleep.',None),
('bristol','Rww_7hw_vA4','https://www.bristol.ac.uk/alumni/events/digital-event-recordings/','Professor Bruce Hood on dealing with adversity','Bruce Hood','Bristol alumni research lectures',['emotion-motivation-sleep','mental-health'],'A developmental psychologist discusses wellbeing during adversity. Educational scope only; the atlas has not assessed any suggested interventions.',None),
('boston-university','7bHyhugtL4s','https://www.bu.edu/cbr/2023/11/20/cbr-seminar-series-matthias-stangl/','Cognitive Neuroscience and Neuromodulation: From the Laboratory into the Real World','Matthias Stangl','Center for Brain Recovery Seminar Series',['methods','neuroscience','perception-action'],'Examines mobile neuroimaging during natural movement and its potential to improve ecological validity and neuromodulation research.','2023-11-20')]
for pid,vid,u,title,speaker,course,topics,desc,date in universityspec:
 r=byurl[u];assert r['httpStatus']=='200' and vid in (ROOT/r['rawPath']).read_text();item=make(vid,r,title,speaker,course,topics,desc,date);item['recordingDatePrecision']='month' if date and len(date)==7 else ('day' if date else None)

register=[]
laburl='https://culture-emotion-lab.stanford.edu/press/media-archive'
labr=byurl[laburl]
for vid,title,speaker in [('T46EZ8LH8Ss','How Are Emotions Culturally Shaped?','Jeanne Tsai'),('LX-1neOc8D4','Ideal Affect and Health-Related Decision-Making','Tamara Sims; Jeanne Tsai'),('RQaEaUwNoiw','Culture and Emotion: A Brief Introduction','Jeanne Tsai')]:
 assert vid in (ROOT/labr['rawPath']).read_text()
 item=make(vid,labr,title,speaker,'Culture and Emotion Lab Media Archive',['social-cultural','emotion-motivation-sleep'],None,note='Official media archive supplies exact title, speaker attribution and video link only. This is a discovery lead, not a checked description.')
 item['selectionBasis']='institutional-collection';item['selectionReason']='Official lab-linked talk relevant to the approved culture/emotion guide; detailed video-description check awaits authorised metadata.';item['editorialRole']='candidate-depth-unchecked';item['level']=None;item['levelBasis']=None;item['providerParent']='Stanford University; not an additional independent university provider.'
 if vid in ('T46EZ8LH8Ss','LX-1neOc8D4'):
  item['editorialRole']='substantial'
  item['originalSynopsis']='A presentation by '+speaker.replace(';',' and')+' linked from the Culture and Emotion Lab’s official media archive. The archive identifies the topic but supplies no detailed abstract.'
  item['selectionReason']='The institutional archive establishes exact identity; the inspected laboratory research page and Noba Culture and Emotion reading support the guide’s conceptual context. Authorised metadata was separately inspected to establish substantive interview/presentation scope, with no API wording exported.'
  item['substanceAuditReceipt']='data/audits/providers/stanford-private-api-inspection.json'
  item['descriptionDepth']='Official title/speaker/context only; no checked detailed-description or core status claimed.'
for pid,name,u,owner,notes in [
('cambridge','University of Cambridge — MRC Cognition and Brain Sciences Unit','https://www.mrc-cbu.cam.ac.uk/people/rik.henson/mytalks/','University of Cambridge','Official researcher collection identifies the CBU course setting, topics and approximate lengths. Approximate lengths are not imported as exact durations.'),
('bristol','University of Bristol','https://www.bristol.ac.uk/alumni/events/digital-event-recordings/','University of Bristol','Selected neuroscience and psychology talks only; other alumni science topics are out of scope.'),
('boston-university','Boston University — Center for Brain Recovery','https://www.bu.edu/cbr/2023/11/20/cbr-seminar-series-matthias-stangl/','Boston University','Full seminar abstract, speaker bio, date and exact embedded recording available.'),
('world-science-festival','World Science Festival','https://www.worldsciencefestival.com/videos/my-neurons-my-self/','World Science Foundation','Same institutional parent as World Science U; do not inflate independent-provider count.'),
('stanford-culture-emotion','Stanford Culture and Emotion Lab',laburl,'Stanford University','Same university already represented elsewhere; these lab links do not add an independent provider. Two substantive recordings have separate private authorised-metadata scope checks; the official archive supplies identity, not a detailed abstract or checked-core description.')]:
 r=byurl[u];register.append({'providerId':pid,'name':name,'owner':owner,'officialPrimaryPageRetrieved':True,'status':'official-source-verified-awaiting-authorised-video-check','verificationNote':notes,'sourceUrl':u,'inspectedSourceEvidence':[ev(r,notes)],'reuseConditions':'Link-only; no blanket open licence established.','sharedParentNote':'Same institution as World Science U.' if pid=='world-science-festival' else ('Same Stanford University already represented.' if pid=='stanford-culture-emotion' else None)})
(OUT/'additional-candidate-observations.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
(OUT/'additional-source-register.json').write_text(json.dumps(register,indent=2,ensure_ascii=False)+'\n')
(OUT/'additional-api-ids.json').write_text(json.dumps([x['id'].split(':',1)[1] for x in out],indent=2)+'\n')
print({'additionalCandidates':len(out),'additionalUniversityProviders':3,'apiIds':[x['id'] for x in out]})
