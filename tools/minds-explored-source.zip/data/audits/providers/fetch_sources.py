#!/usr/bin/env python3
"""Bounded public-page audit fetcher. Cached raw pages are private evidence, not a public export."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,hashlib,json,datetime,sys
from bs4 import BeautifulSoup
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[3]
RAW=ROOT/'data/raw/providers';RAW.mkdir(parents=True,exist_ok=True)
INDEX=ROOT/'data/audits/providers/retrievals.json'
old=json.loads(INDEX.read_text()) if INDEX.exists() else []
known={r['requestedUrl']:r for r in old}
items=json.loads(Path(sys.argv[1]).read_text())
def fetch(item):
 url=item['url']
 if url in known:return known[url]
 host=(urlparse(url).hostname or '').lower()
 if host=='youtu.be' or host=='youtube.com' or host.endswith('.youtube.com') or host=='youtube-nocookie.com' or host.endswith('.youtube-nocookie.com'):
  raise RuntimeError('YouTube automated retrieval is not an approved ingestion route. Use an authorised API or institutional media alternative. Previously cached audit evidence may be analysed.')
 key=hashlib.sha256(url.encode()).hexdigest()[:20]
 p=RAW/(key+'.html');h=RAW/(key+'.headers')
 t=datetime.datetime.now(datetime.timezone.utc).isoformat()
 cmd=['curl','-L','--silent','--show-error','--max-time','30','--max-filesize','5000000','-D',str(h),'-o',str(p),'-w','%{http_code}\n%{url_effective}\n%{content_type}',url]
 proc=subprocess.run(cmd,capture_output=True,text=True)
 meta=proc.stdout.splitlines();body=p.read_bytes() if p.exists() else b''
 r={**item,'requestedUrl':url,'retrievedAt':t,'httpStatus':meta[0] if meta else None,'effectiveUrl':meta[1] if len(meta)>1 else None,'contentType':meta[2] if len(meta)>2 else None,'exitCode':proc.returncode,'error':proc.stderr[:1000],'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'rawPath':str(p.relative_to(ROOT)),'redistribution':'private source cache; not licensed for public redistribution by this receipt'}
 if body and 'html' in (r['contentType'] or ''):
  soup=BeautifulSoup(body,'html.parser')
  r['title']=soup.title.get_text(' ',strip=True) if soup.title else None
  links=[{'text':a.get_text(' ',strip=True),'href':a.get('href')} for a in soup.find_all('a',href=True)]
  (RAW/(key+'.links.json')).write_text(json.dumps(links,indent=2))
  r['embeds']=[x.get('src') or x.get('data-src') for x in soup.find_all(['iframe','video','source'])]
  for x in soup(['script','style','nav','header','footer']):x.decompose()
  text=soup.get_text('\n',strip=True)
  (RAW/(key+'.txt')).write_text(text)
  r['textPath']=str((RAW/(key+'.txt')).relative_to(ROOT));r['linksPath']=str((RAW/(key+'.links.json')).relative_to(ROOT))
 return r
# Single worker: conservative per-domain/public-server request load.
results=[]
for item in items:
 r=fetch(item);known[r['requestedUrl']]=r;results.append(r)
 INDEX.write_text(json.dumps(list(known.values()),indent=2)+'\n')
 print(json.dumps({k:r.get(k) for k in ['providerId','httpStatus','title','bytes','error']}),flush=True)
