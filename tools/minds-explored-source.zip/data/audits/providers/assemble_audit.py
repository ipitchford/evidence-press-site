#!/usr/bin/env python3
"""Assemble bounded audit observations from the private cache. No network calls."""
from pathlib import Path
from collections import Counter
from urllib.parse import urlparse
import json,re,hashlib,datetime
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'data/audits/providers'
rows=json.loads((OUT/'retrievals.json').read_text())
byurl={r['requestedUrl']:r for r in rows}
def text_of(r):return (ROOT/r['textPath']).read_text() if r.get('textPath') else ''
def soup_of(r):return BeautifulSoup((ROOT/r['rawPath']).read_bytes(),'html.parser')
def links_of(r):return json.loads((ROOT/r['linksPath']).read_text()) if r.get('linksPath') else []
def evidence(r,note):
 return {'url':r['requestedUrl'],'retrievedAt':r['retrievedAt'],'httpStatus':r['httpStatus'],'sha256':r['sha256'],'rawPath':r['rawPath'],'inspectedMaterial':note}

# These are retained historical audit observations, not a repeatable permitted API.
players={}
for r in rows:
 if r['role']!='player-metadata' or 'youtube.com/watch' not in r['url']:continue
 h=(ROOT/r['rawPath']).read_text(errors='replace')
 m=re.search(r'(?:var\s+)?ytInitialPlayerResponse\s*=\s*',h)
 if not m:continue
 j=json.JSONDecoder().raw_decode(h[m.end():])[0]
 d=j.get('videoDetails',{});p=j.get('playabilityStatus',{});mf=j.get('microformat',{}).get('playerMicroformatRenderer',{})
 tracks=j.get('captions',{}).get('playerCaptionsTracklistRenderer',{}).get('captionTracks',[])
 players[d['videoId']]={'id':d['videoId'],'title':d.get('title'),'channel':d.get('author'),'channelId':d.get('channelId'),'durationSeconds':int(d['lengthSeconds']) if d.get('lengthSeconds') else None,'uploadDate':mf.get('uploadDate'),'publishDate':mf.get('publishDate'),'playabilityStatus':p.get('status'),'playableInEmbed':p.get('playableInEmbed'),'captionTracks':[{'languageCode':x.get('languageCode'),'kind':x.get('kind'),'name':x.get('name')} for x in tracks],'captionTextRetrieved':False,'playbackObserved':False,'auditOnly':True,'repeatablePermittedRoute':False,'releaseQualification':'Awaiting authorised API recheck or permitted institutional alternative','termsReceipt':'data/audits/hackertube/terms-receipt.json','evidence':evidence(r,'Public watch-page player metadata parsed before terms restriction was identified; no audiovisual playback or media download.')}
(OUT/'historical-player-observations.json').write_text(json.dumps(list(players.values()),indent=2,ensure_ascii=False)+'\n')

# Short original descriptions: selection judgments, not scientific validation.
# id: speaker, course, families, level, original summary, editorial role
spec={
'hfwxwzTujLI':('Suzana Herculano-Houzel','Big Brains, Small Brains',['evolution-comparative-cognition','neuroscience'],'introductory','Introduces comparisons of brain size across species and the problem of relating size to intelligence.','substantial'),
'VdGjDTRQwko':('Miguel Nicolelis','Brain Machine Interfaces',['neuroscience','computational-cognition'],'intermediate','Explains early brain-machine interface experiments as part of a course on neural control and rehabilitation. The title uses telepathic as the publisher’s metaphor.','substantial'),
'1kMB7VuI1-s':('Christof Koch','The Biology of Consciousness',['consciousness-philosophy','neuroscience'],'intermediate','Introduces Koch’s approach to explaining conscious experience; use within a route that also represents competing theories.','substantial'),
'eEGRUQv3ZWY':('Alfred Mele','Free Will and Neuroscience',['consciousness-philosophy','methods-reproducibility'],'intermediate','Examines what neuroscience experiments can and cannot establish about free will from Mele’s philosophical perspective.','substantial'),
'xr5MYqN5-Vg':('Isabella Catalano','Share Your Research',['evolution-comparative-cognition'],'introductory','An interview accompanying the research presentation; retain separately to avoid counting both as substantive lectures.','auxiliary-interview'),
'hc0t6I_aB78':('Isabella Catalano','Share Your Research',['evolution-comparative-cognition','learning-memory','neuroscience'],'intermediate','Presents zebra-finch research on brain responses involved in recognising individuals.','substantial'),
'bw6juVfL2ZQ':('Paige Greenwood','Share Your Research',['development','language','learning-memory'],'intermediate','Discusses associations between maternal reading fluency and children’s language-network development. Association should not be rewritten as proof of causation.','substantial'),
'HD2QGCu-GIk':('Beth Stevens','The Role of Microglia in Health and Disease',['neuroscience','development'],'intermediate','Introduces microglial states and their roles in brain development, health and disease.','substantial'),
'M3bNorPiYS8':('Beth Stevens','The Role of Microglia in Health and Disease',['neuroscience','development'],'advanced','Develops the account of microglia and synaptic pruning, including implications for ageing and disease.','substantial'),
'PymMVna6T8A':('Anne Churchland','Decision-Making in the Brain',['decision-making','neuroscience','methods-reproducibility'],'intermediate','Explains behavioural tasks and neural-recording approaches used to study decision-making.','substantial'),
'cFpGbmqXWOI':('Anne Churchland','Decision-Making in the Brain',['decision-making','perception-action','neuroscience'],'advanced','Connects movement measurements with brain activity in experimental studies of decision-making.','substantial'),
'eqHUkMmeOk8':('Stanislas Dehaene','SWC Annual Lectures',['language','learning-memory','development'],'intermediate','Links reading research with changes in developing brain circuits and educational questions.','substantial'),
'ZhQaCIUmJQI':('Blaise Agüera y Arcas','SWC Annual Lectures',['computational-cognition','evolution-comparative-cognition'],'intermediate','Presents a computational perspective on life and intelligence.','substantial'),
'dV1yPA0Rv5I':('Stephen Reicher','SWC Annual Lectures',['social-cultural','methods-reproducibility'],'intermediate','Uses the pandemic to examine social relationships and behavioural science.','substantial'),
'Lt0iZSSGfW0':('Emily Murphy','SWC Annual Lectures',['social-cultural','neuroscience'],'intermediate','Presents a proposal for assessing policy through its effects on cognitive and emotional functioning.','substantial'),
'5gDWmzeFPLA':('Arielle Sheftall','NIMH Director’s Innovation Speaker Series',['mental-health','development'],'advanced','Discusses developmental research and disparities in youth suicidal behaviour. It is research education, not individual clinical advice.','substantial'),
'HMa56658fGU':('Jenny Radesky; Megan Moreno','NIMH Director’s Innovation Speaker Series',['development','mental-health','methods-reproducibility'],'advanced','Discusses research methods that incorporate young people’s perspectives when studying digital media and health.','substantial'),
'5uQWglAwlps':('Robin May','Why do we have emotions?',['emotion-motivation','social-cultural','neuroscience'],'introductory','Explores biological explanations of romantic and parental love. Broad empirical claims in the transcript need separate scientific assessment before being repeated as conclusions.','substantial'),
'J-HmfRIe5xM':('Gwyneth Card','The Lab',['evolution-comparative-cognition','perception-action'],'introductory','Short laboratory documentary showing research on fly escape behaviour. It has not been judged a substitute for a full lecture.','supporting-video'),
'FYza3eWp2zE':('Kristin Branson','The Lab',['methods-reproducibility','computational-cognition'],'introductory','Short laboratory documentary introducing automated classification of animal behaviour.','supporting-video'),
'UNYtsGraoaI':('Karel Svoboda','The Lab',['neuroscience','methods-reproducibility'],'introductory','Short laboratory documentary about microscopy and experiments on mouse behaviour.','supporting-video'),
'jbqLZoRGuUM':('Michael Cole; Paul Middlebrooks','Brain Inspired',['computational-cognition','neuroscience'],'advanced','A long interview on Cole’s proposal that flows of activity between brain regions are useful units for understanding cognition.','substantial'),
'HeBpsiFQiTI':('Richard Davidson','The Science of a Meaningful Life',['emotion-motivation'],'introductory','Presents Davidson’s framework for wellbeing; retain attribution and assess intervention claims separately.','substantial'),
'vGcFqzZYJxQ':('Daniel Siegel','The Science of a Meaningful Life',['development','decision-making'],'introductory','Discusses adolescent novelty seeking and risk taking. The 2014 explanation should not be labelled a current consensus review.','substantial'),
'gw9GrgNcYcg':('Daniel Siegel','The Science of a Meaningful Life',['development'],'introductory','Introduces an account of how adolescent brain changes relate to preparation for adulthood.','substantial'),
'VNNsN9IJkws':(None,'Three Core Concepts in Early Development',['development','neuroscience'],'introductory','A brief animation introducing how early experience relates to brain development.','supporting-video'),
'm_5u8-QSh6A':(None,'Three Core Concepts in Early Development',['development','social-cultural'],'introductory','A brief animation illustrating responsive interaction between a child and caregiver.','supporting-video'),
'0ef9Ub6lTHQ':('Swarna Vinaitheerthan','Brain Awareness Video Contest 2024',['learning-memory'],'introductory','A short contest explanation of learning and memory. Source-specific quantitative analogies require review before use in an evidence-led guide.','supporting-video'),
'9QWaZp_2I1k':('Nicholas Humphrey','Royal Institution public lectures',['consciousness-philosophy','evolution-comparative-cognition'],'intermediate','Presents Humphrey’s evolutionary theory of consciousness, including discussion of blindsight and animal sentience.','substantial'),
'evPPrWHH4kg':('Sue Carter','The Origin of Love',['social-cultural','emotion-motivation','neuroscience'],'advanced','Examines the oxytocin hypothesis of social bonding while acknowledging unresolved mechanisms and interpretations.','substantial'),
'T4TfPkbM-EQ':('Karen Bales','The Origin of Love',['evolution-comparative-cognition','emotion-motivation'],'intermediate','Compares pair bonds, loss and underlying biology across species.','substantial'),
'6g9C6wC2hIU':('James Rilling','The Origin of Love',['development','evolution-comparative-cognition','social-cultural'],'intermediate','Explores biological and evolutionary hypotheses about grandmaternal caregiving.','substantial'),
'5P58wHbWXBU':('Simon DeDeo','Maximum Entropy Methods',['methods-reproducibility','computational-cognition'],'intermediate','Uses a waiting-time example to introduce maximum-entropy modelling.','substantial'),
'CPkzXsp-VdM':('Seth Lloyd','Introduction to Information Theory',['methods-reproducibility','computational-cognition'],'introductory','Introduces bits as a measure of information within a structured tutorial.','substantial'),
'a1EClFkubjk':('Helena Miton','Introduction to Open Science',['methods-reproducibility'],'introductory','Defines open-science practices and introduces the structure of the tutorial.','substantial'),
'vemZtEM63GY':('Josh Starmer','StatQuest Statistics Fundamentals',['methods-reproducibility'],'introductory','An introductory explanation of p-values and their interpretation. Scientific accuracy has not been independently audited.','substantial'),
'VX_M3tIyiYk':('Josh Starmer','StatQuest Statistics Fundamentals',['methods-reproducibility'],'introductory','An introduction to statistical power and sample-size planning.','substantial'),
'9wCnvr7Xw4E':('Josh Starmer','StatQuest Statistics Fundamentals',['methods-reproducibility'],'introductory','Introduces Bayes’ theorem through worked explanation.','substantial'),
}

def source_for(vid):
 hits=[]
 for r in rows:
  if r['role'] in ('player-metadata','licence'):continue
  if r.get('rawPath') and vid in (ROOT/r['rawPath']).read_text(errors='replace'):
   # Only explicit embeds, player IDs or linked watch URLs; not thumbnails in arbitrary pages.
   s=soup_of(r)
   explicit=any(vid in (x or '') for x in r.get('embeds',[])) or any(x.get('data-youtube-id-value')==vid for x in s.select('[data-youtube-id-value]')) or any(vid in x['href'] for x in links_of(r))
   if explicit:hits.append(r)
 return hits[-1] if hits else None

observations=[]
for vid,m in players.items():
 r=source_for(vid)
 if vid not in spec or r is None:raise ValueError(f'Missing inspected source/selection: {vid}')
 speaker,course,families,level,summary,role=spec[vid]
 # CARTA's media wrapper proves the destination; the session page supplies the description.
 descr=r
 if r['providerId']=='carta-ucsd':
  for x in rows:
   if '/events/sessions/' in x['url'] and any(a['href']==r['url'] for a in links_of(x)):descr=x;break
 rec=None
 if r['providerId']=='world-science-u':
  match=re.search(r'This lecture was (?:recorded|filmed) on ([A-Za-z]+ \d+, \d{4})',text_of(r))
  if match:rec=datetime.datetime.strptime(match[1],'%B %d, %Y').date().isoformat()
 if vid=='9QWaZp_2I1k':rec='2023-06-21'
 if r['providerId']=='carta-ucsd':rec='2025-02-14'
 if vid=='5uQWglAwlps':rec='2026-04-22'
 observation={'id':'youtube:'+vid,'title':m['title'],'sourceUrl':descr['url'],'canonicalUrl':'https://www.youtube.com/watch?v='+vid,'providerId':r['providerId'],'speaker':speaker,'parentCourse':course,'subjectFamilies':families,'level':level,'levelBasis':'Editorial inference from the retrieved publisher description and format; not a credential or difficulty assessment by the provider.','language':None,'languageNote':'English publisher text and caption metadata observed; spoken language not independently checked.','durationSeconds':m['durationSeconds'],'uploadDate':m['uploadDate'],'recordingDate':rec,'transcriptStatus':{'status':'caption-metadata-present' if m['captionTracks'] else 'unknown','textInspected':False,'tracks':m['captionTracks']},'descriptionEvidence':[evidence(descr,'Publisher description inspected; original short annotation written from that material.')],'originalSynopsis':summary,'selectionBasis':'publisher-description','selectionReason':summary,'scientificAssessment':'Not assessed','editorialRole':role,'availability':{'status':'historical-player-metadata-OK' if m['playabilityStatus']=='OK' else m['playabilityStatus'],'method':'Public watch-page player metadata; route subsequently closed for terms compliance.','checkedAt':m['evidence']['retrievedAt'],'playableInEmbed':m['playableInEmbed'],'playbackObserved':False,'repeatablePermittedRoute':False,'auditOnly':True,'termsReceipt':m['termsReceipt'],'evidence':m['evidence']},'qualificationStatus':'pending-authorised-availability-check' if role=='substantial' else 'supporting-or-auxiliary-not-counted','releaseEligible':False,'sourceLicenceNotes':'See provider register. Link-only is the default; no permission to republish cached pages, descriptions, captions or video is inferred.'}
 if r['providerId']=='nimh':
  observation['transcriptStatus']['publisherTranscriptUrl']=descr['url'];observation['transcriptStatus']['publisherTranscriptPresent']=True;observation['transcriptStatus']['textInspected']='speaker introduction and topic framing; not full claim audit'
 if r['providerId']=='brain-inspired':observation.update({'recordingDate':'2026-11-04','recordingDatePrecision':'day','recordingDateNote':'Official episode page explicitly labels this date as recorded. Source statement preserved, not an independently observed production date.'})
 if r['providerId']=='statquest':observation['descriptionEvidence'][0]['inspectedMaterial']='Official topic-index title/link inspected; description basis is limited. Needs deeper source or transcript checking before selected-core inclusion.'
 observations.append(observation)

heads=json.loads((OUT/'media-head-checks.json').read_text())
oxmeta={
'consciousness-humans-and-other-things':('Consciousness in Humans and in Other Things','Anil Seth','Science in Society: The Simonyi Lectures',3573,'2024-11-07',None,'Seth presents an embodied, predictive account of consciousness and selfhood. It is one theoretical perspective.','standard-provider-copyright'),
'pedro-mediano-moving-beyond-integration-and-differentiation-measures-neural-dynamics':('Moving beyond integration and differentiation in measures of neural dynamics','Pedro Mediano','Models of Consciousness',1432,'2019-10-13','2019-09','Introduces information-theoretic approaches to neural dynamics and limitations of earlier integration/differentiation measures.','CC BY-NC-SA 2.0 UK'),
'ines-hipolito-generative-models-mind-neural-connections-and-cognitive-integration':('Generative models of the mind: neural connections and cognitive integration','Inês Hipólito','Models of Consciousness',1074,'2019-10-13','2019-09','Presents a philosophical argument about generative models, connectivity and cognitive integration.','CC BY-NC-SA 2.0 UK')}
for head in heads:
 r=byurl[head['sourcePage']];key=r['url'].split('/')[-1];title,speaker,course,duration,added,recording,summary,lic=oxmeta[key]
 observations.append({'id':'oxford:'+key,'title':title,'sourceUrl':r['url'],'canonicalUrl':head['requestedUrl'],'providerId':'oxford-podcasts','speaker':speaker,'parentCourse':course,'subjectFamilies':['consciousness-philosophy','neuroscience']+(['methods-reproducibility'] if 'mediano' in key else []),'level':'advanced' if '2019' in (recording or '') else 'intermediate','levelBasis':'Editorial inference from publisher description.','language':None,'durationSeconds':duration,'uploadDate':None,'sourceDateAdded':added,'recordingDate':recording,'recordingDatePrecision':'month' if recording else None,'transcriptStatus':{'status':'publisher-SRT-linked' if key.startswith('consciousness-') else 'unknown','textInspected':False},'descriptionEvidence':[evidence(r,'Episode description, speaker, duration, date-added and individual licence inspected.')],'originalSynopsis':summary,'selectionBasis':'publisher-description','selectionReason':summary,'scientificAssessment':'Not assessed','editorialRole':'substantial','availability':{'status':'official-media-endpoint-accessible','method':'HTTP HEAD of official MP4 URL','checkedAt':head['retrievedAt'],'httpStatus':head['httpStatus'],'contentType':head['contentType'],'playbackObserved':False,'embeddingStatus':'not-checked','repeatablePermittedRoute':True,'evidence':head},'qualificationStatus':'institutional-media-evidence-ready-for-editorial-qualification','releaseEligible':None,'sourceLicenceNotes':lic+'; preserve item licence and attribution. No inference from this licence to other Oxford episodes.'})
 if key.startswith('consciousness-'):observations[-1].update({'transcriptUrls':['https://media.podcasts.ox.ac.uk/maths/simonyi-lectures/2024-11-01-simonyi-seth-consciousness.srt'],'transcriptNote':'Official source link present; transcript text not retrieved or inspected.'})

# Three historical Ri lectures have working source pages but no permitted playback check.
for r in rows:
 if r['providerId']=='royal-institution' and 'meet-your-brain-' in r['url']:
  v=next((re.search(r'/video/(\d+)',x)[1] for x in r.get('embeds',[]) if x and 'player.vimeo.com/video/' in x),None)
  observations.append({'id':'vimeo:'+v,'title':r['title'].split(' | ')[0],'sourceUrl':r['url'],'canonicalUrl':'https://vimeo.com/'+v,'providerId':'royal-institution','speaker':'Bruce Hood','parentCourse':'Meet your brain — Christmas Lectures 2011','subjectFamilies':['neuroscience','perception-action','social-cultural'],'level':'introductory','language':None,'durationSeconds':None,'uploadDate':None,'recordingDate':'2011','recordingDatePrecision':'year','transcriptStatus':'unknown','descriptionEvidence':[evidence(r,'Individual lecture description and embedded Vimeo destination inspected.')],'selectionBasis':'publisher-description','selectionReason':'A coherent public lecture sequence introducing brain, behaviour and social cognition.','scientificAssessment':'Not assessed','editorialRole':'substantial','availability':{'status':'source-page-and-embed-seen','playbackObserved':False,'note':'One standalone Vimeo player request returned 403 with a privacy-settings message. This could depend on embed context; on-site playback is unverified for all three.'},'qualificationStatus':'pending-permitted-playback-or-media-check','releaseEligible':False,'sourceLicenceNotes':'Ri terms require review before publication, including their stated linking-notice condition; no outreach sent.'})

# 3Blue1Brown exposes the intended full video in VideoObject JSON-LD. Inline MP4 animations are not extra lectures.
for r in rows:
 if r['providerId']!='3blue1brown' or r['role']!='item':continue
 s=soup_of(r);objects=[]
 def walk(x):
  if isinstance(x,dict):
   if x.get('@type')=='VideoObject':objects.append(x)
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 for el in s.select('script[type="application/ld+json"]'):
  try:walk(json.loads(el.get_text()))
  except json.JSONDecodeError:pass
 for obj in objects:
  match=re.search(r'/embed/([\w-]{11})',obj.get('embedUrl',''))
  if not match:continue
  vid=match[1];summary={'neural-networks':'Introduces a simple neural network through handwritten-digit recognition.','backpropagation':'Explains the backpropagation algorithm used to train neural networks.','mlp':'Examines hypotheses and partial results about how transformer multilayer perceptrons represent information.'}[r['url'].rstrip('/').split('/')[-1]]
  observations.append({'id':'youtube:'+vid,'title':obj.get('name'),'sourceUrl':r['url'],'canonicalUrl':'https://www.youtube.com/watch?v='+vid,'providerId':'3blue1brown','speaker':'Grant Sanderson','parentCourse':'Neural Networks','subjectFamilies':['computational-cognition','methods-reproducibility'],'level':'intermediate','levelBasis':'Editorial inference.','language':None,'durationSeconds':None,'uploadDate':obj.get('uploadDate'),'uploadDateNote':'Provider VideoObject field; independent destination metadata not checked.','recordingDate':None,'transcriptStatus':{'status':'text-adaptation-on-source-page','textInspected':'introduction and framing; not complete mathematical audit'},'descriptionEvidence':[evidence(r,'Official lesson text and VideoObject inspected; thumbnail recommendations and inline animation clips excluded.')],'originalSynopsis':summary,'selectionBasis':'publisher-description','selectionReason':summary,'scientificAssessment':'Not assessed','editorialRole':'substantial','availability':{'status':'source-page-and-VideoObject-seen','checkedAt':r['retrievedAt'],'playbackObserved':False,'repeatablePermittedRoute':False,'note':'YouTube watch-page probing stopped before checking these destinations; use authorised API.'},'qualificationStatus':'pending-authorised-availability-check','releaseEligible':False,'sourceLicenceNotes':'Copyright retained by creator; link-only, no blanket Creative Commons licence verified.'})

alt_path=OUT/'institutional-alternative-head-checks.json'
alternatives=json.loads(alt_path.read_text()) if alt_path.exists() else []
for alt in alternatives:
 for item in observations:
  if item['id']==alt['alternativeFor']:
   item['institutionalAlternative']={**alt,'qualificationNote':'HTTP HEAD confirms a public binary endpoint. application/octet-stream does not itself verify the MP4 container or playback; retain that limit.'}
(OUT/'candidate-observations.json').write_text(json.dumps(observations,indent=2,ensure_ascii=False)+'\n')

configs={
'brainfacts':('BrainFacts / Society for Neuroscience','Society for Neuroscience','supporting-videos-and-reading',['neuroscience','learning-memory'],'About page identifies SfN and editorial mission. One contest video is a short supporting resource, not a substitute for substantial lectures.','YouTube films subject to YouTube terms; other film/audio is CC BY-NC unless otherwise stated. Blog text and images have separate permissions.','Use curated video/article pages with byline, date and embedded destination; do not count the About-page promotion.','terms-reviewed-specific-conditions'),
'noba':('Noba','Diener Education Fund','supporting-reading',['psychology','learning-memory','development','social-cultural'],'Accessible psychology modules; no substantive-video corpus established.','About and licence pages specify CC BY-NC-SA 4.0 with agreement conditions. No registration or acceptance performed.','Import reading metadata separately; retain author/module attribution and NC-SA terms.','CC BY-NC-SA 4.0'),
'world-science-u':('World Science U','World Science Foundation / World Science Festival','useful-video-provider',['neuroscience','consciousness-philosophy','evolution-comparative-cognition'],'Four in-scope courses and four video lessons inspected; login is for participation/progress, not evidence that the public embeds are gated.','Terms reserve rights, with limited personal/educational use; link-only default.','Parse only explicitly video-labelled steps, not summaries, exercises, discussion or course container. Preserve parent course and segment order.','terms-reviewed-link-only'),
'royal-society':('Royal Society','The Royal Society','blocked',['neuroscience','consciousness-philosophy'],'Exact initial collection and a relevant Faraday-lecture page both returned WAF 403. Search-index material is only a lead.','Not verified in this audit.','Stop route after documented failures; authorised official alternative needed.','unknown'),
'ibiology':('iBiology','Science Communication Lab','useful-video-provider',['neuroscience','development','decision-making','evolution-comparative-cognition'],'Corrected neuroscience collection and four talk pages expose distinct research-talk videos.','YouTube content has BY-NC-ND terms with attribution/branding and official-embed conditions; no reuploads, cuts, overlays or remixing. Feature films require separate permission.','Parse each talk part and speaker biography; distinguish interviews from talks; inspect Talk Overview rather than keyword-only categorisation.','BY-NC-ND; version and item exceptions require care'),
'royal-institution':('Royal Institution','Royal Institution of Great Britain','useful-video-provider-with-publication-condition',['neuroscience','consciousness-philosophy','evolution-comparative-cognition'],'Archive exposes full historical lecture sequences and contemporary public talks. Vimeo context restriction remains unresolved for sampled 2011 lectures.','Terms reserve rights and state personal/not-for-profit education scope. Their linking clause asks for email notice. No notice or outreach was sent; flag before external publication.','Archive to series to lecture; record recording year/date separately; do not treat newer BBC exclusivity or Vimeo privacy as universal availability.','terms-reviewed-publication-decision-needed'),
'harvard-developing-child':('Center on the Developing Child','Harvard University','supporting-videos-and-reading',['development','social-cultural'],'Two sampled animations are 117 and 102 seconds. Good guide introductions; not counted as substantial-video capacity.','Terms reserve rights; no provider-wide open licence established.','Resource guide separates videos, papers, activities and audio. Group translations as alternatives to the same work.','terms-reviewed-link-only'),
'oxford-podcasts':('University of Oxford Podcasts','University of Oxford','useful-video-provider',['consciousness-philosophy','neuroscience','methods-reproducibility'],'Three video episodes have official accessible MP4 endpoints and stated durations. Two carry individual CC licences.','Default copyright restrictions; two Models of Consciousness episodes explicitly CC BY-NC-SA 2.0 UK. Seth episode did not show that licence.','Use Video RSS and episode pages; separate audio; retain Date Added as its own field, not recording date. HEAD official media and preserve content type/status.','item-specific'),
'hhmi-biointeractive':('HHMI BioInteractive','Howard Hughes Medical Institute','blocked',['evolution-comparative-cognition','methods-reproducibility'],'Classroom-resources route returned 403. No authorised destination verified.','Unknown in this audit.','Stop blocked route; Janelia shares institutional parent and should not inflate independent-provider count.','unknown'),
'allen-institute':('Allen Institute','Allen Institute','identity-and-events-only',['neuroscience','methods-reproducibility'],'Old path 404; current Brain Science and webinar pages retrieved. Embedded site-wide media are promotional; no individual substantive recording extracted.','No video-specific reuse licence verified. Open datasets do not imply open video rights.','Select documented past training recordings rather than counting future events or site background videos.','unknown'),
'janelia':('Janelia Research Campus','Howard Hughes Medical Institute','supporting-laboratory-documentaries',['neuroscience','methods-reproducibility','evolution-comparative-cognition'],'Three 7–9 minute laboratory films are accessible in historical player metadata; retained as supporting introductions pending editorial depth review.','No blanket licence established; same institutional parent as BioInteractive.','The Lab series has heading-to-iframe pairs. Do not infer 50 labs means 50 videos.','unknown'),
'greater-good-berkeley':('Greater Good Science Center','University of California, Berkeley','useful-video-provider',['social-cultural','emotion-motivation','development'],'Three 8–14 minute explanations inspected; scientific validity/clinical utility not established by institutional hosting.','No open licence verified; link-only.','Series to item pages; record speaker and date, evaluate explanatory depth and distinguish empirical evidence from wellbeing advice.','unknown'),
'association-psychological-science':('Association for Psychological Science','Association for Psychological Science','gated-sample',['psychology','learning-memory','social-cultural'],'Video index is public, but the selected 2025 Kensinger keynote says log in to view. No free recording destination verified.','Unknown; access restricted for sampled item.','Do not treat pagination or public abstracts as free video availability. Inspect older individual items if separately authorised and useful.','unknown'),
'psychonomic-society':('Psychonomic Society','Psychonomic Society','blocked',['perception-action','learning-memory'],'Webinars route returned 403.','Unknown.','Document blocked route; do not infer empty collection or accessible corpus.','unknown'),
'nimh':('NIMH','US National Institute of Mental Health','useful-video-provider',['mental-health','development','methods-reproducibility'],'Two substantial innovation lectures with publisher transcripts and official embedded destinations.','Do not automatically extend US-government public-domain assumptions to guest talks, illustrations or third-party assets. Link-only pending item review.','Multimedia listing to transcript-bearing lecture pages; distinguish publication/event dates from video upload.','unknown-item-rights'),
'openlearn':('OpenLearn','The Open University','blocked',['psychology','development','mental-health'],'Health/sports/psychology route returned 403. No video inventory verified in this bounded pass.','Not verified here; open-course licences may have item exceptions.','Use a permitted official route in a separate bounded investigation; do not count web reading as video.','unknown'),
'gresham-college':('Gresham College','Gresham College','useful-video-provider',['emotion-motivation','neuroscience','social-cultural'],'One substantial modern lecture sampled; coherent six-lecture emotions series observed. One 1997 page has only transcript evidence. Whole-site 3500 figure is not an in-scope count.','Terms reserve copyright; link-only default.','Prefer coherent series pages to unrendered filter results; verify each video exists. A Watch Now path can be transcript-only.','terms-reviewed-link-only'),
'sainsbury-wellcome':('Sainsbury Wellcome Centre','University College London','useful-video-provider',['development','social-cultural','computational-cognition','consciousness-philosophy'],'Four annual lectures have embedded YouTube players and substantive descriptions. Older 2017–2019 headings have no retrieved iframe; do not count them yet.','No open licence verified; link-only.','Parse year/speaker/description and associated iframe; the 2016 Attenborough item is explicitly only part of a lecture.','unknown'),
'carta-ucsd':('CARTA','UC San Diego / Salk collaboration','useful-video-provider',['evolution-comparative-cognition','development','social-cultural'],'Archive to symposium to session to media-wrapper is a reproducible institutional route. Three talks inspected.','CARTA terms reserve rights except limited personal noncommercial use; link-only annotations.','Use session IDs as works, canonical video ID for mirror deduplication; exclude welcome/closing administration; retain event recording date.','terms-reviewed-link-only'),
'complexity-explorer':('Complexity Explorer','Santa Fe Institute','useful-video-provider',['methods-reproducibility','computational-cognition'],'Three relevant tutorials expose public lesson indexes and player IDs. Enrollment tracks progress/homework; no account created.','No blanket licence verified in this audit; linked official download availability is distinct from reuse permission.','Parse /segments?summary, distinguish lessons from quizzes/solutions/references, associate lesson title and data-youtube-id-value. Official MP4 alternatives exist for some older tutorials.','unknown'),
'statquest':('StatQuest','Josh Starmer','useful-methods-provider',['methods-reproducibility'],'Official index links three sampled statistics explanations. Selection evidence is only index labels plus historical player metadata; not yet selected-core depth review.','No blanket open licence verified; link-only.','Use exact official index links, preserve topic hierarchy; authorised API for destination refresh. Avoid importing all ML by association.','unknown'),
'3blue1brown':('3Blue1Brown','Grant Sanderson','useful-methods-provider-pending-destination-check',['methods-reproducibility','computational-cognition'],'Three lesson pages include substantive text and canonical full-video JSON-LD. Topic page was a client-rendered skeleton in direct retrieval.','Creator copyright; no blanket open licence verified.','VideoObject embedUrl identifies the full lecture. Exclude recommendation thumbnails and tiny inline MP4 animations.','unknown'),
'brain-inspired':('Brain Inspired','Paul Middlebrooks','useful-interview-provider-mixed-access',['computational-cognition','neuroscience'],'One long episode has a matching 6102-second public video. The site promotes paid full archive access, so no whole-archive availability inference.','No blanket open licence verified; link-only.','Require actual video embed and duration. Audio RSS or MP3 alone is not video; check each episode’s public/full status.','unknown'),
'melbourne-cognitive-neuroscience':('Melbourne Cognitive Neuroscience Hub','University of Melbourne','blocked-direct-with-indexed-recording-evidence',['development','perception-action','methods-reproducibility'],'Direct request returned challenge 403. A web-reader view shows official seminar titles, speakers and player links; cached/indexed evidence does not establish current playback.','Unknown.','Use an authorised accessible institutional route; do not bypass challenge. Indexed 40 section links are not 40 qualified recordings.','unknown')}

register=[]
for pid,c in configs.items():
 name,owner,status,families,note,rights,adapter,lic=c;pr=[r for r in rows if r['providerId']==pid];sample=[x for x in observations if x['providerId']==pid]
 register.append({'providerId':pid,'name':name,'owner':owner,'status':status,'subjectFamilies':families,'officialPrimaryPageRetrieved':any(r['httpStatus']=='200' and r['role']!='player-metadata' for r in pr),'initialUrls':[r['url'] for r in pr if r in rows[:22]],'verificationNote':note,'reuseConditions':rights,'licenceStatus':lic,'recommendedAcquisition':adapter,'candidateObservationCount':len(sample),'substantialSampleCount':sum(x['editorialRole']=='substantial' for x in sample),'releaseQualifiedCount':0,'releaseQualifiedCountNote':'This feasibility audit does not grant release qualification; historical YouTube checks require authorised recheck and Oxford institutional checks await integration/editorial review.','inspectedSourceEvidence':[evidence(r,'Page identity, route, licence, collection or item content inspected as indicated by role: '+r['role']) for r in pr if r['role']!='player-metadata'],'failedAttempts':[evidence(r,r.get('title') or r.get('error') or 'Non-success response') for r in pr if r['httpStatus']!='200'],'sharedParentNote':'HHMI BioInteractive and Janelia are distinct brands under the same institutional parent.' if pid in ('hhmi-biointeractive','janelia') else None})
(OUT/'source-register.json').write_text(json.dumps(register,indent=2,ensure_ascii=False)+'\n')

support=[]
for r in rows:
 if r['providerId']=='noba' and '/modules/' in r['url']:
  support.append({'type':'reading','providerId':'noba','title':r.get('title'),'sourceUrl':r['url'],'videoCount':0,'licence':'CC BY-NC-SA 4.0, subject to module/third-party exceptions and terms','evidence':evidence(r,'Supporting textbook module inspected; not a video.')})
 if r['url']=='https://www.gresham.ac.uk/watch-now/exploring-brain-brain-computer':
  support.append({'type':'transcript-only-in-this-retrieval','providerId':'gresham-college','title':'Exploring the Brain: The Brain as Computer','sourceUrl':r['url'],'speaker':'Susan Greenfield','eventDate':'1997-11-27','videoCount':0,'evidence':evidence(r,'Transcript links and event description present; no video destination established.')})
for x in observations:
 if x['editorialRole']!='substantial':support.append({'type':x['editorialRole'],'providerId':x['providerId'],'id':x['id'],'title':x['title'],'sourceUrl':x['sourceUrl'],'durationSeconds':x['durationSeconds'],'videoCountForSubstantialCorpus':0,'reason':x['selectionReason']})
(OUT/'supporting-resources.json').write_text(json.dumps(support,indent=2,ensure_ascii=False)+'\n')

# Bounded link inventory; denominators describe only retrieved pages, never whole-provider counts.
inventory=[]
for r in rows:
 if r['providerId']=='world-science-u' and r['role']=='course':
  ls=[x for x in links_of(r) if x['text'].startswith('video ') and '/lessons/' in x['href']]
 elif r['providerId']=='complexity-explorer' and r['role']=='lesson-collection':
  ls=[x for x in links_of(r) if re.search(r'/segments/\d+$',x['href']) and ('Video' in x['text'] or r['url'].find('125-')>0)]
 elif r['providerId']=='carta-ucsd' and r['role']=='item' and '/sessions/' not in r['url']:
  ls=[x for x in links_of(r) if '/events/sessions/' in x['href']]
 elif r['providerId']=='gresham-college' and '/series/why-emotions' in r['url']:
  ls=[x for x in links_of(r) if x['text'].startswith('Why Do We') or 'Manipulate' in x['text']]
 elif r['providerId']=='ibiology' and r['url']=='https://www.ibiology.org/research-talks/neuroscience/':
  ls=[x for x in links_of(r) if '/neuroscience/' in x['href'] and '/research-talks/' not in x['href'] and x['text']]
 else:continue
 unique={}
 for x in ls:unique.setdefault(x['href'],x)
 inventory.append({'providerId':r['providerId'],'sourceUrl':r['url'],'retrievedAt':r['retrievedAt'],'observedDistinctLinks':len(unique),'qualifiedVideoCount':0,'note':'Link inventory only: may include containers, quizzes, non-substantive items or duplicates across pages. No extrapolation to provider capacity.','links':list(unique.values())})
(OUT/'bounded-collection-inventory.json').write_text(json.dumps(inventory,indent=2,ensure_ascii=False)+'\n')

# Hash supplementary web-reader evidence too; it is indexed evidence, not a successful direct retrieval.
extra=ROOT/'data/raw/providers/melbourne-web-reader.json'
supplement=[]
if extra.exists():
 body=extra.read_bytes();j=json.loads(body);supplement.append({'url':j['requestedUrl'],'retrievedAt':j['retrievedAt'],'method':'web-reader','rawPath':str(extra.relative_to(ROOT)),'sha256':hashlib.sha256(body).hexdigest(),'note':j['interpretation']})
(OUT/'supplementary-evidence.json').write_text(json.dumps(supplement,indent=2)+'\n')
summary={'assembledAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'providerBrandsInvestigated':len(register),'officialPrimaryProviderPagesRetrieved':sum(x['officialPrimaryPageRetrieved'] for x in register),'independentProviderCountCaution':'Janelia and BioInteractive share HHMI; source identities, useful collections and accessible-video providers are different counts.','retrievalReceipts':len(rows),'historicalYouTubePlayerObservations':len(players),'youtubeRouteAuditOnly':True,'youtubeRepeatablePermittedRoute':False,'observedOKPlayerMetadata':sum(x['playabilityStatus']=='OK' for x in players.values()),'institutionalMediaHeadChecks':len(heads),'institutionalMediaHeadSuccesses':sum(x['httpStatus']=='200' and x['contentType']=='video/mp4' for x in heads),'additionalInstitutionalBinaryHeadChecks':len(alternatives),'candidateObservations':len(observations),'substantialCandidateObservations':sum(x['editorialRole']=='substantial' for x in observations),'supportingOrAuxiliaryVideoObservations':sum(x['editorialRole']!='substantial' for x in observations),'releaseQualifiedVideosGrantedByThisAudit':0,'playbackObservedCount':0,'providerStatuses':dict(Counter(x['status'] for x in register))}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
