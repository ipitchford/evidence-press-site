"""Verify all concrete provenance cache paths in the four normalised data files.

Receipt hashes without a cache path are reported separately, not invented or
treated as a local-file verification. This checks integrity, not interpretation.
"""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
checks = {}
conflicts = []
inputs = []
no_cache = set()
for name in ["catalogue.jsonl", "sources.json", "courses.json", "supporting.json"]:
    p = ROOT / "data" / name
    data = p.read_bytes()
    inputs.append({"file":str(p.relative_to(ROOT)), "sha256":hashlib.sha256(data).hexdigest()})
    rows = [json.loads(line) for line in data.splitlines()] if name.endswith(".jsonl") else json.loads(data)
    for row in rows:
        for proof in row.get("provenance", []):
            cache = proof.get("cachePath")
            if not cache:
                no_cache.add((proof["url"], proof["sha256"]))
                continue
            assert cache.startswith(("data/raw/", "data/audits/")) and ".." not in Path(cache).parts
            if cache in checks and checks[cache] != proof["sha256"]:
                conflicts.append(cache)
            checks[cache] = proof["sha256"]

failures = []
total = 0
for cache, expected in checks.items():
    p = ROOT / cache
    if not p.is_file():
        failures.append({"file":cache, "reason":"missing"})
        continue
    data = p.read_bytes()
    total += len(data)
    if hashlib.sha256(data).hexdigest() != expected:
        failures.append({"file":cache, "reason":"hash mismatch"})

changed = [x["file"] for x in inputs if hashlib.sha256((ROOT / x["file"]).read_bytes()).hexdigest() != x["sha256"]]
report = {
    "checkedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "inputs":inputs,
    "uniqueCacheFiles":len(checks), "bytesChecked":total,
    "distinctReceiptsWithoutCachePath":len(no_cache),
    "conflictingExpectedHashes":conflicts, "failures":failures,
    "inputsChangedDuringCheck":changed,
    "passed":not (conflicts or failures or changed),
    "boundary":"This verifies saved cache identity against normalised provenance. It does not establish substantive source interpretation, scientific accuracy or full-video playback.",
}
(ROOT / "evaluation/normalisation-cache-integrity.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k != "inputs"},indent=2))
raise SystemExit(0 if report["passed"] else 1)
