"""Materialise individually reviewed scope decisions; no network or classification model.

The decisions below were written after reading all 50 retrieved Yale overviews,
checking them against the actual cached HTML and hashes, and inspecting the
opening of Food lecture 8's transcript because its overview duplicates lecture 7.
This script validates those receipts and records the decisions reproducibly.
"""
import hashlib
import json
import re
from pathlib import Path
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[3]
STAMP = "2026-11-07T16:12:19Z"
FOLLOWUP_STAMP = "2026-11-07T16:46:08Z"
CHECKER = "agent; source-boundary review, not scientific assessment"
rows = json.loads((ROOT / "data/audits/courses/candidates.json").read_text())
records = {}
clusters = {
    "yale-evolution-foundations": {
        "courseId": "yale-evolution-behaviour",
        "action": "retain",
        "rationale": "Lectures 1–17 explain selection, inheritance, genetic variation, development, reproductive strategies and comparative inference. These are explicit foundations for understanding the evolution of behaviour. They are retained as biological and comparative-method foundations, without asserting that each lecture studies cognition or the brain.",
        "limits": "Publisher overviews checked; no viewing or assessment of individual scientific claims. General geological and ecosystem background is handled separately.",
    },
    "yale-evolution-behaviour": {
        "courseId": "yale-evolution-behaviour",
        "action": "retain",
        "rationale": "Lectures 32–36 directly concern foraging choices, strategic contests, mating and parental behaviour, alternative breeding strategies, and cooperation. Their central subject is organismal behaviour.",
    },
    "yale-evolution-background": {
        "courseId": "yale-evolution-behaviour",
        "action": "supporting",
        "rationale": "Lectures 18, 19 and 29–31 concern geological history, fossils, biogeography, ecosystem flows and conservation. These may supply course background, but their publisher overviews do not establish substantial mind, brain or behavioural instruction. They are outside the qualified video denominator.",
    },
    "yale-food-behaviour": {
        "courseId": "yale-food",
        "action": "retain",
        "rationale": "Retained lectures address eating motivation and taste, cultural and environmental influences on food choices, behavioural effects of starvation, addiction/eating disorders, marketing, economic incentives and policy framing. Scope is based on each inspected source, not the psychology department label. Historical clinical material is not current advice.",
    },
    "yale-food-methods": {
        "courseId": "yale-food",
        "action": "retain",
        "rationale": "Lectures 3, 4 and 12 provide measurement, study-design and population-prevention foundations for behavioural health research. They are classified as methods, rather than inferred clinical or emotion content.",
    },
    "yale-food-background": {
        "courseId": "yale-food",
        "action": "supporting",
        "rationale": "Agricultural technology and sustainability, corporate product strategy, legal implementation, local food projects and general change summaries remain optional course context. Their overviews do not establish enough central psychological or behavioural explanation for the qualified denominator.",
    },
}

food = {
    1: ("retain", ["emotion-motivation-sleep", "social-cultural"], "The overview explicitly connects food preferences and intake to psychological, biological and social environments."),
    2: ("retain", ["emotion-motivation-sleep", "evolution-comparative"], "The overview directly links evolved food preferences with present food environments and eating behaviour."),
    3: ("retain", ["methods"], "The overview centres on measuring food intake, measurement error and portion underestimation; retained as behavioural-health measurement background."),
    4: ("retain", ["methods"], "The overview discusses the research challenges in linking diet to health and interpreting dietary recommendations; retained as study-design context, not a mental-health lecture."),
    5: ("retain", ["emotion-motivation-sleep"], "The overview addresses taste, eating, food choice, intake and body-weight regulation, including genetic study designs."),
    6: ("retain", ["emotion-motivation-sleep", "social-cultural", "mental-health"], "The overview explicitly covers food/addiction research and cultural rules and differences in eating; clinical claims remain historical and unassessed."),
    7: ("retain", ["emotion-motivation-sleep", "social-cultural"], "The overview includes the physiological, psychological and behavioural consequences of starvation, with social conditions as context."),
    8: ("retain", ["emotion-motivation-sleep", "social-cultural"], "The inspected transcript opening discusses changes in diet and physical activity, local food traditions, choice environments and global market influences. The duplicated overview is not the basis for this decision."),
    9: ("supporting", ["social-cultural"], "Agricultural technology, irrigation, fertilisers, pesticides and food productivity are the overview's central subjects. Retained only as food-system context; excluded from the mind, brain and behaviour video count."),
    10: ("supporting", ["social-cultural"], "The overview concerns agriculture's water, land, energy and climate effects. Food preferences are a framing context, not a substantial psychological explanation."),
    11: ("supporting", ["social-cultural"], "The overview concerns agricultural sustainability, genetic modification, animal welfare and biodiversity. Retained as background rather than counted psychological or comparative-behaviour instruction."),
    12: ("retain", ["methods"], "The overview explains population prevention, epidemiological reasoning, standards of proof and study methods relevant to behavioural-health research."),
    13: ("retain", ["mental-health", "emotion-motivation-sleep"], "The overview directly addresses eating-disorder psychology, clinical features and multifactorial vulnerability. This is historical educational material, not current diagnostic or treatment guidance."),
    14: ("supporting", ["social-cultural"], "The overview presents a company executive's food-industry strategy and research agenda. It is a stakeholder perspective, not an independently assessed explanation of behaviour."),
    15: ("retain", ["reasoning-decisions", "social-cultural"], "The overview explicitly examines economic incentives, prices, poverty and neighbourhood access as drivers of food choices and overconsumption."),
    16: ("retain", ["social-cultural", "development"], "The overview directly addresses marketing's influence on food choices and children, including advertising and school settings."),
    17: ("retain", ["social-cultural"], "The overview compares public regulation of individual behaviour across alcohol, tobacco and food, providing social-behavioural policy context rather than agriculture instruction."),
    18: ("retain", ["reasoning-decisions", "social-cultural"], "The overview directly examines personal-responsibility beliefs, framing, incentives and government influence on food choices."),
    19: ("supporting", ["social-cultural"], "The overview focuses on legal and public-health implementation examples and policy selection. Retained as an optional policy background source rather than substantial psychological instruction."),
    20: ("retain", ["social-cultural", "development"], "The overview includes research on how school food environments and policy changes influence children's nutrition; retained as environmental influence on behaviour."),
    21: ("retain", ["emotion-motivation-sleep"], "The overview directly concerns eating cues and food-intake behaviour. Scope inclusion is not a reliability endorsement of the speaker's research; the claims have not been scientifically assessed."),
    22: ("supporting", ["social-cultural"], "The overview describes local food and access projects. It is useful implementation context, without substantial specified psychological instruction."),
    23: ("supporting", ["social-cultural"], "The overview is a broad course conclusion about food-system change, labelling laws and local action. It remains background context rather than a separate qualified psychological explanation."),
}

def receipt(row, inspection, prefix="boundary"):
    r = row["retrieval"]
    body = (ROOT / r["cachePath"]).read_bytes()
    assert hashlib.sha256(body).hexdigest() == r["sha256"]
    return {
        "id": f"{prefix}-{row['id'].split(':')[-1]}",
        "url": r["url"], "retrievedAt": r["retrievedAt"], "sha256": r["sha256"],
        "cachePath": r["cachePath"], "inspection": inspection, "checker": CHECKER,
    }

for row in rows:
    course = row.get("parentCourse")
    if course not in {"yale-food", "yale-evolution-behaviour"}:
        continue
    n = int(re.search(r"Lecture (\d+)", row["title"])[1])
    p = receipt(row, "Read the actual cached publisher overview and verified its retrieval SHA-256; no viewing or scientific assessment.")
    soup = BeautifulSoup((ROOT / p["cachePath"]).read_bytes(), "html.parser")
    actual = soup.select_one(".session-full__body").get_text(" ", strip=True)
    assert actual == row["descriptionEvidence"]["excerptForPrivateAudit"]
    if course == "yale-food":
        action, topics, reason = food[n]
        cluster = "yale-food-background" if action == "supporting" else "yale-food-methods" if n in {3, 4, 12} else "yale-food-behaviour"
        if n == 8:
            p["inspection"] = "Read publisher overview and transcript opening through the start of Chapter 2, approximately 12,000 characters. The overview duplicates lecture 7; the distinct transcript supports this scope decision. No full transcript/video or scientific assessment."
    else:
        action = "supporting" if n in {18, 19, 29, 30, 31} else "retain"
        cluster = "yale-evolution-background" if action == "supporting" else "yale-evolution-behaviour" if n >= 32 else "yale-evolution-foundations"
        topics = ["evolution-comparative"]
        if n in {15, 16}: topics.append("methods")
        if n in {32, 33}: topics.append("reasoning-decisions")
        reason = clusters[cluster]["rationale"]
    records[row["id"]] = {"action": action, "reason": reason, "topics": topics, "topicMode": "replace", "subjectAssignmentBasis": "Individual publisher overview inspected for topical relevance; this is a scope decision, not a description or science validation.", "checkedAt": STAMP, "checker": CHECKER, "clusterId": cluster, "checkSources": [p]}

# Individually inspected title/ID mappings reported by the independent sample.
mit = next(x for x in rows if x["id"] == "youtube:zPPsdsAQBx4")
p = receipt(mit, "Verified the cached official lecture title Social Psychology II and exact YouTube destination; title-level topic correction only.", "topic-fix")
text = (ROOT / p["cachePath"]).read_text()
assert "Social Psychology II" in text and "zPPsdsAQBx4" in text
records[mit["id"]] = {"action":"topic-correction", "reason":"The individual official title explicitly establishes social psychology, which was missing from the broad course tags. The broad parent-course topics remain separately on the course entity.", "topics":["social-cultural"], "topicMode":"replace", "checkedAt":STAMP, "checker":CHECKER, "checkSources":[p]}

finding_five = next(x for x in rows if x["id"] == "youtube:SlkQZlr6NEI")
p = receipt(finding_five, "Read the actual individual publisher description and exact video link: the workshop demonstrates web-based behavioural experiments, participant/data management and research paradigms. Topic refinement only; no software trial or video viewing.", "topic-fix")
actual = BeautifulSoup((ROOT / p["cachePath"]).read_bytes(), "html.parser").get_text(" ", strip=True)
assert "web-based experiments" in actual and "SlkQZlr6NEI" in (ROOT / p["cachePath"]).read_text()
records[finding_five["id"]] = {"action":"topic-correction", "reason":"The inspected workshop description centres on designing and running online behavioural studies. Methods is the individual topic; broad neuroscience/computation tags belong to the parent collection.", "topics":["methods"], "topicMode":"replace", "checkedAt":FOLLOWUP_STAMP, "checker":CHECKER, "checkSources":[p]}

nptel = json.loads((ROOT / "data/audits/nptel/reviewed-candidates.json").read_text())
nptel_receipts = json.loads((ROOT / "data/audits/nptel/source-retrievals.json").read_text())
fixes = {"XIV3tdGdREQ":["neuroscience"], "7Uk5kX4ogss":["language"], "X_kV21ZJ5jI":["language","neuroscience"], "5R0b_oXH2BM":["methods","social-cultural"], "c9NLN458TJs":["methods"], "BZuHRRuETuU":["individual-differences","evolution-comparative"]}
for row in nptel:
    vid = row["id"].split(":")[-1]
    if vid not in fixes: continue
    r = next(x for x in nptel_receipts if x["url"] == row["sourceUrl"] and x["sha256"] == row["descriptionEvidence"]["sha256"])
    cache = r["privateReceiptFile"].removesuffix(".receipt.json")
    body = (ROOT / cache).read_bytes()
    assert hashlib.sha256(body).hexdigest() == r["sha256"]
    text = body.decode()
    assert row["title"] in text and f'youtube_id:"{vid}"' in text
    p = {"id":f"topic-fix-{vid}", "url":r["url"], "retrievedAt":r["retrievedAt"], "sha256":r["sha256"], "cachePath":cache, "inspection":"Inspected the exact official lesson object, its title and YouTube ID. Title-level topic correction only; no video or transcript inspection.", "checker":CHECKER}
    reason = f"The exact source-listed lesson title explicitly supports the {', '.join(fixes[vid])} topic assignment. Broader parent-course topics remain separately on the course entity."
    if vid == "c9NLN458TJs":
        reason = "The exact lesson object concerns communicating user-research insights in the research synthesis/analysis sequence. Methods is supported by the title and specific outline context; an individual perception/action lesson is not established."
        p["inspection"] = "Inspected the exact lesson title/YouTube object and its position beside research synthesis and quantitative-analysis lessons in the User Research Methods outline; no transcript/video inspection."
    if vid == "BZuHRRuETuU":
        reason = "The exact title concerns heredity and environment in behaviour. Individual differences and evolution/genetics provide the bounded topical context; broad mental-health, perception, learning and social tags are not individually established."
    records[f"youtube:{vid}"] = {"action":"topic-correction", "reason":reason, "topics":fixes[vid], "topicMode":"replace", "checkedAt":FOLLOWUP_STAMP if vid in {"c9NLN458TJs","BZuHRRuETuU"} else STAMP, "checker":CHECKER, "checkSources":[p]}

for key, cluster in clusters.items():
    cluster["resourceIds"] = [id for id, d in records.items() if d.get("clusterId") == key]
out = {"schemaVersion":1, "checkedAt":FOLLOWUP_STAMP, "reviewer":CHECKER, "scope":"50 individually inspected Yale source overviews, one transcript opening and eight individually grounded topic corrections; no inference of scientific validation.", "clusters":clusters, "records":records}
(ROOT / "data/audits/normalisation/record-decisions.json").write_text(json.dumps(out, ensure_ascii=False, indent=2)+"\n")
print(json.dumps({"decisions":len(records), "supporting":sum(d["action"]=="supporting" for d in records.values()), "retained":sum(d["action"]=="retain" for d in records.values()), "topicCorrections":sum(d["action"]=="topic-correction" for d in records.values())}))
