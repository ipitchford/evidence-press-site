"""Bounded official-page retrieval; private text cache, no video scraping."""
import datetime, hashlib, json, pathlib, subprocess, sys, urllib.parse

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / 'data/audits/editorial-mind'
CACHE = OUT / 'private-cache'
CACHE.mkdir(parents=True, exist_ok=True)

def fetch(url):
    host = urllib.parse.urlsplit(url).hostname or ''
    if host.endswith(('youtube.com', 'youtu.be', 'googlevideo.com')):
        raise ValueError('Use the authorised metadata adapter; no watch-page scraping.')
    key = hashlib.sha256(url.encode()).hexdigest()
    body, receipt = CACHE / (key + '.html'), CACHE / (key + '.json')
    if body.exists() and receipt.exists():
        return json.loads(receipt.read_text())
    result = subprocess.run(['curl','-L','--fail','--silent','--show-error','--retry','1','--max-time','45','--max-filesize','3000000','--output',str(body),'--write-out','%{http_code}\n%{url_effective}',url], capture_output=True, text=True)
    lines = result.stdout.splitlines()
    data = body.read_bytes() if body.exists() else b''
    report = {'url':url,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'httpStatus':int(lines[0]) if lines else None,'finalUrl':lines[1] if len(lines)>1 else None,'exitCode':result.returncode,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest() if data else None,'cachePath':str(body.relative_to(ROOT)) if data else None,'error':result.stderr[:500] or None,'method':'Official source text GET; no media playback or transcript download from YouTube'}
    receipt.write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__ == '__main__':
    for url in sys.argv[1:]: print(json.dumps(fetch(url)))
