"""Write individually authored checks; no automatic scientific assessment."""
import datetime, hashlib, json, pathlib

ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=ROOT/'data/audits/editorial-mind'
source_rows=json.loads((OUT/'inspected-source-sections.json').read_text())
courses={r['id']:r for r in json.loads((ROOT/'data/audits/courses/course-register.json').read_text())}

def level_evidence(row):
    """Editorial demands, grounded in inspected descriptions and prerequisites."""
    course=row['courseId']
    if course=='mit-probability-2010':
        url='https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/pages/syllabus/'
        receipt=json.loads((OUT/'private-cache'/(hashlib.sha256(url.encode()).hexdigest()+'.json')).read_text())
        return 'intermediate', 'Editorial judgement: the official syllabus assumes no previous probability, but requires 18.02 or a year of college-level calculus; these opening lectures develop a formal mathematical model.', receipt, 'Syllabus General Information and Prerequisites sections read; not inferred from the title.'
    if course=='yale-game-theory':
        return 'intermediate', 'Editorial judgement: the official course requires introductory microeconomics and uses one-variable calculus, probability and expectation. The introductory subject title does not mean that no preparation is needed.', courses[course]['sourceCheck'], 'About the Course and Requirements sections read, including explicit mathematics and economics prerequisites.'
    if course=='yale-human-nature':
        return 'foundation', 'Editorial judgement: the inspected lecture overview introduces and explains the relevant philosophical positions and psychological examples within a Yale College survey. Read the assigned texts; this is not a claim that every argument is easy or that no preparation is useful.', courses[course]['sourceCheck'], 'Course description and requirements read alongside the individual lecture Overview; introductory conceptual exposition, not a formal prerequisite certification.'
    if course=='yale-psychology-2007':
        return 'foundation', 'Editorial judgement: the official course describes a comprehensive introductory overview of thought and behaviour, and the inspected lecture Overview introduces the relevant topic rather than presupposing specialist research training.', courses[course]['sourceCheck'], 'About the Course and Requirements sections read alongside the individual lecture Overview.'
    return 'foundation', 'Editorial judgement: the inspected MIT introductory psychology Session Overview introduces the main concepts and the chapter sequence moves from basic definitions to examples. This is a starting survey, not advanced specialist training.', row['source'], row['inspected']

# Each entry below was composed after reading its own retrieved publisher passage.
# Format: description, selection reason, topic families, specific caution (optional).
ANNOTATIONS={
'nM3rTU927io':[
 'Introduces strategic interaction by separating players, available actions and payoffs, then comparing a prisoners’ dilemma with a coordination problem.',
 'Begin here before using a payoff table: the class examples show why changing participants’ goals can change the kind of problem being modelled.',
 ['reasoning-decisions','social-cultural']],
'qQ3kFydI_xQ':[
 'Develops strategic reasoning through dominated strategies, assumptions about other players and the distinction between knowledge and common knowledge.',
 'Use after the introductory game to make the information assumptions explicit; predicting another person requires more than assigning that person a payoff.',
 ['reasoning-decisions','social-cultural']],
'kqDu0RVWTYw':[
 'Applies repeated elimination of dominated strategies to a model of electoral competition and introduces choosing a best response to a belief about another player.',
 'A useful model-criticism exercise: the source explicitly asks how well the electoral model describes politics before extending its assumptions.',
 ['reasoning-decisions','methods']],
'YYUPc-cfPyc':[
 'Works through best responses using penalty kicks and a profit-sharing partnership, leading towards the idea of Nash equilibrium.',
 'Provides concrete practice connecting a belief about someone else’s action to one’s own choice; follow it with the formal equilibrium definition.',
 ['reasoning-decisions']],
'Ac2vCCuf8-s':[
 'Defines Nash equilibrium and uses an investment game to examine coordination, multiple equilibria and undesirable collective outcomes.',
 'Choose this when a learner confuses equilibrium with a good outcome; the comparison with a prisoners’ dilemma also clarifies when communication might help.',
 ['reasoning-decisions','social-cultural']],
'7oASpaBdDMs':[
 'Applies Nash equilibrium to a coordination game and to Cournot competition, discussing collusion and the consequences of different market arrangements.',
 'A further worked application for learners who can already identify best responses. The contrast between games is more useful here than memorising an equilibrium label.',
 ['reasoning-decisions']],
'pMRMYi1SoQs':[
 'Compares price competition with spatial models of customers and voters, including a classroom candidate-entry game.',
 'Use to practise identifying what a model holds fixed and what participants can choose; the lecture varies those ingredients across related settings.',
 ['reasoning-decisions','social-cultural']],
'pglQ_E0g8PY':[
 'Moves from electoral location to Schelling’s segregation game and then introduces randomised choices through mixed strategies.',
 'Connect individual choice rules to collective patterns, while retaining the source’s warning that apparently minor modelling details can change the result.',
 ['reasoning-decisions','social-cultural','computation-ai']],
'unvJofv0wl8':[
 'Uses tennis to derive mixed-strategy equilibria and explains why the pure strategies used in an optimal mixture must have equal expected payoffs.',
 'A focused bridge from probability-weighted payoffs to strategic randomisation; attempt the worked game before continuing to other interpretations of mixtures.',
 ['reasoning-decisions','methods']],
'9b2AMWwMToc':[
 'Distinguishes three interpretations of mixed strategies: actual randomisation, uncertainty about a player and proportions of a population using different actions.',
 'Watch when an equilibrium calculation is clear but its interpretation is not. The tax-auditing example helps separate a model’s mathematics from its behavioural meaning.',
 ['reasoning-decisions','methods']],
'er9KvYn4ldk':[
 'Introduces evolutionary stability and relates it to domination and Nash equilibrium. Yale flags a notation error in the informal argument and supplies a correction in the accompanying notes.',
 'Useful for comparing strategic equilibrium with resistance to invasion by a new strategy; read the official correction rather than treating the spoken notation as definitive.',
 ['reasoning-decisions','evolution-comparative'],
 'Publisher correction: the overview states that U(Ŝ,S′) in the informal argument should be U(S′,Ŝ). This is a reported source correction, not a fresh proof audit.'],
'5sK9W0viyu0':[
 'Applies evolutionary stability to conventions and Hawk–Dove games, then considers a setting without an evolutionarily stable population.',
 'Follow the preceding stability lecture to see why stability need not mean a single uniform behaviour, and why some games instead motivate population dynamics.',
 ['reasoning-decisions','evolution-comparative']],
'5tGh7wd2zOU':[
 'Introduces sequential decisions and backward induction through lending, incentives and commitment examples.',
 'The starting point for the sequential-game part of the course: draw the decision tree and identify later choices before analysing the earlier move.',
 ['reasoning-decisions']],
'aIq0E3OmNz4':[
 'Applies backward induction to sequential quantity competition and examines how commitment and information affect apparent first-mover advantages.',
 'Choose this to test the claim that acting first is always beneficial; the publisher overview explicitly distinguishes timing from commitment and information.',
 ['reasoning-decisions','methods']],
'Bm8lM73lTmk':[
 'Discusses solutions to finite perfect-information games, defines strategies in sequential games and examines equilibrium threats that may not be credible.',
 'A useful transition from solving a decision tree to questioning which equilibrium predictions remain plausible when later decisions are reached.',
 ['reasoning-decisions','methods']],
'SE7kP7XZuV4':[
 'Studies reputation in the chain-store paradox and a pre-emption game, using uncertainty about other players to revisit credible promises and threats.',
 'Extends backward induction beyond a fully known opponent. Compare the model’s assumptions with the lecture’s discussion of overconfidence rather than conflating them.',
 ['reasoning-decisions','social-cultural'],
 'The overview reports classroom and behavioural examples; their scientific generality has not been assessed here.'],
'XpEmuxE4qWk':[
 'Builds a bargaining model from ultimatum offers to alternating offers, making patience, discounting and knowledge of the bargaining surplus explicit.',
 'A strong assumptions exercise: the equal-split conclusion in the overview is conditional, and changing patience, information or resources changes the bargaining analysis.',
 ['reasoning-decisions','social-cultural']],
'D7aDIZ-KPEU':[
 'Uses information sets to represent what players cannot distinguish, then introduces subgame perfection for games with sequential and simultaneous components.',
 'Watch after basic sequential games to learn why drawing moves in time order does not by itself describe what a decision-maker knows.',
 ['reasoning-decisions','methods']],
'hw014me49ks':[
 'Applies subgame-perfect equilibrium to examples involving mistakes, matchmaking and investment, including how an investment changes competitors’ choices.',
 'Provides worked practice after the formal definition; compare an action’s direct effect with the indirect effect produced by other players’ responses.',
 ['reasoning-decisions']],
'wR8dqbc6mlQ':[
 'Analyses wars of attrition in short and potentially continuing games, asking why costly conflict can persist under particular rational-choice assumptions.',
 'Useful for separating an unpleasant outcome from a diagnosis of irrationality. Reconstruct the assumed payoffs before applying the lesson to any real conflict.',
 ['reasoning-decisions','social-cultural']],
'zNxVVVk5It0':[
 'Examines repeated games, end-of-game incentives and the use of future outcomes to sustain present cooperation.',
 'Start the repeated-game sequence here: it distinguishes a known final round from an uncertain continuation and shows why that distinction changes incentives.',
 ['reasoning-decisions','social-cultural']],
'NBKr-wK-TEQ':[
 'Continues repeated-game analysis with credible rewards and punishments, contrasting severe and milder punishment strategies as relationships endure.',
 'Use after the end-game lecture to ask whether a promised future response would actually be optimal when its time arrives.',
 ['reasoning-decisions','social-cultural']],
'RWxTJsTbK2w':[
 'Studies communication under asymmetric information, contrasting verifiable disclosure with costly signals and discussing education as a signalling example.',
 'A route into evaluating messages by the sender’s incentives. Treat the education example as a specified model, not a verdict on every purpose of education.',
 ['reasoning-decisions','learning-memory','social-cultural']],
'pJAhnc8VuDo':[
 'Compares auction formats and distinguishes common-value from private-value settings, using a classroom auction to introduce the winner’s curse.',
 'A concrete application of conditional reasoning: ask what winning itself tells a bidder about the estimate on which the bid was based.',
 ['reasoning-decisions','methods']],
'mUHYlyacMmA':[
 'Tamar Gendler introduces a course connecting philosophy, psychology, behavioural economics and literature through flourishing, morality and political thought.',
 'A useful orientation before the more specialised lectures: it makes clear when the course is asking what people do and when it is asking what they ought to do.',
 ['reasoning-decisions','consciousness-philosophy']],
'1ojnSKzI2BE':[
 'Compares several historical and modern ways of dividing motives or mental processes, including accounts associated with Plato, Hume, Freud and Haidt.',
 'Use as conceptual history before a dual-process discussion; the different divisions should be compared as proposals, not treated as interchangeable anatomical facts.',
 ['reasoning-decisions','consciousness-philosophy'],
 'The source juxtaposes historical theories and simplified psychological divisions; inclusion does not endorse any of them as a current neuroscientific model.'],
'znE88LapbTs':[
 'Introduces sampling bias, dual-process accounts, the Wason task and framing examples before explaining Gendler’s distinction between alief and belief.',
 'A cross-disciplinary entry to reasoning errors: it places a problem of sampling beside claims about how people reason, encouraging scrutiny of both evidence and explanation.',
 ['reasoning-decisions','methods']],
'reZA81S0zfI':[
 'Connects Aristotle’s account of acquiring virtue with habituation and comparisons to conditioning and parenting practices.',
 'Choose for the question of how deliberate commitments might become routine; distinguish the philosophical ideal from the empirical learning mechanisms used as analogies.',
 ['learning-memory','reasoning-decisions','consciousness-philosophy']],
'C8yNxXAm7F4':[
 'Continues Aristotle’s account of virtue, discusses pleasure and flow, and introduces a situationist challenge to stable character.',
 'Pairs well with the preceding habit lecture and a modern traits resource, because it separates having a repeated behaviour from the stronger claim of possessing a virtue.',
 ['individual-differences','reasoning-decisions','consciousness-philosophy']],
'xp3m7e9T72k':[
 'Discusses weakness of will, delay of gratification and discounting, then presents several proposed ways of structuring self-regulation.',
 'A source for comparing explanations of procrastination with proposed changes to incentives or opportunities; the 2011 examples need their historical date retained.',
 ['reasoning-decisions','learning-memory'],
 'This is a 2011 course discussion, not a current systematic review of delay-of-gratification studies or a guarantee of effective self-help.'],
'K60AdYPVNWk':[
 'Introduces moral theories and examines Mill’s utilitarianism through a dilemma about aggregate happiness and individual suffering.',
 'Use to define a possible standard for evaluating a choice before comparing it with psychological findings about choices people actually make.',
 ['reasoning-decisions','consciousness-philosophy']],
'rc-vSvT0YuE':[
 'Contrasts a criticism of utilitarianism with an introduction to Kant’s account of moral duty and the agent’s will.',
 'An explicit alternative evaluative framework for the decision-making route; compare its criterion with an outcome-based rule before interpreting disagreement as bias.',
 ['reasoning-decisions','consciousness-philosophy']],
'rzGksx_yZ6A':[
 'Continues the categorical imperative and introduces the trolley problem through Foot’s and Thomson’s proposed responses.',
 'Useful for identifying exactly which feature of a decision changes between thought experiments; avoid treating a classroom intuition as an empirical population estimate.',
 ['reasoning-decisions','consciousness-philosophy']],
'lIlRWR9vNtE':[
 'Compares three non-classic responses to the trolley problem that use different methods to examine apparently conflicting judgements.',
 'Choose after the original problem to practise comparing explanatory methods as well as conclusions; the lecture’s stated purpose is not simply to collect another intuition.',
 ['reasoning-decisions','consciousness-philosophy','methods']],
'Zzi-BIaAljY':[
 'Discusses heuristics in risk regulation and then introduces puzzles about shielding, ducking and moral luck.',
 'A useful limit case for a bias-based explanation: ask whether identifying a heuristic resolves a normative problem or leaves a further question about responsibility.',
 ['reasoning-decisions','consciousness-philosophy']],
'6w7DrbaVwTc':[
 'Examines the prisoners’ dilemma and the commons as cases where individually attractive choices can produce a collectively worse result.',
 'Pairs the philosophy course with Yale’s formal game-theory introduction, giving learners two presentations of the same strategic tension without claiming they are separate discoveries.',
 ['reasoning-decisions','social-cultural']],
'7emS3ye3cVU':[
 'Paul Bloom introduces Freud’s psychoanalytic ideas, their limitations and the historical role of unconscious mental processes in psychology.',
 'Useful historical comparison for later accounts of personality and automatic processing; Freud’s proposals are attributed rather than presented as established mechanisms.',
 ['individual-differences','consciousness-philosophy'],
 'The lecture is from the 2007 introductory course. It is historical teaching, not current clinical guidance.'],
'rCKK6r15fro':[
 'Introduces Skinner and behaviourism, compares forms of learning and discusses why behaviourism alone is insufficient for the course’s account of mental life.',
 'Begin a conditioning route here if the learner needs the historical debate before distinguishing particular experimental learning procedures.',
 ['learning-memory']],
'Uf9tlbMckS0':[
 'Introduces language through sounds, word structure, sentence structure and recursion, alongside arguments about acquisition and specialisation.',
 'A broad starting lecture for connecting a language’s structure to questions about learning it. Its brain, mouth and hands framing also helps avoid equating all language with speech.',
 ['language']],
'AMsQfgV07vU':[
 'Introduces an evolutionary perspective on psychology and discusses how evolutionary arguments are used to constrain explanations of behaviour and choice.',
 'Use as a theoretical comparison when evaluating a decision rule: identify the proposed adaptive problem and then ask what evidence would distinguish the explanation.',
 ['reasoning-decisions','evolution-comparative'],
 'The overview describes the course’s arguments, not an independent assessment of each evolutionary explanation.'],
'piDznzrNymE':[
 'Surveys personality and intelligence measurement and the course’s discussion of genetic and environmental explanations for differences between people.',
 'Provides a broad 2007 comparison before separate trait and intelligence guides; retain the date and check particular empirical claims in more focused sources.',
 ['individual-differences'],
 'The publisher’s phrase “latest theories” refers to the course’s 2007 context; it is not retained as a claim of currentness.'],
'jsrB5m3mL-A':[
 'Introduces social psychology through connectedness and biases in thinking about oneself and other people.',
 'Use alongside decision-bias material to distinguish a judgement about social information from a purely numerical probability problem.',
 ['reasoning-decisions','social-cultural']],
'SBrCPDC21f4':[
 'Surveys classical and operant conditioning, their limits, learned helplessness and delayed gratification in MIT’s 2011 introductory psychology course.',
 'The session outline moves from basic procedures to their limits, making it useful for comparing what a conditioning experiment explains with broader claims about learning.',
 ['learning-memory'],
 'Historical experiments and applied examples are included; this annotation checks the session’s subject and selection purpose, not current evidence for every example.'],
'gRe7dy2HSTg':[
 'Connects speech perception and meaning with the brain basis of language, language difficulties and acquisition, including infant and bilingual examples.',
 'A useful bridge from linguistic structure to brain and behavioural questions; the official chapter headings let learners see these distinct levels before specialising.',
 ['language','neuroscience']],
'qZdm4mpQA_8':[
 'Uses problems and puzzles to examine functional fixedness, heuristics, anchoring and framing, with a brief discussion of frontal-lobe contributions.',
 'A practical starting point for a reasoning-bias guide: compare an answer with the task’s assumptions before naming a supposed bias.',
 ['reasoning-decisions']],
'bihrpOS0qtY':[
 'Examines intelligence tests and models, including test validity, biological and environmental interpretations, and debates about educational interventions.',
 'Useful for separating an operational test score from a theory of intelligence. The 2011 examples should be checked individually before making current policy claims.',
 ['individual-differences','methods'],
 'Includes historically situated claims about group differences and interventions; no inference about an individual or group is endorsed by catalogue inclusion.'],
'Vko17una2Zw':[
 'Introduces ways of measuring personality and discusses trait dimensions, temperament, biological contributions and learning in MIT’s 2011 course.',
 'Choose for the distinction between a trait dimension and a categorical personality label, then compare the dated teaching material with more recent source checks.',
 ['individual-differences','methods'],
 'The session answer key asserts particular birth-order effects. Those claims are not carried into this annotation or treated as settled current evidence.'],
'j9WZyLZCBzs':[
 'Introduces probability as a mathematical model, develops its axioms and works through introductory examples.',
 'Start here before using probability as a standard for evaluating uncertain judgements; explicit events and assumptions prevent intuitive words from replacing a model.',
 ['methods','reasoning-decisions']],
'TluTv5V0RmE':[
 'Introduces conditional probability, the multiplication rule, total probability and Bayes’ rule.',
 'The mathematical continuation for a learner asking how new evidence should change a belief; reconstruct the conditioning event before substituting numbers.',
 ['methods','reasoning-decisions']],
'19Ql_Q3l0GA':[
 'Distinguishes independence of two events, independence of a collection and pairwise independence.',
 'A useful follow-up to conditioning because many informal probability arguments silently assume independence; the lecture separates several meanings of that assumption.',
 ['methods','reasoning-decisions']]
}

assert len(ANNOTATIONS)==50,len(ANNOTATIONS)
assert {x['id'].split(':')[1] for x in source_rows}==set(ANNOTATIONS)
checked=datetime.datetime.now(datetime.timezone.utc).isoformat()
overrides={}; receipts=[]
for row in source_rows:
    vid=row['id'].split(':')[1]; description,reason,topics,*caution=ANNOTATIONS[vid]
    source=row['source']; raw=(ROOT/source['cachePath']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==source['sha256']
    evidence_id='mind-core-'+vid
    check_source={'id':evidence_id,'url':row['sourceUrl'],'retrievedAt':source['retrievedAt'],'sha256':source['sha256'],'inspection':row['inspected'],'cachePath':source['cachePath'],'checker':'agent'}
    level,level_basis,level_source,level_inspection=level_evidence(row)
    assert hashlib.sha256((ROOT/level_source['cachePath']).read_bytes()).hexdigest()==level_source['sha256']
    level_check={'id':'mind-level-'+hashlib.sha256(level_source['url'].encode()).hexdigest()[:16],'url':level_source['url'],'retrievedAt':level_source['retrievedAt'],'sha256':level_source['sha256'],'inspection':level_inspection,'cachePath':level_source['cachePath'],'checker':'agent'}
    note='Individually checked against retrieved publisher material; no full-video viewing, independent scientific appraisal or human peer review.'
    if caution: note+=' '+caution[0]
    overrides[row['id']]={'description':description,'descriptionCheck':{'status':'checked','method':'publisher-description','checkedAt':checked,'checker':'agent','evidenceIds':[evidence_id],'note':note},'selection':{'basis':'institutional-collection','reason':reason,'checkedAt':checked,'checker':'agent','evidenceIds':[evidence_id],'subjectAssignmentBasis':'Individual publisher overview or session outline, not channel-wide attribution.'},'topics':topics,'checkSources':[check_source]}
    overrides[row['id']].update(level=level,levelBasis=level_basis)
    overrides[row['id']]['checkSources'].append(level_check)
    receipts.append({'resourceId':row['id'],'title':row['title'],'sourceUrl':row['sourceUrl'],'sourceSha256':source['sha256'],'sourceRetrievedAt':source['retrievedAt'],'checkedAt':checked,'checker':'agent','materialInspected':row['inspected'],'descriptionDecision':description,'selectionDecision':reason,'sourceSpecificCaution':caution[0] if caution else None,'accessibilityCheck':'Separate authorised metadata or endpoint evidence; not established by this editorial check.','scientificAssessment':'Not assessed'})
    receipts[-1].update(level=level,levelBasis=level_basis,levelEvidence=level_check)
(OUT/'core-overrides.json').write_text(json.dumps(overrides,ensure_ascii=False,indent=2)+'\n')
(OUT/'core-check-receipts.json').write_text(json.dumps({'checkedAt':checked,'checker':'agent','records':receipts,'counts':{'uniqueIndividuallyChecked':len(receipts),'viewedVideos':0,'fullTranscriptsRead':0},'boundary':'These 50 title/content-scope and selection checks are not scientific validation; qualified accessible-core count remains dependent on destination evidence.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'overrides':len(overrides),'distinct':len(set(overrides)),'sourceHashesVerified':len(receipts),'scientificAssessment':'Not assessed'}))
