"""Assemble source-grounded writing and explicit item-level editorial receipts."""
import datetime,hashlib,json,pathlib,re
from guide_routes import GUIDES,PATHS
from guide_bodies import BODIES,META
from path_writing import PATH_WRITING
from reading_register import SOURCES
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=ROOT/'data/audits/editorial-mind'
DATE=datetime.datetime.now(datetime.timezone.utc).isoformat()
CATALOGUE={r['id'].replace('yt:','youtube:'):r for r in json.loads((ROOT/'data/audits/courses/candidates.json').read_text())}
NPTEL={}
for f in (ROOT/'data/audits/nptel').glob('course-*.json'):
    d=json.loads(f.read_text())
    if not isinstance(d,dict) or not d.get('course'): continue
    NPTEL[d['course']['id']]=d['course']
    CATALOGUE.update({r['id'].replace('yt:','youtube:'):r for r in d.get('candidates',[])})
CORE={r['id']:r for r in json.loads((OUT/'inspected-source-sections.json').read_text())}
COURSES={r['id']:r for r in json.loads((ROOT/'data/audits/courses/course-register.json').read_text())}

def verified_source(title,rec,inspection):
    assert rec.get('cachePath'),(title,rec)
    assert hashlib.sha256((ROOT/rec['cachePath']).read_bytes()).hexdigest()==rec['sha256'],title
    return {'id':'mind-source-'+hashlib.sha256(rec['url'].encode()).hexdigest()[:16], 'title':title,'url':rec['url'],'retrievedAt':rec['retrievedAt'],'sha256':rec['sha256'],'inspection':inspection,'cachePath':rec['cachePath']}

def video_source(vid):
    cid='youtube:'+vid; r=CATALOGUE[cid]
    if cid in CORE:
        c=CORE[cid]
        return verified_source(c['title']+' — official publisher material',c['source'],c['inspected'])
    if vid=='76O3rulk844':
        src=json.loads((ROOT/'data/audits/courses/core-overrides.json').read_text())[cid]['checkSources'][-1]
        return verified_source('MIT Memory I — session overview',src,'Session Overview, keywords and chapter headings read for this guide, including categories, retention and interference. Not a full transcript or video viewing.')
    course=NPTEL[r['parentCourse']]
    rec=dict(course['sourceEvidence']);rec['cachePath']='data/raw/nptel/course-'+course['nptelId']+'.html'
    basis='Official course description, relevant syllabus entries and ordered lecture outline inspected; selection uses the named topic and sequence, not an invented account of the recording.' if course.get('courseDescription') else 'Official ordered lecture outline and course attribution inspected. No substantive course description was supplied; the item is selected for its named topic and place in the outline only.'
    return verified_source(course['title']+' — official course outline',rec,basis+' No individual transcript read or video viewed.')

def course_source(course):
    if course in NPTEL:
        c=NPTEL[course];rec=dict(c['sourceEvidence']);rec['cachePath']='data/raw/nptel/course-'+c['nptelId']+'.html'
        return verified_source(c['title']+' — course context',rec,'Course description where present, attribution and ordered outline inspected; no claim of full-course viewing.')
    c=COURSES[course]
    return verified_source(c['title']+' — course context',c['sourceCheck'],'Official course description and requirements inspected. Course year is not asserted to be the exact recording date of every item.')

def sources_for(ids,reading,course=None):
    sources=[video_source(v) for v in ids]
    sources.extend(SOURCES[k] for k in reading)
    if course in ['yale-game-theory','yale-human-nature','yale-psychology-2007']: sources.append(course_source(course))
    if course=='mit-probability-2010' or any(v in ['j9WZyLZCBzs','TluTv5V0RmE','19Ql_Q3l0GA'] for v in ids):
        url='https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/pages/syllabus/'
        rec=json.loads((OUT/'private-cache'/(hashlib.sha256(url.encode()).hexdigest()+'.json')).read_text())
        sources.append(verified_source('MIT probability — syllabus and prerequisites',rec,'General Information and Prerequisites sections inspected, including no previous probability and the required year of college-level calculus.'))
    # Preserve distinct evidence IDs but deduplicate the same URL/checksum.
    return list({(s['url'],s['sha256']):s for s in sources}.values())

SCOPES={
'practice-that-lasts':'Turn a small piece of study into an attempt, a comparison with the source and a later check; keep the task aligned with the intended understanding.',
'what-conditioning-explains':'Distinguish cue–outcome learning, action–outcome learning and broader uses of the word habit before judging what an experiment explains.',
'align-teaching-and-assessment':'Design one lesson whose intended outcome, practice task and assessment call for the same kind of thinking.',
'what-learning-analytics-can-tell-us':'Connect recorded learning traces to a defensible educational question, distinguishing measurement, prediction and evidence of improvement.',
'speech-and-language':'Separate a communication medium from linguistic structure, meaning and context, then locate perception and production within that map.',
'recognising-and-retrieving-words':'Ask what knowing a word involves and how recognition, retrieval and production tasks make different demands on that knowledge.',
'resolving-sentence-ambiguity':'Represent more than one interpretation of a sentence and distinguish that structural problem from explaining comprehension over time.',
'bilingual-language-control':'Examine how a language-use task is controlled while keeping acquisition history and claims of general cognitive benefit distinct.',
'how-children-acquire-language':'Connect theories of acquisition with observable evidence, especially when children cannot explain what they know.',
'when-is-a-choice-biased':'Specify the information, goal and comparison rule before interpreting a response as a judgement bias.',
'habits-intentions-and-procrastination':'Compare philosophical, learning and time-preference accounts without turning an explanatory model into a moral diagnosis or a treatment claim.',
'choices-that-depend-on-others':'Make a small strategic model explicit, then separate best responses, equilibrium and desirable outcomes.',
'reasoning-with-uncertain-information':'Build a probability model, condition on information and expose independence assumptions before comparing formal rules with human judgements.',
'what-intelligence-tests-measure':'Distinguish a performance, a score, a construct and a causal explanation when reading intelligence claims.',
'personality-dimensions-without-boxes':'Describe traits as dimensions supported by observations, with context and change still visible.'}
LIMITS={
'practice-that-lasts':'CMU supplies a teaching synthesis rather than an individually audited set of trials. The exercise is a study routine, not an effect-size estimate. The NPTEL retrieval item has an ordered title listing but no substantive individual description.',
'what-conditioning-explains':'The introductory MIT and Yale teaching dates are 2011 and 2007. The Noba sections support the distinctions; the philosophical habit analogy is not treated as experimental confirmation or clinical guidance.',
'align-teaching-and-assessment':'The plan can reveal a mismatch, but it cannot show that learners improved before outcomes are observed. Official course outlines establish selected topics; a course’s pedagogical commitments are not adopted as universal consensus.',
'what-learning-analytics-can-tell-us':'SoLAR’s definition is dated 2026. The source check does not validate any predictive model, implementation or educational intervention. NPTEL selections use named topics and their official sequence; no real learner data are required.',
'speech-and-language':'The Yale and MIT introductions date from 2007 and 2011. Their inclusion maps concepts, not the present standing of every empirical claim. The Noba language-use section was inspected directly; NPTEL topic selection uses course outlines.',
'recognising-and-retrieving-words':'The textbook section supplies a conceptual account of learned linguistic information. It does not by itself identify a storage location or settle a processing model. NPTEL selection is based on ordered official outlines, not a review of experimental results within recordings.',
'resolving-sentence-ambiguity':'The worked structural example was read directly. Course outlines establish the parsing sequence, but no full transcript was read. A structural interpretation or introspective preference is not a processing mechanism or population estimate.',
'bilingual-language-control':'The 2018 adult meta-analysis was checked at abstract level via official NCBI XML; the full paper and subsequent literature were not exhaustively reviewed. Language-control videos were selected from official ordered course outlines. No broad cognitive advantage is promised.',
'how-children-acquire-language':'The inspected textbook explains indirect behavioural measures and acknowledges developmental variation. This is not a milestone checklist or assessment of an individual child. NPTEL lecture topics were checked in official outlines rather than full recordings.',
'when-is-a-choice-biased':'The foundational psychology and philosophy lectures are dated teaching material. Examples and definitions do not establish current effect sizes or universal mechanisms; the exercise illustrates a comparison, not a population result.',
'habits-intentions-and-procrastination':'The principal Yale discussion is from 2011. Proposed self-regulation strategies are not presented as a current intervention review. NPTEL titles establish the time-preference sequence without certifying every claim inside it.',
'choices-that-depend-on-others':'The Yale course is from Fall 2007 and formally requires introductory microeconomics, calculus and probability preparation. Its model-based predictions are conditional on assumptions and not automatically empirical descriptions or personal advice.',
'reasoning-with-uncertain-information':'The official transcript was read only in its opening conceptual portion. Its filename and course-page year differ, so no precise recording date is inferred. MIT’s full course requires college calculus; linked assignments were identified, not solved or independently audited.',
'what-intelligence-tests-measure':'The guide uses introductory measurement explanations and older teaching, not a current systematic review. Quantitative group-difference, intervention and genetic claims were not adopted. A fictional task set is not an intelligence test.',
'personality-dimensions-without-boxes':'The MIT teaching is from 2011. Only summary sections of the 2015 and 2025 birth-order papers were inspected; their different measures and samples do not establish a universal rule. The exercise does not assess real people.'}
EXERCISE_TITLES={
'practice-that-lasts':'Attempt, compare and revisit',
'what-conditioning-explains':'Separate cue, action and outcome',
'align-teaching-and-assessment':'Repair a lesson mismatch',
'what-learning-analytics-can-tell-us':'Audit a fictional learning dataset',
'speech-and-language':'Disentangle signal, structure and context',
'recognising-and-retrieving-words':'Map what you know about a word',
'resolving-sentence-ambiguity':'Give one sentence two structures',
'bilingual-language-control':'Specify a switching comparison',
'how-children-acquire-language':'Compare an utterance and its explanations',
'when-is-a-choice-biased':'Change a frame, hold the outcomes fixed',
'habits-intentions-and-procrastination':'Draw competing explanations on a timeline',
'choices-that-depend-on-others':'Change one payoff',
'reasoning-with-uncertain-information':'Update a table of counts',
'what-intelligence-tests-measure':'Design tasks before interpreting a score',
'personality-dimensions-without-boxes':'Separate behaviour from a trait inference'}

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def supporting(key):
    s=SOURCES[key]
    return {'id':s['id'],'title':s['title'],'url':s['displayUrl'],'kind':'reading','reason':s['reason']}
def minimal_source(s):
    return {k:s[k] for k in ['id','title','url','retrievedAt','sha256','inspection','cachePath']}
def resource_check(vid,reason):
    r=CATALOGUE['youtube:'+vid];s=video_source(vid)
    return {'resourceId':'youtube:'+vid,'sourceTitle':r['title'],'courseId':r['parentCourse'],'sourceId':s['id'],'sourceUrl':s['url'],'sourceSha256':s['sha256'],'inspection':s['inspection'],'selectionDecision':reason}

def main():
    assert len(GUIDES)==15 and len(PATHS)==6
    assert set(BODIES)==set(SCOPES)==set(LIMITS)==set(EXERCISE_TITLES)=={g['slug'] for g in GUIDES}
    index={'checkedAt':DATE,'guides':[],'paths':[],'boundary':'Editorial source/selection checks by an agent; no human peer review, no full-video viewing and no independent scientific assessment. Access is checked separately by the authorised metadata adapter.'}
    for g in GUIDES:
        slug=g['slug'];audience,prereqs,terms,neighbours,next_step=META[slug];reading=list(g['reading']);ids=[g['start']]+[r[0] for r in g['resources']]
        if slug=='personality-dimensions-without-boxes':reading+=['birth-order-2015','birth-order-2025']
        if slug=='reasoning-with-uncertain-information':reading+=['probability-assignments'];prereqs=prereqs+['MIT’s full probability course requires a year of college-level calculus; the fictional counts exercise itself uses fractions and algebra.']
        if slug=='choices-that-depend-on-others':prereqs=['Comfort reading a small table for the opening exercise.','The Yale course requires introductory microeconomics and uses one-variable calculus, probability and expectation; later selections should be approached with that preparation.']
        sources=sources_for(ids,reading,g['course']);body=BODIES[slug];source_urls={s['url'] for s in sources}|{s.get('displayUrl') for s in sources}
        inline=re.findall(r'\]\((https?://[^)]+)\)',body)
        assert set(inline)<=source_urls,(slug,set(inline)-source_urls)
        assert len(set(ids))==len(ids)
        receipt='data/editorial-checks/guides/'+slug+'.json'
        method_key='acquisition-exercise' if slug=='how-children-acquire-language' else 'probability-assignments' if slug=='reasoning-with-uncertain-information' else reading[0]
        content={'slug':slug,'title':g['title'],'question':g['title'],'topics':g['topics'],'audience':audience,'scope':SCOPES[slug],'status':'reviewed','startingResourceId':'youtube:'+g['start'],'startingReason':g['startReason'],'resources':[{'id':'youtube:'+v,'purpose':p,'reason':r} for v,p,r in g['resources']],'body':body,'courseId':g['course'],'supporting':[supporting(k) for k in reading],'methodsOrExercise':{'title':EXERCISE_TITLES[slug],'instructions':g['exercise'],'url':SOURCES[method_key]['displayUrl']},'prerequisites':prereqs,'keyTerms':[{'term':t,'meaning':m} for t,m in terms],'neighbours':neighbours,'nextStep':next_step,'limits':LIMITS[slug]+' Source checks establish scope and selection usefulness; they do not claim full-video viewing, human review or scientific validation.','sources':[minimal_source(s) for s in sources],'check':{'date':DATE[:10],'checker':'agent','materialInspected':'Individual publisher overviews for selected Yale/MIT material; ordered official NPTEL outlines and available course descriptions; the specifically identified supporting reading sections. Each source record states its inspection limit.','receipt':receipt}}
        checks=[resource_check(g['start'],g['startReason'])]+[resource_check(v,r) for v,p,r in g['resources']]
        report={'slug':slug,'checkedAt':DATE,'checker':'agent','status':'completed editorial source check','bodySha256':hashlib.sha256(body.encode()).hexdigest(),'wordCount':len(body.split()),'question':g['title'],'claimDecisions':[{'claim':c,'basis':[SOURCES[k]['id'] for k in reading]+[video_source(g['start'])['id']],'limit':LIMITS[slug]} for c in g['claims']],'resourceDecisions':checks,'sourceChecks':[minimal_source(s) for s in sources],'exerciseDecision':{'title':EXERCISE_TITLES[slug],'purpose':g['exercise'],'boundary':'Original pedagogical exercise; not a validated assessment, trial or diagnostic procedure.'},'bodyReview':'Read the original body and checked the cited passages and distinctions against the recorded sources; kept historical, abstract-only and outline-only limits visible. Checked resource sequence and named topic against actual source records.','structuralChecks':{'canonicalIdsResolved':len(ids),'distinctResources':len(set(ids)),'inlineLinksBackedByRetrievedSources':len(inline),'sourceHashesVerified':len(sources)},'scientificAssessment':'Not assessed','accessibility':'Independent authorised metadata checks supply current availability; no playback verified by this receipt.'}
        dump(ROOT/'content/guides'/(slug+'.json'),content);dump(ROOT/receipt,report);index['guides'].append({'slug':slug,'receipt':receipt,'bodyWords':len(body.split()),'resources':len(ids),'sources':len(sources)})
    for p in PATHS:
        slug=p['slug'];w=PATH_WRITING[slug];ids=p['ids'];assert len(ids)==len(w['steps']) and len(set(ids))==len(ids)
        course='yale-game-theory' if slug=='strategic-interaction' else None
        sources=sources_for(ids,w['reading'],course);receipt='data/editorial-checks/paths/'+slug+'.json'
        steps=[{'resourceId':'youtube:'+vid,'reason':reason,'task':task} for vid,(reason,task) in zip(ids,w['steps'])]
        content={'slug':slug,'title':p['title'],'topics':w['topics'],'audience':w['audience'],'description':p['distinctive'],'prerequisites':w['prerequisites'],'objectives':w['objectives'],'status':'reviewed','steps':steps,'shortRoute':{'stepNumbers':w['short'][0],'reason':w['short'][1]},'continuation':{'text':w['continuation'][0],'url':w['continuation'][1]},'sources':[minimal_source(s) for s in sources],'limits':w['limits']+' This is an agent editorial check, not human peer review or independent scientific assessment.','check':{'date':DATE[:10],'checker':'agent','materialInspected':'The recorded official publisher overviews/course outlines and supporting reading sections; the sequence, reasons and tasks were checked individually. No full-video viewing.','receipt':receipt}}
        report={'slug':slug,'checkedAt':DATE,'checker':'agent','status':'completed editorial source check','sequenceSha256':hashlib.sha256(json.dumps(steps,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'distinctiveQuestion':p['distinctive'],'objectives':w['objectives'],'resourceDecisions':[dict(resource_check(vid,reason),taskDecision=task,step=i+1) for i,(vid,(reason,task)) in enumerate(zip(ids,w['steps']))],'shortRouteDecision':content['shortRoute'],'sourceChecks':[minimal_source(s) for s in sources],'limits':content['limits'],'structuralChecks':{'canonicalIdsResolved':len(ids),'distinctResources':len(set(ids)),'sourceHashesVerified':len(sources),'noEstimatedDurations':True},'scientificAssessment':'Not assessed','accessibility':'Availability remains a separate authorised metadata check; these source receipts do not assert playback.'}
        dump(ROOT/'content/paths'/(slug+'.json'),content);dump(ROOT/receipt,report);index['paths'].append({'slug':slug,'receipt':receipt,'steps':len(ids),'sources':len(sources)})
    dump(OUT/'editorial-completion.json',index)
    print(json.dumps({'guides':len(index['guides']),'paths':len(index['paths']),'guideBodyWords':sum(g['bodyWords'] for g in index['guides']),'pathSteps':sum(p['steps'] for p in index['paths'])}))
if __name__=='__main__':main()
