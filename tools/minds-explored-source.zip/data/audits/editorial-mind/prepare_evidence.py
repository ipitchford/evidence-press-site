"""Reconcile the exact source passages used in individual editorial checks."""
import hashlib, json, pathlib, re
from bs4 import BeautifulSoup

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / 'data/audits/editorial-mind'
records = json.loads((ROOT/'data/audits/courses/candidates.json').read_text())
sessions = {json.loads(p.read_text())['url']:json.loads(p.read_text()) for p in (OUT/'private-cache').glob('*.json')}
psych = {'SBrCPDC21f4':'learning', 'gRe7dy2HSTg':'language-1', 'qZdm4mpQA_8':'thinking', 'bihrpOS0qtY':'intelligence', 'Vko17una2Zw':'personality'}
rows=[]
for record in records:
    match=re.match(r'Lecture (\d+)',record['title']); n=int(match[1]) if match else 0
    course=record['parentCourse']; vid=record['id'].split(':')[1]
    selected=(course=='yale-game-theory' or (course=='yale-human-nature' and n in [1,3,4,9,10,11,12,13,14,15,16,20]) or (course=='yale-psychology-2007' and n in [3,4,6,10,13,16]) or vid in psych or (course=='mit-probability-2010' and n in [1,2,3]))
    if not selected: continue
    receipt=record['retrieval']
    if vid in psych:
        receipt=sessions[f'https://ocw.mit.edu/courses/9-00sc-introduction-to-psychology-fall-2011/pages/{psych[vid]}/']
    data=(ROOT/receipt['cachePath']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==receipt['sha256']
    soup=BeautifulSoup(data,'html.parser')
    if course.startswith('yale-'):
        section=soup.select_one('.session-full__body')
        passage=section.get_text(' ',strip=True)
        inspected='Official lecture Overview paragraph. Transcript is linked or included on the page but was not read in full; video not viewed.'
    elif vid in psych:
        section=soup.select_one('#course-content-section') or soup.select_one('main')
        text=section.get_text(' ',strip=True)
        passage=text.split('Session Overview',1)[-1].split('Session Activities',1)[0].strip()+' Chapter headings: '+text.split('View by Chapter',1)[-1].split('Video Resources',1)[0].strip()
        inspected='Official Session Overview and lecture chapter headings, including the exact full-video link; not a full transcript or viewing.'
    else:
        meta=soup.find('meta',attrs={'name':'description'})
        passage=meta.get('content','') if meta else ''
        if not passage: passage=record['descriptionEvidence']['excerptForPrivateAudit']
        inspected='Official resource page description and explicit instructor attribution; not a full transcript or viewing.'
    rows.append({'id':record['id'],'title':record['title'],'courseId':course,'sourceUrl':receipt['url'],'recordSourceUrl':record['sourceUrl'],'source':receipt,'inspected':inspected,'privateSourcePassage':passage})
assert len(rows)==50,(len(rows),[r['id'] for r in rows])
(OUT/'inspected-source-sections.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'records':len(rows),'uniqueIds':len({r['id'] for r in rows}),'sourceHashesVerified':len(rows),'boundary':'Private source excerpts; checks become editorial only after individual annotations are written and inspected.'}))
