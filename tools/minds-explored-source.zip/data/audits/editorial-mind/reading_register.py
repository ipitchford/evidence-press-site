"""Actually inspected supporting texts; retrieval identity and inspection are separate."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=ROOT/'data/audits/editorial-mind'
# key: title, URL, provider, inspection, use. All wording is original.
READINGS={
'retrieval':('Retrieval practice — Carnegie Mellon Eberly Center','https://www.cmu.edu/teaching/resources/instructionalstrategies/activelearningstrategies/retrievalpractice/','cmu-eberly','Definition, evidence discussion, task formats and implementation guidance read; not every cited primary study retrieved.','Use the task examples to design an attempt to recall and a check of the answer.'),
'alignment':('Align assessments, objectives and instructional strategies — Carnegie Mellon','https://www.cmu.edu/teaching/assessment/basics/alignment.html','cmu-eberly','Main explanation and alignment table read.','Compare the operation in an objective with the operation required by practice and assessment.'),
'solar':('What is learning analytics? — Society for Learning Analytics Research','https://www.solaresearch.org/about/what-is-learning-analytics/','solar','2026 definition, descriptive/predictive/prescriptive distinctions and ethics discussion read.','Start with the educational purpose and measurement question before choosing a model.'),
'conditioning':('Conditioning and learning — Mark E. Bouton','https://nobaproject.com/modules/conditioning-and-learning','noba','Learning objectives and sections on classical/instrumental conditioning, extinction, goal-directed control, habit and observational learning read.','Compare the experimentally specified learning relations and their limits.'),
'language-use':('Language and language use — Yoshihisa Kashima','https://nobaproject.com/textbooks/daniel-kay-new-textbook/modules/language-and-language-use','noba','Introduction and How Do We Use Language section read, including common ground, conversational coordination and audience design.','Add shared context and coordination to explanations of linguistic form.'),
'intelligence':('Intelligence — Noba','https://nobaproject.com/textbooks/rachael-long-introduction-to-psychology-the-full-noba-collection/modules/intelligence','noba','Defining intelligence and historical/measurement sections read, including standardisation and sampled performances; quantitative group and causal claims not adopted.','Use the measurement history to distinguish a score from a model and a causal explanation.'),
'personality':('Personality traits — Ed Diener and Richard E. Lucas','https://nobaproject.com/textbooks/jack-arnal-introduction-to-psychology-the-full-noba-collection/modules/personality-traits','noba','Trait dimensions, five factors, facets and person–situation discussion read.','Compare broad dimensions, narrower facets and variation across situations.'),
'decisions':('Judgment and decision making — Noba','https://nobaproject.com/textbooks/sobia-ali-faisal-new-textbook/modules/judgment-and-decision-making','noba','Proposed rational procedure and sections/examples on confidence, anchoring and framing read.','State a comparison rule before calling a judgement biased.'),
'lexicon':('7.4 The mental lexicon — Essentials of Linguistics, second edition','https://ecampusontario.pressbooks.pub/essentialsoflinguistics2/chapter/7-4-the-mental-lexicon/','essentials-linguistics','Rendered chapter body on stored linguistic information, predictable rules, morphemes and idioms read. Hash identifies the saved rendered-source bundle, not raw HTML.','Distinguish learned item-specific knowledge from information predicted by a rule.'),
'ambiguity':('6.17 Structural ambiguity in syntax — Essentials of Linguistics','https://ecampusontario.pressbooks.pub/essentialsoflinguistics2/chapter/structural-ambiguity/','essentials-linguistics','Rendered chapter explanation and prepositional-phrase attachment example read. Hash identifies the saved rendered-source bundle, not raw HTML.','Represent two interpretations with different phrase structures before proposing a processing explanation.'),
'acquisition':('11.2 When does language learning start? — Essentials of Linguistics','https://ecampusontario.pressbooks.pub/essentialsoflinguistics2/chapter/11-2-when-does-language-learning-start/','essentials-linguistics','Rendered chapter body on habituation, high-amplitude sucking, prosody and developmental variation read. Hash identifies the saved rendered-source bundle, not raw HTML.','Ask how researchers infer a discrimination from an infant’s observable response.'),
'acquisition-exercise':('11.11 Exercise your linguistics skills — Essentials of Linguistics','https://ecampusontario.pressbooks.pub/essentialsoflinguistics2/chapter/11-11-exercise-your-linguistics-skills/','essentials-linguistics','Rendered chapter exercises comparing child and adult utterances read. Hash identifies the saved rendered-source bundle, not raw HTML.','Practise making an explicit comparison without using an exercise to diagnose a child.'),
'bilingual-review':('Lehtonen and colleagues (2018): bilingualism and executive functioning in adults','https://pubmed.ncbi.nlm.nih.gov/29494195/','ncbi','Full abstract inspected via official NCBI efetch XML, not the full paper. The abstract reports small pre-correction effects and no advantage after its publication-bias correction; this is a dated synthesis, not a current exhaustive review.','Keep language-control questions separate from a broad cognitive-advantage claim.'),
'birth-order-2015':('Rohrer and colleagues (2015): examining birth-order effects on personality','https://pmc.ncbi.nlm.nih.gov/articles/PMC4655522/','ncbi','Significance and summary sections inspected; full paper and analyses not independently reviewed.','Compare the measures and samples with both the older lecture claim and the later study.'),
'birth-order-2025':('Ashton and Lee (2025): personality differences, birth order and sibship size','https://pmc.ncbi.nlm.nih.gov/articles/PMC11725879/','ncbi','Significance and abstract/summary inspected; full paper and analyses not independently reviewed. Published online in December 2024 and in a 2025 issue.','Notice that a different personality instrument and sample can change what a birth-order comparison means.'),
'yale-game-reading':('Ben Polak: summary of the first Game Theory class, Fall 2007','https://oyc.yale.edu/sites/default/files/summary%20of%20first%20class.pdf','open-yale','Text from the three-page PDF read: outcomes/payoffs, preferences, dominance, coordination and prisoners’ dilemma. Some mathematical symbols were imperfectly extracted; no numerical matrix is reproduced.','Distinguish the physical outcome from its value to each player.'),
'probability-reading':('MIT: Conditioning and Bayes’ Rule lecture transcript','https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/92ff13dc0bfc3bc78a6844399e48e146_TluTv5V0RmE.pdf','mit-ocw','Opening conceptual portion of the official transcript read (approximately first 7,000 extracted characters), covering models, assumptions and partial information; not the complete transcript. Filename mentions F11 despite the course URL; no exact recording date inferred.','Read the opening discussion of how observations change the probability question.'),
'probability-assignments':('MIT probability: assignments and solutions','https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/pages/assignments/','mit-ocw','Assignment index inspected: eleven problem sets with linked solutions; the problem-set PDFs were not solved or checked in this source review.','Attempt the early course problems before reading the linked solutions.')
}

def source_for(key):
    title,url,provider,inspection,reason=READINGS[key]
    if key in ['lexicon','ambiguity','acquisition','acquisition-exercise']:
        fname='pressbooks-lexicon-ambiguity.json' if key in ['lexicon','ambiguity'] else 'pressbooks-rendered-body.json'
        cache=OUT/'private-cache'/fname
        d=json.loads(cache.read_text())
        assert url in d['result'],url
        rec={'url':url,'retrievedAt':d['retrievedAt'],'sha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'cachePath':str(cache.relative_to(ROOT)),'method':d['method']}
    else:
        actual='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=29494195&retmode=xml' if key=='bilingual-review' else url
        receipt=OUT/'private-cache'/(hashlib.sha256(actual.encode()).hexdigest()+'.json')
        rec=json.loads(receipt.read_text())
        assert rec.get('cachePath') and rec.get('httpStatus')==200,(key,rec)
        assert hashlib.sha256((ROOT/rec['cachePath']).read_bytes()).hexdigest()==rec['sha256'],key
    return {'id':'mind-reading-'+key,'title':title,'url':rec['url'],'displayUrl':url,'retrievedAt':rec['retrievedAt'],'sha256':rec['sha256'],'inspection':inspection,'cachePath':rec['cachePath'],'providerId':provider,'kind':'reading','reason':reason,'method':rec.get('method')}

SOURCES={key:source_for(key) for key in READINGS}
if __name__=='__main__':
    resources=[]
    for key,s in SOURCES.items():
        resources.append({'id':s['id'],'title':s['title'],'url':s['displayUrl'],'providerId':s['providerId'],'kind':'reading','reason':s['reason'],'inspection':s['inspection'],'sourceEvidence':{k:v for k,v in s.items() if k not in ['reason','providerId','kind','displayUrl']},'scientificAssessment':'Not assessed'})
    (OUT/'supporting-resources.json').write_text(json.dumps(resources,ensure_ascii=False,indent=2)+'\n')
    (OUT/'supporting-source-checks.json').write_text(json.dumps(SOURCES,ensure_ascii=False,indent=2)+'\n')
    print('Supporting sources checked:',len(resources))
