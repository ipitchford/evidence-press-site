#!/usr/bin/env python3
"""Bounded, resumable official NPTEL source-page acquisition. No video downloads.

Dependencies already available in this environment: beautifulsoup4, json5.
HTML/script strings are parsed as data; no remote JavaScript is executed.
Run from project root: python3 data/audits/nptel/acquire.py
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import argparse, hashlib, json, re, subprocess, time
from bs4 import BeautifulSoup
import json5

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'data/audits/nptel'
RAW = ROOT / 'data/raw/nptel'
RAW.mkdir(parents=True, exist_ok=True)
FORCE_REFRESH = False
OFFLINE = False

GROUPS = {
    'neuroscience': '102104099 102105100 108105185 102106023 102106066 102106345 102108071 108108167 127104003 127105779 127106001',
    'psychology': '109103001 109103136 109103152 109103182 109103540 109103736 109104093 109104121 109104123 109104126 109104151 109105118 109105204 109106403 109107204 109103395 109103598 109104029 109104048 109104070 109104082 109104105 109104108 109104171 109104607 109104878 109105884 109107399 109101007 109101015 109102157 109103134 109103142',
    'language-and-communication': '109103753 109103189 109103198 109104398 109104143 109106063 109106083 109106085 109106091 109106182 109105205 109107132',
    'philosophy-and-research-foundations': '109101003 109101004 109105396 109103184',
    'evolution': '102106002 102106751 103101127 127101592',
    'research-methods': '106104844 103106112 103106120 102106051 111102112 111102143 111104120 111106415 109107741 109105115',
    'learning-and-education': '127101003 127106533 127108781 106101224 127101012 127101013 127108015',
    'social-and-cultural-behaviour': '109106180 109106204 109103002 109105113 109104074 110107759 110103433 110106145 110105154',
}
# A second bounded screen fills explicit subject/method gaps after syllabus and
# ordered-title inspection. It does not import generic AI or engineering courses.
GROUPS['neuroscience'] += ' 109106401 112104293'
GROUPS['psychology'] += ' 109105116 110105074 110105054'
GROUPS['language-and-communication'] += ' 109105495'
GROUPS['research-methods'] += ' 107103001 127105237 110105060 111105091'
GROUPS['social-and-cultural-behaviour'] += ' 109107740 110105034 110105144'
SELECTION = {course_id: group for group, ids in GROUPS.items() for course_id in ids.split()}

def utc():
    return datetime.now(timezone.utc).isoformat()

def save_json(path, obj):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)

def fetch(url, name):
    target = RAW / name
    receipt_path = RAW / (name + '.receipt.json')
    if target.exists() and receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        if not FORCE_REFRESH and receipt.get('status') == 200 and receipt.get('sha256') == hashlib.sha256(target.read_bytes()).hexdigest():
            return target, receipt
    if OFFLINE:
        raise RuntimeError('No valid cached source for offline replay: '+url)
    tmp = target.with_suffix(target.suffix + '.part')
    started = utc()
    result = subprocess.run(['curl', '-L', '--silent', '--show-error', '--max-time', '45', '--retry', '1', '--retry-delay', '2', '--max-filesize', '6000000', '-w', '%{http_code}\n%{url_effective}', '-o', str(tmp), url], capture_output=True, text=True)
    parts = result.stdout.splitlines()
    status = int(parts[0]) if parts and parts[0].isdigit() else None
    receipt = {'url': url, 'finalUrl': parts[1] if len(parts)>1 else None, 'retrievedAt': utc(), 'startedAt': started, 'status': status, 'curlExit': result.returncode, 'error': result.stderr.strip() or None, 'method': 'GET official source page; not video playback'}
    if tmp.exists():
        tmp.replace(target)
        receipt.update(bytes=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest())
    save_json(receipt_path, receipt)
    time.sleep(0.7)
    if result.returncode or status != 200:
        raise RuntimeError(json.dumps(receipt))
    return target, receipt

def object_after(text, marker):
    start = text.find(marker)
    if start < 0:
        raise ValueError('Missing marker ' + marker)
    start = text.find('{', start + len(marker))
    depth = 0; quoted = False; escape = False
    for end in range(start, len(text)):
        c = text[end]
        if quoted:
            if escape: escape = False
            elif c == '\\': escape = True
            elif c == '"': quoted = False
        elif c == '"': quoted = True
        elif c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: return json5.loads(text[start:end+1])
    raise ValueError('Unclosed data object')

def plain(html):
    return BeautifulSoup(html or '', 'html.parser').get_text(' ', strip=True)

def acquire_course(pair):
    cid, group = pair
    url = f'https://nptel.ac.in/courses/{cid}'
    try:
        path, receipt = fetch(url, 'course-' + cid + '.html')
        course = object_after(path.read_text(), 'courseOutline:')
        syllabus = course.get('syllabus') or {}
        meta = {x['label']:x['value'] for x in syllabus.get('meta',[])}
        abstract = plain(syllabus.get('aboutHtml'))
        courses = {'id':'nptel:'+cid,'nptelId':cid,'title':course.get('title'),'sourceUrl':url,'providerId':'nptel','institution':course.get('instituteName'),'speaker':course.get('professor'),'contentType':course.get('contentType'),'subjectFamily':group,'language':meta.get('Language'),'statedLevel':meta.get('Level'),'courseDuration':meta.get('Duration'),'courseDescription':abstract,'prerequisitesAndAudience':syllabus.get('facts',[]),'weeks':syllabus.get('weeks',[]),'readingsText':plain(syllabus.get('booksHtml')),'sourceEvidence':receipt,'qualificationStatus':'source-listed course; lectures require destination checks','currentRun':course.get('currentRun'),'recordingDate':None,'uploadDate':None}
        lessons=[]; excluded=[]
        for unit_order, unit in enumerate(course.get('units') or []):
            for order, lesson in enumerate(unit.get('lessons') or []):
                vid=lesson.get('youtube_id');name=lesson.get('name') or ''
                if not vid or not re.fullmatch(r'[A-Za-z0-9_-]{11}',vid):
                    excluded.append({'courseId':cid,'title':name,'reason':'No valid canonical YouTube ID supplied in source outline','rawId':vid});continue
                if re.search(r'^(?:course introduction|about (?:the )?course|promo|trailer|how to register|feedback session|exam information)\b',name,re.I):
                    excluded.append({'courseId':cid,'title':name,'youtubeId':vid,'reason':'Administrative or promotional title; not a substantive lecture'});continue
                lessons.append({'id':'yt:'+vid,'title':name,'canonicalUrl':'https://www.youtube.com/watch?v='+vid,'sourceUrl':url,'providerId':'nptel','institution':course.get('instituteName'),'speaker':course.get('professor'),'parentCourse':'nptel:'+cid,'courseTitle':course.get('title'),'unitTitle':unit.get('name'),'unitOrder':unit_order+1,'lessonOrder':order+1,'sourceLessonId':lesson.get('id'),'subjectFamilies':[group],'level':meta.get('Level'),'language':meta.get('Language'),'format':'lecture','durationSeconds':None,'uploadDate':None,'recordingDate':None,'transcriptStatus':'unknown','description':None,'descriptionEvidence':{'kind':'official course outline and syllabus','sourceUrl':url,'sha256':receipt['sha256'],'inspected':'ordered lecture title and parent-course syllabus; no video viewed or transcript read'},'selectionBasis':'institutional-collection','selectionReason':'A substantive listed lecture in a deliberately selected in-scope NPTEL course; parent-course context is preserved. Individual explanatory annotation remains pending.','availability':{'status':'unknown','checkedAt':receipt['retrievedAt'],'method':'official-source-outline-only','sourcePageAccessible':True,'destinationChecked':False,'playbackVerified':False},'retrievedAt':receipt['retrievedAt'],'scientificAssessment':'not-assessed','qualificationStatus':'candidate','rights':{'licence':'NPTEL CC BY-NC-SA site notice; preserve source terms and individual exceptions','publicExport':'factual title, URL and attribution only; no full course prose or video redistribution by this adapter'}})
        save_json(OUT/f'course-{cid}.json',{'course':courses,'candidates':lessons,'exclusions':excluded})
        return {'course':courses,'candidates':lessons,'exclusions':excluded}
    except Exception as exc:
        return {'failedCourseId':cid,'sourceUrl':url,'subjectFamily':group,'error':str(exc),'checkedAt':utc()}

def main():
    global FORCE_REFRESH, OFFLINE
    ap=argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group()
    mode.add_argument('--refresh',action='store_true',help='Re-fetch selected official source pages, replacing dated private caches')
    mode.add_argument('--offline',action='store_true',help='Rebuild solely from cached responses with matching SHA-256')
    args=ap.parse_args();FORCE_REFRESH=args.refresh;OFFLINE=args.offline
    save_json(OUT/'selection.json',{'createdAt':utc(),'selection':'Explicit editorial title screening of the official catalogue; no whole-channel import. Source-listed courses are further inspected through syllabuses. Generic engineering, mechanical behaviour, off-topic AI, programming-language and statistical-physics title matches were not included.','courses':[{'id':k,'family':v} for k,v in SELECTION.items()]})
    fetch('https://nptel.ac.in/courses','courses.html')
    for name,url in [('aboutus.html','https://nptel.ac.in/aboutus'),('faq.html','https://nptel.ac.in/faq'),('archive-footer.html','https://archive.nptel.ac.in/footer.html')]:
        try:fetch(url,name)
        except Exception as exc:print('Source page failure:',name,str(exc),flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(acquire_course,SELECTION.items()))
    courses=[x['course'] for x in results if 'course' in x]
    candidates=[r for x in results for r in x.get('candidates',[])]
    exclusions=[r for x in results for r in x.get('exclusions',[])]
    failures=[x for x in results if 'failedCourseId' in x]
    ids={r['id'] for r in candidates}
    duplicates={k:[{'course':r['parentCourse'],'title':r['title']} for r in candidates if r['id']==k] for k in ids if sum(r['id']==k for r in candidates)>1}
    save_json(OUT/'courses.json',courses);save_json(OUT/'candidates.json',candidates)
    save_json(OUT/'exclusions.json',exclusions);save_json(OUT/'failures.json',failures);save_json(OUT/'duplicate-course-memberships.json',duplicates)
    summary={'checkedAt':utc(),'selectedCourses':len(SELECTION),'retrievedCourses':len(courses),'failedCourses':len(failures),'sourceListedLectureRows':len(candidates),'distinctCanonicalVideoCandidates':len(ids),'duplicateMembershipIds':len(duplicates),'excludedRows':len(exclusions),'qualifiedAccessibleVideos':0,'boundary':'No YouTube destination requests or video downloads made. Source-page access is not playback verification. Candidates require permitted destination accessibility evidence before release-count qualification.'}
    save_json(OUT/'summary.json',summary);print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
