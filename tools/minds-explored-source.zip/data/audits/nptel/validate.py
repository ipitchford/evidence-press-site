#!/usr/bin/env python3
"""Validate acquired identity/mapping/evidence invariants without network access."""
from pathlib import Path
from urllib.parse import urlparse
from collections import Counter
import hashlib,json,re

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];RAW=ROOT/'data/raw/nptel'
def read(name):return json.loads((HERE/name).read_text())

def main():
    errors=[];r=read('reviewed-candidates.json');ids=[x['id'] for x in r]
    if len(ids)!=len(set(ids)):errors.append('Duplicate reviewed canonical IDs')
    courses={x['id']:x for x in read('reviewed-courses.json')}
    for v in r:
        if not re.fullmatch('yt:[A-Za-z0-9_-]{11}',v['id']):errors.append('Invalid canonical ID '+v['id'])
        if v['canonicalUrl']!='https://www.youtube.com/watch?v='+v['id'][3:]:errors.append('Canonical URL mismatch '+v['id'])
        if v['parentCourse'] not in courses:errors.append('Missing parent course '+v['id'])
        c=courses[v['parentCourse']];p=RAW/('course-'+c['nptelId']+'.html')
        if hashlib.sha256(p.read_bytes()).hexdigest()!=v['descriptionEvidence']['sha256']:errors.append('Course hash mismatch '+v['id'])
        if v['scientificAssessment']!='not-assessed':errors.append('Unjustified assessment '+v['id'])
        if v['recordingDate'] is not None or v['uploadDate'] is not None:errors.append('Unexpected inferred date '+v['id'])
    mappings=read('media-mappings.json');duplicates=[u for u,n in Counter(x['mediaUrl'] for x in mappings).items() if n>1]
    if duplicates:errors.append('Duplicate official media URLs need alternate-upload review: '+str(len(duplicates)))
    for m in mappings:
        if m['id'] not in ids:errors.append('Unreviewed media mapping '+m['id'])
        if urlparse(m['mediaUrl']).netloc!='media.dev.nptel.ac.in':errors.append('Unexpected media host '+m['id'])
        if m['titleSimilarity']<.75:errors.append('Unreviewed title mismatch '+m['id'])
        cid=m['course'].split(':')[1];p=RAW/('downloads-'+cid+'.json')
        if hashlib.sha256(p.read_bytes()).hexdigest()!=m['downloadSourceSha256']:errors.append('Download source hash mismatch '+m['id'])
        data=json.loads(p.read_text())['data']
        matches=[x for x in data['course_downloads'] if str(x.get('lesson_id'))==str(m['sourceLessonId']) and x.get('url')==m['mediaUrl']]
        if len(matches)!=1:errors.append('Source mapping not unique '+m['id'])
    qualified=read('qualified-candidates.json') if (HERE/'qualified-candidates.json').exists() else []
    for v in qualified:
        a=v['availability'];h=ROOT/a['privateHeaderFile'];b=ROOT/a['privateSampleFile'];data=b.read_bytes()
        if hashlib.sha256(data).hexdigest()!=a['sampleSha256']:errors.append('Sample hash mismatch '+v['id'])
        if hashlib.sha256(h.read_bytes()).hexdigest()!=a['headersSha256']:errors.append('Header hash mismatch '+v['id'])
        if not(a['httpStatus']==206 and len(data)==1024 and data[4:8]==b'ftyp' and a['contentType']=='video/mp4' and a['playbackVerified'] is False):errors.append('Insufficient media evidence '+v['id'])
    result={'checkedAt':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'reviewedVideos':len(r),'sourceMappedMedia':len(mappings),'qualifiedChecked':len(qualified),'duplicateOfficialMediaUrls':len(duplicates),'errors':errors,'passed':not errors,'scope':'Schema/identity/source hashes/media mappings and saved range evidence; no network, content watching or scientific validation'}
    (HERE/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if errors:raise SystemExit(1)

if __name__=='__main__':main()
