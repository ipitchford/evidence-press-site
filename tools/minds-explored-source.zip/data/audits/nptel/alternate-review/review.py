#!/usr/bin/env python3
"""Reproduce the bounded alternate-edition audit from saved official evidence.

Read-only on the catalogue and previous audits. No network, API overlay, title
similarity merger, video access or external dependencies are used by this file.
The decisions below are authored review decisions, not inferred identities.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, csv, io

ROOT = Path(__file__).resolve().parents[4]
OUT = ROOT / 'data/audits/nptel/alternate-review'
RAW = ROOT / 'data/raw/nptel/alternate-review'
NOW = datetime.now(timezone.utc).isoformat()
CIDS = ['109106182','109106083','111105091','110105060','106104844','127104003']

def read(p): return json.loads((ROOT/p).read_text())
def digest(p): return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def write(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')

catalogue_path = 'data/catalogue.jsonl'
before = digest(catalogue_path)
catalogue = {r['id']:r for r in map(json.loads,(ROOT/catalogue_path).read_text().splitlines())}
courses = {cid:read('data/audits/nptel/course-'+cid+'.json') for cid in CIDS}
lessons = {cid:{r['sourceLessonId']:r for r in courses[cid]['candidates'] if not r['title'].startswith('Live Session')} for cid in CIDS}
def rid(cid, no): return lessons[cid][no]['id'].replace('yt:','youtube:')
def ids(cid, nos): return [rid(cid,n) for n in nos]

sources = {}
def evidence(cid, kind='course'):
    key = kind+'-'+cid
    if key in sources: return sources[key]
    if kind in ['course','downloads']:
        ext = 'html' if kind=='course' else 'json'
        path='data/raw/nptel/'+kind+'-'+cid+'.'+ext
        receipt=read(path+'.receipt.json')
    elif kind=='syllabus':
        path='data/raw/nptel/alternate-review/syllabus-'+cid+'.pdf'
        receipt=read('data/raw/nptel/alternate-review/syllabus-'+cid+'.receipt.json')
    else: raise ValueError(kind)
    assert receipt['status']==200 and digest(path)==receipt['sha256'],path
    scope={
        'course':'Complete official ordered lesson list and instructor/institution identity inspected. Available individual concepts_covered fields and the embedded syllabus were read; no playback observed.',
        'downloads':'Entire official public downloads response inspected for course/lesson correspondence and actual nonempty transcript URLs. A listed MP4 is not evidence of identical content or playback.',
        'syllabus':'All pages of the official PDF syllabus were extracted and read, including course aims, detailed teaching sequence, instructor and prerequisites. Syllabus correspondence is not recording equivalence.'
    }[kind]
    ev={'id':'nptel-alternate-'+key,'url':receipt['url'],'retrievedAt':receipt['retrievedAt'],'sha256':receipt['sha256'],'inspection':scope,'cachePath':path}
    sources[key]=ev
    return ev

for cid in CIDS:
    evidence(cid);evidence(cid,'downloads')
for cid in ['109106182','109106083','110105060']:evidence(cid,'syllabus')
tr=read('data/raw/nptel/alternate-review/transcript-109106182-37.receipt.json')
assert digest(tr['cachePath'])==tr['sha256']
sources['transcript-109106182-37']={k:tr[k] for k in ['url','retrievedAt','sha256','inspection','cachePath','hashScope']}|{'id':'nptel-alternate-transcript-109106182-37'}

def refs(*keys): return [sources[k] for k in keys]
language_sources=refs('course-109106182','course-109106083','downloads-109106182','downloads-109106083','syllabus-109106182','syllabus-109106083')
stats_sources=refs('course-111105091','course-110105060','downloads-111105091','downloads-110105060','syllabus-110105060')
math_sources=refs('course-106104844','course-127104003','downloads-106104844','downloads-127104003')
unresolved=[]

def hold(cluster, secondary, numbers, primary, primary_numbers, relation, observation, check_sources):
    unresolved.append({
        'clusterId':cluster,'ids':ids(secondary,numbers),'primaryIds':ids(primary,primary_numbers),
        'status':'unresolved-overlap','relationship':relation,'countingAction':'hold-secondary',
        'checkedAt':NOW,'checker':'agent','reason':observation+' This is a conservative distinctness hold, not a finding that the recordings are identical. Keep the documented primary version countable under its existing eligibility rules; retain all secondary source records and links.',
        'checkSources':check_sources,
        'sourcePositions':{'secondaryCourseId':'nptel:'+secondary,'secondarySourceLessonIds':numbers,'primaryCourseId':'nptel:'+primary,'primarySourceLessonIds':primary_numbers},
        'releaseCondition':'Paired source transcripts, an explicit publisher edition/segment correspondence, or sufficiently scoped content comparison establishing unique material or full equivalence. Titles, similar runtimes, an HTTP 200 and common topic alone are insufficient.'
    })

# The official new syllabus repeats the earlier course plan, while its current
# page has a different opening and offset numbering. Every secondary lesson is
# held as an unresolved edition; this intentionally does not assert that the
# opening/administrative lessons or all recordings are duplicates.
language_pairs={1:[1],2:[1],3:[1],4:[2],5:[3],6:[4],7:[4,5],8:[6],9:[7],10:[9],11:[10],12:[11]}
language_pairs.update({n:[n-1] for n in range(13,34)})
language_pairs.update({n:[n] for n in range(34,42)})
for n, primary in language_pairs.items():
    if n<=3:
        obs='The same instructor and institution publish parallel course plans; the new official syllabus follows the older course sequence, but its current page has three opening modules. The extent of unique opening material is not established by the available brief module descriptions.'
    else:
        obs='The official syllabuses identify the same generative-language teaching progression, and the current secondary page supplies a corresponding module description. The earlier course has no nonempty transcript URL in its official downloads response, so a paired content comparison cannot establish this lesson as a distinct recording or a complete alternate.'
    checks=language_sources + ([sources['transcript-109106182-37']] if n==37 else [])
    if n==37:
        obs+=' The secondary transcript was inspected at its opening, its John’s-mother/c-command exchange and its final Principle C discussion; without the primary transcript this confirms content only on one side.'
    hold('language-edition-'+str(n).zfill(2),'109106182',[n],'109106083',primary,'unresolved-course-edition',obs,checks)

# All 67 teaching lectures are accounted for. These are proposed coverage
# correspondences only; paired short parts are never merged into one upload.
stats_groups=[
([1,2],[1],'introductory modelling'),([3,4],[2],'statistical approaches to building models'),
([5,6],[3],'univariate descriptive statistics'),([7,8],[4],'sampling distributions'),
([9],[5],'estimation'),([10],[6],'continued estimation'),([11,12],[7],'hypothesis testing'),
([13,14],[8],'multivariate observations and mean/covariance structure'),([15,16],[9],'multivariate correlation structure'),
([17,18],[10],'multivariate normal distribution'),([19,20],[11],'multivariate normal interpretation and checking'),
([21,22],[12],'multivariate inference and confidence regions'),([23,24],[13],'multivariate confidence intervals and hypothesis tests'),
([25,26],[14],'ANOVA model, assumptions and sum-of-squares decomposition'),([27,28],[15],'ANOVA estimation, adequacy and multi-factor models'),
([29],[18],'ANOVA tutorial'),([30],[19],'continued ANOVA tutorial'),
([31,32],[16],'MANOVA model and cross-products'),([33,34],[17],'MANOVA inference'),([35],[20],'MANOVA case study'),
([36,37],[21],'multiple-regression introduction, assumptions and estimation'),([38,39],[22],'regression-parameter sampling distributions'),
([40,41],[23],'regression model adequacy'),([42],[24],'regression assumptions and remedies'),([43],[25],'leverage, influence and multicollinearity'),([44],[26],'regression case study'),
([45,46],[27],'multivariate-regression model and parameters'),([47,48],[28],'multivariate-regression estimation and sampling distributions'),
([49,50],[29],'multivariate-regression adequacy statistics'),([51],[32],'regression software example using SPSS'),
([52,53],[30],'principal-component model and extraction'),([54,55],[31],'principal-component adequacy and retention'),
([56,57],[33],'factor-model foundations'),([58,59],[34],'factor-model estimation'),([60,61],[35],'factor adequacy, rotation and scores'),
([62,63],[38],'structural-equation-model foundations'),([64,65],[39],'measurement model'),([66,67],[40],'structural model')
]
assert sorted(n for a,_,_ in stats_groups for n in a)==list(range(1,68))
for secondary,primary,topic in stats_groups:
    obs='The official primary syllabus specifies '+topic+' within its modelling sequence; the same instructor’s secondary course follows that sequence, with shorter numbered sections and available concepts-covered notes. The source offers no paired transcript links or explicit statement identifying these as new recordings. Potential segmentation or reuse remains unresolved.'
    if 11 in secondary or 14 in secondary:
        obs+=' A concepts-covered field repeats material from a preceding lesson; it was not treated as a reliable individual equivalence claim.'
    hold('multivariate-edition-'+str(secondary[0]).zfill(2),'111105091',secondary,'110105060',primary,'possible-resegmentation' if len(secondary)>1 else 'possible-full-alternate',obs,stats_sources)

for secondary,primary,topic in [(42,2,'probability axioms'),(44,14,'conditional probability'),(51,11,'probability distributions in R')]:
    hold('math-bayesian-'+str(secondary),'127104003',[secondary],'106104844',[primary],'possible-full-alternate',
        'The two official course pages identify the same instructor and this '+topic+' lesson within their overlapping probability foundations. This candidate was prioritised in the close-runtime review, but the official pages provide neither individual descriptive text nor nonempty transcript links for a paired content check. The mathematical-tools upload is held as the secondary candidate, without inferring identity from the shared title or runtime.',math_sources)

held={rid for x in unresolved for rid in x['ids']}
assert len(held)==111
assert held<=catalogue.keys()
primary={rid for x in unresolved for rid in x['primaryIds']}
assert not held&primary

# Shared subject matter is recorded, but by itself it is not an alternate-upload
# finding. The different course-level aims and granularity remain explicit.
topic_relationships=[
([1],[36,37,38,39,40],'sets and set operations'),
([3,4],[41,43,45],'probability assignment and worked probability'),
([5],[46,47],'random-variable foundations'),
([6],[59],'statistical inference foundations'),
([7],[48],'binomial and Poisson distributions'),
([8,9,10],[49,50],'continuous distributions'),
([12],[54],'likelihood functions'),
([13,17],[55,56,57],'likelihood calculation and R examples'),
([15,16],[60],'Bayesian inference foundations'),
([26],[58],'parameter estimation')
]
relationships=[{'status':'shared-topic-not-an-alternate-finding','action':'no-count-change','bayesianIds':ids('106104844',a),'mathematicalToolsIds':ids('127104003',b),'topic':topic,
    'reason':'The inspected official syllabus gives mathematical-tools a foundations role, whereas the other ordered course develops Bayesian modelling and computation. This is a thematic correspondence, not evidence that the underlying recording is reused. No paired substantive transcript is available, so uniqueness has not been newly proved; no additional alternate assertion or hold is made from topic similarity alone.',
    'checkSources':math_sources} for a,b,topic in topic_relationships]

inventory=[]
for cid in CIDS:
    for r in courses[cid]['candidates']:
        ident=r['id'].replace('yt:','youtube:')
        inventory.append({'courseId':'nptel:'+cid,'sourceLessonId':r['sourceLessonId'],'unitOrder':r['unitOrder'],'lessonOrder':r['lessonOrder'],'id':ident,'title':r['title'],'sourceUrl':r['sourceUrl'],
            'inCurrentCatalogue':ident in catalogue,'decision':'hold-secondary-distinctness' if ident in held else ('retain-existing-no-alternate-finding' if ident in catalogue else 'outside-current-catalogue'),
            'proposedPrimaryIds':sorted({p for x in unresolved if ident in x['ids'] for p in x['primaryIds']}),'sourceEvidenceId':sources['course-'+cid]['id']})

scope_ids={r['id'] for r in inventory if r['inCurrentCatalogue']}
selected={}
for folder in ['guides','paths']:
    for p in (ROOT/'content'/folder).glob('*.json'):
        text=p.read_text()
        for ident in scope_ids:
            if ident in text:selected.setdefault(ident,[]).append(str(p.relative_to(ROOT)))
core_fragments=[]
for p in (ROOT/'data/audits').glob('*/core-overrides.json'):
    d=json.loads(p.read_text())
    matches=sorted(scope_ids&set(d))
    if matches:core_fragments.append({'file':str(p.relative_to(ROOT)),'ids':matches})
assert not selected and not core_fragments

summary={'checkedAt':NOW,'checker':'agent','scopeCourseIds':['nptel:'+c for c in CIDS],
 'sourceListedRows':len(inventory),'distinctSourceIds':len({r['id'] for r in inventory}),
 'currentCatalogueRecordsInScope':len(scope_ids),'confirmedEquivalentMappings':0,'unresolvedGroups':len(unresolved),
 'secondaryRecordsHeld':len(held),'remainingScopeRecordsWithoutNewHold':len(scope_ids-held),
 'holdCountsByCourse':{cid:sum(r['id'] in held for r in catalogue.values() if r.get('courseId')=='nptel:'+cid) for cid in CIDS},
 'selectedGuideOrPathIdsAffected':selected,'coreOverrideIdsAffected':core_fragments,
 'exactIdDuplicateAlreadyCollapsed':{'id':rid('106104844',40),'sourceLessonIds':[40,56],'reason':'The feedback-labelled row repeats the exact canonical ID of lecture 40; it is one record already, not a new alternate mapping.'},
 'outsideCurrentCatalogue':[r for r in inventory if not r['inCurrentCatalogue']],
 'countsBoundary':'Hold counts describe identity decisions, not guaranteed qualified-video losses. Existing scope/accessibility/withdrawal rules remain operative.',
 'evidenceBoundary':'Official source pages, complete syllabuses, source-linked transcript availability metadata and one inspected secondary transcript. No paired transcript or complete recording comparison established equivalence. No API payload or copied API-derived attribute is stored in this audit.',
 'fullVideoDownloads':0,'youtubeWatchPageRequests':0,'catalogueSha256Before':before,'catalogueSha256After':digest(catalogue_path),'catalogueUnchanged':digest(catalogue_path)==before,
 'reproducibleCommand':'python3 data/audits/nptel/alternate-review/review.py'}
assert summary['catalogueUnchanged']
write('alternate-mappings.json',{'version':1,'checkedAt':NOW,'mappings':[],'unresolved':unresolved,
 'primaryEditionPolicy':'Preserve 109106083 and 110105060 as the complete primary course editions. Preserve 106104844 for the three named probability comparisons. This is a counting convention pending content evidence, not a quality ranking or proof of recording age.',
 'screenedTopicalRelationships':relationships,'summary':summary})
write('source-checks.json',{'checkedAt':NOW,'sources':list(sources.values()),'rights':'Source caches and extracted transcript/syllabus text remain private. The public decisions contain authored conclusions, factual identifiers and source receipts only.'})
write('review-inventory.json',{'checkedAt':NOW,'rows':inventory})
write('summary.json',summary)
with (OUT/'review-inventory.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['courseId','sourceLessonId','id','title','inCurrentCatalogue','decision','proposedPrimaryIds'])
    for r in inventory:w.writerow([r[k] for k in ['courseId','sourceLessonId','id','title','inCurrentCatalogue','decision']]+[','.join(r['proposedPrimaryIds'])])
print(json.dumps({k:summary[k] for k in ['sourceListedRows','distinctSourceIds','currentCatalogueRecordsInScope','confirmedEquivalentMappings','unresolvedGroups','secondaryRecordsHeld','remainingScopeRecordsWithoutNewHold','catalogueUnchanged']},indent=2))
