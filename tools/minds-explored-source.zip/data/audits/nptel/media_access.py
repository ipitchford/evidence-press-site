#!/usr/bin/env python3
"""Verify official NPTEL-listed media alternatives using 1 KiB byte-range reads.

No full videos, YouTube requests, credentials, or undocumented private endpoints.
The downloads endpoint is observed in the public course UI's network code; it is
public, unauthenticated and returns is_public. Only its exact listed MP4 URLs on
the observed NPTEL media host can be checked. See REPORT.md for evidence limits.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import urlparse
from difflib import SequenceMatcher
from collections import Counter
import argparse, hashlib, json, re, subprocess, time, unicodedata
import acquire

OUT=acquire.OUT; RAW=acquire.RAW; CHECKS=OUT/'media-checks'
CHECKS.mkdir(exist_ok=True)
def save(name,obj):acquire.save_json(OUT/name,obj)

def norm(s):
    s=unicodedata.normalize('NFKD',s).lower()
    s=re.sub(r'^(?:week\s*\d+\s*:\s*)?(?:lecture|lec|l)\s*\d*\s*[:|.-]?\s*','',s)
    return re.sub(r'[^a-z0-9]+','',s)

def metadata(course):
    cid=course['nptelId']; url='https://nptel.ac.in/api/downloads/'+cid
    try:
        path,receipt=acquire.fetch(url,'downloads-'+cid+'.json')
        d=json.loads(path.read_text()).get('data') or {}
        if d.get('is_public') is not True:raise ValueError('Source does not declare is_public=true')
        if str(d.get('course_id'))!=cid:raise ValueError('Course ID mismatch')
        return {'courseId':course['id'],'sourceUrl':url,'receipt':receipt,'data':d}
    except Exception as exc:return {'courseId':course['id'],'error':str(exc)}

def metadata_all():
    courses=json.loads((OUT/'reviewed-courses.json').read_text())
    courses=[c for c in courses if c['scopeStatus']=='course-context-screened' and c['reviewedCandidateCount']]
    with ThreadPoolExecutor(max_workers=2) as pool:items=list(pool.map(metadata,courses))
    candidates=json.loads((OUT/'reviewed-candidates.json').read_text())
    lookup={x['courseId']:x for x in items if 'data' in x}
    matched=[];unmatched=[]
    for v in candidates:
        d=lookup.get(v['parentCourse']);hit=None
        if d:
            hit=next((x for x in d['data'].get('course_downloads',[]) if str(x.get('lesson_id'))==str(v['sourceLessonId'])),None)
        if not hit or not hit.get('url'):
            unmatched.append({'id':v['id'],'course':v['parentCourse'],'reason':'No nonempty MP4 URL listed for this source lesson ID'});continue
        u=urlparse(hit['url'])
        if not (u.scheme=='https' and u.netloc=='media.dev.nptel.ac.in' and u.path.endswith('.mp4') and not u.query and not u.fragment):
            unmatched.append({'id':v['id'],'course':v['parentCourse'],'reason':'URL outside observed safe media host/path policy','url':hit['url']});continue
        title_similarity=SequenceMatcher(None,norm(v['title']),norm(hit.get('title',''))).ratio()
        if title_similarity<0.75:
            unmatched.append({'id':v['id'],'course':v['parentCourse'],'reason':'Lesson ID matched but title identity requires manual check','sourceTitle':v['title'],'downloadTitle':hit.get('title'),'similarity':title_similarity,'url':hit['url']});continue
        transcripts=[]
        for t in d['data'].get('transcripts',[]):
            if str(t.get('lesson_id'))==str(v['sourceLessonId']):
                transcripts=[{'language':x.get('language'),'url':x['url']} for x in t.get('downloads',[]) if x.get('url')]
        matched.append({'id':v['id'],'course':v['parentCourse'],'title':v['title'],'sourceLessonId':v['sourceLessonId'],'mediaUrl':hit['url'],'downloadTitle':hit['title'],'titleSimilarity':title_similarity,'downloadSourceUrl':d['sourceUrl'],'downloadSourceSha256':d['receipt']['sha256'],'downloadSourceRetrievedAt':d['receipt']['retrievedAt'],'transcriptsListed':transcripts})
    save('media-mappings.json',matched);save('media-mapping-residuals.json',unmatched)
    save('downloads-summary.json',{'checkedAt':acquire.utc(),'courseResponses':len(lookup),'failures':[x for x in items if 'error'in x],'mappedMedia':len(matched),'unmappedCandidates':len(unmatched),'nonemptyCourseDownloads':sum(sum(bool(x.get('url')) for x in d['data'].get('course_downloads',[])) for d in items if 'data'in d),'boundary':'Exact official download URLs only; mapped by source course and lesson ID with title agreement. Does not establish endpoint accessibility.'})
    print(json.dumps(json.loads((OUT/'downloads-summary.json').read_text()),indent=2),flush=True)

def check_media(m,refresh=False):
    url=m['mediaUrl'];key=hashlib.sha256(url.encode()).hexdigest();receipt_path=CHECKS/(key+'.json')
    if receipt_path.exists() and not refresh:
        old=json.loads(receipt_path.read_text())
        age=(datetime.now(timezone.utc)-datetime.fromisoformat(old['checkedAt'])).total_seconds()
        if old['url']==url and age<7*86400:return old
    headers=RAW/('range-'+key+'.headers');body=RAW/('range-'+key+'.bin')
    # Remove only this adapter's previous small sample to avoid attributing old
    # bytes to a failed refresh. Receipt histories remain in the parent release.
    if headers.exists():headers.unlink()
    if body.exists():body.unlink()
    # A 206 response must match the requested range and MP4 signature. A server
    # ignoring Range must not cause a full download: curl enforces 2048 bytes.
    cmd=['curl','--location','--silent','--show-error','--max-time','20','--range','0-1023','--max-filesize','2048','--max-redirs','3','--proto','=https','--proto-redir','=https','--dump-header',str(headers),'--output',str(body),'--write-out','%{http_code}\n%{url_effective}',url]
    result=subprocess.run(cmd,capture_output=True,text=True)
    lines=result.stdout.splitlines();status=int(lines[0]) if lines and lines[0].isdigit() else None
    final=lines[1] if len(lines)>1 else None
    rawheaders=headers.read_text() if headers.exists() else ''
    data=body.read_bytes() if body.exists() else b''
    block=re.split(r'\r?\n\r?\n',rawheaders.strip())[-1]
    hs={k.strip().lower():v.strip() for line in block.splitlines()[1:] if ':' in line for k,v in [line.split(':',1)]}
    sig=len(data)>=12 and data[4:8]==b'ftyp'
    valid=(result.returncode==0 and status==206 and len(data)==1024 and hs.get('content-type','').split(';')[0]=='video/mp4' and bool(re.fullmatch(r'bytes 0-1023/\d+',hs.get('content-range',''))) and sig and final==url)
    record={'url':url,'checkedAt':acquire.utc(),'status':'accessible' if valid else 'unknown','method':'official-media-byte-range','httpStatus':status,'curlExit':result.returncode,'requestedRange':'bytes=0-1023','hardByteCap':2048,'receivedBytes':len(data),'mp4Signature':sig,'first24Hex':data[:24].hex(),'contentType':hs.get('content-type'),'contentRange':hs.get('content-range'),'mediaLastModified':hs.get('last-modified'),'etag':hs.get('etag'),'finalUrl':final,'sampleSha256':hashlib.sha256(data).hexdigest(),'headersSha256':hashlib.sha256(headers.read_bytes()).hexdigest() if headers.exists() else None,'privateSampleFile':str(body.relative_to(acquire.ROOT)),'privateHeaderFile':str(headers.relative_to(acquire.ROOT)),'error':result.stderr.strip() or None,'playbackVerified':False,'wholeFileVerified':False,'inspection':'The first 1 KiB of the official source-listed MP4 was accessible with a valid MP4 header. This is not full playback, decoding, watching, or an assurance about every byte.'}
    acquire.save_json(receipt_path,record)
    time.sleep(0.4)
    return record

def collate():
    mappings=json.loads((OUT/'media-mappings.json').read_text());mmap={m['id']:m for m in mappings}
    candidates=json.loads((OUT/'reviewed-candidates.json').read_text());qualified=[];remaining=[];checks=[]
    for v in candidates:
        m=mmap.get(v['id']);r=None
        if m:
            p=CHECKS/(hashlib.sha256(m['mediaUrl'].encode()).hexdigest()+'.json')
            if p.exists():r=json.loads(p.read_text());checks.append(r)
            v['authorisedAlternative']={'url':m['mediaUrl'],'listedBy':m['downloadSourceUrl'],'sourceSha256':m['downloadSourceSha256'],'matchedBy':'course ID, lesson ID and title agreement','downloadTitle':m['downloadTitle']}
            if r:
                v['authorisedAlternative']['availabilityCheck']=r
                v['authorisedAlternative']['knownInaccessibleAtCheck']=r['httpStatus'] in (404,410)
            if m['transcriptsListed']:
                v['transcriptStatus']='listed-not-retrieved';v['transcriptLinks']=m['transcriptsListed']
        if r and r['status']=='accessible':
            v['availability']=r|{'sourcePageAccessible':True,'destinationChecked':True,'destinationType':'authorised NPTEL MP4 alternative','youtubeStatus':'unknown','evidenceFile':str((CHECKS/(hashlib.sha256(m['mediaUrl'].encode()).hexdigest()+'.json')).relative_to(acquire.ROOT))}
            v['qualificationStatus']='qualified-with-official-media-endpoint-evidence';v['preferredViewingUrl']=m['mediaUrl'];qualified.append(v)
        else:remaining.append(v)
    save('qualified-candidates.json',qualified);save('pending-accessibility.json',remaining)
    summary={'checkedAt':acquire.utc(),'reviewedCanonicalCandidates':len(candidates),'sourceMappedOfficialMedia':len(mappings),'mediaChecked':len(checks),'mediaHttpStatuses':dict(Counter(str(x['httpStatus']) for x in checks)),'knownInaccessibleAlternatives':sum(x['httpStatus'] in (404,410) for x in checks),'qualifiedAccessibleVideos':len(qualified),'pendingAccessibility':len(remaining),'qualifiedCourses':len({x['parentCourse'] for x in qualified}),'qualifiedProviders':1 if qualified else 0,'byAuditFamily':dict(Counter(x['subjectFamilies'][0] for x in qualified)),'method':'Per-item 1 KiB HTTP206 byte-range from exact officially listed MP4, video/mp4 content type and MP4 ftyp header; no full playback or viewing','fullVideosDownloaded':0,'youtubeRequests':0,'checksExpireAfterDays':7}
    summary['unattemptedMappedAlternatives']=len(mappings)-len(checks)
    summary['byAuditFamily']=dict(Counter(x['auditSubjectFamily'] for x in qualified))
    summary['byTaxonomyFamilyIncludingCourseLevelOverlap']=dict(Counter(t for x in qualified for t in x['subjectFamilies']))
    save('accessibility-summary.json',summary);print(json.dumps(summary,indent=2),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['metadata','check','collate']);ap.add_argument('--limit',type=int,default=250);ap.add_argument('--refresh',action='store_true');args=ap.parse_args()
    if args.mode=='metadata':
        acquire.FORCE_REFRESH=args.refresh
        metadata_all();return
    if args.mode=='check':
        records=json.loads((OUT/'media-mappings.json').read_text())
        if args.limit<1 or args.limit>4000:raise ValueError('Explicit bounded limit must be between 1 and 4000')
        with ThreadPoolExecutor(max_workers=2) as pool:
            for n,r in enumerate(pool.map(lambda m:check_media(m,args.refresh),records[:args.limit]),1):
                if n%50==0:print('checked',n,'last',r['httpStatus'],r['status'],flush=True)
    collate()

if __name__=='__main__':main()
