#!/usr/bin/env python3
"""Replay the bounded editorial scope screen; uses only cached official source data."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
import json, re

HERE = Path(__file__).resolve().parent
def save(name, data):
    p=HERE/name;t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n');t.replace(p)

# The source description explicitly identifies this as Neuro Linguistic Programming
# training. It must not be silently conflated with scientific neurolinguistics.
COURSE_EXCLUSIONS = {
    'nptel:109107132': 'The inspected course description identifies Neuro Linguistic Programming training, not a course in the neuroscience of language. Excluded from this scientific foundation; no scientific assessment of its claims has been performed.'
}
EXCLUDED_IDS = {
    'yt:zNHYdkP-8Ds': 'Platform welcome, not subject teaching',
    'yt:OBxJgv36PTU': 'Instructions for discussion forums',
    'yt:K9y18lkqQdo': 'Instructions for assignment scores',
    'yt:4Y94gm5Djfo': 'Instructions for assignment submission types',
    'yt:voFSwV1VwkY': 'Instructions for assignment submission types',
    'yt:rpH42Rr86H8': 'Instructions for assignment submission types',
    'yt:j1WFt_i8osY': 'Instructions for assignment submission types',
    'yt:AMZwGED20J8': 'Instructions for assignment submission types',
    'yt:D9z8ipMHK0A': 'Certification-exam administration',
    'yt:ur5K3m9DKkQ': 'Course structure without a substantive topic in the title',
    'yt:swNiPpmWyW8': 'Course preview',
    'yt:a2AA4zviMD0': 'Preface and course structure; substantive contents not established',
    'yt:Dge71nRLZgQ': 'Course overview; substantive contents not established',
    'yt:lDeUVBUkRKM': 'Course introduction; substantive contents not established',
    'yt:TnBwZogRNBI': 'Course introduction; substantive contents not established',
    'yt:xaXcXuEmH5E': 'Learning outcomes and module administration',
    'yt:0G__3b4Tr18': 'Professional skillset development outside the selected movement-science route',
    'yt:wQXVJs-SJwg': 'Career information outside the selected movement-science route',
    'yt:5frPnzQ--DI': 'Materials-engineering topic without established mind/behaviour relevance in the title',
    'yt:N_D4dsNiOhI': 'Materials-engineering topic without established mind/behaviour relevance in the title',
    'yt:y9pKbSFiXAo': 'Materials-engineering topic without established mind/behaviour relevance in the title',
    'yt:PnmJn1o7THM': 'Source anomaly: oil-stock vaporisation title conflicts with the health-promotion course. Held out pending verified correction; the title/URL has not been silently repaired.',
}
CONTEXT_NOTES = {
    'nptel:109105884': 'Contains historical, philosophical and Indian-tradition accounts alongside psychology. Attribute positions to the lecturer/traditions. Ayurveda, yoga and other health claims are not assessed and must not be presented as current clinical guidance.',
    'nptel:109104121': 'The course uses a biographical account of Gandhi to discuss psychological transformation. Treat explanatory and biographical interpretations as the lecturer\'s account; they have not been independently assessed.',
    'nptel:109101004': 'Philosophy of mind: philosophical positions should be attributed, not presented as settled empirical findings.',
    'nptel:102106345': 'Historical neuroscience course. Historical theories and experiments require their original context, not automatic endorsement as current consensus.',
}

DEFAULT_FAMILIES={
    'neuroscience':['neuroscience'],
    'language-and-communication':['language'],
    'philosophy-and-research-foundations':['consciousness-philosophy'],
    'evolution':['evolution-comparative'],
    'research-methods':['methods'],
    'learning-and-education':['learning-memory'],
    'social-and-cultural-behaviour':['social-cultural'],
}
# Course-level assignments from the inspected course title, description where
# supplied, and ordered outline. These are not transcript-derived lecture tags.
COURSE_FAMILIES={
 '109103001':['learning-memory','perception-action','individual-differences','social-cultural','methods','mental-health'],
 '109103136':['reasoning-decisions','social-cultural'],
 '109103152':['language'],
 '109103182':['emotion-motivation-sleep','mental-health'],
 '109103540':['perception-action','methods'],
 '109103736':['emotion-motivation-sleep','mental-health'],
 '109104093':['learning-memory','perception-action','individual-differences','social-cultural'],
 '109104121':['emotion-motivation-sleep','social-cultural'],
 '109104123':['perception-action','learning-memory'],
 '109104126':['reasoning-decisions','language','learning-memory'],
 '109104151':['reasoning-decisions','social-cultural','emotion-motivation-sleep'],
 '109105118':['methods','learning-memory','social-cultural'],
 '109105204':['learning-memory'],
 '109106403':['perception-action','emotion-motivation-sleep'],
 '109107204':['social-cultural'],
 '109103395':['emotion-motivation-sleep'],
 '109103598':['individual-differences'],
 '109104029':['neuroscience'],
 '109104048':['social-cultural'],
 '109104070':['mental-health','emotion-motivation-sleep'],
 '109104082':['learning-memory','individual-differences','social-cultural'],
 '109104105':['learning-memory','perception-action','individual-differences','social-cultural','methods'],
 '109104108':['neuroscience','consciousness-philosophy'],
 '109104171':['neuroscience','perception-action'],
 '109104607':['social-cultural','neuroscience'],
 '109104878':['methods'],
 '109105884':['consciousness-philosophy','individual-differences'],
 '109107399':['perception-action','methods'],
 '109101007':['mental-health'],
 '109101015':['social-cultural'],
 '109102157':['emotion-motivation-sleep'],
 '109103134':['perception-action','learning-memory','reasoning-decisions'],
 '109103142':['individual-differences','social-cultural','emotion-motivation-sleep'],
 '109105116':['emotion-motivation-sleep','individual-differences'],
 '110105074':['reasoning-decisions','social-cultural'],
 '110105054':['reasoning-decisions','social-cultural'],
 '102105100':['neuroscience','computation-ai'],
 '108105185':['computation-ai','perception-action','neuroscience'],
 '102106023':['neuroscience','computation-ai'],
 '102106066':['neuroscience','consciousness-philosophy'],
 '102108071':['learning-memory','neuroscience'],
 '108108167':['neuroscience','methods'],
 '127104003':['methods','computation-ai'],
 '127106001':['perception-action','neuroscience','learning-memory'],
 '109106401':['perception-action'],
 '112104293':['computation-ai','perception-action','neuroscience'],
 '109103753':['language','development'],
 '109103189':['language','social-cultural'],
 '109105495':['language','methods'],
 '109105396':['reasoning-decisions','consciousness-philosophy'],
 '109103184':['methods','consciousness-philosophy'],
 '110107759':['reasoning-decisions','social-cultural'],
 '110105144':['reasoning-decisions'],
 '127101003':['learning-memory','computation-ai'],
 '106101224':['learning-memory','methods','computation-ai'],
 '127101012':['learning-memory','methods'],
 '107103001':['methods','perception-action'],
 '127105237':['methods','social-cultural'],
}

def families(c):
    return COURSE_FAMILIES.get(c['nptelId']) or DEFAULT_FAMILIES.get(c['subjectFamily']) or []

def main():
    original = json.loads((HERE/'candidates.json').read_text())
    courses = json.loads((HERE/'courses.json').read_text())
    course_lookup={c['id']:c for c in courses}
    selected=[]; excluded=[]
    for raw in original:
        reason=COURSE_EXCLUSIONS.get(raw['parentCourse']) or EXCLUDED_IDS.get(raw['id'])
        if not reason and raw['parentCourse']=='nptel:110105144' and int(raw['sourceLessonId'])>17:
            reason='Only the behavioural-economics, bias and decision-making sequence (lectures 1–17) is in scope; later portfolio, tax and personal-finance instruction is excluded.'
        if not reason and re.match(r'^Live Session\b',raw['title'],re.I):
            reason='Undescribed live session; subject content not established by the outline. Held outside the reviewed candidate count pending individual inspection.'
        if not reason and re.match(r'^Feedback (?:for|session)\b',raw['title'],re.I):
            reason='Administrative feedback item; one source entry repeats a lecture ID and must not add a second record.'
        if reason:
            excluded.append({'id':raw['id'],'title':raw['title'],'parentCourse':raw['parentCourse'],'sourceUrl':raw['sourceUrl'],'reason':reason})
            continue
        r=deepcopy(raw)
        r['auditSubjectFamily']=r['subjectFamilies'][0]
        r['subjectFamilies']=families(course_lookup[r['parentCourse']])
        if not r['subjectFamilies']:raise ValueError('Unmapped in-scope course '+r['parentCourse'])
        r['courseInstructor']=r['speaker'];r['speaker']=None
        r['courseStatedLevel']=r['level'];r['level']=None
        r['courseLanguage']=r['language'];r['language']=None
        r['metadataScope']={'courseInstructor':'official parent-course metadata; speaker not separately established for this lecture','courseStatedLevel':'official parent-course syllabus if supplied','courseLanguage':'official parent-course syllabus if supplied','subjectFamilies':'parent-course context; not a transcript-derived lecture taxonomy'}
        r['descriptionCheckStatus']='not-annotated'
        r['topicalRelevance']={'status':'course-context-screened','basis':'Official lecture title in a deliberately selected course; not a claim that the full lecture has been watched.'}
        r['selectionReason']='Listed within the official '+r['courseTitle']+' course; its ordered course context supports a systematic study route. Individual descriptive annotation is pending.'
        r['rights']['licence']='CC BY-NC-SA 4.0 site notice; individual-source exceptions must be preserved'
        r['rights']['evidenceUrl']='https://archive.nptel.ac.in/footer.html'
        if r['parentCourse'] in CONTEXT_NOTES:r['editorialContext']=CONTEXT_NOTES[r['parentCourse']]
        selected.append(r)
    grouped={}
    for r in selected:
        if r['id'] not in grouped:
            grouped[r['id']]=r
            r['courseMemberships']=[]
        grouped[r['id']]['courseMemberships'].append({k:r[k] for k in ['parentCourse','courseTitle','unitTitle','unitOrder','lessonOrder','sourceLessonId','sourceUrl']})
    selected=list(grouped.values())
    reviewed_courses=[]
    for c in courses:
        c=deepcopy(c);c['reviewedCandidateCount']=sum(c['id'] in [m['parentCourse'] for m in r['courseMemberships']] for r in selected)
        c['subjectFamilies']=families(c)
        c['subjectAssignmentScope']='parent-course title, description where supplied, and ordered outline; agent editorial classification'
        c['scopeStatus']='excluded' if c['id'] in COURSE_EXCLUSIONS else 'supporting-web-course' if c['contentType']=='Web' else 'course-context-screened'
        if c['id'] in COURSE_EXCLUSIONS:c['exclusionReason']=COURSE_EXCLUSIONS[c['id']]
        if c['id'] in CONTEXT_NOTES:c['editorialContext']=CONTEXT_NOTES[c['id']]
        reviewed_courses.append(c)
    save('reviewed-candidates.json',selected)
    save('reviewed-courses.json',reviewed_courses)
    save('editorial-exclusions.json',excluded)
    save('course-subject-mappings.json',[{'courseId':c['id'],'subjectFamilies':c['subjectFamilies'],'sourceUrl':c['sourceUrl'],'sourceSha256':c['sourceEvidence']['sha256'],'assignmentScope':c['subjectAssignmentScope']} for c in reviewed_courses])
    summary={'date':'2026-11-07','method':'Agent screen of official course descriptions where supplied and ordered lecture-title context; not viewing, transcript review or scientific validation','originalCanonicalCandidates':len({r['id'] for r in original}),'reviewedCanonicalCandidates':len(selected),'editorialExcludedRows':len(excluded),'retrievedCourses':len(courses),'inScopeVideoCourses':sum(c['scopeStatus']=='course-context-screened' and c['reviewedCandidateCount']>0 for c in reviewed_courses),'supportingWebCourses':sum(c['contentType']=='Web' for c in courses),'excludedCourses':len(COURSE_EXCLUSIONS),'qualifiedAccessibleVideos':0,'byAuditFamily':dict(Counter(r['auditSubjectFamily'] for r in selected)),'byTaxonomyFamilyIncludingCourseLevelOverlap':dict(Counter(t for r in selected for t in r['subjectFamilies'])),'warning':'Candidate count is not a qualified-accessibility count. Canonical IDs are distinct; alternate-upload equivalence still requires review.'}
    save('review-summary.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
