#!/usr/bin/env python3
"""Render the dated audit report and public factual course list from saved evidence."""
from pathlib import Path
from collections import Counter
import hashlib,json,platform
import acquire

HERE=acquire.OUT;RAW=acquire.RAW
def read(name):return json.loads((HERE/name).read_text())
def save(name,obj):acquire.save_json(HERE/name,obj)

def main():
    scope=read('review-summary.json');access=read('accessibility-summary.json');valid=read('validation.json')
    courses=read('reviewed-courses.json');qualified=read('qualified-candidates.json');pending=read('pending-accessibility.json')
    qc=Counter(v['parentCourse'] for v in qualified)
    public=[]
    for c in courses:
        public.append({k:c[k] for k in ['id','nptelId','title','sourceUrl','providerId','institution','contentType','subjectFamily','subjectFamilies','language','statedLevel','courseDuration','reviewedCandidateCount','scopeStatus']}|{'courseInstructor':c['speaker'],'sourceRetrievedAt':c['sourceEvidence']['retrievedAt'],'sourceSha256':c['sourceEvidence']['sha256'],'qualifiedAccessibleVideos':qc[c['id']],'description':None,'scientificAssessment':'not-assessed'})
    save('public-courses.json',public)
    receipts=[]
    for p in sorted(RAW.glob('*.receipt.json')):
        r=json.loads(p.read_text());r['privateReceiptFile']=str(p.relative_to(acquire.ROOT));receipts.append(r)
    save('source-retrievals.json',receipts)
    licence_urls=['https://archive.nptel.ac.in/footer.html','https://creativecommons.org/licenses/by-nc-sa/4.0/','https://onlinecourses-archive.nptel.ac.in/modules/nptel/assets/html/terms.html']
    register={'id':'nptel','name':'NPTEL — National Programme on Technology Enhanced Learning','homepage':'https://nptel.ac.in/','identityStatus':'verified from official about page','identitySource':'https://nptel.ac.in/aboutus','providerCount':1,'institutionsCountedSeparately':False,'checkedAt':access['checkedAt'],'collectionSource':'https://nptel.ac.in/courses','officialCatalogueDistinctCourseLinks':3483,'selectedCoursePages':len(courses),'subjectCoverage':list(scope['byAuditFamily']),'selectionRoute':'institutional-collection','inclusionRules':'Explicit course-title and outline/description screen; preserve course sequence. Exclude generic AI/engineering, promotional/admin entries, uncharacterised live sessions, off-topic source anomalies and NLP training mistaken for neurolinguistics. Some mixed courses have a selected subject sequence only.','access':{'publicSourcePages':True,'accountUsed':False,'paymentUsed':False,'youtubeQueried':False,'officialMediaMethod':'HTTP206 1KiB Range, video/mp4 and MP4 ftyp signature; every qualified item has a dated receipt','fullPlaybackVerified':False,'fullVideosDownloaded':0,'qualifiedAccessibleVideos':len(qualified),'pendingAccessibility':len(pending)},'reuse':{'notice':'Official archive footer links CC BY-NC-SA 4.0. Current site notice also includes NC-SA, though some older footer prose omits NC. Preserve the non-commercial restriction and individual exceptions.','evidenceUrls':licence_urls,'defaultPublicUse':'Link to official source, title, attribution and original atlas annotations. Do not copy source code, rehost video, or copy full course prose into the public export.','embeddingPermission':'No additional blanket direct-embedding permission separately verified; use source links by default and retain original restrictions.','archivedOnlineCourseTerms':'Copyright retained by NPTEL/affiliates/licensors; rights not expressly granted are reserved. The archived participation terms include an over-18 rule. No course account/registration was used.','missingTermsLink':'The official archive footer Copyright & Disclaimer link returned404; retained in source-retrievals.json. A current related GATE portal disclaimer was read as corroborating context only.'},'limitations':['This is a bounded NPTEL catalogue screen, not an exhaustive SWAYAM census. SWAYAM course runs do not add providers or duplicate video counts.','A source-listed YouTube ID remains unknown unless a usable authorised alternative has been checked.','Course instructor, language and level are explicitly course-level; actual lecture speaker/language/level have not been independently established.','Recording dates, upload dates and durations remain unknown. Media Last-Modified is not treated as any of those dates.','No full lecture watching, transcript reading, human review or independent scientific assessment is claimed.','Canonical IDs are distinct. Course-edition/alternate-upload identity still requires follow-up where reported.']}
    save('source-register.json',register)
    related=[]
    bytitle={}
    for c in courses:
        if c['scopeStatus']=='excluded':continue
        title=' '.join(c['title'].lower().split());bytitle.setdefault(title,[]).append(c)
    for title,rows in bytitle.items():
        if len(rows)>1:
            related.append({'normalisedTitle':title,'courses':[{'id':c['id'],'speaker':c['speaker'],'contentType':c['contentType'],'candidateCount':c['reviewedCandidateCount'],'sourceUrl':c['sourceUrl']} for c in rows],'status':'same course-title family; inspect editions/alternate uploads before merging','inspection':'Distinct course IDs and ordered lecture sequences retained. Web/video versions do not add videos; similarly titled distinct lectures are not merged.'})
    save('course-edition-review.json',related)
    fields=['durationSeconds','uploadDate','recordingDate','speaker','level','language']
    missing={k:sum(v.get(k) is None for v in qualified) for k in fields}
    counts={'checkedAt':access['checkedAt'],'selectedCoursePages':len(courses),'inScopeVideoCourses':scope['inScopeVideoCourses'],'supportingWebCourses':scope['supportingWebCourses'],'excludedCourses':scope['excludedCourses'],'reviewedCanonicalCandidates':scope['reviewedCanonicalCandidates'],'officialMediaMappings':access['sourceMappedOfficialMedia'],'checkedMedia':access['mediaChecked'],'qualifiedAccessibleVideos':len(qualified),'pendingAccessibility':len(pending),'knownInaccessibleAlternatives':access['knownInaccessibleAlternatives'],'providers':1,'selectedCoreDescriptionChecks':0,'qualifiedUnknownFields':missing,'courseLanguageKnownForQualified':sum(v.get('courseLanguage') is not None for v in qualified),'courseLevelKnownForQualified':sum(v.get('courseStatedLevel') is not None for v in qualified),'listedTranscriptLinksForQualified':sum(bool(v.get('transcriptLinks')) for v in qualified),'fullPlaybackChecks':0,'humanValidation':0,'validationPassed':valid['passed']}
    save('final-summary.json',counts)
    manifest={'createdAt':acquire.utc(),'pythonVersion':platform.python_version(),'system':platform.system(),'scope':'NPTEL audit artifacts only','files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [HERE/n for n in ['acquire.py','review.py','media_access.py','validate.py','requirements.txt','qualified-candidates.json','pending-accessibility.json','public-courses.json','source-register.json','final-summary.json']]}}
    save('handoff-manifest.json',manifest)
    rows=[]
    for c in courses:
        rows.append('| ['+c['title'].replace('|','/')+']('+c['sourceUrl']+') | '+c['nptelId']+' | '+str(c['reviewedCandidateCount'])+' | '+str(qc[c['id']])+' | '+c['scopeStatus']+' |')
    body=f'''# NPTEL / SWAYAM bounded source and accessibility audit

Checked {access['checkedAt']}. No paid services, accounts, credentials, YouTube requests or full-video downloads were used. All work is confined to this audit folder and its private raw cache.

## Result and count boundary

The inspected official catalogue contains 3,483 distinct course links. A deliberately bounded two-stage screen retrieved **{len(courses)} course pages**, retaining **{scope['inScopeVideoCourses']} video-course contexts** and **{scope['supportingWebCourses']} supporting web courses**. One misclassified course was excluded. This is not an exhaustive census of every potentially relevant NPTEL or SWAYAM course.

There are **{scope['reviewedCanonicalCandidates']:,} distinct reviewed canonical video candidates** after the scope screen. Of those, **{len(qualified):,} have documented accessibility through an exact official NPTEL MP4 alternative**, across **{access['qualifiedCourses']} courses**, and **{len(pending):,} remain outside the qualified count**. **{access['knownInaccessibleAlternatives']} listed MP4 alternatives returned404/410** at the last check. Other pending records lack a listed alternative, have not yet been endpoint-checked, or did not meet the endpoint-verification test. YouTube accessibility remains unknown for all records. One provider is counted: NPTEL. Partner institutions and SWAYAM course runs are not additional providers.

This is a sizeable course foundation, not completion of the atlas's 3,000-video or twenty-provider targets. No selected-core description checks, human review, guide completion or scientific validation are claimed by this source-ingestion audit.

## Identity, access and rights

NPTEL identifies itself as a joint IIT/IISc initiative funded by India's Ministry of Education. Its public course materials can be used for study without buying the optional certification exam. Institutional affiliation does not establish correctness of each lecture. [Official about page](https://nptel.ac.in/aboutus).

The [official archive footer](https://archive.nptel.ac.in/footer.html) links [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Preserve attribution, non-commercial and share-alike restrictions where applicable, and individual exceptions. Some older footer prose omits NC while the displayed licence acronym retains it; this audit does not silently weaken that restriction. The [archived online-course terms](https://onlinecourses-archive.nptel.ac.in/modules/nptel/assets/html/terms.html) reserve rights not expressly granted and include participation restrictions. Their requirements are not replaced by this audit. The archive footer's Copyright & Disclaimer target returned404, which is retained as a failed retrieval.

Use factual titles, original source links and original atlas annotations by default. No blanket direct-embedding permission was separately verified. Do not rehost source videos or source application code, and do not redistribute private raw caches. `public-courses.json` excludes copied course descriptions. The live [robots.txt](https://nptel.ac.in/robots.txt) allowed crawling at retrieval; that is access-policy evidence, not a copyright licence.

## Acquisition and accessibility evidence

Public course HTML embeds a structured `courseOutline` object containing ordered unit/lesson titles, YouTube IDs, instructor, institute and any available syllabus metadata. The adapter extracts that object with a brace scanner and a JSON5 data parser; it does not execute source JavaScript. Public Downloads UI code identifies the unauthenticated `/api/downloads/{{courseId}}` interface. Each response used here explicitly marks itself public and provides the source course ID. API entries are matched by course ID, lesson ID and title agreement. Exact URLs are retained; media paths are never invented.

Every qualified alternative returned HTTP206 for bytes0–1023, exactly1024 bytes, `video/mp4`, the expected Content-Range and an MP4 `ftyp` signature. This demonstrates access to the beginning of the real media file. It is not full decoding, end-to-end playback, viewing, or verification of every byte. Per-item receipts preserve UTC, headers, their SHA-256, sample SHA-256, signature, URL and mapping evidence. Header values such as Last-Modified are not recast as recording or upload dates.

Concurrency is two. Curl enforces a2048-byte hard cap. A local synthetic-server check confirmed that a server ignoring Range stops at0 bytes with an oversized known Content-Length, or2048 bytes without Content-Length; both return curl63. See `range-cap-validation.json`. No complete video was downloaded.

## Scope decisions and defects found

The first screen covered psychology, cognition, neuroscience, language, evolutionary foundations, education, social behaviour and research methods. A small follow-up inspected user research, language documentation, emotional intelligence, movement science, cognitive robotics, health-behaviour methods and multivariate analysis. Generic AI, mechanical/material behaviour and engineering keyword matches were not imported merely for volume.

`editorial-exclusions.json` records **{scope['editorialExcludedRows']} excluded source rows**, including platform instructions, certification information, undeclared live-session contents and course-only previews. One feedback row reused the exact ID of a Bayesian parameter-estimation lecture; the substantive lecture is retained once. `exclusions.json` also preserves missing/invalid IDs and initial promotional-title exclusions.

“Perspectives on Neurolinguistic” is actually described as Neuro Linguistic Programming training. It was excluded rather than conflated with scientific neurolinguistics. The finance course contributes only its behavioural-economics/decision-making sequence, lectures1–17; later portfolio/tax/personal-finance teaching is excluded. Cognitive Robotics excludes the three materials-engineering entries. Human Movement Science excludes administrative/career items. A health-promotion course lists “Evaluation of Oil Stocks: Vaporization Characteristics” as lecture5; this apparent source anomaly is held out without an invented correction.

Indian Psychology, philosophical positions, historical neuroscience and biographical interpretations retain context notes. Their presence does not make historical theories, health claims or philosophical views current empirical consensus. Scientific assessment is `not-assessed` throughout. Course-level instructor/language/level are stored separately from unknown actual lecture-level values.

## Remaining uncertainty and continuation

`pending-accessibility.json` preserves the exact remaining candidates and failed-alternative evidence. An authorised YouTube metadata/player route could resolve part of this backlog; scraped watch pages, source-page200s and oEmbed responses must not be treated as playback. Known404 alternatives are not counted merely because their source listing exists.

`course-edition-review.json` groups same-titled courses for follow-up. Different course sequences, web/video variants and possibly revised editions are not merged simply because titles match. Canonical IDs and official media URLs are deduplicated; full content-equivalence between alternate uploads is not established. Core descriptions should next be written against retrieved descriptions or transcripts with explicit evidence scope. Missing durations/dates remain null. Translation or transcript links, when supplied, are marked listed but not read.

## Reproducibility and validation

Use the commands in `README.md`. Source parsing can replay offline from SHA-256-verified caches; fresh source retrieval is explicit. Media checks resume from dated receipts and are reused for at most seven days. The validation checks every reviewed canonical ID, parent reference, source hash, mapping uniqueness, media signature and saved evidence hash. Result: **{'passed' if valid['passed'] else 'FAILED'}**, with **{len(valid['errors'])} errors**. This is engineering/source-integrity validation, not a scientific assessment.

The source register, dated retrieval receipts, final counts and a handoff checksum manifest are machine-readable. `qualified-candidates.json` is the accessible input; `candidates.json` is an earlier unscreened acquisition stage and must not be imported as the release catalogue.

## Course inventory

The candidate and accessible columns count only the selected relevant lecture records, not a guarantee that every lecture in a course is available. Full official course order is preserved in private source evidence and each retained membership.

| Official course | ID | Reviewed candidates | Accessible alternative | Scope |
|---|---|---:|---:|---|
'''+'\n'.join(rows)+'\n'
    (HERE/'REPORT.md').write_text(body)
    print(json.dumps(counts,indent=2))

if __name__=='__main__':main()
