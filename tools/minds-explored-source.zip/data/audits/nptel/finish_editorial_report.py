#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
ROOT=Path(__file__).resolve().parents[3]
NOW=datetime.now(timezone.utc).isoformat()
def read(p):return json.loads((ROOT/p).read_text())
def write(p,x):(ROOT/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
specs=[
 ('102106051',2,'29:33','fail to reject','Non-rejection described as evidence that one drug is as good as another.','Failure to reject a difference does not demonstrate equivalence. Equivalence requires a defined margin and an appropriate analysis; a weakly informative study can fail to reject.','Not selected for the checked methods core; use the ASA/NIST-supported interpretation route.'),
 ('102106051',3,'34:21','completely curative','The observed-survival calculation is presented as establishing a completely curative drug.','The probability of all survivors under a specified survival model can challenge that null; it does not establish perfect efficacy. Clinical design and uncertainty cannot be omitted.','Not selected for the checked methods core; health examples are not adopted as clinical guidance.'),
 ('102106051',6,'opening and 18:25','uniform','Normal distributions are called uniform in the official text.','Normal and uniform distributions have different densities. The wording needs checking against the audiovisual lecture before attributing the error to the speaker.','Not selected for the checked methods core; preserve the official transcript discrepancy.'),
 ('103106120',15,'09:59','unbiased','The official text goes beyond asymptotic unbiasedness and calls the sample correlation unbiased.','The sample Pearson correlation is not generally unbiased in finite samples. The paragraph also needs checking against the video because extraction or transcription errors are possible.','Omitted from the final checked core; retained as an ordinary source candidate with scientific assessment not assessed.'),
 ('111104120',20,'32:02','standard error','The positive square root of the sample variance is called a standard error.','The standard deviation of observations and the standard error of an estimator answer different questions. The displayed sample-spread formula does not become a standard error simply because population values are unknown.','Omitted from the final checked core; use the separately inspected sample-mean lecture for the distinction.'),
 ('111104120',29,'15:29','96.79','The correlation is described as a percentage degree of relationship, followed by overly confident wording about the conclusions.','A correlation should not be read as a percentage of causation, certainty or variance explained. The lecture’s interpretation needs qualification, especially for its clinical illustration.','Not used as a replacement core resource; the histogram and bar-diagram demonstrations were selected instead.')
]
catalogue=read('data/audits/nptel/reviewed-candidates.json');bylesson={(x['parentCourse'].split(':')[1],x['sourceLessonId']):x for x in catalogue}
findings=[]
for cid,no,time,needle,observed,correction,decision in specs:
 p=f'data/raw/nptel/transcript-{cid}-{no:02d}.txt';text=(ROOT/p).read_text();receipt=read(p.replace('.txt','.receipt.json'))
 start=text.find(time) if re.fullmatch(r'\d\d:\d\d',time) else -1
 if start<0:start=text.lower().find(needle.lower())
 # Private evidence pointer only. No full transcript is republished by the site.
 findings.append({'resourceId':bylesson[(cid,no)]['id'].replace('yt:','youtube:'),'courseId':f'nptel:{cid}','lecture':no,'sourceUrl':receipt['url'],'sourceTimeLabel':time,'sourceCachePath':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'hashScope':'UTF-8 connector-extracted text, not original PDF','characterOffset':start,'observedIssue':observed,'editorialCorrectionOrCaution':correction,'decision':decision,'checkedAt':NOW,'checker':'agent','attributionLimit':'Observed in the official transcript extraction. The audiovisual lecture was not watched; a transcription or extraction error remains possible.'})
write('data/audits/nptel/observed-source-cautions.json',{'checkedAt':NOW,'scope':'Six individually located transcript passages encountered during methods-core selection; not a full scientific audit of these courses.','findings':findings,'initialPoolDisposition':'The initial 30-transcript Biostatistics pool was not promoted wholesale to checked core. The final 30 are individually described in core-overrides.json and core-checks/.','catalogueDisposition':'Selection limits do not delete the underlying official source; the default scientific assessment remains not assessed. The independent source-list anomalies are addressed in record-decisions.json.'})
core=read('data/audits/nptel/core-overrides.json')
ed=read('data/audits/nptel/editorial-validation.json')
taxonomy={x['id'] for x in read('data/taxonomy.json')['families']}
errors=[]
for item in ed['guides']:
 g=read('content/guides/'+item['slug']+'.json')
 if not set(g['topics']+g['neighbours'])<=taxonomy:errors.append('taxonomy:'+g['slug'])
 if not (ROOT/g['check']['receipt']).is_file():errors.append('receipt:'+g['slug'])
 for source in g['sources']:
  if hashlib.sha256((ROOT/source['cachePath']).read_bytes()).hexdigest()!=source['sha256']:errors.append('source-hash:'+source['id'])
for item in ed['paths']:
 p=read('content/paths/'+item['slug']+'.json')
 if not set(p['topics'])<=taxonomy:errors.append('taxonomy:'+p['slug'])
 if not (ROOT/p['check']['receipt']).is_file():errors.append('receipt:'+p['slug'])
assert not errors,errors
ed['taxonomyCheck']='passed';ed['individualEditorialReceipts']=7;ed['finalSourceHashCheck']='passed';ed['finalCheckedAt']=NOW;write('data/audits/nptel/editorial-validation.json',ed)
report=f'''# Methods editorial handoff

Completed {NOW} after the parent’s explicit prototype-gate approval.

- Five original guides, with 433–478 words of substantive body prose each.
- Two distinct paths: an eight-step study-design route and a ten-step critical-reading route.
- Thirty distinct selected-core videos, all individually checked against identified official-transcript excerpts, with thirty individual receipts.
- All thirty core videos are used in the guides/paths and belong to the frozen official-media-qualified source set.
- Thirteen foundation and seventeen intermediate levels, explicitly labelled editorial judgements rather than official course difficulty.
- Seven individual guide/path receipts; every cited local source digest and taxonomy identifier checked.

## Deliverables

Guides: `from-question-to-experiment`, `reliable-and-valid-measurement`, `uncertainty-in-statistical-results`, `from-association-to-causation`, `reproducible-quantitative-research`.

Paths: `design-a-behavioural-study`, `read-a-quantitative-paper`.

Core: `data/audits/nptel/core-overrides.json`; individual evidence: `data/audits/nptel/core-checks/`; core receipt validation: `core-validation.json`.

Guide and path source checks: `data/editorial-checks/guides/` and `data/editorial-checks/paths/` using the slugs above. Supporting-source register: `editorial-sources.json`. Final bounded validation: `editorial-validation.json`.

## What was inspected

The thirty video checks used selected official transcript passages with recorded transcript timings or character positions. The description method is `transcript`, with explicit excerpt-only scope. Saved text came from the connected Google Drive readable-file extractor at public URLs supplied by NPTEL’s official downloads API. The SHA-256 identifies extracted UTF-8 text, not original PDF bytes. No complete viewing or complete-transcript reading is claimed.

Supporting claims draw on actually retrieved ASA, NIST, Center for Open Science, BCcampus and Hernán–Robins materials. Individual source records identify the sections read. The causal book check covered selected introductory passages, not the entire 365-page download. BCcampus direct curl returned 403; those failed response bodies are not used as evidence. The successful web-tool text responses have separate hashes and explicit extraction scope.

## Selection repairs and limits

`observed-source-cautions.json` records six precise transcript problems encountered during selection, including non-rejection/equivalence, claims of perfect cure, normal/uniform wording, finite-sample correlation bias, standard deviation/standard error and percentage interpretations of correlation. These passages were not silently converted into authoritative teaching claims. The final guides use individually selected demonstrations and stronger supporting sources. Because the video itself was not watched, transcript errors are not automatically attributed to the speaker.

Scientific assessment remains **not assessed** for the catalogue videos. A description check confirms scope and selection basis; it does not peer-review every numerical or scientific claim. Official media-range evidence is accessibility evidence, not watched playback. Root owns the independent authorised YouTube API overlay and final rendered-page/global test review.

## Separate boundary review

`record-decisions.json` contains 448 scoped decisions across nine evolutionary, organisational and finance courses: 408 retain, 35 supporting context, five excluded official-list anomalies. `BOUNDARY_REVIEW.md` explains retained foundations and all count effects. Frozen acquisition snapshots remain unchanged. This tightening removes 17 of the original 1,535 media-qualified records; source-list totals and final release totals must remain distinct.

## Reproduction

The own-directory scripts `build_core.py`, `write_editorial.py`, `boundary_review.py` and `finish_editorial_report.py` reproduce the authored fragments from the saved sources without requesting new media or changing frozen source snapshots. Re-running them advances editorial timestamps. They do not replace the parent’s site/schema tests or visual review.
'''
(ROOT/'data/audits/nptel/EDITORIAL_REPORT.md').write_text(report)
print(json.dumps({'guides':len(ed['guides']),'paths':len(ed['paths']),'core':len(core),'sourceCautions':len(findings),'errors':errors}))
