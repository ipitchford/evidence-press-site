#!/usr/bin/env python3
"""Add bounded scope decisions without changing frozen source snapshots."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
ROOT=Path(__file__).resolve().parents[3]
NOW=datetime.now(timezone.utc).isoformat()
def read(p):return json.loads((ROOT/p).read_text())
def write(p,x):
 p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
courses={x['nptelId']:x for x in read('data/audits/nptel/reviewed-courses.json')}
rows=read('data/audits/nptel/reviewed-candidates.json')
qualified={x['id'] for x in read('data/audits/nptel/qualified-candidates.json')}
selected=['102106002','102106751','103101127','127101592','110103433','110106145','110105154','109107740','110105144']
retained={
 '102106002':('evolution-genetics-foundation','Retain the evolution/genetics foundation. The official description and weeks connect evolutionary history, natural and sexual selection, genotype/phenotype, population genetics and genetic evidence. The project brief explicitly includes evolution and genetics; this is not being counted as a behavioural intervention course. The mixed sector-applications lecture is separately held out.'),
 '102106751':('evolution-comparative-foundation','Retain the evolutionary-biology foundation. The inspected syllabus explicitly connects mechanisms with ageing, sexual selection, kin selection, parent–offspring conflict, human evolution and evolutionary psychology. Shared foundations such as variation, inheritance, drift and speciation support those questions. Origin-of-life lectures are separate background.'),
 '103101127':('evolutionary-dynamics-foundation','Retain the population/evolutionary modelling sequence through selection, mutation, drift, fitness landscapes, Moran processes and evolutionary games. Its ordered outline supplies mathematical foundations for evolutionary reasoning; microbial examples are models of these general mechanisms, not claims about human behaviour. The terminal HIV application is separately held out.'),
 '127101592':('evolutionary-dynamics-foundation','Retain the general mechanisms and mathematical models of natural selection, genetic variation, fitness landscapes, drift and fixation in the official ordered outline. Applied microbiological cultivation/laboratory blocks and origin-of-life background are held separately; the unrelated network-security rows are excluded as source-list anomalies.'),
 '110103433':('individual-and-social-work-behaviour','Retain the individual-behaviour course: its complete inspected outline centres on perception, decisions, individual differences, personality measurement, affect, motivation, learning, creativity, knowledge sharing and voice/silence. Workplace setting is a legitimate human/social-behaviour context. This does not confer scientific validation on each named theory or workplace technique.'),
 '110106145':('individual-and-social-work-behaviour','Retain the psychological and group-behaviour sequence. The official syllabus explicitly covers perception/attribution, conditioning, personality, attitudes, emotion, motivation, interpersonal relationships, communication, decisions and group dynamics. General organisational structure/change context is held out.'),
 '110105154':('group-behaviour-foundation','Retain the group/social-psychological concepts: formation, cooperation/competition, communication, conflict, social influence, decisions, creativity and cross-cultural interpersonal behaviour. The official syllabus describes group dynamics. General managerial skills, organisation profiles and team-evaluation/reward procedures are separated as course background.'),
 '109107740':('individual-and-social-work-behaviour','Retain the behavioural and psychological sequence grounded in the official syllabus: individual differences, conditioning, emotion regulation, motivation, group processes, communication, conflict, fairness and workplace well-being. Generic corporate-responsibility, change-management and organisational-development implementation are held out. Historical or contested models remain scientifically not assessed.'),
 '110105144':('behavioural-decision-foundation','Retain only the already-screened lessons 1–17: risk/uncertainty, non-expected utility, prospect theory, biases, heuristics and overconfidence. The original audit already excluded personal-finance, portfolio, tax and wealth-management remainder. These retained resources are decision-science foundations, not financial advice.'),
}
support={
 '102106002':{16:'The syllabus identifies this as applications of evolutionary genomics to agriculture, conservation genetics and personalised medicine; no specific brain or behavioural application is established. Preserve as course background outside the qualified atlas count.'},
 '102106751':{47:'Origin-of-life background, not a substantive treatment of the atlas’s mind/brain/behaviour questions. Retained only as optional broader evolutionary course context.',48:'Continuation of origin-of-life background, not a substantive treatment of the atlas’s mind/brain/behaviour questions. Retained only as optional broader evolutionary course context.'},
 '103101127':{40:'The terminal application concerns HIV evolutionary dynamics. Its disease-specific application is broader biological background rather than a mind/brain/behaviour resource.'},
 '127101592':{n:reason for n,reason in [
  (3,'Origin-of-life background is outside the selected mind/brain/behaviour foundation.'),
  (9,'E. coli quantitative biology is broader microbial background; an individual behavioural/genetic teaching purpose beyond that context is not established.'),
  (12,'E. coli division is microbiological background rather than a substantive atlas learning question.'),
  (14,'Batch-culture growth is cultivation context; the adjacent general growth/selection models remain in scope.'),
  (18,'Chemostat growth is cultivation context; genotype competition and general selection models remain in scope.'),
  (46,'This mixed dN/dS continuation and laboratory-evolution procedure is held as specialist course background; the preceding general dN/dS lecture is retained.'),
  (47,'Serial-subculture experimental procedure is specialist microbial laboratory background.'),
  (48,'Chemostat and mutation-accumulation experimental procedure is specialist microbial laboratory background.'),
  (49,'The megaplate experiment is a specialist microbial experimental application.'),
  (50,'The long-term microbial evolution experiment is retained as broader biological context rather than counted as a behavioural resource.'),
  (55,'Metabolic innovation in laboratory evolution is a specialist microbial application.')
 ]},
 '110106145':{n:'General organisational change/structure material: useful surrounding course context, but no specific individual or group psychological teaching focus is established in this lesson. The prior behavioural sequence is retained.' for n in [53,54,55,56]},
 '110105154':{n:'This lesson is in the course’s practical management/organisation-skills or team-evaluation/reward block rather than the retained psychological account of group behaviour. Preserve as surrounding course context, outside the qualified count.' for n in [37,39,40,50,53,54,55,56,57,58,59,60]},
 '109107740':{n:'Corporate-responsibility or general organisational-change/development implementation is managerial context. The related behavioural lessons on fairness, resistance, motivation and social processes are separately retained.' for n in [50,51,53,54]},
}
exclude={'127101592':{n:'Official evolutionary-course listing anomaly: the title concerns IPsec/VPN or wireless-LAN security. Successful media access does not establish relevance or repair the inconsistent course linkage. Exclude from qualified videos and from supporting recommendations; preserve only the source/audit trail.' for n in [26,27,28,29,30]}}
records={};counts={};clusters={}
for cid in selected:
 c=courses[cid];ev=c['sourceEvidence'];path=f'data/raw/nptel/course-{cid}.html'
 assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==ev['sha256']
 cluster_id,rationale=retained[cid]
 evidence={'id':f'nptel-boundary-{cid}','url':c['sourceUrl'],'retrievedAt':ev['retrievedAt'],'sha256':ev['sha256'],'cachePath':path,'inspection':'Inspected the complete ordered official lecture outline and the course description/weekly syllabus where supplied. Scope boundary review only; no additional transcript or video inspection claimed.'}
 count={'retain':0,'supporting':0,'exclude':0,'qualifiedBefore':0,'qualifiedRemoved':0}
 for r in rows:
  if r['parentCourse']!=c['id']:continue
  no=r['sourceLessonId'];action='retain';reason=rationale;cl=cluster_id
  if no in support.get(cid,{}):action='supporting';reason=support[cid][no];cl='broader-course-context'
  if no in exclude.get(cid,{}):action='exclude';reason=exclude[cid][no];cl='official-course-list-anomaly'
  rid=r['id'].replace('yt:','youtube:')
  records[rid]={'action':action,'reason':reason,'checkedAt':NOW,'checker':'agent','clusterId':cl,'checkSources':[evidence],'courseId':c['id'],'sourceLessonId':no,'title':r['title'],'scopeReviewMethod':'ordered source outline and available syllabus; not a description-check credit'}
  count[action]+=1
  if r['id'] in qualified:
   count['qualifiedBefore']+=1
   if action!='retain':count['qualifiedRemoved']+=1
 counts[cid]={'title':c['title'],**count}
 clusters[cid]={'clusterId':cluster_id,'rationale':rationale,'evidence':evidence}
totals={k:sum(v[k] for v in counts.values()) for k in ['retain','supporting','exclude','qualifiedBefore','qualifiedRemoved']}
write('data/audits/nptel/record-decisions.json',{'checkedAt':NOW,'checker':'agent','scope':'Nine evolutionary, organisational and behavioural-finance courses; bounded independent scope tightening after source acquisition. Frozen snapshots are unchanged.','records':records,'clusters':clusters,'totals':totals,'courseCounts':counts,'limits':'These are source-grounded topical decisions, not scientific appraisals or new transcript-description checks. Other source clusters were not independently re-reviewed in this pass.'})
lines=['# NPTEL boundary review',f'\nChecked {NOW}. No frozen source or media receipt was changed.','\nThe project explicitly includes evolution, genetics and research methods. This review retains coherent general foundations where their role is stated, while removing unrelated course-list anomalies and separating specialist microbiological, origin-of-life and general-management applications.','\n## Counts',f"\n{len(records)} distinct records in nine courses: {totals['retain']} retained, {totals['supporting']} supporting course-context links, {totals['exclude']} excluded anomalies. Of the original 1,535 official-media-qualified NPTEL records, {totals['qualifiedRemoved']} leave the qualified count in this bounded pass, leaving {1535-totals['qualifiedRemoved']} before other agents’ decisions or YouTube API overlays.",'\n| Course | Retain | Supporting | Exclude | Original media-qualified removed |','|---|---:|---:|---:|---:|']
for cid,c in counts.items():lines.append(f"| {cid}: {c['title']} | {c['retain']} | {c['supporting']} | {c['exclude']} | {c['qualifiedRemoved']} |")
lines+=['\n## Source-list defect','\nCourse 127101592 lessons 26–30 are labelled as network security (IPsec, VPNs and wireless LANs), despite their evolutionary-dynamics course context. They are excluded even though the official media endpoint returned a valid MP4 signature. The audit does not invent corrected titles or replacement identifiers.','\n## Retained clusters']
for cid,c in clusters.items():lines.append(f"\n- **{cid}** — {c['rationale']} [Official course]({c['evidence']['url']}).")
lines+=['\n## Limits','\nOrdered outline and syllabus inspection can support a topical decision; it does not establish the scientific correctness of every lecture. No additional selected-core credit comes from this review. Every individual decision, source SHA-256 and cache pointer is in `record-decisions.json`. Generic implementation training is retained only as supporting context, and the five security anomalies receive no supporting recommendation.']
(ROOT/'data/audits/nptel/BOUNDARY_REVIEW.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'records':len(records),'totals':totals,'courseCounts':counts},indent=2))
