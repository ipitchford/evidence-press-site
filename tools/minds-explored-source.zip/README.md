# Minds Explored — Evidence Press edition

This authoring copy builds the permanent public edition for `https://evidencepress.org/minds-explored/`. Publication was authorised on 9 November 2026; the public readback receipt is retained in the host publication workspace. Domain registration is deferred.

This edition deliberately contains no private YouTube API overlay. It includes 4,209 discoverable video records, 51 guides and 20 paths; 1,608 videos have retained independent access evidence. YouTube-only videos open at their original source. The earlier local preview figures below are historical and do not describe this edition.

Build with `ATLAS_BASE_URL=https://evidencepress.org/minds-explored npm run build`, then import with the host repository's `node tools/update-minds-explored.js /absolute/path/to/authoring-copy`. The host retains its guarded deployment and immutable file-manifest checks.

---

# Mind, Brain & Behaviour — an open learning atlas

Evidence Press connects substantive lectures and courses with topic guides and ordered learning paths. Independent learners, students and educators can start with a question, compare sources and prerequisites, and keep a personal library in their browser. The atlas provides education and source navigation, not personalised medical advice or an automatic judgement of scientific correctness.

## Current status

This is a local application and static publication package. **Production publication and DNS changes are not authorised.** All numerical first-release targets have been reached, and the bounded browser checks, clean installation and release-package verification are complete. The maintainer’s 7 November 2026 structural check reports:

| Measure | Count |
| --- | ---: |
| Canonical video records | 4,645 |
| Qualified accessible videos | 4,202 |
| Possible alternate uploads held out of the distinct total | 111 |
| Courses | 118 |
| Verified source-register entries | 28 |
| Verified groups supplying qualified videos | 21 |
| Subject families | 14 |
| Reviewed guides / learning paths | 51 / 20 |
| Individually checked core resources | 201 |
| Supporting resources | 127 |

These are dated source and metadata checks, not a guarantee of playback. The 111 holds are conservative exclusions pending evidence of whether the recordings repeat teaching; none is claimed to be a confirmed equivalence. The 118 course records include separate editions and collections. [PROGRESS.md](PROGRESS.md) and matching validation/build receipts govern release status. The full editorial review cleared all 51 guides and 20 paths. Its 250 selected resources comprise 249 with qualified access evidence and one disclosed optional restricted video, with alternatives. Agent source checks are not human peer review or full-video viewing.

See [EVALUATION.md](EVALUATION.md) for the source sample, fixed search benchmark, engineering checks and their limitations, and the [release checklist](docs/RELEASE_CHECKLIST.md) for the completed checks and their limits. No human pilot or learning-impact evaluation has been conducted.

## Run locally

Requires Node.js 22 or later and npm. A dependency lockfile is supplied.

```sh
npm ci
npm run build
npm start
```

Open `http://127.0.0.1:4173/`. `npm run dev` is the same static preview server: it does not watch or rebuild edited files. Run the build again after changes. Set `PORT` for a different local port. The server binds to the local machine.

| Command | Purpose |
| --- | --- |
| `npm run validate` | Check schema, identifiers, provenance, editorial structure and numerical release gaps. |
| `npm test` | Run the local Node tests. |
| `npm run build` | Recreate `dist/` from current data and reviewed content. |
| `npm run verify` | Validate, test and build. |
| `npm run refresh -- --offline` | Reconcile the maintainer’s saved source snapshots; no new acquisition. |
| `npm run refresh` | Reconcile snapshots and request bounded official YouTube metadata using existing authorised credentials. |
| `npm run evaluate` | Produce fixed-task search comparisons, missingness and an in-memory scale test; manual relevance review is separate. |
| `npm run release:check` | Enforce the numerical first-release targets. It does not certify all release-checklist gates. |

A build needs no API credential, visitor account, hosting account or paid service. A clean distribution without the private YouTube cache has **fewer qualified accessible videos and more unknown metadata**. It rebuilds the supplied permitted base catalogue and original editorial content; it cannot reproduce the private API-enriched totals without a new authorised refresh. Do not copy private credentials or expired responses to force count agreement. The separate clean-build receipt is described in [EVALUATION.md](EVALUATION.md).

Environment variables are read from the process; scripts do not automatically load `.env`. `.env.example` documents `ATLAS_BASE_URL`, `PORT` and the optional local token-file path. Credentials belong only in the private ingestion environment. Source-refresh adapters require their reviewed acquisition inputs; ordinary building does not require republishing those raw snapshots.

## Work with the project

Read [DATA.md](DATA.md), [ATTRIBUTION.md](ATTRIBUTION.md), [corrections](docs/CORRECTIONS.md) and [maintenance](docs/MAINTENANCE.md). The executable schema is under `data/schema/`; original guides and paths are under `content/`. [Deployment instructions](docs/DEPLOYMENT.md) describe a future £0 workflow, subject to approval. [Pilot materials](docs/PILOT_PROTOCOL.md) prepare voluntary evaluation and are not evidence of participation.

Publish only a reviewed `dist/`. Private tokens, API caches, raw source snapshots, downloaded transcript/comment text and local evaluation snapshots are excluded from source distributions and public uploads. API-enriched static builds have a refresh deadline: replacing local cache is insufficient if old HTML or an old search index remains published. See [DATA.md](DATA.md) for the distribution boundary.

Watch later, likes, hidden items, watched status, playlists and path progress stay in browser storage and do not synchronise automatically. Export/import moves this state between browsers. Opening a video is distinct from marking it watched. The correction form downloads a note locally and does not send it.
