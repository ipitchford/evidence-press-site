import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {MAX_API_AGE_MS, retentionClock, purgeEvaluationAPIData} from '../scripts/api-retention.mjs';

const START = '2026-01-01T12:00:00.000Z';
const END = Date.parse(START) + MAX_API_AGE_MS;
const ID = 'youtube:abcdefghijk';
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'atlas-api-retention-'));
  t.after(() => fs.rm(root, {recursive: true, force: true}));
  async function write(file, value, jsonl = false) {
    await fs.mkdir(path.dirname(path.join(root, file)), {recursive: true});
    await fs.writeFile(path.join(root, file), jsonl ? value.map(v => JSON.stringify(v)).join('\n') + '\n' : JSON.stringify(value));
  }
  async function read(file) { return JSON.parse(await fs.readFile(path.join(root, file), 'utf8')); }
  return {root, write, read};
}
function record({id = ID, checkedAt = START, range = false, sourceDuration = false} = {}) {
  return {
    id, title: 'Institutional title', description: 'Independent source description',
    apiMetadata: {checkedAt, expiresAt: '2099-01-01T00:00:00Z', title: 'API-only title', channel: 'API channel', thumbnail: 'https://example.org/api-image'},
    durationSeconds: sourceDuration ? 600 : 999,
    durationOrigin: sourceDuration ? 'publisher' : 'youtube-api',
    language: 'en-US', languageOrigin: 'youtube-api', uploadDate: '2025-12-01', uploadDateOrigin: 'youtube-api',
    recordingDate: '2024-01-01', recordingDateOrigin: 'publisher',
    qualification: range ? {status: 'qualified', sourceIdentityResolved: true} : {status: 'qualified', sourceIdentityResolved: true, accessEvidence: 'youtube-api-abcdefghijk'},
    availability: range ? {status: 'accessible', method: 'official-media-range', checkedAt: '2025-12-30T00:00:00Z', note: '32 bytes and MP4 header. Separate YouTube API check (2026-01-01): public processed video.'} : {status: 'accessible', method: 'authorised-api-metadata', checkedAt, note: 'API says public', evidence: ['youtube-api-abcdefghijk']},
    provenance: [{id: 'publisher-receipt', sha256: 'source-hash', retrievedAt: '2025-12-01T00:00:00Z'}, {id: 'youtube-api-abcdefghijk', sha256: 'api-body-hash', retrievedAt: checkedAt, cachePath: '.cache/youtube/batches/example.json'}],
  };
}

test('the deadline is original retrieval +28 days, with an earlier expiry honoured', () => {
  assert.equal(retentionClock(START, '2099-01-01T00:00:00Z').end, END);
  assert.equal(retentionClock(START, '2026-01-10T12:00:00Z').end, Date.parse('2026-01-10T12:00:00Z'));
  assert.equal(retentionClock('yesterday'), null);
  assert.equal(retentionClock('2026-01-01'), null);
});

test('dry run is read-only; exact boundary redacts only expired fields and is idempotent', async t => {
  const f = await fixture(t), file = 'evaluation/editorial-review/current-resources.json';
  const old = record(), fresh = record({id: 'youtube:lmnopqrstuv', checkedAt: '2026-01-20T12:00:00Z'});
  const value = {checkedAt: '2026-01-29T11:59:59Z', records: [old, fresh]};
  await f.write(file, value);
  const originalText = await fs.readFile(path.join(f.root, file), 'utf8');
  assert.equal((await purgeEvaluationAPIData({root: f.root, now: END - 1})).redactions, 0);
  const dry = await purgeEvaluationAPIData({root: f.root, now: END});
  assert(dry.redactions > 0); assert.equal(dry.applied, false);
  assert.equal(await fs.readFile(path.join(f.root, file), 'utf8'), originalText);
  const applied = await purgeEvaluationAPIData({root: f.root, now: END, apply: true});
  assert.equal(applied.blocked.length, 0);
  const after = await f.read(file), r = after.records[0];
  assert.equal(r.apiMetadata, undefined); assert.equal(r.durationSeconds, undefined); assert.equal(r.language, undefined); assert.equal(r.uploadDate, undefined);
  assert.equal(r.availability.status, undefined); assert.equal(r.qualification.status, undefined);
  assert.equal(r.title, old.title); assert.equal(r.description, old.description); assert.equal(r.recordingDate, old.recordingDate);
  assert.deepEqual(r.provenance, old.provenance); assert.equal(r.qualification.sourceIdentityResolved, true);
  assert.equal(r.apiRetention.events[0].originalCheckedAt, START);
  assert.deepEqual(after.records[1], fresh);
  const once = await fs.readFile(path.join(f.root, file), 'utf8');
  assert.equal((await purgeEvaluationAPIData({root: f.root, now: END + 1, apply: true})).redactions, 0);
  assert.equal(await fs.readFile(path.join(f.root, file), 'utf8'), once);
});

test('official range evidence and publisher-derived values survive removal of the API overlay', async t => {
  const f = await fixture(t), file = 'evaluation/source-sample/snapshot.json';
  const old = record({range: true, sourceDuration: true}); await f.write(file, [old]);
  await purgeEvaluationAPIData({root: f.root, now: END, apply: true});
  const [r] = await f.read(file);
  assert.equal(r.durationSeconds, 600); assert.equal(r.durationOrigin, 'publisher');
  assert.equal(r.availability.status, 'accessible'); assert.equal(r.qualification.status, 'qualified');
  assert.equal(r.availability.note, '32 bytes and MP4 header.'); assert.deepEqual(r.provenance, old.provenance);
});

test('an independent scope exclusion is preserved even beside a stale API evidence reference', async t => {
  const f = await fixture(t), file = 'evaluation/source-sample/snapshot.json';
  const old = record(); old.qualification.status = 'excluded'; old.qualification.reason = 'Independent scope exclusion';
  await f.write(file, [old]); await purgeEvaluationAPIData({root: f.root, now: END, apply: true});
  const [r] = await f.read(file);
  assert.equal(r.qualification.status, 'excluded'); assert.equal(r.qualification.reason, 'Independent scope exclusion');
  assert.equal(r.apiMetadata, undefined);
});

test('mixed JSONL retains independent conclusions and provenance while expiring embedded access', async t => {
  const f = await fixture(t), file = 'evaluation/source-sample/records.jsonl';
  const value = {id: ID, inspectedBasis: 'Actual publisher text read.', result: 'pass', sourceSha256: 'source-hash',
    retrievalProvenance: [{id: 'youtube-api-abcdefghijk', retrievedAt: START, sha256: 'api-body-hash'}],
    qualificationAtFreeze: {status: 'qualified', accessEvidence: 'youtube-api-abcdefghijk', substanceResolved: true},
    accessInspection: {id: ID, method: 'authorised-api-metadata', status: 'accessible', api: {checkedAt: START, privacy: 'public', duration: 'PT10M'}}};
  await f.write(file, [value], true);
  const r = await purgeEvaluationAPIData({root: f.root, now: END, apply: true}); assert.equal(r.blocked.length, 0);
  const out = JSON.parse((await fs.readFile(path.join(f.root, file), 'utf8')).trim());
  assert.equal(out.accessInspection.api, undefined); assert.equal(out.accessInspection.status, undefined);
  assert.equal(out.qualificationAtFreeze.status, undefined); assert.equal(out.qualificationAtFreeze.substanceResolved, true);
  assert.equal(out.inspectedBasis, value.inspectedBasis); assert.equal(out.result, 'pass'); assert.equal(out.sourceSha256, 'source-hash');
  assert.deepEqual(out.retrievalProvenance, value.retrievalProvenance);
});

test('source-reading projections use frozen origin flags and keep source text and duration', async t => {
  const f = await fixture(t);
  await f.write('evaluation/source-sample/snapshot.json', [record({range: true, sourceDuration: true})]);
  await f.write('evaluation/source-sample/inspection-packet.json', [{id: ID, sourceBlocks: ['Publisher paragraph'], actualSha256: 'source-hash', language: 'en-US', durationSeconds: 600, recordingDate: '2024-01-01'}]);
  const result = await purgeEvaluationAPIData({root: f.root, now: END, apply: true}); assert.equal(result.blocked.length, 0);
  const [r] = await f.read('evaluation/source-sample/inspection-packet.json');
  assert.equal(r.language, undefined); assert.equal(r.durationSeconds, 600); assert.equal(r.recordingDate, '2024-01-01');
  assert.deepEqual(r.sourceBlocks, ['Publisher paragraph']); assert.equal(r.actualSha256, 'source-hash');
});

test('an old search projection cannot receive a new lifetime from copy time or a refreshed cache', async t => {
  const f = await fixture(t);
  await f.write('evaluation/source-sample/snapshot.json', [record()]);
  await f.write('.cache/youtube/metadata.json', {records: {abcdefghijk: {checkedAt: '2026-01-29T12:00:00Z'}}});
  const report = {checkedAt: '2026-01-29T12:00:00Z', tasks: [{variants: {enhanced: {firstFive: [{id: ID, qualified: true, title: 'Institutional title', relevance: 'direct', reason: 'Manually checked selection.', score: 12}]}}}]};
  const copies = ['manual-review-123456.json', 'pre-genetics-search-results.json', 'manual-review-pre-genetics.json',
    'pre-overlap-search-results.json', 'manual-review-pre-overlap.json'];
  for (const name of copies) await f.write(`evaluation/search-review-inputs/${name}`, report);
  const result = await purgeEvaluationAPIData({root: f.root, now: END, apply: true}); assert.equal(result.blocked.length, 0);
  for (const name of copies) {
    const out = await f.read(`evaluation/search-review-inputs/${name}`);
    const row = out.tasks[0].variants.enhanced.firstFive[0];
    assert.equal(row.qualified, undefined); assert.equal(row.relevance, 'direct'); assert.equal(row.reason, 'Manually checked selection.'); assert.equal(row.score, 12);
    assert.equal(row.apiRetention.events[0].originalCheckedAt, START);
  }
});

test('an untraceable original date blocks apply without deleting independent or otherwise due data', async t => {
  const f = await fixture(t);
  await f.write('evaluation/source-sample/snapshot.json', [record()]);
  const report = {checkedAt: '2026-01-10T00:00:00Z', tasks: [{id: 'youtube:zzzzzzzzzzz', qualified: true, reason: 'Independent note'}]};
  await f.write('evaluation/search-results.json', report);
  await f.write('.cache/youtube/metadata.json', {records: {zzzzzzzzzzz: {checkedAt: '2026-01-29T12:00:00Z'}}});
  const before = await fs.readFile(path.join(f.root, 'evaluation/source-sample/snapshot.json'), 'utf8');
  const result = await purgeEvaluationAPIData({root: f.root, now: END, apply: true});
  assert.equal(result.applied, false); assert.equal(result.blocked.length, 1);
  assert.match(result.blocked[0].reason, /No copy-time lifetime/);
  assert.equal(await fs.readFile(path.join(f.root, 'evaluation/source-sample/snapshot.json'), 'utf8'), before);
  assert.deepEqual(await f.read('evaluation/search-results.json'), report);
});

test('allowlist preserves packets, baseline source records, notes, aggregate design and unrelated files', async t => {
  const f = await fixture(t), protectedFiles = [
    'evaluation/editorial-review/packets/guides/example.json',
    'evaluation/source-sample/plan.json', 'data/catalogue.jsonl',
    'evaluation/source-sample/independent-notes.json', 'evaluation/search-review-inputs/manual-review-notes.json',
  ];
  for (const file of protectedFiles) await f.write(file, {independentNote: 'Preserve exactly', apiMetadata: {checkedAt: START, title: 'Not an allowlisted snapshot'}});
  await f.write('evaluation/source-sample/access-inspection.json', [{id: ID, api: {checkedAt: START, privacy: 'public'}, range: {sha256: 'range-hash', httpStatus: 206}}]);
  const before = await Promise.all(protectedFiles.map(file => fs.readFile(path.join(f.root, file), 'utf8')));
  const result = await purgeEvaluationAPIData({root: f.root, now: END, apply: true}); assert.equal(result.blocked.length, 0);
  for (let i = 0; i < protectedFiles.length; i++) assert.equal(await fs.readFile(path.join(f.root, protectedFiles[i]), 'utf8'), before[i]);
  const [out] = await f.read('evaluation/source-sample/access-inspection.json');
  assert.equal(out.api, undefined); assert.deepEqual(out.range, {sha256: 'range-hash', httpStatus: 206});
});

test('selected-record maps retain source records and prose while removing an expired overlay', async t => {
  const f = await fixture(t), file = 'evaluation/search-review-inputs/selected-records.json';
  const source = {id: 'youtube:lmnopqrstuv', title: 'Publisher title', description: 'Publisher description',
    durationSeconds: 600, thumbnail: 'https://publisher.example/image.jpg',
    availability: {status: 'accessible', method: 'official-media-range', checkedAt: START},
    qualification: {status: 'qualified', reason: 'Independent range observation'},
    provenance: [{id: 'publisher-receipt', sha256: 'source-hash'}]};
  const guide = {slug: 'example', body: 'Manually authored source-based guidance.', sources: [{sha256: 'source-hash'}]};
  const selected = {[ID]: record(), [source.id]: source, 'guide:example': guide};
  await f.write(file, selected);
  const result = await purgeEvaluationAPIData({root: f.root, now: END, apply: true});
  assert.equal(result.blocked.length, 0);
  const out = await f.read(file);
  assert.equal(out[ID].apiMetadata, undefined); assert.equal(out[ID].durationSeconds, undefined);
  assert.equal(out[ID].description, selected[ID].description);
  assert.deepEqual(out[source.id], source); assert.deepEqual(out['guide:example'], guide);
});

test('symlink targets and ancestor symlinks are refused without touching external files', async t => {
  const f = await fixture(t), outside = path.join(f.root, 'outside.json');
  await fs.writeFile(outside, JSON.stringify([record()]));
  await fs.mkdir(path.join(f.root, 'evaluation/source-sample'), {recursive: true});
  const link = path.join(f.root, 'evaluation/source-sample/snapshot.json'); await fs.symlink(outside, link);
  await assert.rejects(purgeEvaluationAPIData({root: f.root, now: END, apply: true}), /symlink/);
  assert.deepEqual(JSON.parse(await fs.readFile(outside, 'utf8')), [record()]);
  await fs.unlink(link); await fs.rm(path.join(f.root, 'evaluation'), {recursive: true});
  await fs.mkdir(path.join(f.root, 'elsewhere/source-sample'), {recursive: true});
  await fs.symlink(path.join(f.root, 'elsewhere'), path.join(f.root, 'evaluation'));
  await assert.rejects(purgeEvaluationAPIData({root: f.root, now: END, apply: true}), /symlink/);
});
