import test from 'node:test';
import assert from 'node:assert/strict';
import {applyAPI} from '../scripts/api-overlay.mjs';
import {apiAccessibility,isoDuration} from '../scripts/youtube-refresh.mjs';

const now=Date.parse('2026-11-07T18:00:00Z');
const record={id:'youtube:abcdefghijk',qualification:{status:'candidate',sourceIdentityResolved:true,substanceResolved:true},availability:{status:'unknown'},provenance:[],durationSeconds:null,language:null};
const metadata={checkedAt:'2026-11-07T17:00:00Z',expiresAt:'2026-12-05T17:00:00Z',method:'authorised-api-metadata',availability:{status:'accessible',reason:'Public, processed; not observed playback.'},provenance:{id:'api-test'},item:{snippet:{publishedAt:'2020-01-01T00:00:00Z',defaultAudioLanguage:'en'},contentDetails:{duration:'PT1H2M3S'},status:{privacyStatus:'public',uploadStatus:'processed'}}};
const overlay=(row=record,meta=metadata)=>applyAPI([row],{records:{abcdefghijk:meta}},now)[0];
test('API overlay expires without mutating independent source records',()=>{
  const before=structuredClone(record),result=overlay();assert.equal(result.qualification.status,'qualified');assert.equal(result.durationSeconds,3723);assert.equal(result.availability.playbackObserved,false);assert.deepEqual(record,before);
  for(const expiresAt of ['2026-11-06','not-a-date',undefined])assert.equal(overlay(record,{...metadata,expiresAt}),record);
});
test('API accessibility cannot override unresolved identity, shallow content, overlap holds or exclusion',()=>{
  for(const qualification of [{...record.qualification,sourceIdentityResolved:false},{...record.qualification,substanceResolved:false},{...record.qualification,distinctnessResolved:false},{...record.qualification,status:'excluded'}])assert.notEqual(overlay({...record,qualification}).qualification.status,'qualified');
  assert.notEqual(overlay({...record,alternateOf:'youtube:other123456'}).qualification.status,'qualified');
});
test('spoken language uses only defaultAudioLanguage and preserves an established source language',()=>{
  const meta=snippet=>({...metadata,item:{...metadata.item,snippet}});
  const metadataOnly=overlay(record,meta({defaultLanguage:'en'}));assert.equal(metadataOnly.language,null);assert.equal(metadataOnly.languageOrigin,undefined);
  const audio=overlay(record,meta({defaultLanguage:'en',defaultAudioLanguage:'fr'}));assert.equal(audio.language,'fr');assert.equal(audio.languageOrigin,'youtube-api');
  const established=overlay({...record,language:'de'},meta({defaultLanguage:'en',defaultAudioLanguage:'fr'}));assert.equal(established.language,'de');assert.equal(established.languageOrigin,undefined);
});
test('a verified authorised alternative survives a restricted YouTube destination',()=>{
  const alternative={...record,qualification:{...record.qualification,status:'qualified'},availability:{status:'accessible',method:'official-media-range',evidence:['range'],note:'Media range verified.'}};
  const result=overlay(alternative,{...metadata,availability:{status:'restricted',reason:'Age restriction'}});assert.equal(result.availability.method,'official-media-range');assert.equal(result.qualification.status,'qualified');assert.match(result.availability.note,/Age restriction/);
  assert.equal(overlay({...record,qualification:{...record.qualification,status:'qualified'}},{...metadata,availability:{status:'unavailable',reason:'Missing'}}).qualification.status,'candidate');
});
test('API status preserves age, regional, unprocessed and absent-item uncertainty',()=>{
  const item=metadata.item;assert.equal(apiAccessibility(item).status,'accessible');assert.equal(apiAccessibility(null).status,'unavailable');assert.equal(apiAccessibility({...item,status:{privacyStatus:'public',uploadStatus:'uploaded'}}).status,'unknown');
  for(const contentDetails of [{regionRestriction:{blocked:['GB']}},{regionRestriction:{allowed:['US']}},{contentRating:{ytRating:'ytAgeRestricted'}}])assert.equal(apiAccessibility({...item,contentDetails}).status,'restricted');
  assert.equal(isoDuration('P1DT2H3M4S'),93784);assert.equal(isoDuration('invalid'),null);
});
