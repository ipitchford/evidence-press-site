import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {accessEvidence,applyAlternateReviews,applyAuditDecisions,applyCommunityReviews,canonicalIdentity,evidence,mergeCoreFragments,mergeRecords,normalise,normaliseRecord,normaliseTopics,publicURL} from '../scripts/normalise.mjs';
import {isQualified} from '../src/model.mjs';

const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const date='2026-11-07T15:00:00Z';
const videoId='ba-HMvDn_vU';
const sourceUrl='https://ocw.mit.edu/courses/test/resources/lecture-1/';
const mediaUrl='https://archive.org/download/test/lecture1.mp4';
const sourceHash=hash('fixture source page');
const report=()=>({unmappedTopics:[],conflicts:[],orphanEditorialFragments:[],editorialFragmentFailures:[],appliedEditorialFragments:[],orphanAuditDecisions:[],auditDecisionFailures:[],appliedAuditDecisions:[],communityReviewFailures:[],communityReviews:[]});
async function temporary(t) {
  const root=await fs.mkdtemp(path.join(os.tmpdir(),'atlas-normalise-'));
  t.after(()=>fs.rm(root,{recursive:true,force:true}));
  return root;
}
async function save(root,name,value) {
  const filename=path.join(root,name);await fs.mkdir(path.dirname(filename),{recursive:true});
  await fs.writeFile(filename,typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');
}
async function receipt(root,{badBody=false,mime='video/mp4'}={}) {
  const body=Buffer.alloc(32);body.writeUInt32BE(24,0);body.write(badBody?'xxxx':'ftyp',4);body.write('isom',8);
  const filename='data/raw/fixture/media.bin';await fs.mkdir(path.dirname(path.join(root,filename)),{recursive:true});await fs.writeFile(path.join(root,filename),body);
  return {url:mediaUrl,checkedAt:date,method:'GET Range bytes=0-31',exitCode:0,httpStatus:206,contentType:mime,contentRange:'bytes 0-31/10000',bytes:32,bodyCachePath:filename,sha256:hash(body),mediaEndpointAccessible:true,playbackObserved:false};
}
function rawRecord(overrides={}) {
  return {id:`youtube:${videoId}`,title:'Lecture 1: Introduction',canonicalUrl:`https://www.youtube.com/watch?v=${videoId}`,sourceUrl,providerId:'mit-ocw',parentCourse:'test-course',subjectFamilies:['neuroscience'],format:'lecture',speaker:'Course Instructor',courseInstructor:'Course Instructor',language:'en',languageEvidence:'English-language institutional page; audio not checked',level:'undergraduate',descriptionEvidence:{url:sourceUrl,retrievedAt:date,sha256:sourceHash,inspection:'Fixture source title and course context',excerptForPrivateAudit:'THIS MUST NEVER APPEAR IN EXPORT'},retrieval:{url:sourceUrl,retrievedAt:date,sha256:sourceHash},availability:{status:'unknown',method:'source-page-only',checkedAt:date},selectionBasis:'institutional_collection',selectionReason:'An in-scope source-listed course lecture.',scientificAssessment:'Not assessed',authorisedMediaAlternatives:[mediaUrl],...overrides};
}
function context(root) {
  return {root,report:report(),courses:new Map([['test-course',{id:'test-course',title:'Test Neuroscience',statedLevel:'Undergraduate'}]]),sources:new Map([['mit-ocw',{id:'mit-ocw',name:'MIT OpenCourseWare',licence:'CC BY-NC-SA 4.0'}]])};
}

test('only exact official, successful range samples with verified bytes qualify',async t=>{
  const root=await temporary(t),r=await receipt(root);
  const options={root,officialAlternatives:[mediaUrl]};
  const good=await accessEvidence({availability:{},mediaEndpointChecks:[r]},options);
  assert.equal(good.availability.status,'accessible');assert.equal(good.availability.playbackObserved,false);
  for(const changed of [{httpStatus:200},{contentRange:'bytes 100-131/10000'},{sha256:'0'.repeat(64)},{method:'HEAD'},{url:'https://unlisted.example/lecture.mp4'},{permitted:false},{auditOnly:true}]) {
    const bad=await accessEvidence({mediaEndpointChecks:[{...r,...changed}]},options);assert.equal(bad.availability.status,'unknown');
  }
  const bad=await receipt(root,{badBody:true});
  assert.equal((await accessEvidence({mediaEndpointChecks:[bad]},options)).availability.status,'unknown');
});

test('a generic binary response needs MP4 path and container bytes; HEAD alone is insufficient',async t=>{
  const root=await temporary(t),r=await receipt(root,{mime:'application/octet-stream'});
  assert.equal((await accessEvidence({mediaEndpointChecks:[r]},{root,officialAlternatives:[mediaUrl]})).availability.status,'accessible');
  const head=await accessEvidence({availability:{status:'official-media-endpoint-accessible',method:'HTTP HEAD',checkedAt:date,httpStatus:200}});
  assert.equal(head.availability.status,'unknown');
});

test('a legacy Archive.org source link qualifies only through its exact evidenced HTTPS request',async t=>{
  const root=await temporary(t),r=await receipt(root),http=mediaUrl.replace('https:','http:');
  const good=await normaliseRecord(rawRecord({authorisedMediaAlternatives:[http],mediaEndpointChecks:[{...r,url:http,requestUrl:mediaUrl}]}),'courses',context(root));
  assert.equal(good.record.availability.status,'accessible');
  const wrong=await normaliseRecord(rawRecord({authorisedMediaAlternatives:[http],mediaEndpointChecks:[{...r,url:http,requestUrl:'https://archive.org/download/other.mp4'}]}),'courses',context(root));
  assert.equal(wrong.record.availability.status,'unknown');
});

test('historical player observations do not qualify, and course fields do not become lecture facts',async t=>{
  const root=await temporary(t);
  const raw=rawRecord({availability:{status:'historical-player-metadata-OK',auditOnly:true,method:'Public watch-page player metadata',checkedAt:date},durationSeconds:4200,uploadDate:'2020-01-01',recordingDate:'2019-01-01'});
  const {record}=await normaliseRecord(raw,'courses',context(root));
  assert.equal(record.availability.status,'unknown');assert.equal(record.availability.auditOnly,true);
  assert.equal(record.speaker,null);assert.equal(record.language,null);assert.equal(record.level,'unknown');
  assert.equal(record.durationSeconds,null);assert.equal(record.uploadDate,null);assert.equal(record.recordingDate,null);
  assert.equal(record.descriptionCheck.status,'unchecked');assert.equal(isQualified(record),false);
  assert(!JSON.stringify(record).includes('THIS MUST NEVER APPEAR'));
});

test('source mapping ambiguity and unresolved substance remain independent of accessibility',async t=>{
  const root=await temporary(t),r=await receipt(root);
  for(const fields of [{titleStatus:'page_context_only_multiple_videos'},{substanceCheck:'Pending individual duration and content check'}]) {
    const {record}=await normaliseRecord(rawRecord({...fields,mediaEndpointChecks:[r]}),'courses',context(root));
    assert.equal(record.availability.status,'accessible');assert.equal(record.qualification.status,'candidate');assert.equal(isQualified(record),false);
  }
});

test('canonicalisation is stable and refuses embedded credentials and signed URLs',()=>{
  assert.equal(canonicalIdentity(`https://youtu.be/${videoId}?t=2`).id,`youtube:${videoId}`);
  assert.deepEqual(canonicalIdentity('https://official.example/a.mp4?utm_source=abc'),canonicalIdentity('https://official.example/a.mp4'));
  assert.equal(publicURL('https://official.example/file?access_token=secret'),null);
  assert.equal(publicURL('https://user:password@official.example/file'),null);
  assert.throws(()=>canonicalIdentity('javascript:alert(1)'));
  assert.equal(evidence({url:'https://example.com',sha256:'invented',retrievedAt:date},'x'),null);
});

test('unknown taxonomy values are reported rather than silently assigned to a narrow subject',()=>{
  const r=report();assert.deepEqual(normaliseTopics(['psychology','learning-memory-education','computational-cognition'],r,'row'),['computation-ai','learning-memory']);
  assert.deepEqual(r.unmappedTopics,[{context:'row',topic:'psychology'}]);
});

test('duplicate IDs preserve all memberships and evidence without merging distinct lecture IDs',async t=>{
  const root=await temporary(t),a=await normaliseRecord(rawRecord(),'courses',context(root));
  const b=structuredClone(a);b.origin='second-source';b.record.title='An alternate source title';b.record.courseId='another-course';b.memberships=['another-course'];
  b.record.provenance=[{...b.record.provenance[0],id:'second-proof',url:'https://official.example/lecture'}];
  const c=structuredClone(a);c.record.id='youtube:NNnIGh9g6fA';c.record.canonicalUrl='https://www.youtube.com/watch?v=NNnIGh9g6fA';
  const r=report(),one=mergeRecords([b,c,a],r),two=mergeRecords([a,b,c],report());
  assert.deepEqual(one,two);assert.equal(one.length,2);
  const merged=one.find(x=>x.record.id===a.record.id);assert.deepEqual(merged.memberships,['another-course','test-course']);assert.equal(merged.record.provenance.length,2);
  assert(r.conflicts.some(x=>x.field==='title'));assert(r.conflicts.some(x=>x.field==='courseId'));
});

test('only explicit source-backed equivalence maps uploads; overlap stays held without transferring access',async t=>{
  const root=await temporary(t),sample=await receipt(root),a=await normaliseRecord(rawRecord({mediaEndpointChecks:[sample]}),'courses',context(root));
  const b=await normaliseRecord(rawRecord({canonicalUrl:'https://www.youtube.com/watch?v=NNnIGh9g6fA',sourceUrl:'https://official.example/alternate'}),'courses',context(root));
  const c=await normaliseRecord(rawRecord({canonicalUrl:'https://www.youtube.com/watch?v=phbw9r1iUDI',mediaEndpointChecks:[sample]}),'courses',context(root));
  const proof={id:'equivalence-proof',url:sourceUrl,retrievedAt:date,sha256:sourceHash,inspection:'Fixture equivalent content decision'};
  const common={checkedAt:date,checker:'agent',reason:'Exact source comparison, not a title match.',checkSources:[proof]};
  const r=report();applyAlternateReviews([a,b,c],[{file:'pack',value:{mappings:[{...common,id:b.record.id,alternateOf:a.record.id,status:'confirmed-equivalent'}],unresolved:[{...common,ids:[c.record.id],status:'overlap-unresolved'}]}}],r);
  assert.equal(isQualified(a.record),true);assert.equal(b.record.alternateOf,a.record.id);assert.equal(isQualified(b.record),false);
  assert.equal(b.record.availability.status,'unknown');assert.equal(b.record.sourceUrl,'https://official.example/alternate');
  assert.equal(c.record.availability.status,'accessible');assert.equal(c.record.qualification.distinctnessResolved,false);assert.equal(isQualified(c.record),false);
  assert.equal(a.record.selection.alternateUploads[0].id,b.record.id);assert.equal(r.alternateReviews.confirmed.length,1);assert.equal(r.alternateReviews.holds.length,1);
});

test('alternate review rejects missing parents, cycles, conflicting parents and unproved title matches',async t=>{
  const root=await temporary(t),a=await normaliseRecord(rawRecord(),'courses',context(root)),b=structuredClone(a),c=structuredClone(a);
  b.record.id='youtube:NNnIGh9g6fA';c.record.id='youtube:phbw9r1iUDI';
  const common={status:'confirmed-equivalent',checkedAt:date,checker:'agent',reason:'Fixture comparison.',checkSources:[{id:'proof',url:sourceUrl,retrievedAt:date,sha256:sourceHash}]};
  const one={...common,id:b.record.id,alternateOf:a.record.id};
  for(const mappings of [[{...one,alternateOf:'youtube:missing1234'}],[one,{...common,id:a.record.id,alternateOf:b.record.id}],[one,{...one,alternateOf:c.record.id}],[{...one,checkSources:[]}],[{...one,status:'same-title'}]]) {
    const rows=structuredClone([a,b,c]),before=structuredClone(rows);
    assert.throws(()=>applyAlternateReviews(rows,[{file:'pack',value:{mappings,unresolved:[]}}],report()));assert.deepEqual(rows,before);
  }
});

test('individually checked editorial fragments need real evidence IDs and cannot replace availability',async t=>{
  const root=await temporary(t),item=await normaliseRecord(rawRecord(),'courses',context(root));
  const source={id:'checked-source',url:sourceUrl,retrievedAt:date,sha256:sourceHash,inspection:'Individually inspected source description'};
  const good={description:'Individually authored description.',descriptionCheck:{status:'checked',method:'publisher-description',checkedAt:date,checker:'agent',evidenceIds:['checked-source']},selection:{basis:'institutional-collection',reason:'A specific source-grounded role.',checkedAt:date,checker:'agent',evidenceIds:['checked-source']},checkSources:[source],availability:{status:'accessible'}};
  const r=report();mergeCoreFragments([item],[{file:'data/audits/editor/core-overrides.json',value:{[item.record.id]:good}}],r);
  assert.equal(item.record.descriptionCheck.status,'checked');assert.equal(item.record.availability.status,'unknown');assert.equal(item.record.qualification.status,'candidate');
  const bad={...good,descriptionCheck:{...good.descriptionCheck,evidenceIds:['missing']}};
  mergeCoreFragments([item],[{file:'other',value:{[item.record.id]:bad}}],r);assert.equal(r.editorialFragmentFailures.length,1);
});

test('source scope exclusions survive accessible bytes and do not create description-check credit',async t=>{
  const root=await temporary(t),r=await receipt(root),item=await normaliseRecord(rawRecord({mediaEndpointChecks:[r]}),'courses',context(root));
  assert.equal(isQualified(item.record),true);
  const source={id:'scope-source',url:sourceUrl,retrievedAt:date,sha256:sourceHash,inspection:'Individual scope check'};
  const decision={action:'supporting',reason:'General ecosystem background outside the selected subject scope.',checkedAt:date,checker:'agent',topics:['evolution-comparative'],checkSources:[source]};
  const audit=report();applyAuditDecisions([item],[{file:'scope',value:{records:{[item.record.id]:decision}}}],audit);
  assert.equal(item.record.availability.status,'accessible');assert.equal(item.record.qualification.status,'excluded');assert.equal(isQualified(item.record),false);
  assert.equal(item.record.descriptionCheck.status,'unchecked');assert(item.supportingDecision);
  assert.deepEqual(item.record.topics,['evolution-comparative']);
  applyAuditDecisions([item],[{file:'topic',value:{records:{[item.record.id]:{...decision,action:'topic-correction',topicMode:'add',topics:['methods']}}}}],audit);
  assert.equal(item.record.qualification.status,'excluded');assert.deepEqual(item.record.topics,['evolution-comparative','methods']);
});

test('community counts require explicit positive, non-promotional, source-backed individual review',async t=>{
  const root=await temporary(t),item=await normaliseRecord(rawRecord(),'courses',context(root));
  item.record.community={positiveMentions:5,independentPositiveMentions:null,note:'Imported sample.'};
  const sources=[1,2,3].map(n=>({id:`community-proof-${n}`,url:`https://official.example/proof${n}`,retrievedAt:date,sha256:sourceHash,inspection:'Fixture identity/context source'}));
  const base={videoId:item.record.id,commentId:1,sourceUrl:'https://news.ycombinator.com/item?id=1',stance:'rec',positiveContextConfirmed:true,selfPromotion:false,independenceChecked:true,independenceRationale:'Explicit bounded public identity and recommendation context.',checkedAt:date,checker:'agent',checkSources:sources};
  const reviews=[base,{...base,commentId:2,selfPromotion:null,independenceChecked:false},{...base,commentId:3,selfPromotion:true},{...base,commentId:4,stance:'reference'}];
  const r=report();applyCommunityReviews([item],reviews,r);
  assert.equal(item.record.community.independentPositiveMentions,1);assert.equal(item.record.community.reviewedMentions.length,4);
  assert.equal(r.communityReviews[0].notCounted,3);
  const untouched=structuredClone(item);untouched.record.community.independentPositiveMentions=null;
  applyCommunityReviews([untouched],[{...base,selfPromotion:null}],report());assert.equal(untouched.record.community.independentPositiveMentions,null);
});

test('repeatable imports preserve local overrides/withdrawals and evidenced course order',async t=>{
  const root=await temporary(t),r=await receipt(root);
  const rows=[rawRecord({id:'youtube:NNnIGh9g6fA',canonicalUrl:'https://www.youtube.com/watch?v=NNnIGh9g6fA',title:'Lecture 12: Later topic',sourceUrl:'https://ocw.mit.edu/courses/test/resources/lecture-12/',mediaEndpointChecks:[r]}),rawRecord({title:'Lecture 2: Earlier topic',mediaEndpointChecks:[r]})];
  await save(root,'data/audits/courses/candidates.json',rows);
  await save(root,'data/audits/courses/course-register.json',[{id:'test-course',title:'Test Neuroscience',provider:'mit-ocw',url:'https://ocw.mit.edu/courses/test/',families:['neuroscience'],sourceCheck:{url:'https://ocw.mit.edu/courses/test/',retrievedAt:date,sha256:sourceHash}}]);
  await save(root,'data/audits/courses/provider-register.json',[{id:'mit-ocw',name:'MIT OpenCourseWare',url:'https://ocw.mit.edu/',seedRetrieval:{url:'https://ocw.mit.edu/courses/test/',retrievedAt:date,sha256:sourceHash}}]);
  const overrides=`{\n  "youtube:${videoId}": {"title":"Editor's title"}\n}\n`;
  const withdrawals=`[{"id":"youtube:${videoId}","reason":"An explicit withdrawal"}]\n`;
  await save(root,'data/editorial-overrides.json',overrides);await save(root,'data/withdrawals.json',withdrawals);
  const first=await normalise({root});const bytes=await fs.readFile(path.join(root,'data/catalogue.jsonl'),'utf8');
  const second=await normalise({root});
  assert.equal(await fs.readFile(path.join(root,'data/catalogue.jsonl'),'utf8'),bytes);
  assert.deepEqual(first.report.outputHashes,second.report.outputHashes);
  assert.equal(await fs.readFile(path.join(root,'data/editorial-overrides.json'),'utf8'),overrides);
  assert.equal(await fs.readFile(path.join(root,'data/withdrawals.json'),'utf8'),withdrawals);
  const effective=second.effectiveRecords.find(x=>x.id===`youtube:${videoId}`);assert.equal(effective.title,"Editor's title");assert.equal(effective.withdrawn,true);assert.equal(isQualified(effective),false);
  assert.deepEqual(second.courses[0].resourceIds,[`youtube:${videoId}`,'youtube:NNnIGh9g6fA']);
  assert.match(second.courses[0].orderBasis,/Explicit institutional lecture number/);
  const persisted=JSON.parse(bytes.split('\n')[0]);assert(!JSON.stringify(persisted).includes('THIS MUST NEVER APPEAR'));
});

test('repeatable alternate imports retain both upload rows and original course source/order',async t=>{
  const root=await temporary(t),r=await receipt(root),alternateId='youtube:NNnIGh9g6fA',alternateURL='https://ocw.mit.edu/courses/second/resources/lecture-12/';
  await save(root,'data/audits/courses/candidates.json',[rawRecord({title:'Lecture 2: Earlier topic',mediaEndpointChecks:[r]}),rawRecord({id:alternateId,canonicalUrl:'https://www.youtube.com/watch?v=NNnIGh9g6fA',parentCourse:'second-course',sourceUrl:alternateURL,title:'Lecture 12: Alternate source label'})]);
  const sourceCheck={url:'https://ocw.mit.edu/courses/test/',retrievedAt:date,sha256:sourceHash};
  await save(root,'data/audits/courses/course-register.json',['test-course','second-course'].map(id=>({id,title:'Fixture course',provider:'mit-ocw',url:sourceCheck.url,families:['neuroscience'],sourceCheck})));
  await save(root,'data/audits/courses/provider-register.json',[{id:'mit-ocw',name:'MIT OpenCourseWare',url:'https://ocw.mit.edu/',seedRetrieval:sourceCheck}]);
  await save(root,'data/audits/courses/alternate-review/alternate-mappings.json',{mappings:[{id:alternateId,alternateOf:`youtube:${videoId}`,status:'confirmed-equivalent',reason:'Fixture source equivalence, independent of the differently numbered source labels.',checkedAt:date,checker:'agent',checkSources:[sourceCheck]}],unresolved:[]});
  const first=await normalise({root}),second=await normalise({root});assert.deepEqual(first.report.outputHashes,second.report.outputHashes);
  assert.equal(second.records.length,2);assert.equal(second.report.counts.alternateUploads,1);assert.equal(second.report.counts.qualifiedAccessibleVideos,1);
  const course=second.courses.find(c=>c.id==='second-course');assert.deepEqual(course.resourceIds,[`youtube:${videoId}`]);
  assert.equal(course.sequence[0].sourceResourceId,alternateId);assert.equal(course.sequence[0].sourceUrl,alternateURL);assert.equal(course.sequence[0].lessonOrder,12);
});
