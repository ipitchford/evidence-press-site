import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {checkBuild,FREE_LIMITS,inspectMarkup} from '../scripts/check-build.mjs';

const base='http://localhost:4173';
async function temp(t){const root=await fs.mkdtemp(path.join(os.tmpdir(),'atlas-artifact-test-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));return root;}
async function save(root,file,text){const p=path.join(root,file);await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,typeof text==='string'||Buffer.isBuffer(text)?text:JSON.stringify(text));}
const html=(route,body)=>`<!doctype html><html><head><title>A useful methods page</title><meta name="description" content="A concrete route through behavioural research methods."><link rel="canonical" href="${base}${route}"><link rel="stylesheet" href="/assets/style.css"><script type="module" src="/assets/app.mjs"></script></head><body><main id="main"><h1>Study <em>methods</em></h1>${body}</main></body></html>`;
async function fixture(t){
  const root=await temp(t);
  const record={id:'youtube:ba-HMvDn_vU',title:'Research methods lecture',canonicalUrl:'https://www.youtube.com/watch?v=ba-HMvDn_vU',sourceUrl:'https://ocw.mit.edu/courses/source/',providerId:'mit-ocw',topics:['methods'],description:'An original account of a source-listed research methods lecture.',qualification:{status:'candidate'},withdrawn:false,reuse:{exportAllowed:true,attribution:'MIT OpenCourseWare',sourceLicence:'Source terms apply',annotationLicence:'Original navigation'}};
  const exported={id:record.id,title:record.title,url:record.canonicalUrl,sourceUrl:record.sourceUrl,providerId:record.providerId,topics:record.topics,description:record.description,attribution:record.reuse.attribution,licence:record.reuse.sourceLicence,annotationLicence:record.reuse.annotationLicence};
  await save(root,'data/catalogue.jsonl',JSON.stringify(record)+'\n');
  await save(root,'dist/index.html',html('/',`<a href="/lesson/?q=one&amp;x=2#part%3Aone">Next</a><a href="${base}/lesson/#part:one">Absolute local</a><a href="https://elsewhere.example/missing#unknown">External</a><img src="/mark.svg#shape">`));
  await save(root,'dist/lesson/index.html',html('/lesson/','<h2 id="part:one">An example</h2><a href="#main">Top of content</a>'));
  await save(root,'dist/mark.svg','<svg xmlns="http://www.w3.org/2000/svg"><path id="shape" d="M0 0"/></svg>');
  await save(root,'dist/assets/style.css','@font-face{font-family:Example;src:url("/font.woff2")}');
  await save(root,'dist/font.woff2',Buffer.from([1,2,3]));
  await save(root,'dist/assets/app.mjs',"import './helper.mjs';\n");
  await save(root,'dist/assets/helper.mjs','export const ready=true;\n');
  await save(root,'dist/data/index.json',{version:1,records:[{id:record.id,url:'/lesson/',kind:'video'}]});
  await save(root,'dist/exports/catalogue.json',{boundary:'Source-only factual metadata and original annotations.',records:[exported]});
  await save(root,'dist/sitemap.xml',`<?xml version="1.0"?><urlset><url><loc>${base}/</loc></url><url><loc>${base}/lesson/</loc></url></urlset>`);
  return {root,record,exported};
}
const codes=r=>new Set(r.errors.map(x=>x.code));

test('static audit resolves relative/root/absolute links and encoded HTML/SVG fragments without external requests',async t=>{
  const {root}=await fixture(t),r=await checkBuild({root,write:false});
  assert.equal(r.passed,true,JSON.stringify(r.errors));assert.equal(r.counts.htmlPages,2);assert.equal(r.counts.publicCatalogueRecords,1);
  assert(r.counts.fragmentChecks>=4);assert(r.counts.externalReferencesSkipped>0);assert.equal(r.sitemapPages,2);assert.match(r.manifestSha256,/^[a-f0-9]{64}$/);
  assert(r.warnings.some(x=>x.code==='local-canonical'));
});

test('markup parser ignores script pseudo-tags and respects quoted angle brackets',()=>{
  const doc=inspectMarkup('<title>Research &amp; methods</title><h1>A <em>topic</em></h1><a title="x > y" href="/a/?q=1&amp;b=2#anchor">Go</a><script type="application/json">{"title":"<h1>not a heading</h1>"}</script>');
  assert.deepEqual(doc.h1,['A topic']);assert.deepEqual(doc.titles,['Research & methods']);assert.equal(doc.refs[0].value,'/a/?q=1&b=2#anchor');assert.equal(doc.jsonScripts.length,1);
});

test('resource player fallback survives replacement of the whole nested player container',async t=>{
  const {root,record}=await fixture(t),route='/resources/youtube-ba-HMvDn_vU/';
  const player=`<div data-player><div class="placeholder"><button>Load player</button><p><a href="${record.canonicalUrl}">Watch at source</a></p></div></div>`;
  const permanent=`<p><a href="${record.canonicalUrl}"><span>Watch</span> at source ↗</a></p>`;
  const config=`<script type="application/json" id="player-data">${JSON.stringify({canonicalUrl:record.canonicalUrl})}</script>`;
  await save(root,'dist'+route+'index.html',html(route,`<article>${player}${permanent}${config}</article>`));
  const sitemap=await fs.readFile(path.join(root,'dist/sitemap.xml'),'utf8');await save(root,'dist/sitemap.xml',sitemap.replace('</urlset>',`<url><loc>${base}${route}</loc></url></urlset>`));
  const pass=await checkBuild({root,write:false});assert.equal(pass.passed,true,JSON.stringify(pass.errors));assert.equal(pass.counts.resourcePlayerPages,1);assert.equal(pass.counts.permanentSourceFallbacks,1);
  await save(root,'dist'+route+'index.html',html(route,`<article>${player}${config}</article>`));
  const fail=await checkBuild({root,write:false});assert(codes(fail).has('permanent-source-fallback'));assert.equal(fail.counts.permanentSourceFallbacks,0);
});

test('an unrelated destination or hidden source link cannot substitute for the permanent fallback',async t=>{
  const {root,record}=await fixture(t),route='/resources/youtube-ba-HMvDn_vU/';
  const source=`<a href="${record.canonicalUrl}">Watch at source</a>`;
  const config=`<script type="application/json" id="player-data">${JSON.stringify({canonicalUrl:record.canonicalUrl})}</script>`;
  const sitemap=await fs.readFile(path.join(root,'dist/sitemap.xml'),'utf8');await save(root,'dist/sitemap.xml',sitemap.replace('</urlset>',`<url><loc>${base}${route}</loc></url></urlset>`));
  for(const fallback of [`<a href="https://elsewhere.example/">Watch at source</a>`,`<div hidden>${source}</div>`,`<div inert>${source}</div>`,`<template>${source}</template>`,`<noscript>${source}</noscript>`,`<p style="display:none">${source}</p>`,`<a href="${record.canonicalUrl}">receipt-123</a>`]){
    await save(root,'dist'+route+'index.html',html(route,`<div data-player><button>Load player</button></div>${fallback}${config}`));
    const result=await checkBuild({root,write:false});assert(codes(result).has('permanent-source-fallback'),fallback);
  }
});

test('missing targets, missing fragment IDs and missing module assets fail separately',async t=>{
  const {root}=await fixture(t);
  await save(root,'dist/index.html',html('/','<a href="/does-not-exist/">Bad</a><a href="/lesson/#absent">Wrong anchor</a>'));
  await fs.rm(path.join(root,'dist/assets/helper.mjs'));
  const r=await checkBuild({root,write:false});assert.equal(r.passed,false);assert(codes(r).has('missing-fragment'));assert(r.errors.filter(x=>x.code==='missing-local-target').length>=2);
});

test('metadata, canonical and sitemap mismatches are real release errors',async t=>{
  const {root}=await fixture(t);
  await save(root,'dist/lesson/index.html','<html><head><title>TODO</title><meta name="description" content="short"><link rel="canonical" href="https://wrong.example/lesson/"></head><body><h1>Topic</h1><h1>Duplicate</h1></body></html>');
  await save(root,'dist/sitemap.xml',`<urlset><url><loc>${base}/</loc></url><url><loc>${base}/</loc></url><url><loc>${base}/unknown/</loc></url></urlset>`);
  const r=await checkBuild({root,write:false}),c=codes(r);for(const code of ['page-title','page-description','page-h1','canonical-target','sitemap-duplicate','sitemap-extra'])assert(c.has(code),code);
});

test('public export rejects duplicate IDs, API fields and values changed by an API overlay',async t=>{
  const {root,exported}=await fixture(t);
  await save(root,'dist/exports/catalogue.json',{records:[{...exported,title:'A platform-derived replacement',durationSeconds:42,apiMetadata:{kind:'youtube#videoListResponse'}},exported]});
  const r=await checkBuild({root,write:false}),c=codes(r);for(const code of ['catalogue-id','catalogue-forbidden-field','catalogue-source-mismatch','raw-youtube-payload'])assert(c.has(code),code);
});

test('source-only export excludes alternates and explicit identity, substance or overlap holds',async t=>{
  const {root,record}=await fixture(t);
  for(const change of [{alternateOf:'youtube:NNnIGh9g6fA'},{qualification:{status:'candidate',distinctnessResolved:false}},{qualification:{status:'candidate',sourceIdentityResolved:false}},{qualification:{status:'candidate',substanceResolved:false}}]) {
    await save(root,'data/catalogue.jsonl',JSON.stringify({...record,...change})+'\n');
    const r=await checkBuild({root,write:false});assert(codes(r).has('catalogue-not-source-permitted'));
  }
});

test('private paths, synthetic markers and credential values fail without echoing the detected value',async t=>{
  const {root}=await fixture(t);const secret='AIza'+'A'.repeat(35);
  await save(root,'dist/leak.txt',`/Users/example/private/file.json\nsynthetic-performance:42\n${secret}`);
  await save(root,'dist/index.html',html('/',`<a href="/${secret}/">A broken secret-bearing path</a>`));
  const r=await checkBuild({root,write:false}),c=codes(r);for(const code of ['private-path','synthetic-fixture','credential-key'])assert(c.has(code),code);
  assert(!JSON.stringify(r.errors).includes(secret));
});

test('a private receipt suffix in an otherwise valid page is blocked',async t=>{
  const {root}=await fixture(t);
  await save(root,'dist/lesson/index.html',html('/lesson/','<h2 id="part:one">An example</h2><p>Selected transcript excerpts only. Individual receipt: data/audits/source/core-checks/lesson-14.json</p>'));
  const r=await checkBuild({root,write:false});assert(codes(r).has('private-path'));assert.equal(r.errors.length,1);
});

test('field-masked API payloads and JSON-escaped secrets are detected structurally',async t=>{
  const {root}=await fixture(t);
  await save(root,'dist/masked-response.json',{items:[{id:'ba-HMvDn_vU',snippet:{title:'A platform response'},contentDetails:{duration:'PT42M'}}]});
  await save(root,'dist/escaped.json','{"\\u0072efresh_token":"hidden-value"}');
  const r=await checkBuild({root,write:false}),c=codes(r);assert(c.has('raw-youtube-payload'));assert(c.has('credential-field'));
});

test('free static-file limits are checked and a missing build produces a saved actionable failure',async t=>{
  const {root}=await fixture(t),r=await checkBuild({root,write:false,limits:{...FREE_LIMITS,maxFiles:2,maxAssetBytes:100}});
  assert(codes(r).has('free-file-limit'));assert(codes(r).has('free-asset-limit'));
  const empty=await temp(t),missing=await checkBuild({root:empty});assert.equal(missing.passed,false);assert(codes(missing).has('missing-build'));
  assert.equal(JSON.parse(await fs.readFile(path.join(empty,'evaluation/artifact-check.json'),'utf8')).passed,false);
});
