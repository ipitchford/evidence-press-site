import test from 'node:test';
import assert from 'node:assert/strict';
import {isDiscoverable,isQualified,resolveAlternateId} from '../src/model.mjs';
import {resolveResourceAliases} from '../scripts/data.mjs';
import {buildIndex} from '../scripts/discovery.mjs';

const primary={id:'youtube:ba-HMvDn_vU',title:'Primary source',canonicalUrl:'https://www.youtube.com/watch?v=ba-HMvDn_vU',sourceUrl:'https://official.example/primary',providerId:'institution',topics:[],tags:[],description:'Source context',descriptionCheck:{status:'unchecked'},selection:{reason:'Useful context',basis:'institutional-collection'},qualification:{status:'qualified'},availability:{status:'accessible',method:'official-media-range',checkedAt:'2026-11-07',evidence:['source']}};
const alternate={...primary,id:'youtube:NNnIGh9g6fA',alternateOf:primary.id};
const held={...primary,id:'youtube:phbw9r1iUDI',qualification:{status:'qualified',distinctnessResolved:false}};

test('alias resolution follows confirmed chains and rejects cycles or missing parents',()=>{
  const next={...alternate,id:'youtube:5XHGEOOYnzw',alternateOf:alternate.id};
  assert.equal(resolveAlternateId(next.id,[primary,alternate,next]),primary.id);
  assert.throws(()=>resolveAlternateId(alternate.id,[alternate]),/Missing alternate/);
  assert.throws(()=>resolveAlternateId(alternate.id,[alternate,{...primary,alternateOf:alternate.id}]),/cycle/);
});

test('in-memory guide, path and course aliases preserve original IDs without editing source documents',()=>{
  const data={records:[primary,alternate,held],courses:[{id:'course',resourceIds:[alternate.id,primary.id],sequence:[{resourceId:alternate.id,sourceUrl:'https://official.example/alternate',lessonOrder:7}]}],guides:[{slug:'guide',startingResourceId:alternate.id,resources:[{id:alternate.id,reason:'Original editorial reason'}]}],paths:[{slug:'path',steps:[{resourceId:alternate.id,task:'Original exercise'}]}]};
  const before=structuredClone(data),out=resolveResourceAliases(data);assert.deepEqual(data,before);
  assert.equal(out.guides[0].startingResourceId,primary.id);assert.equal(out.guides[0].startingSourceResourceId,alternate.id);
  assert.equal(out.guides[0].resources[0].id,primary.id);assert.equal(out.guides[0].resources[0].sourceResourceId,alternate.id);
  assert.equal(out.paths[0].steps[0].resourceId,primary.id);assert.equal(out.paths[0].steps[0].sourceResourceId,alternate.id);
  assert.deepEqual(out.courses[0].resourceIds,[primary.id]);assert.equal(out.courses[0].sequence[0].lessonOrder,7);assert.equal(out.courses[0].sequence[0].sourceResourceId,alternate.id);
  assert.deepEqual(out.resourceAliases,{[alternate.id]:primary.id});
});

test('held and alternate uploads remain outside discovery and qualified counts even with access evidence',()=>{
  assert.equal(isQualified(primary),true);assert.equal(isDiscoverable(primary),true);
  for(const row of [alternate,held]){assert.equal(isQualified(row),false);assert.equal(isDiscoverable(row),false);}
  const index=buildIndex({records:[primary,alternate,held],sources:[],taxonomy:{families:[]},courses:[],guides:[],paths:[]});
  assert.deepEqual(index.map(x=>x.id),[primary.id]);
});
