import test from 'node:test';
import assert from 'node:assert/strict';
import {canonicalVideo,positiveMentions,isQualified,viewingTime,safeURL,markdownLink} from '../src/model.mjs';
import {emptyState,validateState,mergeState,toggleItem} from '../src/state.mjs';
import {matchesFilters,search} from '../src/search.mjs';
import {challenge,authorisedScope} from '../scripts/youtube-oauth.mjs';

test('canonical identifiers collapse tracking and embed variants, not distinct lectures',()=>{
  for(const url of ['https://youtu.be/ba-HMvDn_vU?t=10','https://www.youtube.com/embed/ba-HMvDn_vU','https://www.youtube.com/watch?v=ba-HMvDn_vU&list=ABC'])assert.equal(canonicalVideo(url).id,'youtube:ba-HMvDn_vU');
  assert.notEqual(canonicalVideo('https://youtu.be/ba-HMvDn_vU').id,canonicalVideo('https://youtu.be/NNnIGh9g6fA').id);
  assert.throws(()=>canonicalVideo('javascript:alert(1)'));assert.equal(safeURL('https://name:secret@example.com/'),null);
});
test('criticism, neutral references and self-promotion do not become independent recommendations',()=>{
  const result=positiveMentions([{stance:'rec',author:'a',selfPromotion:true,independenceChecked:true},{stance:'strong_rec',author:'b',selfPromotion:false,independenceChecked:true},{stance:'neutral',author:'c'},{stance:'criticism',author:'d'},{stance:'rec',author:'e'}]);
  assert.deepEqual(result,{positive:3,independent:1,uniqueContributors:3,retained:5});
});
test('a successful source page alone cannot qualify a video',()=>{
  const r={qualification:{status:'qualified'},availability:{status:'accessible',method:'source-page-only',checkedAt:'2026-11-07',evidence:['one']}};
  assert.equal(isQualified(r),false);r.availability.method='official-media-range';assert.equal(isQualified(r),true);r.alternateOf='youtube:other';assert.equal(isQualified(r),false);
});
test('viewing totals omit unverified durations and expose missingness',()=>assert.deepEqual(viewingTime([{durationSeconds:3600,durationEvidence:['x']},{durationSeconds:1000,durationEvidence:[]},{durationSeconds:null}]),{seconds:3600,known:1,unknown:2}));
test('one hour is a long video; unknowns stay distinct',()=>{assert(matchesFilters({durationSeconds:3600},{duration:'long'}));assert(!matchesFilters({durationSeconds:null},{duration:'long'}));assert(matchesFilters({durationSeconds:null},{duration:'unknown'}));});
test('downloaded reading lists cannot change their destination through a source title',()=>{
  assert.equal(markdownLink('A [quoted] title','https://example.org/a(b)'), '[A \\[quoted\\] title](https://example.org/a%28b%29)');
  assert.equal(markdownLink('Unsafe source','javascript:alert(1)'),'Unsafe source');
});
test('import rejects malformed library data, ignores extra properties and never marks opening as watched',()=>{
  const state=toggleItem(emptyState(),'opened','youtube:ba-HMvDn_vU');assert.equal(state.watched.length,0);
  assert.throws(()=>validateState({...state,watched:'everything'}));assert.throws(()=>validateState({...state,pathProgress:JSON.parse('{"__proto__":["x"]}')}));
  const merged=mergeState(state,{...emptyState(),watchLater:['youtube:ba-HMvDn_vU']});assert.equal(merged.opened.length,1);assert.equal(merged.watchLater.length,1);assert.equal(merged.watched.length,0);
});
test('search handles ordinary wording and source diversity without inventing records',()=>{
  const rows=[{id:'a',title:'Neuroscience introduction',providerId:'p',topics:['neuroscience'],description:'neurons'},{id:'b',title:'Brain methods',providerId:'q',topics:['methods']},{id:'c',title:'Administrative meeting',providerId:'p'}];
  assert.deepEqual(new Set(search(rows,'brain',{synonyms:true}).map(r=>r.id)),new Set(['a','b']));assert.equal(search(rows,'brain',{synonyms:true,hidden:['b']}).length,1);assert.deepEqual(search(rows,'brain').map(r=>r.id),['b']);
});
test('broad topic labels do not outrank a resource about the requested concept',()=>{
  const rows=[{id:'target',title:'Retrieval practice and lasting learning',description:'Compare recall attempts with later retention.',terms:['retrieval practice'],providerId:'a'},{id:'unrelated',title:'Mindfulness practice',description:'An introduction to mindful breathing.',topicTerms:['memory','retrieval practice'],providerId:'b'}];
  assert.equal(search(rows,'retrieval practice')[0].id,'target');
  assert(!search([{id:'age',title:'Communication in a digital age'}],'ageing cognition').some(r=>r.id==='age'));
});
test('OAuth uses PKCE S256 and does not mistake upload-only scope for read permission',()=>{
  assert.equal(challenge('dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk'),'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM');
  assert(authorisedScope('https://www.googleapis.com/auth/youtube.readonly'));assert(!authorisedScope('https://www.googleapis.com/auth/youtube.upload'));
});
